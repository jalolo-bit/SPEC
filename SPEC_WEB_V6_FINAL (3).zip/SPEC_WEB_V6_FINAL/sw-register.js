/* M-15 PWA — Service Worker registration
 *
 * Registra sw.js como service worker para habilitar:
 *   - Instalación como app (manifest.json)
 *   - Funcionamiento offline (cache de recursos core)
 *
 * Solo se registra en contextos seguros (https o localhost) — requisito del SW spec.
 * Falla silenciosamente si el navegador no soporta SW o el contexto no es seguro.
 */
if ('serviceWorker' in navigator) {
  var isSecureContext = (location.protocol === 'https:' ||
                        location.hostname === 'localhost' ||
                        location.hostname === '127.0.0.1' ||
                        location.hostname === '0.0.0.0');
  if (isSecureContext) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('sw.js').then(function (reg) {
        console.info('SPEC Web v6.0 — SW registrado con scope:', reg.scope);
      }).catch(function (err) {
        console.warn('SPEC Web v6.0 — SW registro fallido (no crítico para la funcionalidad principal):', err);
      });
    });
  } else {
    console.info('SPEC Web v6.0 — SW no registrado: contexto no seguro (requiere https o localhost).');
  }
} else {
  console.info('SPEC Web v6.0 — Navegador sin soporte ServiceWorker; PWA no disponible.');
}
