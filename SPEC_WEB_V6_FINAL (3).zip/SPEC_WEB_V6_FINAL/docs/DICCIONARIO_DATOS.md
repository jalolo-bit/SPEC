# DICCIONARIO DE DATOS - SPEC V0.47.3

> Lista completa de todas las columnas de las 14 tablas del sistema. Para cada columna: tabla origen, tipo, descripción y regla de cálculo.

## Convenciones
- **type text**: cadena
- **type number**: número decimal
- **Int64.Type**: entero
- **type logical**: booleano
- **type date**: fecha sin hora
- **type nullable ...**: admite null

---

## T1. 01_HorasSinVolumen (117 filas × 25 columnas)

Origen: Power Query `01_HorasSinVolumen`. Datos de horas trabajadas sin volumen productivo (HR-side).

| # | Columna | Tipo | Origen / Regla |
|---|---|---|---|
| 1 | Site name | text | fx_TransformaHoras → fx_NormalizaTexto |
| 2 | Department | text | fx_TransformaHoras → fx_NormalizaTexto |
| 3 | Activity | text | fx_TransformaHoras → fx_NormalizaTexto |
| 4 | Subactivity | text | fx_TransformaHoras → fx_NormalizaTexto |
| 5 | FechaOriginal | text/datetime | Columna "Date" del archivo (renombrada) |
| 6 | HR Task | text | fx_TransformaHoras → fx_NormalizaTexto |
| 7 | WMSLoginOriginal | text | Columna "WMS Login" del archivo (renombrada) |
| 8 | Name | text | fx_TransformaHoras → fx_NormalizaTexto |
| 9 | HorasSinVolumen | number | Columna "Hours without volume" → Number.From(_) |
| 10 | ArchivoOrigen | text | fx_TransformaHoras añade el nombre del archivo |
| 11 | FilaOrigen | Int64 | fx_TransformaHoras añade AddIndexColumn(2, 1) |
| 12 | Fecha | date | fx_Fecha(FechaOriginal) |
| 13 | LoginOriginal | text | fx_NormalizaLogin(Valor).LoginOriginal |
| 14 | LoginOriginalLimpio | text | fx_NormalizaLogin(Valor).LoginOriginalLimpio |
| 15 | LoginCanonico | text | fx_NormalizaLogin(Valor).LoginCanonico |
| 16 | IdNumerico | text | fx_NormalizaLogin(Valor).IdNumerico (literal) |
| 17 | IdNumericoLiteral | text | fx_NormalizaLogin(Valor).IdNumericoLiteral |
| 18 | IdNumericoNormalizado | text | fx_NormalizaLogin(Valor).IdNumericoNormalizado |
| 19 | PrefijoLogin | text | fx_NormalizaLogin(Valor).Prefijo |
| 20 | RegistroValido | logical | Fecha≠null AND LoginCanonico≠null AND Activity≠null AND HorasSinVolumen≠null AND HorasSinVolumen>0 |
| 21 | MotivoInvalido | text? | FECHA INVALIDA / LOGIN VACIO / ACTIVITY VACIA / HORAS NO NUMERICAS / HORAS CERO O NEGATIVAS / null |
| 22 | ClaveNatural | text | Site name \| yyyy-MM-dd \| LoginCanonico \| Department \| Activity \| Subactivity \| HR Task \| HorasSinVolumen |
| 23 | RepeticionesClave | Int64 | Conteo de filas con la misma ClaveNatural |
| 24 | PosibleDuplicado | logical | RepeticionesClave > 1 |
| 25 | IdRegistroHoras | Int64 | AddIndexColumn(1, 1) — identificador único |

---

## T2. 02_VolumenDetalle (744 filas × 24 columnas)

Origen: Power Query `02_VolumenDetalle`. Detalle de volumen WMS (WMS-side).

| # | Columna | Tipo | Origen / Regla |
|---|---|---|---|
| 1 | FechaOriginal | text/datetime | Columna "DATE" del archivo (renombrada) |
| 2 | SAP_CODE | text | fx_NormalizaTexto |
| 3 | CUSTOMER | text | fx_NormalizaTexto |
| 4 | WMS_TASK | text | fx_NormalizaTexto |
| 5 | WMSLoginOriginal | text | Columna "WMS_LOGIN" del archivo (renombrada) |
| 6 | USER_NAME | text | fx_NormalizaTexto |
| 7 | VolumenNeto | number | Columna "WMS_UOM" del archivo → Number.From(_) |
| 8 | ArchivoOrigen | text | fx_TransformaVolumen |
| 9 | FilaOrigen | Int64 | fx_TransformaVolumen |
| 10 | Fecha | date | fx_Fecha(FechaOriginal) |
| 11-19 | (mismas columnas de login que T1, sin sufijo) | | fx_NormalizaLogin(WMSLoginOriginal) |
| 20 | VolumenPositivo | number | VolumenNeto > 0 ? VolumenNeto : 0 |
| 21 | VolumenNegativo | number | VolumenNeto < 0 ? VolumenNeto : 0 |
| 22 | EsVolumenCero | logical | VolumenNeto = 0 |
| 23 | RegistroValido | logical | Fecha≠null AND VolumenNeto≠null AND WMS_TASK≠null |
| 24 | ClaveNatural, RepeticionesClave, PosibleDuplicado | | Igual que T1 con sus columnas |

> **Nota:** La tabla tiene 24 columnas (sin IdRegistroHoras ni MotivoInvalido).

---

## T3. 03_VolumenPersonaDia (213 filas × 13 columnas)

Origen: Power Query `03_VolumenPersonaDia`. Agrupación de volumen por persona y día.

| # | Columna | Tipo | Origen / Regla |
|---|---|---|---|
| 1 | Fecha | date | Clave de grupo de 02_VolumenDetalle |
| 2 | LoginCanonico | text | Clave de grupo de 02 |
| 3 | VolumenTotalPositivo | number | SUM(VolumenPositivo) en grupo |
| 4 | VolumenTotalNegativo | number | SUM(VolumenNegativo) |
| 5 | VolumenTotalNeto | number | SUM(VolumenNeto) (con List.RemoveNulls) |
| 6 | RegistrosVolumen | Int64 | RowCount del grupo |
| 7 | RegistrosCero | Int64 | Count where EsVolumenCero = true |
| 8 | RegistrosNegativos | Int64 | Count where VolumenNeto <> null AND < 0 |
| 9 | NumeroTareasWMS | Int64 | Count distinct WMS_TASK |
| 10 | TareasWMS | text | JOIN sorted distinct WMS_TASK con " \| " |
| 11 | ClientesWMS | text | JOIN sorted distinct CUSTOMER |
| 12 | SAPsWMS | text | JOIN sorted distinct SAP_CODE |
| 13 | TieneDuplicadosVolumen | logical | AnyTrue(PosibleDuplicado) |

---

## T4. 05_VolumenIdNumericoDia (197 filas × 7 columnas)

Origen: Power Query `05_VolumenIdNumericoDia`. Agrupación de volumen por IdNumerico normalizado.

| # | Columna | Tipo | Origen / Regla |
|---|---|---|---|
| 1 | Fecha | date | Clave de grupo de 02 |
| 2 | IdNumericoNormalizado | text | Clave de grupo de 02 |
| 3 | VolumenIdPositivo | number | SUM(VolumenPositivo) |
| 4 | NumeroLoginsDistintos | Int64 | Count distinct LoginCanonico |
| 5 | LoginsMismoNumero | text | JOIN sorted distinct LoginCanonico |
| 6 | PrefijosMismoNumero | text | JOIN sorted distinct PrefijoLogin |
| 7 | EsAmbiguoIdNumerico | logical | NumeroLoginsDistintos > 1 |

> **Nota:** Tiene una 8ª columna oculta `LoginsDistintosLista` de tipo `list` (no se exporta a la hoja pero se conserva en M).

---

## T5. 07_Conciliacion (117 filas × 65 columnas)

Origen: Power Query `07_Conciliacion`. **Tabla central del sistema.** Una fila por registro de horas válido.

### Columnas heredadas de 01_HorasSinVolumen (1-25):
IdRegistroHoras, Fecha, Name, WMSLoginOriginal, FechaOriginal, LoginOriginal, LoginCanonico, IdNumerico, IdNumericoLiteral, IdNumericoNormalizado, PrefijoLogin, Site name, Department, LoginOriginalLimpio, Activity, Subactivity, HR Task, HorasSinVolumen, HorasTotalesPersonaDia, RegistroValido, MotivoInvalido, NumeroActividadesHR, RepeticionesClave, NumeroHRTaskDistintas, HRTaskDistintas

### Columnas de 03_VolumenPersonaDia (26-36):
VolumenMismaActividadPositivo, VolumenMismaActividadNegativo, VolumenMismaActividadNeto, TareasWMSMismaActividad, TasksSPECUnaMismaActividad (de 14), VolumenTotalPositivo, VolumenTotalNegativo, VolumenTotalNeto, RegistrosVolumen, TieneDuplicadosVolumen, RegistrosCero, RegistrosNegativos

### Columnas de 05_VolumenIdNumericoDia (37-41):
VolumenMismoNumeroPositivo, NumeroLoginsDistintos, LoginsMismoNumero, PrefijosMismoNumero, EsAmbiguoIdNumerico

### Columnas de 10_VolumenSinHorasPersonaDia (42-46):
VolumenSinHorasPersonaDia, NumeroRegistrosVSH, ActividadesVSH, SubactividadesVSH, TareasVSH

### Columnas de 15_VolumenSinHorasPersonaDiaActividadSPEC (47-48):
VolumenSinHorasMismaActividad, TareasVSHMismaActividad

### Columnas calculadas (49-65):
| # | Columna | Tipo | Regla |
|---|---|---|---|
| 49 | VolumenOtrasActividadesPositivo | number | MAX(0, VolumenTotalPositivo - VolumenMismaActividadPositivo) |
| 50 | NumeroTareasWMS | Int64 | (de 03) Count distinct WMS_TASK |
| 51 | TareasWMS | text | (de 03) JOIN distinct WMS_TASK |
| 52 | ClientesWMS | text | (de 03) JOIN distinct CUSTOMER |
| 53 | SAPsWMS | text | (de 03) JOIN distinct SAP_CODE |
| 54 | Clasificacion | text | Ver REGLAS_NEGOCIO.md R13 |
| 55 | NivelConfianza | text | ALTA / MEDIA / NO DETERMINABLE |
| 56 | Materialidad | text | MICRO/BAJA/MEDIA/ALTA/CRITICA |
| 57 | Evidencia | text | Concatenación de frases de evidencia con "; " |
| 58 | Explicacion | text | Una frase por cada Clasificacion |
| 59 | AccionRecomendada | text | Acción recomendada por cada Clasificacion |
| 60 | ArchivoOrigen | text | (de 01) |
| 61 | FilaOrigen | Int64 | (de 01) |
| 62 | ClaveNatural | text | (de 01) |
| 63 | PosibleDuplicado | logical | (de 01) |
| 64-65 | (columnas extra de NumActHR join) | | |

---

## T6. 08_Validaciones (19 filas × 5 columnas)

Origen: Power Query `08_Validaciones`. KPIs de validación.

| # | Columna | Tipo | Descripción |
|---|---|---|---|
| 1 | Control | text | Nombre del control |
| 2 | ValorOrigen | any | Valor en origen (si aplica) |
| 3 | ValorResultado | any | Valor tras el procesado |
| 4 | Estado | text | OK / ERROR / REVISAR / INFORMATIVO |
| 5 | Detalle | text | Explicación |

**19 controles:** (ver REGLAS_NEGOCIO.md R22 y el código M q20)

---

## T7. 09_VolumenSinHorasDetalle (246 filas × 23 columnas)

Origen: Power Query `09_VolumenSinHorasDetalle`. Detalle de volumen sin horas imputadas.

Mismas columnas que T1 pero con renombrados con sufijo VSH (FechaOriginalVSH, WMSLoginOriginalVSH, VolumenSinHoras, HRTaskVSH, IdNumericoLiteralVSH, IdNumericoNormalizadoVSH, PrefijoLoginVSH, RegistroValidoVSH, ClaveNaturalVSH, RepeticionesVSH, PosibleDuplicadoVSH). La columna IdNumerico y LoginCanonico NO llevan sufijo.

---

## T8. 10_VolumenSinHorasPersonaDia (84 filas × 8 columnas)

Origen: Power Query `10_VolumenSinHorasPersonaDia`.

| # | Columna | Tipo | Origen / Regla |
|---|---|---|---|
| 1 | Fecha | date | Clave de grupo de 09 |
| 2 | LoginCanonico | text | Clave de grupo de 09 |
| 3 | VolumenSinHorasPersonaDia | number | SUM(VolumenSinHoras) |
| 4 | NumeroRegistrosVSH | Int64 | RowCount |
| 5 | ActividadesVSH | text | JOIN distinct Activity |
| 6 | SubactividadesVSH | text | JOIN distinct Subactivity |
| 7 | TareasVSH | text | JOIN distinct HRTaskVSH |
| 8 | TieneDuplicadosVSH | logical | AnyTrue(PosibleDuplicadoVSH) |

---

## T9. 12_MapeoActividadSPEC (135 filas × 14 columnas)

Origen: Power Query `12_MapeoActividadSPEC`. Catálogo de mapeo agrupado.

| # | Columna | Tipo | Origen / Regla |
|---|---|---|---|
| 1 | SAP_CODE | text | Clave de grupo de Mapping |
| 2 | CUSTOMER | text | Clave de grupo |
| 3 | TASK_WMS | text | Clave de grupo |
| 4 | NumeroActividadesSPEC | Int64 | Count distinct ACTIVITY |
| 5 | ActividadesSPECPosibles | text | JOIN sorted distinct ACTIVITY con " \| " |
| 6 | ActividadSPEC | text? | Si solo 1 → valor, si no null |
| 7 | NumeroTasksSPEC | Int64 | Count distinct TASK_SPEC |
| 8 | TasksSPECPosibles | text | JOIN sorted distinct TASK_SPEC |
| 9 | TasksSPEC | text | JOIN sorted distinct TASK_SPEC (igual que TasksSPECPosibles) |
| 10 | DepartamentosSPEC | text | JOIN sorted distinct DEPARTMENT |
| 11 | SubactividadesSPEC | text | JOIN sorted distinct SUB_ACTIVITY |
| 12 | WMS_DCs | text | JOIN sorted distinct WMS_DC |
| 13 | TieneMultipleWMS_DC | logical | Count distinct WMS_DC > 1 |
| 14 | EstadoMapeoSPEC | text | SIN TASK_SPEC / UNICO / AMBIGUO |

---

## T10. 13_VolumenMapeadoSPEC (744 filas × 36 columnas)

Origen: Power Query `13_VolumenMapeadoSPEC`. 02 + JOIN con 12.

24 columnas heredadas de 02 + 11 columnas heredadas de 12 + 1 calculada:

| 36 | EstadoMapeoFinal | text | EstadoMapeoSPEC si no null, si no "SIN MAPEO" |

---

## T11. 14_VolumenPersonaDiaActividadSPEC (311 filas × 8 columnas)

Origen: Power Query `14_VolumenPersonaDiaActividadSPEC`.

| # | Columna | Tipo | Origen / Regla |
|---|---|---|---|
| 1 | Fecha | date | Clave de grupo de 13 (con EstadoMapeoFinal=UNICO) |
| 2 | LoginCanonico | text | Clave de grupo |
| 3 | ActividadSPEC | text | Clave de grupo |
| 4 | VolumenMismaActivitySPECPositivo | number | SUM(VolumenPositivo) |
| 5 | VolumenMismaActivitySPECNegativo | number | SUM(VolumenNegativo) |
| 6 | VolumenMismaActivitySPECNeto | number | SUM(VolumenNeto) |
| 7 | TareasWMSMismaActivitySPEC | text | JOIN distinct WMS_TASK |
| 8 | TasksSPECUna | text | JOIN distinct TasksSPEC |

---

## T12. 15_VolumenSinHorasPersonaDiaActividadSPEC (93 filas × 5 columnas)

Origen: Power Query `15_VolumenSinHorasPersonaDiaActividadSPEC`.

| # | Columna | Tipo | Origen / Regla |
|---|---|---|---|
| 1 | Fecha | date | Clave de grupo de 09 (con LoginCanonico y Activity no nulos) |
| 2 | LoginCanonico | text | Clave de grupo |
| 3 | Activity | text | Clave de grupo |
| 4 | VolumenSinHorasMismaActivitySPEC | number | SUM(VolumenSinHoras) |
| 5 | TareasVSHMismaActivitySPEC | text | JOIN distinct HRTaskVSH |

---

## T13. 16_ControlMapeoSPEC (14 filas × 3 columnas)

Origen: Power Query `16_ControlMapeoSPEC`.

| # | Columna | Tipo | Descripción |
|---|---|---|---|
| 1 | Control | text | Nombre del KPI |
| 2 | Valor | any | Valor calculado |
| 3 | Estado | text | OK / REVISAR / ERROR BLOQUEANTE / INFORMATIVO / SIN DATOS / DATOS INSUFICIENTES |

**14 KPIs:** (ver REGLAS_NEGOCIO.md R18)

---

## T14. REPORTE_CAMBIOS_HR (215 filas × 20 columnas)

Origen: VBA `GenerarReporteCambiosHR`. Reporte final de propuestas de cambio.

| # | Columna | Tipo | Origen / Regla |
|---|---|---|---|
| 1 | SECCION | text | Clasificación del reporte (1-7) |
| 2 | ID REGISTRO | Int64 | 01_HorasSinVolumen.IdRegistroHoras |
| 3 | FECHA | date | 01_HorasSinVolumen.Fecha |
| 4 | PERSONA | text | 01_HorasSinVolumen.Name |
| 5 | LOGIN HORAS | text | 01_HorasSinVolumen.LoginCanonico |
| 6 | HORAS SIN VOLUMEN | number | 01_HorasSinVolumen.HorasSinVolumen |
| 7 | MATERIALIDAD | text | CalcularMaterialidad(HorasSinVolumen) |
| 8 | HR TASK FICHADA | text | 01_HorasSinVolumen.HR Task |
| 9 | TASKSPEC SEGUN MAPPING | text | 13_VolumenMapeadoSPEC.TasksSPEC del match |
| 10 | VOLUMEN POSITIVO | number | 13_VolumenMapeadoSPEC.VolumenPositivo del match |
| 11 | WMS TASK CON VOLUMEN | text | 13_VolumenMapeadoSPEC.WMS_TASK del match |
| 12 | TIPO COINCIDENCIA | text | modo (LOGIN EXACTO / MISMO NUMERO, DISTINTO PREFIJO / REVISION MANUAL - ...) |
| 13 | LOGIN UTILIZADO EN VOLUMEN | text | 13_VolumenMapeadoSPEC.LoginCanonico del match |
| 14 | SAP_CODE | text | 13_VolumenMapeadoSPEC.SAP_CODE del match |
| 15 | CUSTOMER | text | 13_VolumenMapeadoSPEC.CUSTOMER del match |
| 16 | WMS_DC | text | 13_VolumenMapeadoSPEC.WMS_DCs del match |
| 17 | ARCHIVO ORIGEN | text | 13_VolumenMapeadoSPEC.ArchivoOrigen del match |
| 18 | FILA ORIGEN | text | 13_VolumenMapeadoSPEC.FilaOrigen del match |
| 19 | REQUIERE CAMBIO RRHH | text | SI / NO / REVISAR |
| 20 | OBSERVACION | text | Texto explicativo concatenado |

**Secciones del reporte (campo SECCION):**
1. "1. CAMBIO HR TASK PROPUESTO" (REQUIERE=SI)
2. "2. VARIAS TASKSPEC CON VOLUMEN" (REVISAR)
3. "3. HR TASK CORRECTA" (NO)
4. "4. SIN VOLUMEN" (REVISAR)
5. "5. WMS TASK SIN MAPPING" (REVISAR)
6. "6. REVISION MANUAL - MULTIPLES HR TASK" (REVISAR)
7. "7. REVISION MANUAL - AMBIGUEDAD ID NUMERICO" (REVISAR)

---

## Archivos de entrada - Estructura

### HORA SIN VOLUMEN.xlsx (Hoja "Export", 119 filas)

| # | Columna | Tipo deducido | Uso en SPEC |
|---|---|---|---|
| 1 | Site name | text | Usada en fx_TransformaHoras, normalizada |
| 2 | Department | text | Usada |
| 3 | Activity | text | Usada |
| 4 | Subactivity | text | Usada |
| 5 | Date | datetime/text | Renombrada a FechaOriginal → fx_Fecha |
| 6 | HR Task | text | Usada |
| 7 | WMS Login | text | Renombrada a WMSLoginOriginal → fx_NormalizaLogin |
| 8 | Name | text | Usada |
| 9 | Hours without volume | number/text | Renombrada a HorasSinVolumen |

### VOLUMEN.xlsx (Hoja "Export", 746 filas)

| # | Columna | Tipo | Uso |
|---|---|---|---|
| 1 | DATE | datetime/text | → FechaOriginal |
| 2 | SAP_CODE | text | Normalizada |
| 3 | CUSTOMER | text | Normalizada |
| 4 | WMS_TASK | text | Normalizada |
| 5 | WMS_LOGIN | text | → WMSLoginOriginal |
| 6 | USER_NAME | text | Normalizada |
| 7 | WMS_UOM | number | → VolumenNeto (renombrada) |

### VOL SIN HORAS.xlsx (Hoja "Export", 248 filas)

| # | Columna | Tipo | Uso |
|---|---|---|---|
| 1 | Site name | text | Normalizada |
| 2 | Department | text | Normalizada |
| 3 | Activity | text | Normalizada |
| 4 | Subactivity | text | Normalizada |
| 5 | Date | datetime/text | → FechaOriginalVSH |
| 6 | HR Task | text | → HRTaskVSH |
| 7 | WMS Login | text | → WMSLoginOriginalVSH |
| 8 | Name | text | Normalizada |
| 9 | Volume Without Hours | number/text | → VolumenSinHoras |

### Mapping.xlsx (3 hojas)

**Hoja "Mapping" (167 filas):** utilizada en 12_MapeoActividadSPEC.

| # | Columna | Tipo | Uso |
|---|---|---|---|
| 1 | SAP_CODE | text | Clave de mapeo |
| 2 | WMS_DC | text | Verificación multi-WMS_DC |
| 3 | CUSTOMER | text | Clave de mapeo |
| 4 | DEPARTMENT | text | DepartamentosSPEC (JOIN) |
| 5 | HIERARCHY | text | NO UTILIZADA en V0.47.3 |
| 6 | ACTIVITY | text | ActividadesSPEC (JOIN) |
| 7 | SUB_ACTIVITY | text | SubactividadesSPEC (JOIN) |
| 8 | TASK_WMS | text | Clave de mapeo (= WMS_TASK en volumen) |
| 9 | TASK_SPEC | text | TasksSPEC (JOIN) |
| 10 | PRODUCTIVE_TASK | logical | NO UTILIZADA en V0.47.3 |
| 11 | DIRECT_TASK | logical | NO UTILIZADA |
| 12 | GLOBAL_EFFICIENCY | logical | NO UTILIZADA |
| 13 | GLOBAL_PRODUCTIVITY | text/number | NO UTILIZADA |
| 14 | UOM | text | NO UTILIZADA |

**Hoja "Direct Budget" (111 filas):** NO UTILIZADA en V0.47.3. Contiene objetivos presupuestarios por SAP_CODE, CUSTOMER, TASK_WMS, TASK_SPEC (PROD_BUDGET_TARGET, INTERNAL_TARGET, EURO_PER_UNIT, EURO_PER_HOUR, DATE_START, DATE_END).

**Hoja "Indirect Budget" (86 filas):** NO UTILIZADA. Contiene costes indirectos por día de la semana (MONDAY-SUNDAY) por SAP_CODE, CUSTOMER, TASK_WMS, TASK_SPEC.
