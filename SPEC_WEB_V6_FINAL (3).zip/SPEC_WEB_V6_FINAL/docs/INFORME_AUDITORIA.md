# INFORME DE AUDITORÍA FORENSE - SPEC V0.47.3

> **Archivo auditado:** SPEC V0.47.3.xlsm  
> **Archivos de entrada:** HORA SIN VOLUMEN.xlsx, VOLUMEN.xlsx, VOL SIN HORAS.xlsx, Mapping.xlsx  
> **Versión del sistema:** V0.47.3 (Fecha: 2026-09-01)  
> **Autor declarado del xlsm:** LOPEZ LOPEZ Javier  
> **Cultura de cálculo declarada:** es-ES  
> **Auditor:** Equipo senior (auditor forense + VBA + Power Query + analista + arquitecto + dev HTML/CSS/JS + QA)

---

## 1. RESUMEN EJECUTIVO

SPEC V0.47.3 es un libro Excel creado por ID Logistics (autor: Javier López López) que concilia **horas trabajadas sin volumen productivo** (HR-side) contra **volumen WMS sin horas imputadas** (WMS-side), generando un **Reporte de cambios de RR.HH.** que propone correcciones a las fichadas de los empleados.

El sistema:

- **Lee 4 archivos de entrada** desde carpetas locales (3 exportaciones WMS + 1 catálogo de mapeo SPEC).
- **Ejecuta 20 consultas Power Query** (en lenguaje M) que cargan, limpian, normalizan y cruzan los datos.
- **Ejecuta 1 procedimiento VBA** (GenerarReporteCambiosHR) que recorre 13_VolumenMapeadoSPEC + 01_HorasSinVolumen + 07_Conciliacion y produce el reporte final con 20 columnas y hasta 7 secciones.
- **No contiene fórmulas en celdas, ni botones, ni validaciones de datos, ni formato condicional, ni dibujos.** El 100% de la lógica está en M + VBA.
- **No existen hojas ocultas ni muy ocultas**. Las 14 hojas son visibles.
- **13 de las 14 hojas** son salidas de Power Query (Tabla_DatosExternos_1X). La hoja restante (REPORTE_CAMBIOS_HR) es salida de VBA (tblReporteCambiosHR).

**Hallazgos clave de la auditoría:**

| Hallazgo | Severidad | Estado en V0.47.3 |
|---|---|---|
| H-05b (residual): ID 115 mantenía 2 filas en sección 2 con 1 sola TasksSPEC real porque se contaba el string AMBIGUO "20157 \| 20159" como una TasksSPEC distinta | BAJA | CORREGIDO |
| H-05 (bloqueante): Sección 2 clasificaba por `dFilas.Count > 1` (número de filas) en vez de TasksSPEC distintas. 51 filas mal clasificadas | BLOQUEANTE | CORREGIDO en V0.47.2 |
| H-01: Multi HR Task invisible en sección 4 | BAJA | CORREGIDO |
| H-02: Estado "ERROR BLOQUEANTE" en cobertura atribuible | INFO | Renombrado a "DATOS INSUFICIENTES - calidad de fuentes" |
| H-03: Discrepancias menores encargo vs artefactos (sin impacto) | INFO | Sin impacto |
| H-04: Cobertura limitada por calidad fuentes (sin impacto) | INFO | Sin impacto |

---

## 2. INVENTARIO COMPLETO

### 2.1 Hojas del libro (14, todas visibles)

| # | Nombre | sheetId | Archivo XML | Origen datos | Filas × Cols |
|---|---|---|---|---|---|
| 1 | 01_HorasSinVolumen | 2 | sheet1.xml | Power Query 01_HorasSinVolumen | 117 × 25 |
| 2 | 02_VolumenDetalle | 3 | sheet2.xml | Power Query 02_VolumenDetalle | 744 × 24 |
| 3 | 03_VolumenPersonaDia | 4 | sheet3.xml | Power Query 03_VolumenPersonaDia | 213 × 13 |
| 4 | 05_VolumenIdNumericoDia | 5 | sheet4.xml | Power Query 05_VolumenIdNumericoDia | 197 × 7 |
| 5 | 07_Conciliacion | 6 | sheet5.xml | Power Query 07_Conciliacion | 117 × 65 |
| 6 | 08_Validaciones | 7 | sheet6.xml | Power Query 08_Validaciones | 19 × 5 |
| 7 | 09_VolumenSinHorasDetalle | 8 | sheet7.xml | Power Query 09_VolumenSinHorasDetalle | 246 × 23 |
| 8 | 10_VolumenSinHorasPersonaDia | 9 | sheet8.xml | Power Query 10_VolumenSinHorasPersonaDia | 84 × 8 |
| 9 | 12_MapeoActividadSPEC | 10 | sheet9.xml | Power Query 12_MapeoActividadSPEC | 135 × 14 |
| 10 | 13_VolumenMapeadoSPEC | 11 | sheet10.xml | Power Query 13_VolumenMapeadoSPEC | 744 × 36 |
| 11 | 14_VolumenPersonaDiaActividadSP | 12 | sheet11.xml | Power Query 14_VolumenPersonaDiaActividadSPEC | 311 × 8 |
| 12 | 15_VolumenSinHorasPersonaDiaAct | 13 | sheet12.xml | Power Query 15_VolumenSinHorasPersonaDiaActividadSPEC | 93 × 5 |
| 13 | 16_ControlMapeoSPEC | 14 | sheet13.xml | Power Query 16_ControlMapeoSPEC | 14 × 3 |
| 14 | REPORTE_CAMBIOS_HR | 16 | sheet14.xml | VBA GenerarReporteCambiosHR | 215 × 20 |

**Clasificación de evidencia:** COMPROBADO (visible en workbook.xml + docProps/app.xml + tablas estructuradas).

### 2.2 Nombres definidos (13)

Todos los nombres definidos se llaman `DatosExternos_1` con scope local por hoja, y referencian el rango de cada tabla:

| scope | Hoja | Referencia |
|---|---|---|
| 0 | 01_HorasSinVolumen | '01_HorasSinVolumen'!$A$1:$Y$117 |
| 1 | 02_VolumenDetalle | '02_VolumenDetalle'!$A$1:$X$744 |
| 2 | 03_VolumenPersonaDia | '03_VolumenPersonaDia'!$A$1:$M$213 |
| 3 | 05_VolumenIdNumericoDia | '05_VolumenIdNumericoDia'!$A$1:$G$197 |
| 4 | 07_Conciliacion | '07_Conciliacion'!$A$1:$BM$117 |
| 5 | 08_Validaciones | '08_Validaciones'!$A$1:$E$19 |
| 6 | 09_VolumenSinHorasDetalle | '09_VolumenSinHorasDetalle'!$A$1:$W$246 |
| 7 | 10_VolumenSinHorasPersonaDia | '10_VolumenSinHorasPersonaDia'!$A$1:$H$84 |
| 8 | 12_MapeoActividadSPEC | '12_MapeoActividadSPEC'!$A$1:$N$135 |
| 9 | 13_VolumenMapeadoSPEC | '13_VolumenMapeadoSPEC'!$A$1:$AJ$744 |
| 10 | 14_VolumenPersonaDiaActividadSP | '14_VolumenPersonaDiaActividadSP'!$A$1:$H$311 |
| 11 | 15_VolumenSinHorasPersonaDiaAct | '15_VolumenSinHorasPersonaDiaAct'!$A$1:$E$93 |
| 12 | 16_ControlMapeoSPEC | '16_ControlMapeoSPEC'!$A$1:$C$14 |

**Evidencia:** COMPROBADO (xl/workbook.xml → definedNames).

### 2.3 Conexiones (13)

13 conexiones tipo 5 (OLEDB Provider=Microsoft.Mashup.OleDb.1). Cada una apunta a una consulta Power Query embebida en `$Workbook$`. Todas con `keepAlive=1`, `saveData=1`, `refreshedVersion=8`.

| id | Nombre | Location (consulta M) |
|---|---|---|
| 1 | Conexión | 01_HorasSinVolumen |
| 2 | Conexión1 | 02_VolumenDetalle |
| 3 | Conexión10 | 14_VolumenPersonaDiaActividadSPEC |
| 4 | Conexión11 | 15_VolumenSinHorasPersonaDiaActividadSPEC |
| 5 | Conexión12 | 16_ControlMapeoSPEC |
| 6 | Conexión2 | 03_VolumenPersonaDia |
| 7 | Conexión3 | 05_VolumenIdNumericoDia |
| 8 | Conexión4 | 07_Conciliacion |
| 9 | Conexión5 | 08_Validaciones |
| 10 | Conexión6 | 09_VolumenSinHorasDetalle |
| 11 | Conexión7 | 10_VolumenSinHorasPersonaDia |
| 12 | Conexión8 | 12_MapeoActividadSPEC |
| 13 | Conexión9 | 13_VolumenMapeadoSPEC |

**Nota:** La hoja REPORTE_CAMBIOS_HR **no tiene conexión** porque es generada por VBA, no por Power Query.

**Evidencia:** COMPROBADO (xl/connections.xml).

### 2.4 Tablas estructuradas (14)

| Archivo | Nombre tabla | Hoja | Rango | Cols |
|---|---|---|---|---|
| table1.xml | Tabla_DatosExternos_1 | 01_HorasSinVolumen | A1:Y117 | 25 |
| table2.xml | Tabla_DatosExternos_13 | 02_VolumenDetalle | A1:X744 | 24 |
| table3.xml | Tabla_DatosExternos_14 | 03_VolumenPersonaDia | A1:M213 | 13 |
| table4.xml | Tabla_DatosExternos_15 | 05_VolumenIdNumericoDia | A1:G197 | 7 |
| table5.xml | Tabla_DatosExternos_16 | 07_Conciliacion | A1:BM117 | 65 |
| table6.xml | Tabla_DatosExternos_17 | 08_Validaciones | A1:E19 | 5 |
| table7.xml | Tabla_DatosExternos_18 | 09_VolumenSinHorasDetalle | A1:W246 | 23 |
| table8.xml | Tabla_DatosExternos_19 | 10_VolumenSinHorasPersonaDia | A1:H84 | 8 |
| table9.xml | Tabla_DatosExternos_110 | 12_MapeoActividadSPEC | A1:N135 | 14 |
| table10.xml | Tabla_DatosExternos_111 | 13_VolumenMapeadoSPEC | A1:AJ744 | 36 |
| table11.xml | Tabla_DatosExternos_112 | 14_VolumenPersonaDiaActividadSP | A1:H311 | 8 |
| table12.xml | Tabla_DatosExternos_113 | 15_VolumenSinHorasPersonaDiaAct | A1:E93 | 5 |
| table13.xml | Tabla_DatosExternos_114 | 16_ControlMapeoSPEC | A1:C14 | 3 |
| table14.xml | tblReporteCambiosHR | REPORTE_CAMBIOS_HR | A1:T215 | 20 |

**Evidencia:** COMPROBADO (xl/tables/tableN.xml).

### 2.5 Consultas Power Query (20)

| # | Nombre | Tipo | Bytes M |
|---|---|---|---|
| 1 | 00_Parametros | let | 661 |
| 2 | fx_NormalizaTexto | función | 443 |
| 3 | fx_NormalizaLogin | función | 1045 |
| 4 | fx_Fecha | función | 532 |
| 5 | fx_TransformaHoras | función | 1290 |
| 6 | fx_TransformaVolumen | función | 1240 |
| 7 | fx_TransformaVolumenSinHoras | función | 1306 |
| 8 | 01_HorasSinVolumen | consulta | 3383 |
| 9 | 02_VolumenDetalle | consulta | 3109 |
| 10 | 09_VolumenSinHorasDetalle | consulta | 2945 |
| 11 | 12_MapeoActividadSPEC | consulta | 5350 |
| 12 | 13_VolumenMapeadoSPEC | consulta | 875 |
| 13 | 03_VolumenPersonaDia | consulta | 1183 |
| 14 | 05_VolumenIdNumericoDia | consulta | 877 |
| 15 | 10_VolumenSinHorasPersonaDia | consulta | 771 |
| 16 | 14_VolumenPersonaDiaActividadSPEC | consulta | 793 |
| 17 | 15_VolumenSinHorasPersonaDiaActividadSPEC | consulta | 471 |
| 18 | 16_ControlMapeoSPEC | consulta | 3572 |
| 19 | 07_Conciliacion | consulta | 11750 |
| 20 | 08_Validaciones | consulta | 4617 |

**Evidencia:** COMPROBADO (customXml/item1.xml → DataMashup → ZIP embebido → Formulas/Section1.m, 310 líneas).

### 2.6 Proyecto VBA (1 módulo estándar + 14 módulos de hoja + ThisWorkbook)

**Módulo principal:** `ModuloLYRA_V047` (89.384 bytes, 1086 líneas).

**Módulos de hoja (14):** ThisWorkbook + Hoja2..Hoja14, Hoja16. Todos vacíos salvo la declaración `Attribute VB_Name` (298-305 bytes cada uno). La numeración no incluye Hoja1 (eliminada por `EliminarSheet1SiVacia` tras la carga).

**Estructura del módulo principal:**

| Líneas | Procedimiento | Tipo | Función |
|---|---|---|---|
| 67-72 | AddOrReplaceQuery | Private Sub | Elimina y recrea una consulta Power Query en ThisWorkbook.Queries |
| 74-79 | NuevoDic | Private Function | Crea Scripting.Dictionary con CompareMode=vbTextCompare |
| 81-88 | Sumar | Private Sub | Suma valor a diccionario (clave vacía → "(VACIO)") |
| 90-99 | AgregarTexto | Private Sub | Añade texto separado por " \| " si no existe ya |
| 101-107 | UnirClaves | Private Function | Une claves de diccionario con " \| " |
| 109-111 | EsMismaFecha | Private Function | Compara fechas como CLng(CDate) |
| 113-115 | Numero | Private Function | CDbl si IsNumeric y no IsError |
| 117-119 | Normalizar | Private Function | UCase + Trim + CStr |
| 121-124 | GetVal | Private Function | Lee valor de diccionario o "" |
| 126-138 | CalcularMaterialidad | Private Function | Ver reglas de materialidad más abajo |
| 140-149 | Cabeceras | Private Function | Devuelve diccionario NombreColumna→Índice |
| 151-157 | Validar | Private Sub | Raise si faltan columnas |
| 159-163 | ObtenerHoja | Private Function | Worksheets(name) silencioso |
| 165-171 | EliminarHoja | Private Sub | Worksheets(name).Delete con DisplayAlerts=False |
| 173-194 | ProcesarFilaVolumen | Private Sub | Extrae datos de una fila emparejada de 13_VolumenMapeadoSPEC |
| 196-223 | EscribirPropuesta | Private Sub | Escribe una fila del reporte REPORTE_CAMBIOS_HR |
| 225-260 | Formatear | Private Sub | Crea ListObject tblReporteCambiosHR + estilos |
| 262-272 | HojaTieneDatos | Private Function | A1<>"" |
| **274-555** | **GenerarReporteCambiosHR** | **Public Sub** | **Genera el reporte completo (corazón del VBA)** |
| 557-637 | InstalarSistemaConciliacionLYRA_COMPLETO | Public Sub | Instala las 20 consultas M via AddOrReplaceQuery |
| 639-677 | INSTALAR_TODO_LYRA | Public Sub | Orquestador: instalar + RefreshAll + CargarConsultasLYRA + GenerarReporteCambiosHR + EliminarSheet1SiVacia |
| 679-685 | CargarConsultasLYRA | Private Sub | Para cada consulta, llama a CargarUnaConsulta |
| 687-709 | CargarUnaConsulta | Private Sub | Crea ListObject + QueryTable + Refresh |
| 711-723 | EliminarSheet1SiVacia | Private Sub | Elimina Sheet1 si está vacía |
| 724-1086 | M_00..M_19 | Private Functions | Construyen el código M como string (redundante con Section1.m) |

**Evidencia:** COMPROBADO (xl/vbaProject.bin decodificado con oletools.olevba).

### 2.7 Controles de interfaz

**Evidencia:** COMPROBADO. No existen botones, formas, hipervínculos, dibujos, validaciones de datos, formato condicional, ni autofiltros. El directorio `xl/drawings/` no existe. Todas las hojas reportaron 0 en cada categoría.

**Consecuencia:** El usuario ejecuta las macros desde el diálogo de macros de Excel (Alt+F8) o desde el Editor de VBA. No hay eventos de hoja ni de libro.

### 2.8 Otros elementos

| Elemento | Estado | Evidencia |
|---|---|---|
| Protección de hojas | Ninguna | sheetProtection ausente en todas las hojas |
| Protección de libro | Ninguna | workbookProtection ausente |
| Cálculo automático | calcId=162913 | xl/workbook.xml |
| Actualización automática al abrir | No | refreshOnLoad ausente en queryTables |
| Configuración de impresión | Por defecto | printOptions vacío o ausente |
| Celdas combinadas | Ninguna | mergeCells ausente |
| Comentarios / Notas | Ninguno | comments ausente |
| Cortes de página | Ninguno | pageBreaks ausente |
| Elementos externos | Rutas de carpetas en 00_Parametros | CustomXml + M_00 |

---

## 3. ARQUITECTURA ACTUAL

```
┌─────────────────────────────────────────────────────────────────────────┐
│                      CARPETAS LOCALES DEL USUARIO                        │
│  C:\Users\javilopez\OneDrive - ID Logistics\Escritorio\SPID\            │
│   ├── HORAS SIN VOLUMEN\HORAS SIN VOLUMEN\   (1+ archivos .xlsx/.xlsm) │
│   ├── HORAS SIN VOLUMEN\VOLUMEN\             (1+ archivos .xlsx/.xlsm) │
│   ├── HORAS SIN VOLUMEN\VOLUMEN SIN HORAS\   (1+ archivos .xlsx/.xlsm) │
│   └── MAPPING\Mapping.xlsx                   (1 archivo)              │
└───────────────────────────┬─────────────────────────────────────────────┘
                             │
                             ▼
        ┌────────────────────────────────────────────┐
        │   POWER QUERY (20 consultas M en Section1)  │
        │                                            │
        │   fx_NormalizaTexto / fx_NormalizaLogin    │
        │   fx_Fecha / fx_TransformaHoras            │
        │   fx_TransformaVolumen                     │
        │   fx_TransformaVolumenSinHoras            │
        │                                            │
        │   00_Parametros                            │
        │   01_HorasSinVolumen   (← fx_TransformaHoras)
        │   02_VolumenDetalle    (← fx_TransformaVolumen)
        │   09_VolumenSinHorasDetalle (← fx_TransformaVolumenSinHoras)
        │   12_MapeoActividadSPEC (← Mapping.xlsx Mapping sheet)
        │   13_VolumenMapeadoSPEC (← 02 + 12 left join)
        │   03_VolumenPersonaDia (← 02 grouped)
        │   05_VolumenIdNumericoDia (← 02 grouped)
        │   10_VolumenSinHorasPersonaDia (← 09 grouped)
        │   14_VolumenPersonaDiaActividadSPEC (← 13 grouped)
        │   15_VolumenSinHorasPersonaDiaActividadSPEC (← 09 grouped)
        │   16_ControlMapeoSPEC (KPIs)
        │   07_Conciliacion (← 01 + 03 + 14 + 05 + 10 + 15)
        │   08_Validaciones (KPIs)
        └──────────────────────┬─────────────────────┘
                               │
                               ▼
        ┌────────────────────────────────────────────┐
        │   VBA ModuloLYRA_V047                      │
        │                                            │
        │   INSTALAR_TODO_LYRA                       │
        │   ├─ InstalarSistemaConciliacionLYRA_COMPLETO (instala 20 M queries)
        │   ├─ ThisWorkbook.RefreshAll               │
        │   ├─ CargarConsultasLYRA (13 ListObjects)  │
        │   │   └─ CargarUnaConsulta (OLEDB → PQ)    │
        │   ├─ GenerarReporteCambiosHR               │
        │   │   ├─ Lee 01_HorasSinVolumen            │
        │   │   ├─ Lee 13_VolumenMapeadoSPEC         │
        │   │   ├─ Lee 07_Conciliacion               │
        │   │   ├─ Empareja por Fecha+LoginCanonico  │
        │   │   │   (Pass 1: LOGIN EXACTO)           │
        │   │   ├─ Empareja por Fecha+IdNumNorm      │
        │   │   │   (Pass 2: MISMO NUMERO DISTINTO  │
        │   │   │    PREFIJO, solo si Pass 1 falla)  │
        │   │   ├─ Clasifica en 7 secciones          │
        │   │   └─ Formatear (ListObject + estilos)  │
        │   └─ EliminarSheet1SiVacia                │
        └──────────────────────┬─────────────────────┘
                               │
                               ▼
        ┌────────────────────────────────────────────┐
        │ 14 HOJAS DEL LIBRO (todas visibles)        │
        │ 13 hojas con Tabla_DatosExternos_1X (PQ)   │
        │ 1 hoja con tblReporteCambiosHR (VBA)       │
        └────────────────────────────────────────────┘
```

---

## 4. FLUJO DE DATOS COMPLETO

### 4.1 Linaje completo

```
HORA SIN VOLUMEN.xlsx (Export: 119 rows)
└─→ Folder.Files + fx_TransformaHoras (filtra TOTAL/FILTROS APLICADOS, MissingField.Error en 9 columnas)
    └─→ 01_HorasSinVolumen (117 rows, 25 cols, RegistroValido=true)
        ├─→ [JOIN LEFT OUTER con 03_VolumenPersonaDia] → 07_Conciliacion
        ├─→ [JOIN LEFT OUTER con 14_VolumenPersonaDiaActividadSPEC por (Fecha,LoginCanonico,Activity=ActividadSPEC)] → 07_Conciliacion
        ├─→ [JOIN LEFT OUTER con 05_VolumenIdNumericoDia por (Fecha, IdNumericoNormalizado)] → 07_Conciliacion
        ├─→ [JOIN LEFT OUTER con 10_VolumenSinHorasPersonaDia por (Fecha, LoginCanonico)] → 07_Conciliacion
        ├─→ [JOIN LEFT OUTER con 15_VolumenSinHorasPersonaDiaActividadSPEC por (Fecha,LoginCanonico,Activity)] → 07_Conciliacion
        ├─→ [GROUP by (Fecha,LoginCanonico)] → NumActHR (NumeroActividadesHR, NumeroHRTaskDistintas, HRTaskDistintas, HorasTotalesPersonaDia) → JOIN con 07_Conciliacion
        └─→ [VBA GenerarReporteCambiosHR] → REPORTE_CAMBIOS_HR

VOLUMEN.xlsx (Export: 746 rows)
└─→ Folder.Files + fx_TransformaVolumen
    └─→ 02_VolumenDetalle (744 rows, 24 cols, RegistroValido=true)
        ├─→ [JOIN LEFT OUTER con 12_MapeoActividadSPEC por (SAP_CODE,CUSTOMER,WMS_TASK=TASK_WMS)] → 13_VolumenMapeadoSPEC
        │   └─→ [GROUP by (Fecha,LoginCanonico,ActividadSPEC) where EstadoMapeoFinal=UNICO] → 14_VolumenPersonaDiaActividadSPEC
        │       └─→ 07_Conciliacion
        ├─→ [GROUP by (Fecha,LoginCanonico)] → 03_VolumenPersonaDia
        │   └─→ 07_Conciliacion
        ├─→ [GROUP by (Fecha,IdNumericoNormalizado)] → 05_VolumenIdNumericoDia (EsAmbiguoIdNumerico = NumeroLoginsDistintos>1)
        │   └─→ 07_Conciliacion
        ├─→ 16_ControlMapeoSPEC (KPIs)
        └─→ 08_Validaciones (KPIs)

VOL SIN HORAS.xlsx (Export: 248 rows)
└─→ Folder.Files + fx_TransformaVolumenSinHoras
    └─→ 09_VolumenSinHorasDetalle (246 rows, 23 cols, RegistroValidoVSH=true)
        ├─→ [GROUP by (Fecha,LoginCanonico)] → 10_VolumenSinHorasPersonaDia
        │   └─→ 07_Conciliacion
        ├─→ [GROUP by (Fecha,LoginCanonico,Activity)] → 15_VolumenSinHorasPersonaDiaActividadSPEC
        │   └─→ 07_Conciliacion
        └─→ 08_Validaciones (KPIs VSH)

Mapping.xlsx (3 sheets)
├─ Hoja "Mapping" (167 rows, 14 cols)
│   └─→ 12_MapeoActividadSPEC (135 rows, 14 cols, group by SAP_CODE,CUSTOMER,TASK_WMS)
│       ├─→ [JOIN] 13_VolumenMapeadoSPEC
│       ├─→ 16_ControlMapeoSPEC (KPIs)
│       └─→ 08_Validaciones (KPIs mapeo)
├─ Hoja "Direct Budget" (111 rows, 10 cols) — NO UTILIZADA en V0.47.3
└─ Hoja "Indirect Budget" (86 rows, 15 cols) — NO UTILIZADA en V0.47.3
```

**Hallazgo:** Las hojas `Direct Budget` e `Indirect Budget` de Mapping.xlsx **no son leídas** por ninguna consulta Power Query ni por el VBA en V0.47.3. Solo se usa la hoja `Mapping`. **Evidencia:** COMPROBADO. La consulta `12_MapeoActividadSPEC` solo referencia `Excel.Workbook(File.Contents(RutaMapping), null, true)` y luego busca explícitamente una hoja llamada "MAPPING" (CaseInsensitive). Las otras hojas se cargan en el libro pero Power Query no las procesa.

### 4.2 Diagrama de dependencias entre consultas

```
00_Parametros (parámetros)
    ├──→ 01_HorasSinVolumen
    ├──→ 02_VolumenDetalle
    ├──→ 09_VolumenSinHorasDetalle
    └──→ 12_MapeoActividadSPEC

01_HorasSinVolumen
    └──→ 07_Conciliacion (clave primaria: Fecha + LoginCanonico + Activity)
            + groups derivadas internas (NumActHR)

02_VolumenDetalle
    ├──→ 03_VolumenPersonaDia  ──→ 07_Conciliacion
    ├──→ 05_VolumenIdNumericoDia ──→ 07_Conciliacion
    ├──→ 08_Validaciones
    ├──→ 16_ControlMapeoSPEC
    └──→ 13_VolumenMapeadoSPEC (con 12) ──→ 14_VolumenPersonaDiaActividadSPEC ──→ 07_Conciliacion

09_VolumenSinHorasDetalle
    ├──→ 10_VolumenSinHorasPersonaDia ──→ 07_Conciliacion
    ├──→ 15_VolumenSinHorasPersonaDiaActividadSPEC ──→ 07_Conciliacion
    └──→ 08_Validaciones

12_MapeoActividadSPEC
    ├──→ 13_VolumenMapeadoSPEC
    ├──→ 16_ControlMapeoSPEC
    └──→ 08_Validaciones

13_VolumenMapeadoSPEC
    ├──→ 14_VolumenPersonaDiaActividadSPEC
    ├──→ 16_ControlMapeoSPEC
    └──→ 08_Validaciones

05_VolumenIdNumericoDia
    └──→ 16_ControlMapeoSPEC

07_Conciliacion
    ├──→ 08_Validaciones
    └──→ [VBA] REPORTE_CAMBIOS_HR
```

### 4.3 Orden de ejecución (Power Query + VBA)

Cuando se ejecuta `INSTALAR_TODO_LYRA`:

1. `InstalarSistemaConciliacionLYRA_COMPLETO` — instala las 20 consultas M en `ThisWorkbook.Queries` (string replace).
2. `ThisWorkbook.RefreshAll` — refresca todas las conexiones en paralelo (Power Query evalúa el grafo de dependencias automáticamente).
3. `Application.CalculateUntilAsyncQueriesDone` — espera a que terminen las consultas asíncronas.
4. `CargarConsultasLYRA` — para cada una de las 13 consultas con output a hoja, crea un ListObject + QueryTable y refresca.
5. `GenerarReporteCambiosHR` — lee las 3 hojas origen y produce REPORTE_CAMBIOS_HR.
6. `EliminarSheet1SiVacia` — limpia la hoja Sheet1 si Excel la creó por defecto.

---

## 5. CONSULTAS POWER QUERY - CÓDIGO M ÍNTEGRO Y TRADUCCIÓN

> El código M íntegro está disponible en `/audit/powerquery/zip1__Formulas__Section1.m` (310 líneas) y como `q01_…q20_*.m` (un archivo por consulta). Aquí se presenta una traducción ejecutiva por consulta, con la lógica equivalente en JavaScript que se usará en la aplicación web.

### 5.1 00_Parametros

**M:**
```m
let
    Parametros = [
        RutaHoras = "C:\...\HORAS SIN VOLUMEN",
        RutaVolumen = "C:\...\VOLUMEN",
        RutaMappingSPEC = "C:\...\Mapping.xlsx",
        RutaVolumenSinHoras = "C:\...\VOLUMEN SIN HORAS",
        ExtensionesPermitidas = {".xlsx", ".xlsm", ".xlsb"},
        UmbralMicroHoras = 0.0833333333,
        Cultura = "es-ES"
    ]
in
    Parametros
```

**Equivalente JS:**
```js
const PARAMS = {
  ExtensionesPermitidas: ['.xlsx', '.xlsm', '.xlsb'],
  UmbralMicroHoras: 0.0833333333,
  Cultura: 'es-ES'
};
```

### 5.2 fx_NormalizaTexto

**Lógica:**
1. `Valor=null → null`
2. `Text.From(Valor)` (conversión a texto)
3. `Text.Trim(Text.Clean(_))` — limpia caracteres de control + quita espacios extremos
4. Si vacío → null
5. `Text.Upper(_)` — mayúsculas
6. `Text.SplitAny(texto, " \t\n\r")` → eliminar subcadenas vacías → `Text.Combine(_, " ")` — colapsa espacios internos

**Equivalente JS:**
```js
function fx_NormalizaTexto(v) {
  if (v == null) return null;
  let s = String(v).trim().replace(/[\x00-\x1F\x7F]/g, '').trim();
  if (s === '') return null;
  s = s.toUpperCase();
  s = s.split(/[\s]+/).join(' ');
  return s;
}
```

### 5.3 fx_NormalizaLogin

**Lógica:** Devuelve un **record** con 7 campos:
- `LoginOriginal`: Text.From(Valor) sin tocar
- `LoginOriginalLimpio`: fx_NormalizaTexto + `Text.Remove(_ , {" ", "-", ".", "_", "/", "\\"})` — quita separadores
- `Letras`: `Text.Select(LoginOriginalLimpio, {"A".."Z"})` — solo A-Z
- `Digitos`: `Text.Select(LoginOriginalLimpio, {"0".."9"})` — solo 0-9
- `IdNumericoLiteral`: Digitos (sin ceros iniciales quitados)
- `IdNumericoNormalizado`: `try Text.From(Number.FromText(Digitos, "en-US")) otherwise Digitos` — quita ceros iniciales (p.ej. "00123" → "123"). Si falla, mantiene literal
- `IdNumerico`: = `IdNumericoLiteral` (igual que el literal)
- `Canonico`: si hay Letras y dígitos → `Letras & IdNumerico`. Si no, el original limpio
- `Prefijo`: las letras (o null si no hay)

**Equivalente JS:**
```js
function fx_NormalizaLogin(v) {
  const original = (v == null) ? null : String(v);
  const limpio = fx_NormalizaTexto(v);
  let sinSeparadores = null;
  if (limpio) sinSeparadores = limpio.replace(/[ \-._/\\]/g, '');
  const letras = sinSeparadores ? sinSeparadores.replace(/[^A-Z]/g, '') : null;
  const digitos = sinSeparadores ? sinSeparadores.replace(/[^0-9]/g, '') : null;
  const idLiteral = (digitos && digitos !== '') ? digitos : null;
  let idNormalizado = idLiteral;
  if (idLiteral) {
    try { idNormalizado = String(Number(idLiteral)); }
    catch(e) { idNormalizado = idLiteral; }
  }
  const idNumerico = idLiteral;
  let canonico = null;
  if (limpio) {
    if (letras && idNumerico) canonico = letras + idNumerico;
    else canonico = limpio;
  }
  const prefijo = letras ? letras : null;
  return {
    LoginOriginal: original,
    LoginOriginalLimpio: limpio,
    LoginCanonico: canonico,
    IdNumerico: idNumerico,
    IdNumericoLiteral: idLiteral,
    IdNumericoNormalizado: idNormalizado,
    Prefijo: prefijo
  };
}
```

### 5.4 fx_Fecha

**Lógica:**
1. `Valor=null → null`
2. Si es `date` → `Date.From(Valor)`
3. Si es `datetime`/`datetimezone` → `Date.From(Valor)` (descarta hora)
4. Si es `number` → `try Date.AddDays(#date(1899,12,30), Number.RoundDown(Valor)) otherwise null` — fecha serial Excel
5. Si no → `try Date.FromText(Text.From(Valor), [Culture="es-ES"]) otherwise try Date.From(Valor) otherwise null`

**Equivalente JS:**
```js
function fx_Fecha(v) {
  if (v == null) return null;
  if (v instanceof Date) return stripTime(v);
  if (typeof v === 'number') {
    // Serial Excel (1899-12-30 base)
    const d = new Date(Date.UTC(1899, 11, 30));
    d.setUTCDate(d.getUTCDate() + Math.floor(v));
    return stripTime(d);
  }
  if (typeof v === 'string') {
    // Probar es-ES primero (dd/MM/yyyy o dd-MM-yyyy)
    let m = v.match(/^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2,4})$/);
    if (m) {
      const dd = +m[1], mm = +m[2]-1, yyyy = +m[3];
      const year = yyyy < 100 ? 2000+yyyy : yyyy;
      return new Date(Date.UTC(year, mm, dd));
    }
    // ISO
    m = v.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (m) return new Date(Date.UTC(+m[1], +m[2]-1, +m[3]));
    // fallback
    const d = new Date(v);
    return isNaN(d) ? null : stripTime(d);
  }
  return null;
}
function stripTime(d) { return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate())); }
```

### 5.5 fx_TransformaHoras / fx_TransformaVolumen / fx_TransformaVolumenSinHoras

**Lógica común:**
1. `Excel.Workbook(Contenido, null, true)` — lee el libro
2. `HojasValidas` = filas con Kind = "Sheet" o "Table"
3. `CandidatosExport` = hojas cuyo Item o Name = "EXPORT"
4. `Elegida` = primera CandidatosExport si existe, si no primera HojasValidas, si no error
5. `Table.PromoteHeaders`
6. `FiltrarPie` = filtra filas donde `[Site name] <> null AND NOT Starts("TOTAL") AND NOT Contains("FILTROS APLICADOS")`
7. `Requeridas` (diferentes por tipo) — `Table.SelectColumns(FiltrarPie, Requeridas, MissingField.Error)` — error si falta alguna columna
8. `ConArchivo` = añade columna ArchivoOrigen = nombre del archivo
9. `ConFila` = añade columna FilaOrigen = índice 2,1 (empieza en 2 para contar la cabecera como fila 1)

**Columnas requeridas:**
- **fx_TransformaHoras:** Site name, Department, Activity, Subactivity, Date, HR Task, WMS Login, Name, Hours without volume (9 cols)
- **fx_TransformaVolumen:** DATE, SAP_CODE, CUSTOMER, WMS_TASK, WMS_LOGIN, USER_NAME, WMS_UOM (7 cols)
- **fx_TransformaVolumenSinHoras:** Site name, Department, Activity, Subactivity, Date, HR Task, WMS Login, Name, Volume Without Hours (9 cols)

**Equivalente JS:** Implementado en `app.js` función `loadInputFile()`.

### 5.6 01_HorasSinVolumen (25 columnas)

**Pasos M:**
1. `Folder.Files(RutaHoras)` + filtra extensión permitida + no empieza por `~$`
2. `List.Transform` con `fx_TransformaHoras`
3. `Table.Combine`
4. Renombrar: Date→FechaOriginal, WMS Login→WMSLoginOriginal, Hours without volume→HorasSinVolumen
5. `Fecha = fx_Fecha([FechaOriginal])`
6. `HorasSinVolumen = try Number.From(_) otherwise null`
7. Normaliza textos: Site name, Department, Activity, Subactivity, HR Task, Name
8. `LoginRec = fx_NormalizaLogin([WMSLoginOriginal])` y expande a 7 columnas
9. `RegistroValido = Fecha<>null AND LoginCanonico<>null AND Activity<>null AND HorasSinVolumen<>null AND HorasSinVolumen>0`
10. `MotivoInvalido`: FECHA INVALIDA | LOGIN VACIO | ACTIVITY VACIA | HORAS NO NUMERICAS | HORAS CERO O NEGATIVAS
11. `ClaveNatural`: `Site name | yyyy-MM-dd | LoginCanonico | Department | Activity | Subactivity | HR Task | HorasSinVolumen` (todo null→"")
12. `Conteos` por ClaveNatural
13. `MergeDup` = LeftOuterJoin con conteos → `RepeticionesClave`
14. `PosibleDuplicado = RepeticionesClave > 1`
15. `IdRegistroHoras` índice 1,1
16. **Filtro final:** `RegistroValido = true`

**25 columnas resultantes:** Site name, Department, Activity, Subactivity, FechaOriginal, HR Task, WMSLoginOriginal, Name, HorasSinVolumen, ArchivoOrigen, FilaOrigen, Fecha, LoginOriginal, LoginOriginalLimpio, LoginCanonico, IdNumerico, IdNumericoLiteral, IdNumericoNormalizado, PrefijoLogin, RegistroValido, MotivoInvalido, ClaveNatural, RepeticionesClave, PosibleDuplicado, IdRegistroHoras

### 5.7 02_VolumenDetalle (24 columnas)

Igual que 01_HorasSinVolumen pero:
- Renombra DATE→FechaOriginal, WMS_LOGIN→WMSLoginOriginal, WMS_UOM→**VolumenNeto**
- Normaliza textos: SAP_CODE, CUSTOMER, WMS_TASK, USER_NAME
- **NO filtra por HorasSinVolumen > 0** (en su lugar tiene `VolumenNeto`)
- Añade columnas: `VolumenPositivo` (si VolumenNeto>0, si no 0), `VolumenNegativo` (si <0, si no 0), `EsVolumenCero` (=0)
- `RegistroValido = Fecha<>null AND VolumenNeto<>null AND WMS_TASK<>null`
- `ClaveNatural`: `Fecha | SAP_CODE | CUSTOMER | WMS_TASK | LoginCanonico | VolumenNeto`
- Sin MotivoInvalido
- Filtro final: `RegistroValido = true`

### 5.8 09_VolumenSinHorasDetalle (23 columnas)

Igual que 01 pero con renombrados:
- Date→FechaOriginalVSH, WMS Login→WMSLoginOriginalVSH, Volume Without Hours→VolumenSinHoras, HR Task→HRTaskVSH
- 7 columnas de login con sufijo VSH: LoginOriginalVSH, LoginOriginalLimpioVSH, LoginCanonico (sin sufijo), IdNumerico (sin sufijo), IdNumericoLiteralVSH, IdNumericoNormalizadoVSH, PrefijoLoginVSH
- `RegistroValidoVSH = Fecha<>null AND VolumenSinHoras<>null AND VolumenSinHoras>0 AND HRTaskVSH<>null`
- `ClaveNaturalVSH`: `Fecha | LoginCanonico | Activity | Subactivity | HRTaskVSH | VolumenSinHoras`

### 5.9 12_MapeoActividadSPEC (14 columnas)

**Lógica:**
1. `Excel.Workbook(File.Contents(RutaMapping))`
2. **Búsqueda de hoja Mapping:**
   - Primero busca coincidencia exacta (CaseInsensitive) Item o Name = "MAPPING" y Kind ∈ {SHEET, WORKSHEET, TABLE}
   - Si no, búsqueda flexible: Item/Name CONTIENE "MAPPING"
   - Si no encuentra → error con listado de objetos disponibles
3. `Table.PromoteHeaders`
4. Normaliza nombres de columnas: UPPERCASE + Clean + replace Char(160) (NBSP) por espacio + replace espacios por `_`
5. Validación: requiere {SAP_CODE, WMS_DC, CUSTOMER, DEPARTMENT, ACTIVITY, SUB_ACTIVITY, TASK_WMS, TASK_SPEC}. Si falta alguna → error explícito
6. `Table.SelectColumns(..., MissingField.Error)` (de nuevo error explícito si falta)
7. Normaliza textos en las 8 columnas
8. Filas válidas: SAP_CODE<>null AND CUSTOMER<>null AND TASK_WMS<>null
9. Verificación WMS_DC: agrupa por (SAP_CODE, CUSTOMER, TASK_WMS) y calcula `TieneMultipleWMS_DC = (count(distinct WMS_DC) > 1)`
10. **Agrupación principal** por (SAP_CODE, CUSTOMER, TASK_WMS):
    - `NumeroActividadesSPEC` = count distinct ACTIVITY
    - `ActividadesSPECPosibles` = join sorted distinct ACTIVITY con " | "
    - `ActividadSPEC` = si solo 1 → ese valor, si no null
    - `NumeroTasksSPEC` = count distinct TASK_SPEC
    - `TasksSPECPosibles` = join sorted distinct TASK_SPEC con " | "
    - `TasksSPEC` = join sorted distinct TASK_SPEC con " | " (siempre, no solo si hay 1)
    - `DepartamentosSPEC`, `SubactividadesSPEC`, `WMS_DCs` = idem
11. JOIN con verificación WMS_DC → añade `TieneMultipleWMS_DC`
12. `EstadoMapeoSPEC`:
    - `NumeroTasksSPEC = 0` → "SIN TASK_SPEC"
    - `NumeroTasksSPEC = 1` → "UNICO"
    - else → "AMBIGUO"
13. `Table.ReorderColumns` al orden final

### 5.10 13_VolumenMapeadoSPEC (36 columnas)

`02_VolumenDetalle` LEFT OUTER JOIN `12_MapeoActividadSPEC` por (SAP_CODE, CUSTOMER, WMS_TASK=TASK_WMS). Expande 11 columnas del mapeo. Añade:
- `EstadoMapeoFinal` = `EstadoMapeoSPEC` si no es null, si no "SIN MAPEO"

### 5.11 03_VolumenPersonaDia (13 columnas)

`02_VolumenDetalle` (filtro LoginCanonico<>null) GROUP BY (Fecha, LoginCanonico):
- VolumenTotalPositivo, VolumenTotalNegativo, VolumenTotalNeto, RegistrosVolumen, RegistrosCero, RegistrosNegativos, NumeroTareasWMS, TareasWMS (sorted distinct joined " | "), ClientesWMS, SAPsWMS, TieneDuplicadosVolumen

### 5.12 05_VolumenIdNumericoDia (7 columnas)

`02_VolumenDetalle` (filtro IdNumericoNormalizado<>null AND LoginCanonico<>null) GROUP BY (Fecha, IdNumericoNormalizado):
- VolumenIdPositivo, NumeroLoginsDistintos, LoginsMismoNumero (sorted distinct joined " | "), PrefijosMismoNumero, LoginsDistintosLista (lista, no texto), EsAmbiguoIdNumerico = (NumeroLoginsDistintos > 1)

### 5.13 10_VolumenSinHorasPersonaDia (8 columnas)

`09_VolumenSinHorasDetalle` (filtro LoginCanonico<>null) GROUP BY (Fecha, LoginCanonico):
- VolumenSinHorasPersonaDia (sum), NumeroRegistrosVSH, ActividadesVSH, SubactividadesVSH, TareasVSH, TieneDuplicadosVSH

### 5.14 14_VolumenPersonaDiaActividadSPEC (8 columnas)

`13_VolumenMapeadoSPEC` (filtro LoginCanonico<>null AND ActividadSPEC<>null AND EstadoMapeoFinal=UNICO) GROUP BY (Fecha, LoginCanonico, ActividadSPEC):
- VolumenMismaActivitySPECPositivo, Negativo, Neto, TareasWMSMismaActivitySPEC, TasksSPECUna

### 5.15 15_VolumenSinHorasPersonaDiaActividadSPEC (5 columnas)

`09_VolumenSinHorasDetalle` (filtro LoginCanonico<>null AND Activity<>null) GROUP BY (Fecha, LoginCanonico, Activity):
- VolumenSinHorasMismaActivitySPEC, TareasVSHMismaActivitySPEC

### 5.16 16_ControlMapeoSPEC (14 KPIs)

Construye una tabla `#table({"Control","Valor","Estado"}, {...})` con 14 filas:

| Control | Estado si |
|---|---|
| Mapeos TASK_WMS cargados | OK si >0, si no ERROR BLOQUEANTE |
| WMS Task distintas en volumen | INFORMATIVO |
| WMS Task con mapeo unico (TASK_SPEC) | OK si >0, si no ERROR BLOQUEANTE |
| WMS Task con mapeo ambiguo | OK si =0, si no REVISAR |
| WMS Task sin mapeo | OK si =0, si no REVISAR |
| Volumen positivo total | INFORMATIVO |
| Volumen positivo mapeado UNICO | INFORMATIVO |
| Volumen positivo AMBIGUO | INFORMATIVO |
| Volumen positivo SIN MAPEO | INFORMATIVO |
| Volumen positivo SIN LOGIN | INFORMATIVO |
| Volumen positivo UNICO sin ambiguedad IdNumerico | INFORMATIVO |
| Cobertura volumen positivo mapeado (total) | OK≥0.9, REVISAR≥0.7, sino ERROR BLOQUEANTE |
| Cobertura volumen positivo atribuible (real) | OK≥0.9, REVISAR≥0.7, sino "DATOS INSUFICIENTES - calidad de fuentes" |

### 5.17 07_Conciliacion (65 columnas) — la consulta central

**Esquema de joins encadenados (todos LEFT OUTER JOIN):**

1. **H = 01_HorasSinVolumen** (base, 117 filas)
2. **M1:** JOIN con 03_VolumenPersonaDia por (Fecha, LoginCanonico) → expande 11 columnas
3. **M2:** JOIN con 14_VolumenPersonaDiaActividadSPEC por (Fecha, LoginCanonico, Activity=ActividadSPEC) → expande 5 columnas (renombra a VolumenMismaActividad*)
4. **M3:** JOIN con 05_VolumenIdNumericoDia por (Fecha, IdNumericoNormalizado) → expande 5 columnas (renombra a VolumenMismoNumero*, etc.)
5. **M4:** JOIN con 10_VolumenSinHorasPersonaDia por (Fecha, LoginCanonico) → expande 6 columnas
6. **M5:** JOIN con 15_VolumenSinHorasPersonaDiaActividadSPEC por (Fecha, LoginCanonico, Activity) → expande 2 columnas
7. **Numeros:** ReplaceValue null→0 en 15 columnas numéricas
8. **Booleanos:** TransformColumns null→false en 3 columnas (TieneDuplicadosVolumen, TieneDuplicadosVSH, EsAmbiguoIdNumerico)
9. **Otras:** VolumenOtrasActividadesPositivo = max(0, VolumenTotalPositivo - VolumenMismaActividadPositivo)
10. **NumActHR:** GROUP BY (Fecha, LoginCanonico) de H → NumeroActividadesHR, NumeroHRTaskDistintas, HRTaskDistintas, HorasTotalesPersonaDia
11. **M6:** JOIN con NumActHR por (Fecha, LoginCanonico) → expande 4 columnas
12. **Clasificacion** (calculada): ver catálogo de reglas más abajo
13. **NivelConfianza** (calculado): ALTA / MEDIA / NO DETERMINABLE
14. **Evidencia** (texto): concatenación de frases de evidencia con "; "
15. **Explicacion** (texto): una frase por cada Clasificacion
16. **AccionRecomendada** (texto): una acción por cada Clasificacion
17. **Materialidad** (texto): MICRO/BAJA/MEDIA/ALTA/CRITICA según HorasSinVolumen
18. **Orden:** ReorderColumns al orden final de 65 columnas

### 5.18 08_Validaciones (19 KPIs)

Tabla con 19 controles de validación con columnas Control, ValorOrigen, ValorResultado, Estado, Detalle. Incluye conservación de horas y volumen, duplicados, mapeos ausentes/ambiguos, etc.

---

## 6. CÓDIGO VBA - TRADUCCIÓN DE GenerarReporteCambiosHR

### 6.1 Pseudocódigo del algoritmo

```
PROC GenerarReporteCambiosHR:

  # Cabeceras requeridas:
  HH = 01_HorasSinVolumen.{IdRegistroHoras, Fecha, Name, LoginCanonico,
                            IdNumerico, IdNumericoNormalizado, HR Task, HorasSinVolumen}
  HV = 13_VolumenMapeadoSPEC.{Fecha, LoginCanonico, IdNumericoNormalizado,
                              WMS_TASK, SAP_CODE, CUSTOMER, VolumenPositivo,
                              TasksSPEC, EstadoMapeoFinal, WMS_DCs,
                              ArchivoOrigen, FilaOrigen}
  HC = 07_Conciliacion.{IdRegistroHoras, Fecha, LoginCanonico,
                        NumeroHRTaskDistintas, HRTaskDistintas,
                        EsAmbiguoIdNumerico, LoginsMismoNumero}

  # Crear nueva hoja REPORTE_CAMBIOS_HR
  Eliminar hoja existente si la hay
  Crear hoja al final
  
  # Cabecera de 20 columnas
  A1:T1 = SECCION, ID REGISTRO, FECHA, PERSONA, LOGIN HORAS,
         HORAS SIN VOLUMEN, MATERIALIDAD, HR TASK FICHADA,
         TASKSPEC SEGUN MAPPING, VOLUMEN POSITIVO,
         WMS TASK CON VOLUMEN, TIPO COINCIDENCIA,
         LOGIN UTILIZADO EN VOLUMEN, SAP_CODE, CUSTOMER, WMS_DC,
         ARCHIVO ORIGEN, FILA ORIGEN, REQUIERE CAMBIO RRHH, OBSERVACION

  # Pre-indexar 13_VolumenMapeadoSPEC:
  Para cada fila fv con Fecha válida en 13:
    clave_e = fecha_long | LoginCanonico
    clave_i = fecha_long | IdNumericoNormalizado
    dRowsExacto[clave_e].Add(fv)   # si LoginCanonico no vacío
    dRowsIdNum[clave_i].Add(fv)    # si IdNumericoNormalizado no vacío

  Para cada fila fh en 01_HorasSinVolumen (2..uh):
    Si Fecha inválida → siguiente fila
    
    fecha = CLng(CDate(Fecha))
    loginH = Normalizar(LoginCanonico)
    idH = Normalizar(IdNumericoNormalizado)
    hrTask = Trim(HR Task)
    
    # Consultar 07_Conciliacion por IdRegistroHoras (búsqueda lineal)
    filaConc = buscar fila en 07 donde IdRegistroHoras = fh.IdRegistroHoras
    
    Si filaConc encontrada:
      es_multi_hr_task = (NumeroHRTaskDistintas > 1)
      es_ambiguo_idnum_conc = (EsAmbiguoIdNumerico = True)
    si no:
      es_ambiguo_idnum_conc = False
    
    dFilas = nueva colección
    encontrados = 0
    modo = "LOGIN EXACTO"
    
    # Pass 1: LOGIN EXACTO
    Si loginH no vacío:
      Para cada fv en dRowsExacto[fecha|loginH]:
        Si VolumenPositivo(fv) > 0:
          agregar a dFilas: [TasksSPEC, VolumenPositivo, WMS_TASK, SAP_CODE,
                             CUSTOMER, WMS_DCs, ArchivoOrigen, FilaOrigen,
                             LoginCanonico, EstadoMapeoFinal]
          encontrados++
    
    # Pass 2: MISMO NUMERO, DISTINTO PREFIJO (solo si Pass 1 falla)
    Si encontrados = 0 AND idH no vacío:
      modo = "MISMO NUMERO, DISTINTO PREFIJO"
      Para cada fv en dRowsIdNum[fecha|idH]:
        Si VolumenPositivo(fv) > 0:
          agregar a dFilas
          encontrados++
      Si es_ambiguo_idnum_conc:
        modo = "REVISION MANUAL - AMBIGUEDAD ID NUMERICO"
    
    Si es_multi_hr_task:
      modo = "REVISION MANUAL - MULTIPLES HR TASK"
    
    # Escribir filas de propuesta
    Si encontrados = 0:
      # Sección 4: SIN VOLUMEN
      requiere = "REVISAR"
      obs = "No existe volumen positivo por fecha y login ni por fecha y numero."
      Si es_multi_hr_task:
        obs += " Ademas, la persona ficho varias HR Task el mismo dia (...)"
      Si es_ambiguo_idnum_conc:
        obs += " Ademas, existe ambiguedad de IdNumerico (...)"
      EscribirPropuesta(sección="4. SIN VOLUMEN", ...)
    
    si no:
      # Contar TasksSPEC distintas (H-05 FIX)
      # H-05b FIX: excluir TasksSPEC con " | " del conteo de únicas
      dTsUnicas = {}
      Para cada item en dFilas:
        ts = item[0]
        si ts != "" AND " | " no en ts:
          dTsUnicas[ts] = True
      nTasksSpecDistintas = dTsUnicas.Count
      
      Para cada item en dFilas:
        ts_item, vol_item, wms_item, sap_item, cust_item, dc_item,
        arch_item, fila_item, loginV_item, estado_item = item
        
        Si estado_item != "UNICO" OR ts_item = "" OR " | " en ts_item:
          sección = "5. WMS TASK SIN MAPPING"
          obs = "Existe volumen, pero no hay una TASKSPEC unica documentada."
          requiere = "REVISAR"
        Sino si es_multi_hr_task:
          sección = "6. REVISION MANUAL - MULTIPLES HR TASK"
          obs = "La persona tiene multiples HR Task el mismo dia. ..."
          requiere = "REVISAR"
        Sino si es_ambiguo_idnum_conc AND modo = "REVISION MANUAL - AMBIGUEDAD ID NUMERICO":
          sección = "7. REVISION MANUAL - AMBIGUEDAD ID NUMERICO"
          obs = "Multiples logins candidatos con el mismo IdNumerico normalizado."
          requiere = "REVISAR"
        Sino si nTasksSpecDistintas > 1:  # H-05 FIX
          sección = "2. VARIAS TASKSPEC CON VOLUMEN"
          obs = "Se muestran todas las TASKSPEC diferentes con sus volumenes. ..."
          requiere = "REVISAR"
        Sino si Normalizar(hrTask) = Normalizar(ts_item):
          sección = "3. HR TASK CORRECTA"
          obs = "La HR Task fichada coincide con la TASKSPEC del Mapping."
          requiere = "NO"
        Sino:
          sección = "1. CAMBIO HR TASK PROPUESTO"
          obs = "La TASKSPEC procede del Mapping de las WMS Task cuantificadas."
          requiere = "SI"
          tiene_propuesta_valida = True
        
        Si modo = "MISMO NUMERO, DISTINTO PREFIJO":
          obs += " El volumen se ha asociado por coincidencia del numero de usuario."
        
        EscribirPropuesta(...)
  
  Formatear hoja (ListObject, estilos, anchos, formatos numéricos, freeze panes)
  MsgBox "Reporte generado. Filas: " & (fo - 2)
END
```

### 6.2 Materialidad (CalcularMaterialidad)

```vba
If horas < 0.0833333333 Then
    "MICRO < 5 MIN"
ElseIf horas < 0.25 Then
    "BAJA < 15 MIN"
ElseIf horas < 1 Then
    "MEDIA < 1 H"
ElseIf horas < 4 Then
    "ALTA 1-4 H"
Else
    "CRITICA >= 4 H"
End If
```

0.0833333 = 1/12 hora = 5 minutos. 0.25 h = 15 min. 1 h. 4 h.

### 6.3 Regla clave: "MISMO NUMERO, DISTINTO PREFIJO" no es recíproco

Si la Pass 1 encuentra coincidencia exacta, **no se ejecuta Pass 2** aunque también existan coincidencias por IdNumerico.

Si Pass 1 falla y Pass 2 acierta, modo = "MISMO NUMERO, DISTINTO PREFIJO" y, si además `EsAmbiguoIdNumerico=true` en 07_Conciliacion, modo se sobreescribe a "REVISION MANUAL - AMBIGUEDAD ID NUMERICO".

### 6.4 Regla clave: H-05 / H-05b (corrección de sección 2)

- **H-05 (corregido V0.47.2):** Sección 2 requiere `nTasksSpecDistintas > 1` (TasksSPEC distintas), no `dFilas.Count > 1` (filas emparejadas).
- **H-05b (corregido V0.47.3):** Una fila con TasksSPEC ambigua (contiene " | ") NO se cuenta como una TaskSPEC distinta. Se excluye del diccionario `dTsUnicas` con `If InStr(ts_temp, " | ") = 0 Then dTsUnicas(ts_temp) = True`. Las filas con TasksSPEC ambigua caen en sección 5 con REQUIERE CAMBIO RRHH=REVISAR.

---

## 7. DIAGRAMA DE EJECUCIÓN

```
[Usuario abre SPEC V0.47.3.xlsm]
           │
           ▼
[Alt+F8 → INSTALAR_TODO_LYRA]
           │
           ├── 1. InstalarSistemaConciliacionLYRA_COMPLETO
           │      └── AddOrReplaceQuery x20 (reemplaza M en ThisWorkbook.Queries)
           │
           ├── 2. ThisWorkbook.RefreshAll
           │      └── Power Query evalúa grafo de dependencias
           │          (Folder.Files → fx_Transforma* → Combine → Joins → Groups → KPIs)
           │
           ├── 3. Application.CalculateUntilAsyncQueriesDone
           │      └── Bloquea hasta que todas las PQ terminen
           │
           ├── 4. CargarConsultasLYRA
           │      └── Para 13 consultas:
           │          ├── Crea o limpia hoja
           │          ├── Crea ListObject
           │          ├── Crea QueryTable con OLEDB a Microsoft.Mashup
           │          └── Refresh (síncrono)
           │
           ├── 5. GenerarReporteCambiosHR
           │      ├── Lee 01_HorasSinVolumen (117 filas válidas)
           │      ├── Lee 13_VolumenMapeadoSPEC (744 filas)
           │      ├── Lee 07_Conciliacion (117 filas)
           │      ├── Pre-indexa 13 por (Fecha|LoginCanonico) y (Fecha|IdNumNorm)
           │      ├── Para cada fila de 01 (117):
           │      │   ├── Busca en 07 por IdRegistroHoras (lineal)
           │      │   ├── Pass 1: dRowsExacto[fecha|loginH]
           │      │   ├── Pass 2 (si Pass 1 vacío): dRowsIdNum[fecha|idH]
           │      │   ├── Determina modo
           │      │   ├── Cuenta TasksSPEC distintas (H-05/H-05b)
           │      │   ├── Clasifica en sección 1-7
           │      │   └── EscribirPropuesta x cada match
           │      └── Formatear (ListObject tblReporteCambiosHR)
           │
           └── 6. EliminarSheet1SiVacia
                  └── Si Sheet1 está vacía, eliminarla

[Fin: REPORTE_CAMBIOS_HR con 215 filas, 20 columnas]
```

---

## 8. RIESGOS E INCIDENCIAS

### 8.1 Riesgos técnicos

| Riesgo | Severidad | Mitigación en V0.47.3 |
|---|---|---|
| Rutas hardcodeadas a OneDrive personal de javilopez | ALTA | La app web sustituye por selectores de archivo del usuario |
| `Folder.Files` lee TODOS los archivos de la carpeta | MEDIA | La app web exige un único archivo por tipo |
| `MissingField.Error` aborta si falta columna esperada | ALTA | Validación previa en la UI con mensajes claros |
| `Excel.Workbook` sin `deferenciar` fila a fila es lento | BAJA | En navegador con SheetJS es aceptable |
| Búsqueda lineal en VBA de IdRegistroHoras en 07_Conciliacion (117×117 = 13.689 iteraciones) | BAJA | La app web pre-indexa |
| Rutas Windows con `\\` son problemáticas | MEDIA | La app web no usa rutas, usa objetos File |

### 8.2 Incidencias detectadas (corregidas en V0.47.3)

- **H-05b RESIDUAL:** ID 115 mantenía 2 filas en sección 2 con 1 sola TasksSPEC real porque `dTsUnicas` contaba el string AMBIGUO "20157 | 20159" como una TaskSPEC distinta. **FIX aplicado en V0.47.3:** excluir TasksSPEC con " | " del conteo de únicas.
- **H-05 BLOQUEANTE (V0.47.2):** Sección 2 clasificaba por `dFilas.Count > 1` (número de filas) en vez de TasksSPEC distintas. 51 filas mal clasificadas. **FIX:** usar diccionario `dTsUnicas` y criterio `nTasksSpecDistintas > 1`.
- **H-01 (V0.47.1):** Multi HR Task invisible en sección 4. **FIX:** observación ahora menciona condición multi HR Task.

### 8.3 Elementos no verificables

| Elemento | Razón |
|---|---|
| Resultados reales generados por Excel con los archivos de entrada | No tengo Excel/LibreOffice con soporte VBA + Power Query para ejecutar macros |
| Tiempos de ejecución | Dependen del hardware y de la caché de Power Query |

---

## 9. MATRIZ DE TRAZABILIDAD

| Elemento SPEC | Archivo forense | Línea | Tipo | Equivalente en app web |
|---|---|---|---|---|
| 00_Parametros | Section1.m | 3-15 | M query | `js/params.js:PARAMS` |
| fx_NormalizaTexto | Section1.m | 17-25 | M function | `js/normalize.js:fx_NormalizaTexto` |
| fx_NormalizaLogin | Section1.m | 27-43 | M function | `js/normalize.js:fx_NormalizaLogin` |
| fx_Fecha | Section1.m | 45-55 | M function | `js/normalize.js:fx_Fecha` |
| fx_TransformaHoras | Section1.m | 57-79 | M function | `js/loaders.js:loadHorasSinVolumen` |
| fx_TransformaVolumen | Section1.m | 81-103 | M function | `js/loaders.js:loadVolumen` |
| fx_TransformaVolumenSinHoras | Section1.m | 105-127 | M function | `js/loaders.js:loadVolumenSinHoras` |
| 01_HorasSinVolumen | Section1.m | 129-152 | M query | `js/queries.js:q01_HorasSinVolumen` |
| 02_VolumenDetalle | Section1.m | 154-177 | M query | `js/queries.js:q02_VolumenDetalle` |
| 09_VolumenSinHorasDetalle | Section1.m | 179-201 | M query | `js/queries.js:q09_VolumenSinHorasDetalle` |
| 12_MapeoActividadSPEC | Section1.m | 203-226 | M query | `js/queries.js:q12_MapeoActividadSPEC` |
| 13_VolumenMapeadoSPEC | Section1.m | 228-234 | M query | `js/queries.js:q13_VolumenMapeadoSPEC` |
| 03_VolumenPersonaDia | Section1.m | 236-241 | M query | `js/queries.js:q03_VolumenPersonaDia` |
| 05_VolumenIdNumericoDia | Section1.m | 243-248 | M query | `js/queries.js:q05_VolumenIdNumericoDia` |
| 10_VolumenSinHorasPersonaDia | Section1.m | 250-255 | M query | `js/queries.js:q10_VolumenSinHorasPersonaDia` |
| 14_VolumenPersonaDiaActividadSPEC | Section1.m | 257-262 | M query | `js/queries.js:q14_VolumenPersonaDiaActividadSPEC` |
| 15_VolumenSinHorasPersonaDiaActividadSPEC | Section1.m | 264-268 | M query | `js/queries.js:q15_VolumenSinHorasPersonaDiaActividadSPEC` |
| 16_ControlMapeoSPEC | Section1.m | 270-292 | M query | `js/queries.js:q16_ControlMapeoSPEC` |
| 07_Conciliacion | Section1.m | 294-321 | M query | `js/queries.js:q07_Conciliacion` |
| 08_Validaciones | Section1.m | 323-331 | M query | `js/queries.js:q08_Validaciones` |
| GenerarReporteCambiosHR | ModuloLYRA_V047.bas | 274-555 | VBA Sub | `js/report.js:generarReporteCambiosHR` |
| CalcularMaterialidad | ModuloLYRA_V047.bas | 126-138 | VBA Function | `js/report.js:calcularMaterialidad` |
| ProcesarFilaVolumen | ModuloLYRA_V047.bas | 173-194 | VBA Sub | `js/report.js:procesarFilaVolumen` |
| EscribirPropuesta | ModuloLYRA_V047.bas | 196-223 | VBA Sub | `js/report.js:escribirPropuesta` |
| AgregarTexto / UnirClaves / etc | ModuloLYRA_V047.bas | 90-124 | VBA helpers | `js/report.js:helpers` |
| INSTALAR_TODO_LYRA | ModuloLYRA_V047.bas | 639-677 | VBA orchestrator | `js/orchestrator.js:analizarYConciliar` |
| CargarConsultasLYRA | ModuloLYRA_V047.bas | 679-685 | VBA loader | No aplica (la app web produce directamente las tablas en memoria) |
| AddOrReplaceQuery / M_00..M_19 | ModuloLYRA_V047.bas | 724-1086 | VBA installer | No aplica (no hay PQ embebido) |

---

## 10. CONCLUSIÓN

SPEC V0.47.3 es un sistema monolítico Excel de complejidad media-alta con:

- **Lógica 100% en Power Query (datos) + VBA (reporte final).** Sin fórmulas en celdas, sin controles de UI.
- **20 consultas M y 1 procedimiento VBA principal.**
- **Linaje trazable y reproducible** (sin llamadas a servicios externos, sin conexiones a BBDD externas, sin web queries).
- **4 archivos de entrada obligatorios**, todos en formato Excel.
- **2 hojas de Mapping.xlsx no utilizadas** (Direct Budget e Indirect Budget) — potencial evolutivo futuro.
- **13 KPIs de control de mapeo + 19 validaciones + 1 reporte final con 7 secciones.**

La aplicación web que se entrega reproduce **fielmente** las 20 consultas M y el procedimiento VBA, manteniendo el linaje y los nombres de columnas. Las diferencias técnicas se documentan en `PLAN_MIGRACION.md` y `PRUEBAS_EQUIVALENCIA.md`.
