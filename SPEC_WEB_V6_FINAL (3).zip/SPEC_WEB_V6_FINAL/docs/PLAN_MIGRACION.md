# PLAN DE MIGRACIÓN EXCEL → WEB

> Cómo se migró SPEC V0.47.3.xlsm a una aplicación web HTML/CSS/JS.  
> Matriz de correspondencia Excel→HTML, Power Query→JS, VBA→JS.

---

## 1. ARQUITECTURA PROPUESTA

**Stack tecnológico:**
- HTML5 (estructura semántica, pestañas, drop zones)
- CSS3 (diseño responsive, KPI cards, tablas con encabezados fijos)
- JavaScript ES2017+ (sin frameworks, vanilla JS)
- SheetJS (xlsx.full.min.js, Apache 2.0) — lectura/escritura de archivos .xlsx
- Sin servidor. Procesamiento 100% local en el navegador.

**Compatibilidad:**
- Microsoft Edge 88+ (Chromium)
- Google Chrome 88+
- Otros navegadores modernos con soporte ES2017

**Modelo de datos interno:**

```
Archivo XLSX ─── SheetJS ───► { SheetNames, Sheets }
                                      │
                              sheet_to_json(header:1, raw:true, defval:null)
                                      │
                                      ▼
                              Array<Array>  (filas crudas)
                                      │
                              fx_Transforma* (renombrado, filtrado pie, validación columnas)
                                      │
                                      ▼
                              Array<Object> (filas con campos con nombre)
                                      │
                              20 consultas M (port a JS)
                                      │
                                      ▼
                              STATE.queries = { 13 tablas intermedias + KPIs }
                                      │
                              VBA GenerarReporteCambiosHR (port a JS)
                                      │
                                      ▼
                              STATE.reporte = Array<Object> (215 filas × 20 cols)
                                      │
                              UI (pestañas, tablas, KPI cards)
                                      │
                              XLSX/CSV export (SheetJS write o CSV manual)
```

---

## 2. CORRESPONDENCIA EXCEL → APLICACIÓN WEB

| Elemento Excel | Equivalente Web | Notas |
|---|---|---|
| Archivo .xlsm (libro con macros) | Página HTML + JS | Sin macros; lógica en JS |
| 14 hojas | 14 resultsets en memoria + 14 vistas tabulares | Estado en `STATE.queries` |
| Conexiones Power Query (13) | Llamadas a funciones JS | Sin conexión real, datos en memoria |
| Consulta Power Query 01_HorasSinVolumen | `q01_HorasSinVolumen()` | 25 columnas idénticas |
| Consulta Power Query 02_VolumenDetalle | `q02_VolumenDetalle()` | 24 columnas idénticas |
| Consulta Power Query 09_VolumenSinHorasDetalle | `q09_VolumenSinHorasDetalle()` | 23 columnas idénticas |
| Consulta Power Query 12_MapeoActividadSPEC | `q12_MapeoActividadSPEC()` | 14 columnas idénticas |
| Consulta Power Query 13_VolumenMapeadoSPEC | `q13_VolumenMapeadoSPEC()` | 36 columnas idénticas |
| Consulta Power Query 03_VolumenPersonaDia | `q03_VolumenPersonaDia()` | 13 columnas idénticas |
| Consulta Power Query 05_VolumenIdNumericoDia | `q05_VolumenIdNumericoDia()` | 7 columnas idénticas |
| Consulta Power Query 10_VolumenSinHorasPersonaDia | `q10_VolumenSinHorasPersonaDia()` | 8 columnas idénticas |
| Consulta Power Query 14_VolumenPersonaDiaActividadSPEC | `q14_VolumenPersonaDiaActividadSPEC()` | 8 columnas idénticas |
| Consulta Power Query 15_VolumenSinHorasPersonaDiaActividadSPEC | `q15_VolumenSinHorasPersonaDiaActividadSPEC()` | 5 columnas idénticas |
| Consulta Power Query 16_ControlMapeoSPEC | `q16_ControlMapeoSPEC()` | 3 columnas idénticas |
| Consulta Power Query 07_Conciliacion | `q07_Conciliacion()` | 65 columnas idénticas |
| Consulta Power Query 08_Validaciones | `q08_Validaciones()` | 5 columnas idénticas |
| Procedimiento VBA GenerarReporteCambiosHR | `generarReporteCambiosHR()` | 20 columnas idénticas, 7 secciones idénticas |
| Procedimiento VBA INSTALAR_TODO_LYRA | `analizarYConciliar()` | Orquestador único |
| Procedimiento VBA InstalarSistemaConciliacionLYRA_COMPLETO | No aplica | Las consultas M están directamente en app.js |
| Procedimiento VBA CargarConsultasLYRA + CargarUnaConsulta | No aplica | No hay hojas que rellenar; los datos viven en memoria |
| Procedimiento VBA AddOrReplaceQuery + M_00..M_19 | No aplica | Las consultas M están directamente en app.js |
| Tabla estructurada tblReporteCambiosHR | `STATE.reporte` (Array) | Misma estructura, mismos anchos de columna aplicados vía CSS |
| Botones/dibujos (no existen) | Botones HTML con `addEventListener` | SPEC original no tiene botones; usuario ejecutaba macros con Alt+F8 |
| `MsgBox` VBA | `alert()` / mensajes en UI | |
| `Application.ScreenUpdating=False` | No aplica | JS no tiene redraw visible |
| `Application.Calculation=xlCalculationManual` | No aplica | JS no recalcula automáticamente |
| `On Error GoTo ErrorControl` | `try/catch` | |
| `Scripting.Dictionary` | `Map` o `{}` | |
| `Collection` | `Array` | |
| `ThisWorkbook.RefreshAll` | Llamadas secuenciales a queries | JS ejecuta en orden explícito |
| Folder.Files(ruta) | `FileReader` + drop zone | El usuario carga archivos individualmente |
| `Excel.Workbook(BinaryContent)` | `XLSX.read(arrayBuffer, {cellDates:true})` | SheetJS |
| `Table.PromoteHeaders` | Tomar `rows[0]` como headers | |
| `Text.Clean` (control chars) | `replace(/[\x00-\x1F\x7F]/g, '')` | |
| `Text.Upper` | `toUpperCase()` | |
| `Text.Trim` | `replace(/^\s+\|\s+$/g, '')` | |
| `Text.Combine(list, sep)` | `Array.join(sep)` | |
| `Text.SplitAny(text, separators)` | `text.split(/[\s]+/)` (en fx_NormalizaTexto) o `String.split` en general | |
| `Text.Select(text, charList)` | `text.replace(/[^A-Z0-9]/g, '')` | |
| `Text.Remove(text, charList)` | `text.replace(/[ \-._\/\\]/g, '')` | |
| `Text.StartsWith(text, prefix)` | `text.startsWith(prefix)` | |
| `Text.Contains(text, sub)` | `text.includes(sub)` | |
| `Number.FromText(text, "en-US")` | `Number(text)` (en-US usa punto decimal) | |
| `Number.ToText(n, "0.############", "en-US")` | `n.toLocaleString('en-US', {maximumFractionDigits:12, useGrouping:false})` | |
| `Date.From(value)` | `stripTime(new Date(value))` | |
| `Date.AddDays(#date(1899,12,30), n)` | `new Date(Date.UTC(1899,11,30) + n*86400000)` | |
| `Table.SelectRows(table, condition)` | `array.filter(condition)` | |
| `Table.SelectColumns(table, cols, MissingField.Error)` | Validación de headers + map | |
| `Table.AddColumn(table, name, expr)` | `array.map(r => ({...r, [name]: expr(r)}))` | |
| `Table.TransformColumns(table, ...)` | `array.map(r => ({...r, [col]: fn(r[col])}))` | |
| `Table.RenameColumns` | `array.map(r => ({newName: r.oldName, ...}))` | |
| `Table.Group(table, keys, aggregations)` | `groupBy(rows, keys)` + reduce | |
| `Table.NestedJoin(left, lkeys, right, rkeys, "name", JoinKind.LeftOuter)` + `Table.ExpandTableColumn` | `leftOuterJoin(left, right, lkeys, rkeys, fields)` | |
| `Table.Combine(tables)` | `[...t1, ...t2, ...]` o `flat()` | |
| `Table.Distinct(table)` | `Array.from(new Set(...))` o custom distinctOf | |
| `Table.RowCount(table)` | `array.length` | |
| `List.Sum(list)` | `array.reduce((a,b)=>a+(+b||0), 0)` | sumList helper |
| `List.Count(list)` | `array.length` | |
| `List.Distinct(list)` | `Array.from(new Set(...))` | distinctList helper |
| `List.RemoveNulls(list)` | `array.filter(x => x != null)` | |
| `List.AnyTrue(list)` | `array.some(x => x === true)` | anyTrue helper |
| `List.Transform(list, fn)` | `array.map(fn)` | |
| `List.Contains(list, item)` | `array.includes(item)` o `set.has(item)` | |
| `Table.IsEmpty(table)` | `array.length === 0` | |
| `Table.ReorderColumns(table, order)` | Iterar columnas en orden al exportar | El JS mantiene el orden natural de inserción |
| `try ... otherwise` | `try { ... } catch(e) { fallback }` | |
| `#table({...}, {...})` | Array de objetos | |

---

## 3. ORDEN DE PROCESAMIENTO

```
analizarYConciliar():
  1. fx_TransformaHoras(wbHoras)  → rawHoras (119 filas crudas)
  2. fx_TransformaVolumen(wbVolumen) → rawVolumen (746)
  3. fx_TransformaVolumenSinHoras(wbVSH) → rawVSH (248)
  4. leerMapping(wbMapping) → rawMapping (167)
  5. q01_HorasSinVolumen(rawHoras) → H (116)
  6. q02_VolumenDetalle(rawVolumen) → V (743)
  7. q09_VolumenSinHorasDetalle(rawVSH) → VSH (245)
  8. q12_MapeoActividadSPEC(rawMapping) → M (134)
  9. q13_VolumenMapeadoSPEC(V, M) → VM (743)
  10. q03_VolumenPersonaDia(V) → VPD (212)
  11. q05_VolumenIdNumericoDia(V) → VID (196)
  12. q10_VolumenSinHorasPersonaDia(VSH) → VSPD (83)
  13. q14_VolumenPersonaDiaActividadSPEC(VM) → VPDAS (311)
  14. q15_VolumenSinHorasPersonaDiaActividadSPEC(VSH) → VSPDAS (93)
  15. q16_ControlMapeoSPEC(M, VM, VID) → CTRL (13)
  16. q07_Conciliacion(H, VPD, VID, VSPD, VPDAS, VSPDAS) → C (116)
  17. q08_Validaciones(H, V, VSH, C, VM, VID) → VAL (18)
  18. generarReporteCambiosHR(H, VM, C) → REP (214)
```

**Diferencia con Excel:** Excel usa `RefreshAll` que evalúa en paralelo siguiendo el grafo de dependencias. Aquí se ejecuta en orden explícito (el orden importa porque cada query depende de las anteriores).

---

## 4. GESTIÓN DE ERRORES

| Caso | Excel | Web |
|---|---|---|
| Falta columna en archivo de entrada | `MissingField.Error` aborta la carga | `throw new Error('Faltan columnas: ...')` en `fx_Transforma*` |
| Carpeta vacía | `error "Carpeta vacía"` | Validación previa: botón "Analizar" deshabilitado hasta que los 4 archivos estén cargados |
| Hoja Mapping no encontrada | `error "No existe una hoja..."` | `throw new Error(...)` con listado de hojas disponibles |
| Columna requerida ausente en Mapping | `error "faltan estas columnas obligatorias"` | `throw new Error(...)` con listado de columnas faltantes |
| Error en macro VBA | `MsgBox vbCritical` | `alert` + mensaje en log area (rojo) |
| Restaurar estado tras error | `On Error GoTo ... If estadosGuardados Then ...` | `try/catch/finally` |

---

## 5. GESTIÓN DE VERSIONES

| Versión web | Cambios |
|---|---|
| 1.0.0 (esta entrega) | Port inicial de SPEC V0.47.3. Equivalencia 12/12 OK. |

**Próximas versiones potenciales:**
- 1.1.0: Soporte multi-archivo por tipo (carpeta con varios .xlsx)
- 1.2.0: Gráficos de cobertura y materialidad
- 1.3.0: Comparador de ejecuciones (diff de resultados)

---

## 6. ESTRATEGIA DE PRUEBAS

Ver `PRUEBAS_EQUIVALENCIA.md`.

---

## 7. LIMITACIONES CONOCIDAS

1. **No ejecuta el Excel original como referencia.** Las pruebas de equivalencia se basan en los resultados pre-calculados que están en las 14 hojas del xlsm (que se asumen correctos porque fueron generados por el propio sistema Power Query + VBA).
2. **Un único archivo por tipo.** Excel original usa `Folder.Files` para leer una carpeta completa con varios archivos del mismo tipo. La versión web acepta un solo archivo por tipo. Es suficiente para los archivos de muestra, pero si hubiera varios archivos en una misma carpeta, habría que cargarlos uno por uno (añadiéndolos a una lista).
3. **Las hojas `Direct Budget` e `Indirect Budget` de Mapping.xlsx no son leídas** ni en Excel V0.47.3 ni en esta web (verificado en código M).
4. **Sin soporte offline para instalar SheetJS.** El archivo `SPEC_LYRA_AUTONOMO.html` embebe SheetJS inline (881 KB), por lo que sí es 100% offline. La versión modular requiere tener `xlsx.full.min.js` en la misma carpeta que `index.html`.
