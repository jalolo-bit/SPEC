# CATÁLOGO DE REGLAS DE NEGOCIO - SPEC V0.47.3

> Documento numerado de todas las reglas de negocio descubiertas en SPEC V0.47.3.xlsm (Power Query + VBA).  
> Cada regla tiene evidencia directa (archivo + línea/celda/procedimiento).

---

## R1. Parámetros globales

**R1.1 — Extensiones permitidas**  
Archivo: `Section1.m` línea 9 (query `00_Parametros`).  
Regla: Solo se procesan archivos `.xlsx`, `.xlsm`, `.xlsb`. Otros se ignoran.  
Severidad: FILTRO.

**R1.2 — Archivos temporales excluidos**  
Archivo: `Section1.m` líneas 4, 4, 4 (queries `01_HorasSinVolumen`, `02_VolumenDetalle`, `09_VolumenSinHorasDetalle`).  
Regla: Se ignoran archivos cuyo nombre empieza por `~$` (archivos temporales de bloqueo de Excel).  
Severidad: FILTRO.

**R1.3 — Umbral MICRO**  
Archivo: `Section1.m` línea 10 + `ModuloLYRA_V047.bas` línea 127.  
Regla: `UmbralMicroHoras = 0.0833333333` horas (5 minutos). Una hora < 5 min se clasifica "MICRO < 5 MIN".  
Severidad: UMBRAL.

**R1.4 — Cultura es-ES**  
Archivo: `Section1.m` línea 11.  
Regla: Todas las conversiones de fecha en `fx_Fecha` usan cultura `es-ES` (formato `dd/MM/yyyy`).  
Severidad: CONFIG.

---

## R2. Normalización de texto (fx_NormalizaTexto)

**R2.1** — `Valor = null → null`  
**R2.2** — Convertir a texto con `Text.From`  
**R2.3** — `Text.Clean` elimina caracteres de control (0x00-0x1F)  
**R2.4** — `Text.Trim` elimina espacios, tabuladores y retornos extremos  
**R2.5** — Si vacío → null  
**R2.6** — Convertir a mayúsculas (`Text.Upper`)  
**R2.7** — Dividir por espacios/tabs/CR/LF y volver a unir con un único espacio — colapsa espacios internos  

Archivo: `Section1.m` líneas 17-25.

---

## R3. Normalización de login (fx_NormalizaLogin)

Devuelve un record con 7 campos.

**R3.1** — `LoginOriginal = Text.From(Valor)` (sin normalizar)  
**R3.2** — `LoginOriginalLimpio = fx_NormalizaTexto(Valor)` y luego `Text.Remove(_, {" ", "-", ".", "_", "/", "\\"})` (quita separadores)  
**R3.3** — `Letras = Text.Select(LoginOriginalLimpio, {"A".."Z"})` (solo A-Z mayúsculas)  
**R3.4** — `Digitos = Text.Select(LoginOriginalLimpio, {"0".."9"})` (solo 0-9)  
**R3.5** — `IdNumericoLiteral = Digitos` (conserva ceros iniciales: "00123" se queda "00123")  
**R3.6** — `IdNumericoNormalizado = try Text.From(Number.FromText(Digitos, "en-US")) otherwise Digitos` (convierte a número y vuelve a texto, eliminando ceros iniciales: "00123" → "123"; si falla, mantiene literal)  
**R3.7** — `IdNumerico = IdNumericoLiteral` (alias del literal)  
**R3.8** — `Canonico`: si Letras no vacío AND IdNumerico no null → `Letras & IdNumerico`; si no → `LoginOriginalLimpio`  
**R3.9** — `Prefijo = Letras` si no vacío, si no null  

Archivo: `Section1.m` líneas 27-43.

---

## R4. Conversión de fecha (fx_Fecha)

**R4.1** — `null → null`  
**R4.2** — Si `type date` → usar directo  
**R4.3** — Si `type datetime`/`datetimezone` → `Date.From(Valor)` (descarta hora)  
**R4.4** — Si `type number` → `Date.AddDays(#date(1899,12,30), Number.RoundDown(Valor))` (fecha serial Excel, base 1899-12-30). Si falla → null.  
**R4.5** — Si no → `Date.FromText(Text.From(Valor), [Culture="es-ES"])`, fallback `Date.From(Valor)`, fallback null.  

Archivo: `Section1.m` líneas 45-55.

---

## R5. Lectura de archivos de entrada (fx_TransformaHoras/Volumen/VolumenSinHoras)

**R5.1** — `Excel.Workbook(Contenido, null, true)` (useHeaders=false para poder filtrar pie)  
**R5.2** — Hojas válidas = Kind = "Sheet" o Kind = "Table"  
**R5.3** — Búsqueda de hoja EXPORT:  
  - Primera coincidencia exacta (UPPER(TRIM(Item))="EXPORT" o UPPER(TRIM(Name))="EXPORT")  
  - Si no, primera hoja válida  
  - Si no hay hojas → error  
**R5.4** — `Table.PromoteHeaders` (fila 1 → cabecera)  
**R5.5** — Filtro pie: filtra filas donde `[Site name] IS NULL` OR `Starts(Upper([Site name]), "TOTAL")` OR `Contains(Upper([Site name]), "FILTROS APLICADOS")`  
**R5.6** — `Table.SelectColumns(FiltrarPie, Requeridas, MissingField.Error)` — error si falta alguna columna requerida  
  - fx_TransformaHoras requiere: `Site name, Department, Activity, Subactivity, Date, HR Task, WMS Login, Name, Hours without volume`  
  - fx_TransformaVolumen requiere: `DATE, SAP_CODE, CUSTOMER, WMS_TASK, WMS_LOGIN, USER_NAME, WMS_UOM`  
  - fx_TransformaVolumenSinHoras requiere: `Site name, Department, Activity, Subactivity, Date, HR Task, WMS Login, Name, Volume Without Hours`  
**R5.7** — Añade columna `ArchivoOrigen = nombre del archivo`  
**R5.8** — Añade columna `FilaOrigen = AddIndexColumn(2, 1)` — empieza en 2 (fila 1 es cabecera)  

Archivo: `Section1.m` líneas 57-127.

---

## R6. Validez de registros

**R6.1 — Registro válido en 01_HorasSinVolumen:**  
`Fecha <> null AND LoginCanonico <> null AND Activity <> null AND HorasSinVolumen <> null AND HorasSinVolumen > 0`  

**R6.2 — MotivoInvalido (en orden, el primero que aplica):**  
1. `Fecha = null` → "FECHA INVALIDA"  
2. `LoginCanonico = null` → "LOGIN VACIO"  
3. `Activity = null` → "ACTIVITY VACIA"  
4. `HorasSinVolumen = null` → "HORAS NO NUMERICAS"  
5. `HorasSinVolumen <= 0` → "HORAS CERO O NEGATIVAS"  
6. else → null  

**R6.3 — Registro válido en 02_VolumenDetalle:**  
`Fecha <> null AND VolumenNeto <> null AND WMS_TASK <> null`  

**R6.4 — Registro válido en 09_VolumenSinHorasDetalle:**  
`Fecha <> null AND VolumenSinHoras <> null AND VolumenSinHoras > 0 AND HRTaskVSH <> null`  

**R6.5 — Filtro de salida:**  
Cada una de las 3 consultas de detalle filtra finalmente `RegistroValido = true` (o `RegistroValidoVSH = true`). Los registros inválidos NO aparecen en las hojas resultantes.

Archivo: `Section1.m` líneas 13-14 (q08), 16 (q09), 13 (q10).

---

## R7. Clave natural y duplicados

**R7.1 — Clave natural en 01_HorasSinVolumen:**  
`Site name | yyyy-MM-dd | LoginCanonico | Department | Activity | Subactivity | HR Task | HorasSinVolumen` (nulos → "")

**R7.2 — Clave natural en 02_VolumenDetalle:**  
`yyyy-MM-dd | SAP_CODE | CUSTOMER | WMS_TASK | LoginCanonico | VolumenNeto`

**R7.3 — Clave natural en 09_VolumenSinHorasDetalle:**  
`yyyy-MM-dd | LoginCanonico | Activity | Subactivity | HRTaskVSH | VolumenSinHoras`

**R7.4 — RepeticionesClave:**  
GROUP BY ClaveNatural → RepeticionesClave = Table.RowCount. JOIN left outer con la tabla original para añadir la columna.

**R7.5 — PosibleDuplicado:**  
`RepeticionesClave > 1`. Booleano. NO se eliminan los duplicados (se conservan todos con el flag).

Archivo: `Section1.m` q08-q10.

---

## R8. Volumen: positivo, negativo, cero

**R8.1 — VolumenPositivo:** si `VolumenNeto <> null AND VolumenNeto > 0` → `VolumenNeto`, si no `0`.  
**R8.2 — VolumenNegativo:** si `VolumenNeto <> null AND VolumenNeto < 0` → `VolumenNeto`, si no `0`.  
**R8.3 — EsVolumenCero:** `VolumenNeto = 0` (booleano).

Archivo: `Section1.m` q09 líneas 13-15.

---

## R9. Mapeo SPEC (12_MapeoActividadSPEC)

**R9.1 — Búsqueda de hoja Mapping:**  
1. Coincidencia exacta (case-insensitive) Item o Name = "MAPPING" AND Kind ∈ {SHEET, WORKSHEET, TABLE}  
2. Si no, coincidencia flexible: contiene "MAPPING"  
3. Si no, error con listado de objetos disponibles  

**R9.2 — Normalización de nombres de columnas:**  
UPPER + Clean + replace Char(160) (NBSP) por espacio + replace espacios por `_`  

**R9.3 — Columnas obligatorias:**  
`{SAP_CODE, WMS_DC, CUSTOMER, DEPARTMENT, ACTIVITY, SUB_ACTIVITY, TASK_WMS, TASK_SPEC}`  
Falta alguna → error explícito (MissingField.Error).  

**R9.4 — Filas válidas:**  
`SAP_CODE <> null AND CUSTOMER <> null AND TASK_WMS <> null`  

**R9.5 — Verificación multi WMS_DC:**  
GROUP BY (SAP_CODE, CUSTOMER, TASK_WMS) → `TieneMultipleWMS_DC = (count distinct WMS_DC > 1)`  

**R9.6 — Agrupación principal:**  
GROUP BY (SAP_CODE, CUSTOMER, TASK_WMS) con agregaciones:  
- `NumeroActividadesSPEC = count distinct ACTIVITY`  
- `ActividadesSPECPosibles = join sorted distinct ACTIVITY con " | "`  
- `ActividadSPEC = si solo 1 → valor, si no null`  
- `NumeroTasksSPEC = count distinct TASK_SPEC`  
- `TasksSPECPosibles = join sorted distinct TASK_SPEC con " | "`  
- `TasksSPEC = join sorted distinct TASK_SPEC con " | "` (siempre, no solo si 1)  
- `DepartamentosSPEC, SubactividadesSPEC, WMS_DCs` = idem  

**R9.7 — EstadoMapeoSPEC:**  
- `NumeroTasksSPEC = 0` → "SIN TASK_SPEC"  
- `NumeroTasksSPEC = 1` → "UNICO"  
- else → "AMBIGUO"  

Archivo: `Section1.m` q11 (12_MapeoActividadSPEC).

---

## R10. Volumen mapeado (13_VolumenMapeadoSPEC)

**R10.1** — `02_VolumenDetalle` LEFT OUTER JOIN `12_MapeoActividadSPEC` por (SAP_CODE, CUSTOMER, WMS_TASK=TASK_WMS).  
**R10.2** — Expande 11 columnas del mapeo.  
**R10.3** — `EstadoMapeoFinal`:  
- Si `EstadoMapeoSPEC = null` → "SIN MAPEO"  
- Si no → el valor de `EstadoMapeoSPEC` (UNICO / AMBIGUO / SIN TASK_SPEC)  

Archivo: `Section1.m` q12 (13_VolumenMapeadoSPEC).

---

## R11. Agregaciones por persona y día

**R11.1 — 03_VolumenPersonaDia** (group by Fecha, LoginCanonico, de 02):  
VolumenTotalPositivo, VolumenTotalNegativo, VolumenTotalNeto, RegistrosVolumen, RegistrosCero, RegistrosNegativos, NumeroTareasWMS, TareasWMS (sorted distinct " | "), ClientesWMS, SAPsWMS, TieneDuplicadosVolumen.

**R11.2 — 05_VolumenIdNumericoDia** (group by Fecha, IdNumericoNormalizado, de 02 con IdNumNorm y LoginCanonico no nulos):  
VolumenIdPositivo, NumeroLoginsDistintos, LoginsMismoNumero (sorted distinct " | "), PrefijosMismoNumero, **EsAmbiguoIdNumerico = NumeroLoginsDistintos > 1**.

**R11.3 — 10_VolumenSinHorasPersonaDia** (group by Fecha, LoginCanonico, de 09):  
VolumenSinHorasPersonaDia, NumeroRegistrosVSH, ActividadesVSH, SubactividadesVSH, TareasVSH, TieneDuplicadosVSH.

**R11.4 — 14_VolumenPersonaDiaActividadSPEC** (group by Fecha, LoginCanonico, ActividadSPEC, de 13 con filtro EstadoMapeoFinal=UNICO):  
VolumenMismaActivitySPECPositivo, Negativo, Neto, TareasWMSMismaActivitySPEC, TasksSPECUna.

**R11.5 — 15_VolumenSinHorasPersonaDiaActividadSPEC** (group by Fecha, LoginCanonico, Activity, de 09 con LoginCanonico y Activity no nulos):  
VolumenSinHorasMismaActivitySPEC, TareasVSHMismaActivitySPEC.

Archivo: `Section1.m` q13-q17.

---

## R12. Conciliación (07_Conciliacion)

**R12.1 — Base:** 01_HorasSinVolumen (117 filas válidas).

**R12.2 — 5 joins LEFT OUTER:**  
- M1: con 03_VolumenPersonaDia por (Fecha, LoginCanonico)  
- M2: con 14_VolumenPersonaDiaActividadSPEC por (Fecha, LoginCanonico, Activity = ActividadSPEC)  
- M3: con 05_VolumenIdNumericoDia por (Fecha, IdNumericoNormalizado)  
- M4: con 10_VolumenSinHorasPersonaDia por (Fecha, LoginCanonico)  
- M5: con 15_VolumenSinHorasPersonaDiaActividadSPEC por (Fecha, LoginCanonico, Activity)  

**R12.3 — JOIN interno NumActHR:**  
GROUP BY (Fecha, LoginCanonico) de 01 → NumeroActividadesHR, NumeroHRTaskDistintas, HRTaskDistintas, HorasTotalesPersonaDia. JOIN con tabla base por (Fecha, LoginCanonico).

**R12.4 — Nulos reemplazados:**  
15 columnas numéricas → null reemplazado por 0.  
3 booleanos (TieneDuplicadosVolumen, TieneDuplicadosVSH, EsAmbiguoIdNumerico) → null reemplazado por false.

**R12.5 — VolumenOtrasActividadesPositivo:**  
`max(0, VolumenTotalPositivo - VolumenMismaActividadPositivo)`

Archivo: `Section1.m` q19.

---

## R13. Clasificación (07_Conciliacion.Clasificacion)

En orden, el primero que aplica:

| # | Condición | Clasificacion |
|---|---|---|
| 1 | PosibleDuplicado OR TieneDuplicadosVolumen OR TieneDuplicadosVSH | "POSIBLE DUPLICIDAD" |
| 2 | EsAmbiguoIdNumerico AND VolumenMismoNumeroPositivo > 0 AND VolumenTotalPositivo = 0 | "REVISION MANUAL - AMBIGUEDAD ID NUMERICO" |
| 3 | VolumenSinHorasMismaActividad > 0 | "DESCUADRE RECIPROCO EN LA MISMA ACTIVITY SPEC" |
| 4 | VolumenSinHorasPersonaDia > 0 | "VOLUMEN SIN HORAS EN OTRA ACTIVITY SPEC" |
| 5 | VolumenMismaActividadPositivo > 0 | "VOLUMEN EN LA MISMA ACTIVITY SPEC" |
| 6 | VolumenOtrasActividadesPositivo > 0 | "VOLUMEN EN OTRA ACTIVITY SPEC O SIN MAPEO" |
| 7 | VolumenTotalPositivo = 0 AND VolumenMismoNumeroPositivo > 0 | "POSIBLE ERROR DE IDENTIFICACION O PREFIJO" |
| 8 | VolumenTotalPositivo = 0 AND RegistrosVolumen > 0 | "SOLO REGISTROS CERO O AJUSTES" |
| 9 | VolumenTotalPositivo = 0 | "SIN EVIDENCIA DE ACTIVIDAD PRODUCTIVA" |
| 10 | else | "CASO NO DETERMINABLE" |

**R13.2 — NivelConfianza:**  
- ALTA: POSIBLE DUPLICIDAD | DESCUADRE RECIPROCO | VOLUMEN SIN HORAS EN OTRA | VOLUMEN EN LA MISMA  
- MEDIA: VOLUMEN EN OTRA | POSIBLE ERROR DE IDENTIFICACION | SOLO REGISTROS CERO | StartsWith(REVISION MANUAL)  
- else: NO DETERMINABLE  

Archivo: `Section1.m` q19.

---

## R14. Materialidad (07_Conciliacion.Materialidad y VBA CalcularMaterialidad)

| HorasSinVolumen | Materialidad |
|---|---|
| < 0.0833333333 (5 min) | "MICRO < 5 MIN" |
| < 0.25 (15 min) | "BAJA < 15 MIN" |
| < 1 | "MEDIA < 1 H" |
| < 4 | "ALTA 1-4 H" |
| >= 4 | "CRITICA >= 4 H" |

Se aplica DOS veces: una vez dentro de 07_Conciliacion (columna `Materialidad`) y otra en VBA (columna `MATERIALIDAD` del reporte). Ambas con el mismo algoritmo.

Archivo: `Section1.m` q19 línea 24, `ModuloLYRA_V047.bas` líneas 126-138.

---

## R15. Conciliación de login (VBA GenerarReporteCambiosHR)

**R15.1 — Pre-indexación de 13_VolumenMapeadoSPEC:**  
- `dRowsExacto[fecha_long | LoginCanonico]` = colección de filas fv  
- `dRowsIdNum[fecha_long | IdNumericoNormalizado]` = colección de filas fv  

Solo se indexan filas con Fecha válida. `fecha_long = CLng(CDate(Fecha))`.

**R15.2 — Pass 1: LOGIN EXACTO**  
Si `Len(LoginCanonico_Horas) > 0`:  
Buscar en `dRowsExacto[fecha | loginH]` → para cada fila fv encontrada:  
- Si `VolumenPositivo(fv) > 0` → añadir a dFilas con `[TasksSPEC(fv), VolumenPositivo(fv), WMS_TASK(fv), SAP_CODE(fv), CUSTOMER(fv), WMS_DCs(fv), ArchivoOrigen(fv), FilaOrigen(fv), LoginCanonico(fv), EstadoMapeoFinal(fv)]`  
- `encontrados++`  

**R15.3 — Pass 2: MISMO NUMERO, DISTINTO PREFIJO** (solo si Pass 1 no encontró nada)  
Si `Len(IdNumericoNormalizado_Horas) > 0`:  
- modo = "MISMO NUMERO, DISTINTO PREFIJO"  
- Buscar en `dRowsIdNum[fecha | idH]` → para cada fv:  
  - Si `VolumenPositivo(fv) > 0` → añadir a dFilas, encontrados++  
- Si `EsAmbiguoIdNumerico(filaConc) = True` → modo = "REVISION MANUAL - AMBIGUEDAD ID NUMERICO"  

**R15.4 — Multi HR Task override:**  
Si `07_Conciliacion.NumeroHRTaskDistintas > 1` para el IdRegistroHoras → modo = "REVISION MANUAL - MULTIPLES HR TASK"  

Archivo: `ModuloLYRA_V047.bas` líneas 373-437.

---

## R16. Clasificación del reporte (VBA GenerarReporteCambiosHR)

**R16.0 — Búsqueda de filaConc:**  
Búsqueda lineal en 07_Conciliacion por `IdRegistroHoras = fh.IdRegistroHoras`. Si no se encuentra, filaConc=0 (no se consultan NiNum ni multi HR).

**R16.1 — Conteo de TasksSPEC distintas (H-05 + H-05b):**  
Para cada item en dFilas:  
`ts = item.TasksSPEC`  
Si `ts <> "" AND InStr(ts, " | ") = 0` → `dTsUnicas[ts] = True`  
`nTasksSpecDistintas = dTsUnicas.Count`  

**R16.2 — Sin coincidencias (encontrados = 0):**  
Sección = "4. SIN VOLUMEN"  
Requiere = "REVISAR"  
Observación = "No existe volumen positivo por fecha y login ni por fecha y numero."  
+ Si es_multi_hr_task: "Ademas, la persona ficho varias HR Task el mismo dia (HRTaskDistintas): revision manual necesaria."  
+ Si es_ambiguo_idnum_conc: "Ademas, existe ambiguedad de IdNumerico (LoginsMismoNumero)."  

**R16.3 — Con coincidencias (recorrer dFilas, una fila de reporte por item):**  
En orden, el primero que aplica:  
1. Si `EstadoMapeoFinal <> "UNICO" OR TasksSPEC = "" OR TasksSPEC contiene " | "` → Sección 5 "WMS TASK SIN MAPPING", REVISAR, "Existe volumen, pero no hay una TASKSPEC unica documentada."  
2. Si `es_multi_hr_task` → Sección 6 "REVISION MANUAL - MULTIPLES HR TASK", REVISAR  
3. Si `es_ambiguo_idnum_conc AND modo = "REVISION MANUAL - AMBIGUEDAD ID NUMERICO"` → Sección 7 "REVISION MANUAL - AMBIGUEDAD ID NUMERICO", REVISAR  
4. Si `nTasksSpecDistintas > 1` → Sección 2 "VARIAS TASKSPEC CON VOLUMEN", REVISAR  
5. Si `Normalizar(hrTask) = Normalizar(ts_item)` → Sección 3 "HR TASK CORRECTA", NO  
6. else → Sección 1 "CAMBIO HR TASK PROPUESTO", SI, `tiene_propuesta_valida = True`  

**R16.4 — Sufijo de Pass 2:**  
Si `modo = "MISMO NUMERO, DISTINTO PREFIJO"` → añadir a observación: " El volumen se ha asociado por coincidencia del numero de usuario."  

Archivo: `ModuloLYRA_V047.bas` líneas 440-533.

---

## R17. Formato del reporte

**R17.1** — Crear hoja REPORTE_CAMBIOS_HR al final del libro (o reemplazar existente).  
**R17.2** — Cabecera A1:T1 con 20 nombres fijos.  
**R17.3** — Crear ListObject `tblReporteCambiosHR` con rango A1:T{ult}, estilo `TableStyleMedium2`.  
**R17.4** — Anchos de columna específicos (A:38, B:11, C:12, D:36, E:16, F:14, G:16, H:42, I:42, J:14, K:55, L:32, M:32, N:12, O:20, P:12, Q:30, R:10, S:16, T:60).  
**R17.5** — Formatos numéricos: C=dd/mm/yyyy, F=0.00, J=#,##0.  
**R17.6** — WrapText=True en A1:T{ult}.  
**R17.7** — Filas 1 en negrita.  
**R17.8** — FreezePanes en A2.  

Archivo: `ModuloLYRA_V047.bas` líneas 225-260 (Formatear).

---

## R18. KPIs de control (16_ControlMapeoSPEC y 08_Validaciones)

**R18.1 — Cobertura total:** `VolumenMapeadoPositivo / VolumenTotalPositivo` (si total=0 → null).  
**R18.2 — Cobertura atribuible:** `VolumenUnicoAtribuible / VolumenTotalPositivo` donde `VolumenUnicoAtribuible` = suma de VolumenPositivo con EstadoMapeoFinal=UNICO AND LoginCanonico<>null AND IdNumericoNormalizado NOT IN (IdNumericos ambiguos de 05_VID).  
**R18.3 — Estados KPI:**  
- OK / REVISAR / ERROR BLOQUEANTE / INFORMATIVO / SIN DATOS / DATOS INSUFICIENTES  

**R18.4 — Umbrales de cobertura:**  
- ≥0.9 → OK  
- ≥0.7 → REVISAR  
- <0.7 → ERROR BLOQUEANTE (cobertura total) o "DATOS INSUFICIENTES - calidad de fuentes" (atribuible)  

Archivo: `Section1.m` q18 (16_ControlMapeoSPEC) y q20 (08_Validaciones).

---

## R19. Reglas de duplicados

**R19.1** — `PosibleDuplicado = RepeticionesClave > 1` (basado en clave natural).  
**R19.2** — En 07_Conciliacion: `TieneDuplicadosVolumen = AnyTrue([PosibleDuplicado])` en el grupo persona/día (de 03_VolumenPersonaDia).  
**R19.3** — `TieneDuplicadosVSH = AnyTrue([PosibleDuplicadoVSH])` en grupo persona/día (de 10_VolumenSinHorasPersonaDia).  
**R19.4** — En el reporte, sección 1 (POSIBLE DUPLICIDAD) tiene prioridad sobre todas las demás.  
**R19.5** — Los duplicados NO se eliminan en ninguna fase del proceso; solo se marcan y propagan.  

Archivo: `Section1.m` q19 + `ModuloLYRA_V047.bas` línea 501.

---

## R20. Reglas de mapeo ausente / ambiguo

**R20.1 — SIN MAPEO:** 13_VolumenMapeadoSPEC.EstadoMapeoFinal = "SIN MAPEO" cuando no hay coincidencia en 12_MapeoActividadSPEC por (SAP_CODE, CUSTOMER, WMS_TASK).  
**R20.2 — AMBIGUO:** EstadoMapeoFinal = "AMBIGUO" cuando hay coincidencia pero NumeroTasksSPEC > 1.  
**R20.3 — SIN TASK_SPEC:** EstadoMapeoFinal = "SIN TASK_SPEC" cuando hay coincidencia pero NumeroTasksSPEC = 0.  
**R20.4 — En el reporte (sección 5):** si EstadoMapeoFinal <> "UNICO" → el registro cae en sección 5 con REVISAR.  

---

## R21. Reglas de ambigüedad IdNumerico

**R21.1 — Definición:** `EsAmbiguoIdNumerico = NumeroLoginsDistintos > 1` (de 05_VolumenIdNumericoDia).  
**R21.2 — Propagación:** 07_Conciliacion la recibe vía LEFT OUTER JOIN con 05.  
**R21.3 — En el reporte (sección 7):** si `es_ambiguo_idnum_conc AND modo = "REVISION MANUAL - AMBIGUEDAD ID NUMERICO"` → sección 7.  

---

## R22. Reglas de coherencia (08_Validaciones)

22 KPIs de validación (ver detalle en INFORME_AUDITORIA.md). Los críticos:  
- Horas totales conservadas (origen vs resultado) → OK si diff < 0.000001  
- Volumen neto conservado (antes vs después mapping) → OK si diff < 0.000001  
- Registros volumen conservados (filas no multiplicadas por mapping) → OK si recuento igual  

Archivo: `Section1.m` q20.
