# PRUEBAS DE EQUIVALENCIA EXCEL vs WEB

> Resultados de la matriz de validación comparando los resultados REALES del Excel original (presentes en las 14 hojas del xlsm) contra los resultados producidos por el port web JavaScript con los mismos 4 archivos de entrada.

---

## 1. Configuración del test

**Script de test:** `/home/z/my-project/scripts/05_test_equivalencia.js`

**Estrategia:**
1. Leer el xlsm SPEC V0.47.3.xlsm y los 4 archivos de entrada con SheetJS (mismo motor que usa la web en producción).
2. Ejecutar el port JS (`analizarYConciliar`) con los 4 archivos de entrada.
3. Leer las 14 hojas resultantes del xlsm (que ya contienen los resultados calculados por Power Query + VBA).
4. Comparar:
   - Recuento de filas por tabla.
   - Recuento de columnas por tabla.
   - Nombre de las columnas.
   - KPIs de 16_ControlMapeoSPEC.
   - KPIs de 08_Validaciones.
   - Secciones del REPORTE_CAMBIOS_HR.

---

## 2. Matriz de validación

### 2.1 Recuentos de filas por tabla

| Tabla | Filas Excel | Filas JS | Diff | Estado |
|---|---|---|---|---|
| 01_HorasSinVolumen | 116 | 116 | 0 | OK ✓ |
| 02_VolumenDetalle | 743 | 743 | 0 | OK ✓ |
| 09_VolumenSinHorasDetalle | 245 | 245 | 0 | OK ✓ |
| 12_MapeoActividadSPEC | 134 | 134 | 0 | OK ✓ |
| 13_VolumenMapeadoSPEC | 743 | 743 | 0 | OK ✓ |
| 03_VolumenPersonaDia | 212 | 212 | 0 | OK ✓ |
| 05_VolumenIdNumericoDia | 196 | 196 | 0 | OK ✓ |
| 10_VolumenSinHorasPersonaDia | 83 | 83 | 0 | OK ✓ |
| 14_VolumenPersonaDiaActividadSPEC | 310 | 310 | 0 | OK ✓ |
| 15_VolumenSinHorasPersonaDiaActividadSPEC | 92 | 92 | 0 | OK ✓ |
| 16_ControlMapeoSPEC | 13 | 13 | 0 | OK ✓ |
| 07_Conciliacion | 116 | 116 | 0 | OK ✓ |
| 08_Validaciones | 18 | 18 | 0 | OK ✓ |
| REPORTE_CAMBIOS_HR | 214 | 214 | 0 | OK ✓ |

**Resumen: 14/14 OK con diff = 0 (equivalencia EXACTA).**

> **Nota sobre el conteo:** La cuenta de filas se realiza sobre filas de datos (sin cabecera). El script `05_test_equivalencia.js` utiliza `aoa.slice(1).filter(r => r.some(c => c != null))` para obtener solo filas de datos del Excel, garantizando una comparación justa con `array.length` del JS.

### 2.2 Estructura de columnas

| Tabla | Cols Excel | Cols JS | Estado |
|---|---|---|---|
| 07_Conciliacion | 65 | 65 | OK ✓ Estructura idéntica |
| REPORTE_CAMBIOS_HR | 20 | 20 | OK ✓ Estructura idéntica |
| 16_ControlMapeoSPEC | 3 | 3 | OK ✓ Estructura idéntica |
| 08_Validaciones | 5 | 5 | OK ✓ (verificado en inspección) |

**Resumen: 4/4 OK.** Las columnas tienen los mismos nombres y en el mismo orden.

### 2.3 KPIs de 16_ControlMapeoSPEC (comparativa valor a valor)

| Control | Excel | JS | Estado |
|---|---|---|---|
| Mapeos TASK_WMS cargados | 134 (Excel: 135 con cabecera) | 134 | OK |
| WMS Task distintas en volumen | 81 | 81 | OK |
| WMS Task con mapeo unico (TASK_SPEC) | 67 | 67 | OK |
| WMS Task con mapeo ambiguo (TASK_SPEC) | 3 | 3 | OK |
| WMS Task sin mapeo | 11 | 11 | OK |
| Volumen positivo total | 266.902 | 266.902 | OK |
| Volumen positivo mapeado UNICO | 265.512 | 265.512 | OK |
| Volumen positivo AMBIGUO | 1.022 | 1.022 | OK |
| Volumen positivo SIN MAPEO | 368 | 368 | OK |
| Volumen positivo SIN LOGIN | 112.055 | 112.055 | OK |
| Volumen positivo UNICO sin ambiguedad IdNumerico | 140.866 | 140.866 | OK |
| Cobertura volumen positivo mapeado (total) | 99,48% | 99,48% | OK |
| Cobertura volumen positivo atribuible (real) | 52,78% | 52,78% | OK |

**Resumen: 13/13 OK.** Todos los KPIs numéricos coinciden exactamente.

### 2.4 KPIs de 08_Validaciones

| Control | Excel | JS | Estado |
|---|---|---|---|
| Registros horas validos | 116/116 | 116/116 | OK |
| Horas totales conservadas | 321,33 h | 321,33 h | OK |
| Volumen neto conservado | 266.253 / 266.253 | 266.253 / 266.253 | OK |
| Volumen positivo conservado | 266.902 / 266.902 | 266.902 / 266.902 | OK |
| Volumen negativo conservado | -649 / -649 | -649 / -649 | OK |
| Registros volumen conservados | 743/743 | 743/743 | OK |
| Registros VSH | 245 | 245 | OK |
| Total VSH | 151.880 | 151.880 | OK |
| Duplicados horas | 0 | 0 | OK |
| Duplicados volumen | 0 | 0 | OK |
| Duplicados VSH | 0 | 0 | OK |
| WMS Task sin mapeo | 11 | 11 | REVISAR (ambos) |
| WMS Task con mapeo ambiguo | 3 | 3 | REVISAR (ambos) |
| Volumen sin login (registros) | 8 | 8 | INFORMATIVO (ambos) |
| Volumen sin login (unidades) | 112.055 | 112.055 | INFORMATIVO (ambos) |
| Logins unicos sin volumen positivo | 97 | 97 | INFORMATIVO (ambos) |
| Casos unicos multi HR Task | 0 | 0 | REVISAR (ambos) |
| Colisiones IdNumerico | 10 | 10 | REVISAR (ambos) |

**Resumen: 18/18 OK.** Todos los KPIs de validación coinciden exactamente.

### 2.5 Secciones del REPORTE_CAMBIOS_HR

| Sección | Filas Excel | Filas JS | Estado |
|---|---|---|---|
| 1. CAMBIO HR TASK PROPUESTO | 93 | 93 | OK |
| 2. VARIAS TASKSPEC CON VOLUMEN | 19 | 19 | OK |
| 3. HR TASK CORRECTA | 48 | 48 | OK |
| 4. SIN VOLUMEN | 51 | 51 | OK |
| 5. WMS TASK SIN MAPPING | 3 | 3 | OK |
| 6. REVISION MANUAL - MULTIPLES HR TASK | 0 | 0 | OK |
| 7. REVISION MANUAL - AMBIGUEDAD ID NUMERICO | 0 | 0 | OK |
| **TOTAL** | **214** | **214** | **OK** |

**Resumen: 7/7 OK.** Distribución de secciones idéntica.

---

## 3. Casos de prueba específicos (datos reales)

### 3.1 Login con prefijo + número (caso típico)

**Entrada:** Fila de HORA SIN VOLUMEN.xlsx con `WMS Login = "EU1020"`.

**Procesamiento:**
- `fx_NormalizaTexto("EU1020")` → `"EU1020"`
- `fx_NormalizaLogin("EU1020")`:
  - LoginOriginal = "EU1020"
  - LoginOriginalLimpio = "EU1020" (sin separadores que quitar)
  - Letras = "EU"
  - Digitos = "1020"
  - IdNumericoLiteral = "1020"
  - IdNumericoNormalizado = "1020" (Number("1020")="1020", sin ceros a quitar)
  - IdNumerico = "1020"
  - Canonico = "EU" + "1020" = "EU1020"
  - Prefijo = "EU"

**Resultado esperado:** LoginCanonico = "EU1020", IdNumericoNormalizado = "1020", Prefijo = "EU". ✓

### 3.2 Login con ceros iniciales

**Entrada:** `WMS Login = "EU00123"`.

**Procesamiento:**
- Letras = "EU", Digitos = "00123"
- IdNumericoLiteral = "00123" (conserva ceros)
- IdNumericoNormalizado = "123" (Number("00123")=123, vuelve a "123")
- IdNumerico = "00123" (alias del literal)
- Canonico = "EU" + "00123" = "EU00123"
- Prefijo = "EU"

**Resultado esperado:** Canonico conserva ceros ("EU00123"); IdNumericoNormalizado los pierde ("123"). ✓

### 3.3 Mismo IdNumerico con distinto prefijo

**Escenario:** Dos logins `EU1020` y `XX1020` (mismo número 1020, distinto prefijo).

**Procesamiento en 02_VolumenDetalle:**
- Ambos pasan por `fx_NormalizaLogin` y terminan con `IdNumericoNormalizado = "1020"`.

**En 05_VolumenIdNumericoDia:**
- Se agrupan ambos bajo la clave (Fecha, IdNumericoNormalizado="1020").
- `NumeroLoginsDistintos = 2` (EU1020 y XX1020).
- `EsAmbiguoIdNumerico = True` (porque >1 login).

**En 07_Conciliacion:** EsAmbiguoIdNumerico se propaga vía JOIN M3.

**En REPORTE_CAMBIOS_HR:**
- Si `01_HorasSinVolumen` tiene el login EU1020 y en VOLUMEN solo hay XX1020:
  - Pass 1 (LOGIN EXACTO con EU1020) → no match.
  - Pass 2 (MISMO NUMERO DISTINTO PREFIJO con IdNumNorm=1020) → match con XX1020.
  - Como `EsAmbiguoIdNumerico = True` → modo = "REVISION MANUAL - AMBIGUEDAD ID NUMERICO".
  - Sección = "7. REVISION MANUAL - AMBIGUEDAD ID NUMERICO" si `encontrados > 0` y la condición del modo se cumple.

### 3.4 Login vacío

**Entrada:** `WMS Login = null` o `""`.

**Procesamiento:**
- `fx_NormalizaTexto(null)` → null
- `fx_NormalizaLogin(null)`:
  - LoginOriginal = null
  - Todos los campos null

**En 01_HorasSinVolumen:**
- `RegistroValido = False`
- `MotivoInvalido = "LOGIN VACIO"`
- Filtrado fuera de la salida.

**En 02_VolumenDetalle:**
- `RegistroValido = (Fecha≠null AND VolumenNeto≠null AND WMS_TASK≠null)` → si fecha y volumen válidos, sigue siendo válido.
- `LoginCanonico = null`.
- En 16_ControlMapeoSPEC: `Volumen positivo SIN LOGIN = sumar` → estas filas contribuyen a ese KPI.

### 3.5 Volumen cero

**Entrada:** Fila de VOLUMEN.xlsx con `WMS_UOM = 0`.

**Procesamiento:**
- VolumenNeto = 0
- VolumenPositivo = 0
- VolumenNegativo = 0
- EsVolumenCero = True

**Resultado:** La fila sigue siendo válida (RegistroValido=True) si Fecha y WMS_TASK son válidos. Contribuye a `RegistrosCero` en 03_VolumenPersonaDia y a "Registros WMS cero" en Evidencia de 07_Conciliacion.

### 3.6 Volumen negativo

**Entrada:** `WMS_UOM = -15`.

**Procesamiento:**
- VolumenNeto = -15
- VolumenPositivo = 0 (no negativo)
- VolumenNegativo = -15

**Resultado:** Contribuye a `VolumenTotalNegativo` en 03_VolumenPersonaDia y a "Registros WMS negativos" en Evidencia.

### 3.7 Duplicado exacto (ClaveNatural repetida)

**Escenario:** Dos filas en HORA SIN VOLUMEN.xlsx con mismo Site name, Fecha, LoginCanonico, Department, Activity, Subactivity, HR Task y HorasSinVolumen.

**Procesamiento:**
- Ambas filas tienen la misma `ClaveNatural`.
- En la fase `Conteos` (GROUP BY ClaveNatural) → `RepeticionesClave = 2` para esa clave.
- `PosibleDuplicado = True` para ambas filas.
- En 07_Conciliacion: `TieneDuplicadosVolumen = True` (AnyTrue de PosibleDuplicado en el grupo persona/día).

**Resultado en el reporte:** La sección del reporte será "1. CAMBIO HR TASK PROPUESTO" si hay match, pero la fila de 07_Conciliacion tendrá `Clasificacion = "POSIBLE DUPLICIDAD"`.

### 3.8 Tarea sin mapeo

**Escenario:** En VOLUMEN.xlsx, fila con `WMS_TASK = "TAREA_NUEVA"` que no existe en Mapping.xlsx.

**Procesamiento:**
- En 12_MapeoActividadSPEC no hay entrada para (SAP_CODE, CUSTOMER, "TAREA_NUEVA").
- En 13_VolumenMapeadoSPEC, el LEFT OUTER JOIN no encuentra match → `EstadoMapeoFinal = "SIN MAPEO"`.
- En 16_ControlMapeoSPEC: la fila contribuye a `WMS Task sin mapeo`.
- En 08_Validaciones: la fila contribuye a `WMS Task sin mapeo SPEC`.

### 3.9 Mapeo ambiguo

**Escenario:** En Mapping.xlsx, para (SAP_CODE="ES146L", CUSTOMER="INDITEX ECOM", TASK_WMS="X"), hay 2 TASK_SPEC distintas ("20052" y "20053").

**Procesamiento:**
- En 12_MapeoActividadSPEC: `NumeroTasksSPEC = 2`, `EstadoMapeoSPEC = "AMBIGUO"`, `TasksSPEC = "20052 | 20053"`.
- En 13_VolumenMapeadoSPEC: `EstadoMapeoFinal = "AMBIGUO"` para todas las filas con esa clave.
- En 14_VolumenPersonaDiaActividadSPEC: como el filtro es `EstadoMapeoFinal = "UNICO"`, estas filas no entran.
- En 16_ControlMapeoSPEC: contribuye a `WMS Task con mapeo ambiguo`.
- En REPORTE_CAMBIOS_HR (líneas que matchean estas filas):
  - Como `item.estado = "AMBIGUO" ≠ "UNICO"`, van a sección 5 "WMS TASK SIN MAPPING" con REQUIERE="REVISAR" (aunque exista match).

### 3.10 Persona con horas pero sin volumen

**Escenario:** `01_HorasSinVolumen` tiene fila con IdRegistroHoras=5 para EU1020 el 2025-05-10, pero en `13_VolumenMapeadoSPEC` no hay ninguna fila con Fecha=2025-05-10 y LoginCanonico=EU1020 (ni siquiera con IdNumNorm=1020).

**Procesamiento en REPORTE_CAMBIOS_HR:**
- `encontrados = 0` (ni Pass 1 ni Pass 2 acertaron).
- Sección = "4. SIN VOLUMEN", REQUIERE = "REVISAR", obs = "No existe volumen positivo por fecha y login ni por fecha y numero."

### 3.11 Persona con volumen pero sin horas

**Escenario:** En VOLUMEN.xlsx hay una fila para EU1020 en 2025-05-10, pero en HORA SIN VOLUMEN.xlsx no hay entrada para EU1020 en esa fecha.

**Procesamiento:**
- Esta fila SÍ está en 02_VolumenDetalle.
- En 03_VolumenPersonaDia se agrupa.
- En 07_Conciliacion, como el LEFT OUTER JOIN parte de 01_HorasSinVolumen, esta fila no se refleja en 07_Conciliacion.
- En 08_Validaciones: "Volumen sin login (registros)" captura estos casos cuando LoginCanonico=null; pero si LoginCanonico=EU1020, no aparecen en ningún KPI específico. La persona simplemente no tiene alerta en 07_Conciliacion.

### 3.12 Coincidencia exacta (Pass 1)

**Escenario:** 01_HorasSinVolumen con EU1020/2025-05-10, y 13_VolumenMapeadoSPEC con EU1020/2025-05-10 y TasksSPEC="20052".

**Procesamiento:**
- Pass 1: key = `2025-05-10_long | EU1020` → encuentra match en dRowsExacto.
- encontrados = 1.
- Si `EstadoMapeoFinal = "UNICO"` y TasksSPEC = "20052" (sin " | "):
  - Si Normalizar(hrTask) == "20052" → sección 3 "HR TASK CORRECTA".
  - Si no → sección 1 "CAMBIO HR TASK PROPUESTO".

### 3.13 Hora crítica (>4h)

**Entrada:** `Hours without volume = 5.5`.

**Procesamiento:**
- `calcularMaterialidad(5.5)` → "CRITICA >= 4 H".

### 3.14 Hora micro (<5min)

**Entrada:** `Hours without volume = 0.04`.

**Procesamiento:**
- 0.04 < 0.0833333333 (UmbralMicroHoras) → "MICRO < 5 MIN".

---

## 4. (Reservado para futuras ampliaciones)

No hay diferencias sistemáticas que explicar: el port JS reproduce exactamente los recuentos, KPIs y estructura del Excel original.

---

## 5. Resultado global

| Métrica | Excel | JS | Diferencia | Estado |
|---|---|---|---|---|
| Recuentos de filas (14 tablas y reporte) | 14/14 | 14/14 | 0 | OK |
| Estructura de columnas (todas) | idéntica | idéntica | 0 | OK |
| KPIs de 16_ControlMapeoSPEC (13) | idénticos | idénticos | 0 | OK |
| KPIs de 08_Validaciones (18) | idénticos | idénticos | 0 | OK |
| Distribución de secciones del reporte (7) | idéntica | idéntica | 0 | OK |

**ESTADO FINAL:** ✓ EQUIVALENCIA CONFIRMADA

**Criterio de aceptación cumplido:**
- ✓ Coincidencia exacta en textos, estados y clasificaciones.
- ✓ Coincidencia exacta en recuentos (descontando la cabecera cosmética).
- ✓ Coincidencia numérica dentro de tolerancia 0 (sin redondeos).
- ✓ Cero diferencias sin explicar.
- ✓ Ningún registro perdido.
- ✓ Ningún registro adicional.
- ✓ Ninguna regla omitida.

---

## 6. Cómo reproducir este test

```bash
# Pre-requisitos: Node.js 16+ y SheetJS instalado
cd /home/z/my-project
npm install xlsx

# Ejecutar el test
node scripts/05_test_equivalencia.js
```

Salida esperada: "Pasos exitosos: 12, Avisos: 0, Fallos: 0" y todas las estructuras de columnas idénticas.

---

## 6. TEST DE EQUIVALENCIA A NIVEL DE VALORES (celda a celda)

**Script:** `scripts/07_test_equivalencia_valores.js`

**Estrategia:**
1. Lee las 14 hojas del xlsm (valores REALES generados por Power Query + VBA).
2. Ejecuta el port JS con los 4 archivos de entrada.
3. Para cada tabla, ordena ambas (Excel y JS) por una clave canónica (concatenación de todas las columnas normalizadas).
4. Compara celda a celda los valores normalizados:
   - `null`/vacío → `''`
   - `Date` → `yyyy-MM-dd`
   - `number` → string con hasta 12 decimales, separador punto, sin agrupar
   - `boolean` → `'TRUE'`/`'FALSE'`
   - `string` → trimmed

**Resultado:**

| Tabla | Filas | Cols | Celdas comparadas | Diferencias | Rate | Estado |
|---|---|---|---|---|---|---|
| 01_HorasSinVolumen | 116 | 25 | 2.900 | 0 | 0,00% | OK ✓ |
| 02_VolumenDetalle | 743 | 24 | 17.832 | 0 | 0,00% | OK ✓ |
| 09_VolumenSinHorasDetalle | 245 | 23 | 5.635 | 0 | 0,00% | OK ✓ |
| 12_MapeoActividadSPEC | 134 | 14 | 1.876 | 0 | 0,00% | OK ✓ |
| 13_VolumenMapeadoSPEC | 743 | 36 | 26.748 | 0 | 0,00% | OK ✓ |
| 03_VolumenPersonaDia | 212 | 13 | 2.756 | 0 | 0,00% | OK ✓ |
| 05_VolumenIdNumericoDia | 196 | 7 | 1.372 | 0 | 0,00% | OK ✓ |
| 10_VolumenSinHorasPersonaDia | 83 | 8 | 664 | 0 | 0,00% | OK ✓ |
| 14_VolumenPersonaDiaActividadSPEC | 310 | 8 | 2.480 | 0 | 0,00% | OK ✓ |
| 15_VolumenSinHorasPersonaDiaActividadSPEC | 92 | 5 | 460 | 0 | 0,00% | OK ✓ |
| 16_ControlMapeoSPEC | 13 | 3 | 39 | 0 | 0,00% | OK ✓ |
| 07_Conciliacion | 116 | 65 | 7.540 | 0 | 0,00% | OK ✓ |
| 08_Validaciones | 18 | 5 | 90 | 0 | 0,00% | OK ✓ |
| REPORTE_CAMBIOS_HR | 214 | 20 | 4.280 | 0 | 0,00% | OK ✓ |
| **TOTAL** | | | **74.672** | **0** | **0,00%** | **14/14 OK** |

**Cero diferencias de valor en 74.672 celdas comparadas.**

> **Nota histórica (AUD-MED-001):** Versiones anteriores de este documento mostraban
> "74.172" — se trataba de un typo por transposición de dígitos. El cálculo real
> (verificado por `scripts/_cell_count.cjs` y `reports/EQUIVALENCE_MACHINE_RESULT.json`)
> es **74.672 celdas**. Documentado en el informe de auditoría independiente como
> hallazgo AUD-MED-001.

### 6.1 Bugs encontrados y corregidos gracias a este test

Este test de valores detectó **3 bugs críticos** que pasaron desapercibidos en el test de recuentos:

1. **`deepClone` no manejaba Date correctamente**: trataba `Date` como objeto plano y devolvía `{}`. Esto rompía `Fecha` en `07_Conciliacion` (todos los valores aparecían como `[object Object]`), lo que a su vez rompía el JOIN con `NumActHR` (calculado por `(Fecha, LoginCanonico)`), poniendo `NumeroHRTaskDistintas=0` para TODAS las filas. Eso propagaba errores a `es_multi_hr_task`, al modo `REVISION MANUAL - MULTIPLES HR TASK`, a la sección 6 del reporte, etc.  
   **FIX:** Añadido `if (obj instanceof Date) return new Date(obj.getTime());` en `deepClone`.

2. **`fx_TransformaVolumen` no filtraba filas TOTAL/FILTROS APLICADOS**: a diferencia de `fx_TransformaHoras` y `fx_TransformaVolumenSinHoras` (que sí lo hacían), `fx_TransformaVolumen` solo filtraba filas vacías. La versión M original filtra `[DATE] <> null AND not StartsWith("TOTAL") AND not Contains("FILTROS APLICADOS")`.  
   **FIX:** Añadido el filtro correcto en `fx_TransformaVolumen`.

3. **`formatNum2` y `formatNum0` usaban `useGrouping: true`**: añadían separador de miles (`2.237`) donde el M original no lo hace (`2237`). El formato M `"0"` y `"0.00"` no incluyen separador de miles.  
   **FIX:** Cambiado `useGrouping: false` en ambas funciones.

Sin el test a nivel de valores, estos bugs hubieran pasado desapercibidos porque el test de recuentos solo verificaba conteos de filas y nombres de columnas, no los valores internos.
