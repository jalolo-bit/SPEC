# MANUAL DE USUARIO - SPEC LYRA Web

> Guía de uso de la aplicación web que sustituye al Excel SPEC V0.47.3.xlsm.

---

## 1. REQUISITOS

**Navegador:**
- Microsoft Edge 88 o superior (recomendado)
- Google Chrome 88 o superior
- Otros navegadores modernos con soporte ES2017+ (Firefox 78+, Safari 14+)

**Sistema operativo:**
- Windows 10/11, macOS 11+, o Linux actual

**Archivos de entrada necesarios:**
1. `HORA SIN VOLUMEN.xlsx` — hoja "Export" con columnas: Site name, Department, Activity, Subactivity, Date, HR Task, WMS Login, Name, Hours without volume.
2. `VOLUMEN.xlsx` — hoja "Export" con columnas: DATE, SAP_CODE, CUSTOMER, WMS_TASK, WMS_LOGIN, USER_NAME, WMS_UOM.
3. `VOL SIN HORAS.xlsx` — hoja "Export" con columnas: Site name, Department, Activity, Subactivity, Date, HR Task, WMS Login, Name, Volume Without Hours.
4. `Mapping.xlsx` — hoja "Mapping" con columnas: SAP_CODE, WMS_DC, CUSTOMER, DEPARTMENT, ACTIVITY, SUB_ACTIVITY, TASK_WMS, TASK_SPEC (las hojas "Direct Budget" e "Indirect Budget" se ignoran en V0.47.3).

**Tamaño típico:** < 1 MB por archivo. Tiempo de procesamiento: < 1 segundo.

---

## 2. INSTALACIÓN

**Opción A — Versión autónoma (recomendada para uso puntual):**
1. Copia el archivo `SPEC_LYRA_AUTONOMO.html` (770 KB) a tu equipo.
2. Doble clic para abrirlo en tu navegador.
3. Listo. No requiere instalación ni servidor.

**Opción B — Versión modular (recomendada para personalizar):**
1. Copia la carpeta con estos 5 archivos a tu equipo:
   - `index.html` (11 KB)
   - `styles.css` (13 KB)
   - `app.js` (76 KB)
   - `ui.js` (30 KB)
   - `xlsx.full.min.js` (882 KB, biblioteca SheetJS)
2. Doble clic en `index.html`.
3. Listo.

**Importante:** Para la versión modular, los 5 archivos deben estar en la misma carpeta. Si abres `index.html` con `file://`, el navegador cargará `xlsx.full.min.js`, `styles.css`, `app.js` y `ui.js` desde la misma carpeta.

---

## 3. APERTURA

Al abrir la aplicación verás la pantalla de carga con 4 zonas para soltar archivos (drop zones):

```
┌──────────────────────────────────────────────────────────┐
│ HORA SIN VOLUMEN.xlsx  │  VOLUMEN.xlsx                  │
│ ─────────────────────  │  ─────────────────────         │
│ (Arrastrar o clic)     │  (Arrastrar o clic)             │
│                        │                                │
├──────────────────────────────────────────────────────────┤
│ VOL SIN HORAS.xlsx     │  Mapping.xlsx                  │
│ ─────────────────────  │  ─────────────────────         │
│ (Arrastrar o clic)     │  (Arrastrar o clic)             │
└──────────────────────────────────────────────────────────┘
```

Cada zona muestra:
- El nombre del archivo esperado.
- Las columnas requeridas (para tu referencia).
- El estado actual: "Pendiente" / "nombre_archivo ✓" / "Error: ...".

---

## 4. CARGAR Y ANALIZAR (v6.1 — flujo unificado)

El flujo de v6.1 es **CARGAR → ANALIZAR → REVISAR**: las antiguas pestañas Carga y Proceso se han unificado en una sola, **"Cargar y analizar"**.

1. **Arrastra todos tus archivos Excel a la vez** a la zona grande (o selecciónalos con un clic). La aplicación detecta automáticamente cada tipo: Horas, Volumen, Volumen sin horas y Mapping. Se admiten varios archivos del mismo tipo y de tipos distintos simultáneamente.
2. El checklist superior confirma lo cargado: `✓ Horas (2 archivos) · ✓ Volumen (3) · ✓ Volumen sin horas (1) · ✓ Mapping`.
3. **Mapping activo**: la tarjeta muestra el mapping guardado (nombre, versión, filas, hash SHA-256 y última actualización). La primera vez que importas un mapping queda **guardado** y se reutiliza automáticamente en sesiones futuras, sin volver a subirlo.
4. Para sustituirlo, pulsa **IMPORTAR / ACTUALIZAR MAPPING**: verás una comparación (actual vs nuevo, con hash) y el botón "Usar este nuevo mapping". Los históricos ya guardados no cambian.
5. (Opcional) **Validar archivos** comprueba la estructura antes de analizar.
6. Pulsa **ANALIZAR** (único botón principal): valida, combina, ejecuta el procesamiento en el Web Worker y te lleva automáticamente a **Revisar incidencias**.

> Avanzado: bajo "Carga por tipo (avanzado)" siguen disponibles las zonas individuales por tipo.

## 5. REVISAR INCIDENCIAS (v6.1 — por persona y día)

La unidad de revisión es **PERSONA + FECHA OPERATIVA**: aunque una persona haya fichado varias tareas WMS ese día, verás **una única revisión** con todo su día.

- La lista compacta muestra: persona, fecha, turno, horas, UDS, desviación, nº de actividades y estado de decisión.
- Al desplegar una persona verás: resumen del día, la **tabla de fichajes del día** (ID registro, HR Task, hora y turno de cada fichaje — los registros sin hora muestran «Este registro no contiene hora de fichaje.»), la **tabla de actividades con el reparto de tiempo** (UDS, productividad de referencia, horas equivalentes, peso, horas asignadas y productividad implícita) con **sub-filas por tarea** (TASK_WMS, UDS, productividad, H eq., peso, H asignadas y fuente del valor), y sus **incidencias** con las acciones ACEPTAR / MANTENER / REVISAR / DESHACER.
- **Deshacer** restaura el estado anterior real (funciona también tras acciones consecutivas) y queda registrado en la auditoría.
- **⚙ Productividades de referencia**: edita las productividades medias (uds/h netas) de las 6 actividades; se recalcula el reparto. Los históricos ya guardados conservan sus valores.
- **⚙ → PRODUCTIVIDAD POR TAREA (v6.1.1)**: busca cualquier TASK_WMS (te sugiere las conocidas del mapping y del volumen cargado), asígnale una actividad (incluido convertir una tarea OTRA en productiva) y una productividad > 0, y guarda el **override**. La tabla muestra TASK_WMS | Actividad | Productividad | **Fuente** (DEFAULT / PRODUCTIVIDAD ACTIVIDAD / OVERRIDE TASK_WMS) | Acción (Editar / Resetear). El motor recalcula el reparto inmediatamente con la prioridad override de tarea → productividad de la actividad → default; los históricos ya guardados no cambian (un reprocesado crea una nueva versión trazable).
- Filtro **turno** (v6.1.1 — real, aplicado a la lista): MAÑANA (06:00–14:00), TARDE (14:00–22:00), NOCHE (22:00–06:00, con fecha operativa del día anterior para lo registrado entre 00:00 y 05:59) y MIXTO. Los archivos que solo traen fecha (sin hora) se clasifican "SIN HORA" y **nunca aparecen al filtrar un turno concreto**; si el filtro de turno los oculta, la lista muestra el aviso «Este registro no contiene hora de fichaje.».

## 5b. PATRONES E HISTÓRICOS (v6.1)

La pestaña **Patrones** analiza los registros diarios persistidos en el navegador (IndexedDB): sobreviven al cierre de la aplicación y no se duplican al reprocesar.

- **Filtros combinables**: rango de fechas, persona, turno, actividad, decisión, semana ISO (YYYY-Www) y mes (YYYY-MM).
- **Vistas**: Resumen (KPIs: personas, días, horas analizadas, horas con incidencia, % días con error), Personas (tabla ordenable), Actividades (+ sección *Error de asignación de tarea*: tareas origen/destino, horas y personas afectadas) y Evolución (gráficos por día/semana/mes).
- Toda métrica muestra su fórmula y es reconstruible desde los registros diarios.

## 6. INTERPRETACIÓN DE RESULTADOS

### 6.1 Pestaña "3. Resultados"

Verás:
- **KPIs resumen**: tarjetas con los recuentos clave (registros válidos de horas, volumen, VSH, mapeos SPEC, filas conciliadas, propuestas HR).
- **Lista de tablas disponibles**: cada tabla con su nombre, descripción y número de filas.
- Haz clic en una tabla para verla en una tabla con cabecera fija.

**Tabla interactiva:**
- Búsqueda: escribe en el campo "Buscar..." para filtrar filas.
- Ordenación: haz clic en cualquier cabecera para ordenar ascendente/descendente.
- Paginación: si la tabla tiene más de 1000 filas, solo se muestran las primeras 1000 (usa el buscador para reducir).
- Botones de exportación XLSX y CSV.

### 6.2 Pestaña "4. Reporte HR"

Es la tabla más importante: **REPORTE_CAMBIOS_HR**.

**KPIs arriba:**
- Conteo por sección (1-7).
- Conteo por "Requiere cambio RRHH" (SI / REVISAR / NO).

**Filtros disponibles:**
- Búsqueda libre.
- Filtro por sección.
- Filtro por materialidad (MICRO / BAJA / MEDIA / ALTA / CRITICA).
- Filtro por requiere cambio (SI / NO / REVISAR).

**Tabla con colores por sección:**
- Sección 1 (cambio propuesto): fondo rojo claro.
- Sección 2 (varias TASKSPEC): fondo amarillo claro.
- Sección 3 (HR Task correcta): fondo verde claro.
- Sección 4 (sin volumen): fondo gris claro.
- Sección 5 (sin mapping): fondo amarillo.
- Sección 6 (multi HR Task): fondo lila.
- Sección 7 (ambigüedad IdNumerico): fondo rojo.

**Botones de exportación XLSX y CSV.**

### 6.3 Pestaña "5. Trazabilidad"

Permite trazar una fila concreta hasta su origen.

1. Selecciona la tabla en el desplegable.
2. Introduce el número de fila (1-indexed).
3. Pulsa "Ver trazabilidad".

Verás:
- **Origen del registro**: archivo de origen, fila en el archivo, ID de registro, sección/tipo coincidencia (si es reporte HR).
- **Transformaciones aplicadas**: lista de pasos M / VBA que se ejecutaron sobre esta fila.
- **Registro completo**: todos los valores de la fila en formato `clave → valor`.

---

## 7. USO DE FILTROS

**Búsqueda libre (campo "Buscar..."):**
- Funciona en cualquier tabla visible.
- Busca el texto introducido (case insensitive) en cualquier columna.
- Actualiza la tabla en tiempo real.

**Filtros del Reporte HR:**
- Sección, Materialidad, Requiere Cambio. Combinables.
- Cada filtro tiene una opción "Todas..." / "Todo" para no filtrar.

**Ordenación:**
- Haz clic en una cabecera de tabla para ordenar ascendentemente.
- Haz clic de nuevo para ordenar descendentemente.
- La flecha ▲ o ▼ indica el sentido actual.

---

## 8. EXPORTACIÓN

### 8.1 Exportar tabla individual

En la pestaña "3. Resultados" o "4. Reporte HR":
- Pulsa "Exportar XLSX" o "Exportar CSV".
- El archivo se descarga con el nombre `<tabla>_<fecha_hora>.xlsx` o `.csv`.
- Las columnas mantienen el orden original.
- Las fechas se exportan como tipo fecha con formato dd/MM/yyyy en XLSX, y como texto dd/MM/yyyy en CSV.
- Los números se exportan con formato es-ES (coma decimal, punto miles) en XLSX, y en crudo en CSV.

### 8.2 Exportar todas las tablas

En la pestaña "6. Exportar":
- Lista de todas las tablas disponibles.
- Para cada una, botones XLSX y CSV.

---

## 9. RESOLUCIÓN DE ERRORES

### 9.1 "Faltan columnas: ..."

**Causa:** El archivo no tiene alguna columna requerida.

**Solución:** Abre el archivo Excel y comprueba que la fila 1 tiene los nombres de columna exactamente como se indica en la zona de carga (respetando mayúsculas/minúsculas y espacios).

### 9.2 "No existe una hoja cuyo nombre contenga Mapping"

**Causa:** Mapping.xlsx no tiene una hoja llamada "Mapping" (case insensitive).

**Solución:** Abre Mapping.xlsx, renombra la hoja principal a "Mapping" (sin comillas).

### 9.3 "La hoja Mapping existe, pero faltan estas columnas obligatorias: ..."

**Causa:** La hoja Mapping no tiene las 8 columnas obligatorias (SAP_CODE, WMS_DC, CUSTOMER, DEPARTMENT, ACTIVITY, SUB_ACTIVITY, TASK_WMS, TASK_SPEC).

**Solución:** Verifica que la cabecera de la hoja Mapping tiene esos 8 nombres de columna. Cualquier variación (espacios, mayúsculas) se normaliza automáticamente (UPPER + trim + replace espacios por _), pero los nombres base deben coincidir.

### 9.4 "El archivo no tiene hojas válidas: ..."

**Causa:** El archivo Excel está vacío o corrupto.

**Solución:** Verifica que el archivo se abre correctamente en Excel. Si lo abres y guarda de nuevo como .xlsx, suele resolver problemas de corrupción menor.

### 9.5 La barra de progreso se queda parada

**Causa:** Probablemente el navegador está procesando. Las operaciones son síncronas.

**Solución:** Espera hasta 30 segundos. Si no avanza, refresca la página (F5) y vuelve a intentarlo. Si persiste, intenta con un navegador más moderno o con menos archivos abiertos.

### 9.6 El reporte tiene 0 filas

**Causa:** Los archivos no tienen registros válidos (todos filtrados por RegistroValido).

**Solución:** Revisa el log en la pestaña "2. Proceso" para ver los recuentos de cada etapa. Si 01_HorasSinVolumen tiene 0 filas válidas, revisa que las horas sean numéricas y >0, que los logins no estén vacíos, que las fechas sean válidas.

---

## 10. LIMITACIONES CONOCIDAS

1. **Un único archivo por tipo.** Excel original usa `Folder.Files` para leer una carpeta con varios archivos del mismo tipo. La web acepta un solo archivo por tipo. Si tienes varios archivos del mismo tipo, concaténalos manualmente o carga solo uno.
2. **No ejecuta el Excel original como referencia.** Las pruebas de equivalencia se basan en los resultados pre-calculados del xlsm (que se asumen correctos). No hay un motor VBA ni Power Query real ejecutándose.
3. **Las hojas `Direct Budget` e `Indirect Budget` de Mapping.xlsx no son leídas** ni en V0.47.3 ni en esta web (potencial evolutivo futuro).
4. **Sin autenticación ni persistencia.** Al cerrar la pestaña se pierden los datos. Exporta antes de cerrar.
5. **Solo en español.** La interfaz y los mensajes están en español (igual que el Excel original).
6. **Sin gráficos.** Los resultados se presentan solo en tablas. (Potencial evolutivo futuro.)

---

## 11. ATAJOS DE TECLADO

- `Tab` / `Shift+Tab`: navegar entre elementos.
- `Enter` en una zona de drop: abre el selector de archivo.
- `Esc`: cierra el visor de tabla si está abierto.

---

## 12. SOPORTE Y CONTACTO

Para incidencias, contactar con el equipo de desarrollo indicando:
1. Archivos de entrada utilizados (con tamaños).
2. Mensaje exacto del error (copia del log area).
3. Versión de navegador y sistema operativo.
4. Captura de pantalla si es posible.

## Patrones — estadística avanzada e inteligencia operativa (v6.2)

Abre **Patrones** para responder, con el histórico acumulado (sobrevive al
cierre del navegador): ¿quién se equivoca más? ¿qué tareas se fichan peor?
¿dónde actuar primero? ¿mejoramos o empeoramos?

- **Resumen**: KPIs con tooltip ℹ (fórmula y denominador), evolución actual
  vs anterior en puntos porcentuales, **TOP 5 dónde poner el ojo** (índice de
  prioridad transparente 0-100 con desglose) y **alertas** deterministas.
- **Personas/Tareas/Actividades**: ordena por cualquier columna; clic en una
  fila abre el **perfil histórico** (drill-down). La MUESTRA PEQUEÑA se marca
  siempre (no se sacan conclusiones con 1-2 días).
- **Errores**: matriz fichada→correcta (confusiones recurrentes) y errores
  recurrentes por persona (AISLADO/RECURRENTE/HABITUAL).
- **Evolución**: gráficos diarios/semana/mes con media móvil y comparación de
  periodos (personas que mejoran / empeoran).
- **Pareto**: concentración real 80/20 y matriz frecuencia×impacto.
- **Calidad de datos**: separa problema operativo de problema de mapping.
- **⚙ Configuración estadística**: ajusta umbrales y pesos a tu criterio.
- **Exportar analítica**: XLSX de cada vista con los filtros activos.

Los filtros de la cabecera (fecha, turno, persona, actividad, TASK_WMS,
cliente, mapping…) afectan a TODAS las vistas a la vez.

