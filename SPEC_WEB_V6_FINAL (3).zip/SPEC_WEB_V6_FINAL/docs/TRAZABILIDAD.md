# TRAZABILIDAD DE RESULTADOS

> Cómo se traza cada resultado hasta su origen en los archivos de entrada.  
> Aplica a las 14 tablas del sistema y al REPORTE_CAMBIOS_HR.

---

## 1. Modelo general de trazabilidad

Cada fila de cada tabla resultante tiene **3 marcadores de origen**:

| Marcador | Significado | Dónde está |
|---|---|---|
| `ArchivoOrigen` | Nombre del archivo de entrada del que proviene la fila | Columna en 01, 02, 13 (columna `ArchivoOrigen`) y 09 (`ArchivoOrigenVSH`) |
| `FilaOrigen` | Número de fila en el archivo original (1-indexed, fila 1 = cabecera) | Columna `FilaOrigen` o `FilaOrigenVSH` |
| `IdRegistroHoras` | Identificador interno de 01_HorasSinVolumen (1..N, único) | Columna `IdRegistroHoras` en 01 y 07; en REPORTE_CAMBIOS_HR se llama `ID REGISTRO` |

**Tablas que NO tienen marcadores de origen directos:**
- 03, 05, 10, 12, 14, 15, 16 — son agregadas. Sus filas representan combinaciones de claves, no filas individuales.
- 08 — KPIs globales, no filas origen.

**Trazabilidad para tablas agregadas:** se traza por sus claves de grupo:
- 03: por (Fecha, LoginCanonico) — se puede llegar a 02 filtrando por Fecha+LoginCanonico
- 05: por (Fecha, IdNumericoNormalizado)
- 10: por (Fecha, LoginCanonico) — desde 09
- 14: por (Fecha, LoginCanonico, ActividadSPEC) — desde 13
- 15: por (Fecha, LoginCanonico, Activity) — desde 09
- 12: por (SAP_CODE, CUSTOMER, TASK_WMS) — desde Mapping.xlsx

---

## 2. Linaje por tabla

### 2.1 01_HorasSinVolumen (117 filas en Excel real → 116 válidas)

```
HORA SIN VOLUMEN.xlsx
  └─ Hoja "Export" (119 filas crudas)
     └─ fx_TransformaHoras
        ├─ FiltrarPie (quita TOTAL/FILTROS APLICADOS)
        ├─ SelectColumns(Site name, Department, Activity, Subactivity, Date, HR Task, WMS Login, Name, Hours without volume, MissingField.Error)
        ├─ AddColumn(ArchivoOrigen = nombre archivo)
        └─ AddColumn(FilaOrigen = índice+2)
     → 119 filas transformadas
     └─ q01_HorasSinVolumen
        ├─ Renombrar Date→FechaOriginal, WMS Login→WMSLoginOriginal, Hours without volume→HorasSinVolumen
        ├─ AddColumn(Fecha = fx_Fecha(FechaOriginal))
        ├─ TransformColumns(HorasSinVolumen = Number.From)
        ├─ TransformColumns(Site name, Department, Activity, Subactivity, HR Task, Name = fx_NormalizaTexto)
        ├─ AddColumn(LoginRec = fx_NormalizaLogin(WMSLoginOriginal))
        ├─ ExpandRecordColumn(LoginRec) → 7 columnas
        ├─ AddColumn(RegistroValido = Fecha≠null AND LoginCanonico≠null AND Activity≠null AND HorasSinVolumen≠null AND HorasSinVolumen>0)
        ├─ AddColumn(MotivoInvalido = primer motivo que aplique)
        ├─ AddColumn(ClaveNatural)
        ├─ Group(ClaveNatural) → RepeticionesClave
        ├─ NestedJoin LEFT OUTER → expand RepeticionesClave
        ├─ AddColumn(PosibleDuplicado = RepeticionesClave > 1)
        ├─ AddColumn(IdRegistroHoras = índice 1..N)
        └─ Filter(RegistroValido = true)
     → 116 filas (117 en Excel; diff=1 puede ser por filtrado pie distinto)
```

### 2.2 02_VolumenDetalle (744 filas en Excel → 743 en JS)

Mismo patrón, sin MotivoInvalido, con VolumenPositivo/VolumenNegativo/EsVolumenCero calculados.

### 2.3 09_VolumenSinHorasDetalle (246 → 245)

Mismo patrón que 01 con renombrados con sufijo VSH.

### 2.4 12_MapeoActividadSPEC (135 → 134)

```
Mapping.xlsx (hoja "Mapping", 167 filas)
  └─ Excel.Workbook + búsqueda de hoja "MAPPING" (case insensitive)
     └─ PromoteHeaders
     └─ Normalizar nombres de columnas (UPPER + clean + replace NBSP por espacio + replace espacios por _)
     └─ Validación de columnas obligatorias (MissingField.Error si falta alguna)
     └─ SelectColumns(8 columnas)
     └─ TransformColumns(fx_NormalizaTexto en las 8)
     └─ Filter(SAP_CODE≠null AND CUSTOMER≠null AND TASK_WMS≠null)
     └─ Group by (SAP_CODE, CUSTOMER, TASK_WMS)
        ├─ NumeroActividadesSPEC = count distinct ACTIVITY
        ├─ ActividadesSPECPosibles = JOIN sorted distinct
        ├─ ActividadSPEC = si solo 1 → valor, si no null
        ├─ NumeroTasksSPEC, TasksSPECPosibles, TasksSPEC (siempre JOIN)
        ├─ DepartamentosSPEC, SubactividadesSPEC, WMS_DCs
        └─ TieneMultipleWMS_DC
     └─ AddColumn(EstadoMapeoSPEC)
        = NumeroTasksSPEC = 0 → "SIN TASK_SPEC"
        = 1 → "UNICO"
        > 1 → "AMBIGUO"
     → 134 filas agrupadas
```

### 2.5 13_VolumenMapeadoSPEC (744 → 743)

```
02_VolumenDetalle (743)
  └─ NestedJoin LEFT OUTER con 12_MapeoActividadSPEC por (SAP_CODE, CUSTOMER, WMS_TASK=TASK_WMS)
     └─ ExpandTableColumn → 11 columnas añadidas
  └─ AddColumn(EstadoMapeoFinal = EstadoMapeoSPEC ?? "SIN MAPEO")
  → 743 filas (una por fila de 02)
```

### 2.6 07_Conciliacion (117 → 116)

```
01_HorasSinVolumen (116)  ← BASE
  └─ M1: LEFT OUTER JOIN con 03_VolumenPersonaDia por (Fecha, LoginCanonico) → 11 cols añadidas
  └─ M2: LEFT OUTER JOIN con 14_VolumenPersonaDiaActividadSPEC por (Fecha, LoginCanonico, Activity=ActividadSPEC) → 5 cols
  └─ M3: LEFT OUTER JOIN con 05_VolumenIdNumericoDia por (Fecha, IdNumericoNormalizado) → 5 cols
  └─ M4: LEFT OUTER JOIN con 10_VolumenSinHorasPersonaDia por (Fecha, LoginCanonico) → 6 cols
  └─ M5: LEFT OUTER JOIN con 15_VolumenSinHorasPersonaDiaActividadSPEC por (Fecha, LoginCanonico, Activity) → 2 cols
  └─ ReplaceValue null→0 (15 columnas numéricas)
  └─ TransformColumns null→false (3 booleanos)
  └─ AddColumn(VolumenOtrasActividadesPositivo = MAX(0, VolumenTotalPositivo - VolumenMismaActividadPositivo))
  └─ NumActHR (group by Fecha, LoginCanonico de H) → 4 cols adicionales via M6 JOIN
  └─ AddColumn(Clasificacion)  ← ver catálogo de reglas R13
  └─ AddColumn(NivelConfianza)
  └─ AddColumn(Evidencia)  ← texto concatenado
  └─ AddColumn(Explicacion)
  └─ AddColumn(AccionRecomendada)
  └─ AddColumn(Materialidad)
  → 116 filas × 65 columnas
```

### 2.7 16_ControlMapeoSPEC (14 → 13)

```
12_MapeoActividadSPEC + 13_VolumenMapeadoSPEC + 05_VolumenIdNumericoDia
  └─ Distinct de claves (SAP_CODE, CUSTOMER, WMS_TASK) en V filtrando por EstadoMapeoFinal
  └─ Sum de VolumenPositivo segmentado por estado
  └─ CoberturaTotal = MapeadoPositivo / TotalPositivo
  └─ CoberturaAtribuible = UnicoAtribuible / TotalPositivo
  └─ #table con 13 filas (Control, Valor, Estado)
```

### 2.8 08_Validaciones (19 → 18)

```
01_HorasSinVolumen + 02_VolumenDetalle + 09_VolumenSinHorasDetalle
+ 07_Conciliacion + 13_VolumenMapeadoSPEC + 05_VolumenIdNumericoDia
  └─ #table con 18 filas (Control, ValorOrigen, ValorResultado, Estado, Detalle)
```

### 2.9 REPORTE_CAMBIOS_HR (215 → 214)

```
VBA GenerarReporteCambiosHR:
  Lee 01_HorasSinVolumen (H, 116 filas) ← FOR EACH (fh = 2..uh)
  Lee 13_VolumenMapeadoSPEC (VM, 743 filas) ← pre-indexa por (Fecha|LoginCanonico) y (Fecha|IdNumNorm)
  Lee 07_Conciliacion (C, 116 filas) ← lookup lineal por IdRegistroHoras
  
  Para cada fh en H:
    Si Fecha inválida → siguiente
    LoginH = Normalizar(LoginCanonico)
    idH = Normalizar(IdNumericoNormalizado)
    hrTask = Trim(HR Task)
    
    filaConc = buscar en C por IdRegistroHoras (lineal)
    Si filaConc encontrada:
      es_multi_hr_task = (NumeroHRTaskDistintas > 1)
      es_ambiguo_idnum_conc = (EsAmbiguoIdNumerico = True)
    
    Pass 1: LOGIN EXACTO (Fecha + LoginCanonico)
      dRowsExacto[fecha|loginH] → para cada fv:
        Si VolumenPositivo(fv) > 0:
          dFilas.Add([TasksSPEC, VolumenPositivo, WMS_TASK, SAP_CODE, CUSTOMER, WMS_DCs, ArchivoOrigen, FilaOrigen, LoginCanonico, EstadoMapeoFinal])
          encontrados++
    
    Pass 2 (si encontrados=0): MISMO NUMERO, DISTINTO PREFIJO
      dRowsIdNum[fecha|idH] → mismo proceso
      Si es_ambiguo_idnum_conc → modo = "REVISION MANUAL - AMBIGUEDAD ID NUMERICO"
    
    Si es_multi_hr_task → modo = "REVISION MANUAL - MULTIPLES HR TASK"
    
    Si encontrados = 0:
      Escribir Propuesta: SECCION="4. SIN VOLUMEN", REQUIERE="REVISAR"
    
    Si no:
      Conteo H-05/H-05b: dTsUnicas = TasksSPEC distintas (excluyendo las que contengan " | ")
      Para cada item en dFilas:
        Clasificar en sección 1-7
        Escribir Propuesta (una fila por match)
  
  Resultado: 214 filas × 20 columnas
```

---

## 3. Cómo trazar una fila del REPORTE_CAMBIOS_HR hasta su origen

Dada una fila del reporte con `ID REGISTRO = X`:

1. Buscar en `01_HorasSinVolumen` la fila con `IdRegistroHoras = X` → ahí tienes ArchivoOrigen + FilaOrigen (la fichada original).
2. Si la fila del reporte tiene `FILA ORIGEN = Y` y `ARCHIVO ORIGEN = Z`, eso te lleva directamente al volumen: buscar en `VOLUMEN.xlsx` fila Y, y ese es el match que generó la propuesta.
3. Si `TIPO COINCIDENCIA = "MISMO NUMERO, DISTINTO PREFIJO"`, entonces el match no fue por login exacto, sino por IdNumerico normalizado. Consulta `07_Conciliacion` fila con `IdRegistroHoras = X` para ver `LoginsMismoNumero` y `EsAmbiguoIdNumerico`.

---

## 4. Cómo trazar una fila de 07_Conciliacion hasta su origen

Dada una fila de `07_Conciliacion` con `IdRegistroHoras = X`:

1. La fila base proviene de `01_HorasSinVolumen` (filtrada por `IdRegistroHoras = X`). Ahí está ArchivoOrigen + FilaOrigen.
2. Las columnas `VolumenTotalPositivo, VolumenTotalNegativo, ...` provienen de `03_VolumenPersonaDia` para el grupo (Fecha, LoginCanonico) de esta fila. Para trazarlo: ir a `02_VolumenDetalle` y filtrar por Fecha+LoginCanonico.
3. Las columnas `VolumenMismaActividadPositivo, ...` provienen de `14_VolumenPersonaDiaActividadSPEC` para el grupo (Fecha, LoginCanonico, Activity). Para trazar: ir a `13_VolumenMapeadoSPEC` y filtrar por Fecha+LoginCanonico+ActividadSPEC=Activity (con EstadoMapeoFinal=UNICO).
4. Las columnas `VolumenMismoNumeroPositivo, EsAmbiguoIdNumerico, ...` provienen de `05_VolumenIdNumericoDia` para el grupo (Fecha, IdNumericoNormalizado).
5. Las columnas `VolumenSinHorasPersonaDia, ...` provienen de `10_VolumenSinHorasPersonaDia` para el grupo (Fecha, LoginCanonico). Para trazar: ir a `09_VolumenSinHorasDetalle` y filtrar por Fecha+LoginCanonico.
6. Las columnas `VolumenSinHorasMismaActividad, ...` provienen de `15_VolumenSinHorasPersonaDiaActividadSPEC` para el grupo (Fecha, LoginCanonico, Activity).
7. `NumeroActividadesHR, NumeroHRTaskDistintas, HRTaskDistintas, HorasTotalesPersonaDia` provienen de un GROUP BY interno de 01_HorasSinVolumen por (Fecha, LoginCanonico).

---

## 5. Matriz de trazabilidad (resumen)

| Tabla | Origen directo | Marcadores | Cardinalidad |
|---|---|---|---|
| 01_HorasSinVolumen | HORA SIN VOLUMEN.xlsx (Hoja "Export") | ArchivoOrigen, FilaOrigen, IdRegistroHoras | 1 fila = 1 fila cruda del archivo |
| 02_VolumenDetalle | VOLUMEN.xlsx (Hoja "Export") | ArchivoOrigen, FilaOrigen | 1 fila = 1 fila cruda |
| 09_VolumenSinHorasDetalle | VOL SIN HORAS.xlsx (Hoja "Export") | ArchivoOrigenVSH, FilaOrigenVSH | 1 fila = 1 fila cruda |
| 12_MapeoActividadSPEC | Mapping.xlsx (Hoja "Mapping") | (SAP_CODE, CUSTOMER, TASK_WMS) | 1 fila = 1 grupo de Mapping |
| 13_VolumenMapeadoSPEC | 02 × 12 (LEFT OUTER JOIN) | ArchivoOrigen + FilaOrigen (heredados de 02) + (SAP_CODE, CUSTOMER, WMS_TASK) | 1 fila = 1 fila de 02 |
| 03_VolumenPersonaDia | 02 (GROUP BY) | (Fecha, LoginCanonico) | 1 fila = 1 persona/día |
| 05_VolumenIdNumericoDia | 02 (GROUP BY) | (Fecha, IdNumericoNormalizado) | 1 fila = 1 número/día |
| 10_VolumenSinHorasPersonaDia | 09 (GROUP BY) | (Fecha, LoginCanonico) | 1 fila = 1 persona/día |
| 14_VolumenPersonaDiaActividadSPEC | 13 (GROUP BY, filtrado UNICO) | (Fecha, LoginCanonico, ActividadSPEC) | 1 fila = 1 persona/día/ActividadSPEC |
| 15_VolumenSinHorasPersonaDiaActividadSPEC | 09 (GROUP BY) | (Fecha, LoginCanonico, Activity) | 1 fila = 1 persona/día/Activity |
| 16_ControlMapeoSPEC | M + VM + VID (KPIs) | (sin marcadores, es un resumen) | 13 filas fijas |
| 07_Conciliacion | 01 + 03 + 14 + 05 + 10 + 15 (JOINs) | IdRegistroHoras + (Fecha, LoginCanonico) + ArchivoOrigen + FilaOrigen | 1 fila = 1 registro de 01 |
| 08_Validaciones | H + V + VSH + C + VM + VID (KPIs) | (sin marcadores) | 18 filas fijas |
| REPORTE_CAMBIOS_HR | H + VM + C (VBA) | ID REGISTRO + ARCHIVO ORIGEN + FILA ORIGEN | 1 fila = 1 propuesta (0..N por registro de H) |
