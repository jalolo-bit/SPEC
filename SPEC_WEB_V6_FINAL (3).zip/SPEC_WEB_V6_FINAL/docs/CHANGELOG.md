# CHANGELOG — SPEC Web

## v6.2.0 (2026-10-06) — Módulo de Estadística Avanzada e Inteligencia Operativa (Patrones)

La pestaña PATRONES se transforma en un sistema de detección y priorización
de problemas de calidad de fichaje. La equivalencia con SPEC V0.47.3 sigue
INTACTA (14/14 tablas, 0 mismatches, 74.672 celdas re-verificado tras todos
los cambios; el módulo es 100% aditivo).

### Capa analítica (nueva, cálculos puros sin DOM)
- `analytics/analyticsCore.js`: configuración estadística persistente (24
  umbrales/pesos editables, NADA oculto), divisiones seguras (nunca
  NaN/Infinity), clasificación de las 7 secciones (tipo + causa
  OPERATIVO/DATOS/REVISIÓN/CONTROL), normalización defensiva de históricos
  v6.1/v6.1.1, filtros globales combinables (fecha/semana/mes/persona/turno/
  actividad/TASK_WMS/cliente/mapping), KPIs con denominadores y comparación
  de periodos en puntos porcentuales.
- `person/task/activity/confusion/trend/pareto/alerts/dataQuality`: rankings
  con frecuencia+tasa+impacto+confianza juntos (§8: no castigar por más días
  analizados), semáforo MUY BUENO→CRÍTICO documentado, imputación de errores
  SOLO a la TASK_WMS realmente afectada (§11), espacios separados TASK_WMS y
  tarea fichada (HR Task), matriz fichada→correcta con heatmap, recurrencia
  persona+pareja con persistencia AISLADO/RECURRENTE/HABITUAL, series
  diarias/semana/mes con media móvil solo con ventana completa, rolling
  7/28, Pareto con comprobación REAL de 80/20, matriz frecuencia×impacto por
  medianas, alertas deterministas A1-A11, índice de prioridad transparente
  (0-100, desglose visible) y top 5 «dónde poner el ojo», calidad de datos y
  del mapping con separación operativo vs datos.

### Modelo histórico (extensión aditiva)
- Incidencias enriquecidas: `wmsTask` (WMS TASK CON VOLUMEN → imputación),
  `volumen`, `tipoCoincidencia`, `cliente`, `sapCode`.
- Tareas con `tasksSpec` y `cliente` (dimensiones de análisis).
- `productivityVersion`/`overrideVersion` (hashes deterministas de la
  configuración usada) y `datasetFingerprint` (alias estable).
- El `dataFingerprint` NO cambia por los campos nuevos: los históricos
  previos no se versionan espuriamente.
- Nueva métrica `horasErrorDedup`: horas afectadas solo por errores reales
  (sección ≠ 3), dedup por registro (los controles correctos ya no inflan el
  impacto).

### UI (8 vistas + configuración + exportación)
- RESUMEN (KPIs con tooltip de fórmula/denominador + evolución comparada +
  TOP 5 prioridades con desglose + alertas + quién/qué/dónde) · PERSONAS ·
  TAREAS · ACTIVIDADES (+ turnos + OTRA) · ERRORES (matriz + recurrentes) ·
  EVOLUCIÓN (gráficos de líneas con MM + periodos) · PARETO · CALIDAD DE
  DATOS.
- ⚙ CONFIGURACIÓN ESTADÍSTICA: todos los umbrales editables y persistidos.
- Drill-down: clic en persona/tarea/actividad → perfil histórico (§34/§35/§36).
- Exportación XLSX: resumen, personas, tareas, actividades, errores,
  evolución e histórico diario completo con dimensiones.
- Filtros globales nuevos: TASK_WMS, cliente, mapping (afectan a TODO).

### Tests
- +136 Vitest (11 archivos nuevos: núcleo, personas, tareas, actividades,
  confusiones, tendencias, Pareto, alertas, calidad, batería de casos
  extremos §58 sin NaN/Infinity, extensión del record).
- +14 E2E (patrones_v62.spec.js: los 14 escenarios obligatorios §59,
  incluyendo histórico vacío, acumulación sin duplicados, persistencia tras
  cierre, versionado por cambio de mapping y por override).
- Total: **558/558 reales** (502 Vitest + 56 Playwright) · a11y 5/5 · perf
  3/3 · equivalencia 14/14/0/74672 · validate_manifest PASS ·
  validate_release PASS.

### Documentación
- NUEVOS: `reports/ADVANCED_ANALYTICS_SPEC.md`,
  `reports/HISTORICAL_ANALYTICS_MODEL.md`,
  `reports/ANALYTICS_METRICS_DICTIONARY.md`.
- Actualizados: CHANGELOG, README, MANUAL_USUARIO, RELEASE_FINAL,
  TEST_RESULTS_FINAL, INFORME_REGRESION (apéndice v6.2.0).

## v6.1.1 (2026-10-02) — Corrección y cierre de dos puntos funcionales

Sobre la v6.1: NO hay nueva auditoría ni funcionalidades nuevas; se corrigen
y cierran dos puntos que no estaban completamente implementados. La
equivalencia con SPEC V0.47.3 sigue INTACTA (14/14 tablas, 0 mismatches,
74.672 celdas re-verificado tras todos los cambios).

### 1 — Filtro REAL de turnos en Revisar incidencias
- Nueva función centralizada `SPEC.filtrarRegistrosPorTurno(registros, turno)`:
  la MISMA función filtra Revisar, Patrones, Persona/Día e históricos (antes
  el select de turno era informativo en la cadena de filtrado).
- MAÑANA 06:00≤h<14:00 · TARDE 14:00≤h<22:00 · NOCHE 22:00≤h<06:00 (hora
  exacta por fichaje, sin huecos ni solapamientos).
- **SIN HORA**: los archivos day-level NUNCA aparecen al filtrar un turno
  concreto. Aviso explícito «Este registro no contiene hora de fichaje.» en
  la lista (cuando el filtro de turno los oculta) y en el detalle por fichaje.
- Nueva tabla «Fichajes del día» en el detalle persona/día: ID registro · HR
  Task · hora · turno · horas.
- Fecha operativa nocturna mantenida: 22:00–23:59 → fecha actual ·
  00:00–05:59 → fecha anterior (tests obligatorios del usuario).

### 2 — PRODUCTIVIDAD POR TAREA (overrides por TASK_WMS)
- Nueva sección compacta «PRODUCTIVIDAD POR TAREA» dentro de ⚙
  Productividades de referencia: buscar TASK_WMS (datalist con las tareas
  conocidas del mapping y del volumen cargado; también admite nombres
  escritos a mano), seleccionar actividad, productividad, guardar, editar y
  resetear. Persistencia en `localStorage['spec_task_overrides']`.
- Tabla TASK_WMS | Actividad | Productividad | **Fuente** | Acción, donde
  Fuente distingue `DEFAULT` / `PRODUCTIVIDAD ACTIVIDAD` / `OVERRIDE TASK_WMS`
  (y `OTRA` para tareas fuera del reparto).
- **OTRA editable**: una tarea OTRA puede reasignarse a cualquier actividad
  productiva (se exige productividad > 0). Ej.: REPARTO A TIENDA AGV -
  BERSHKA → PICKING AGV → 150 uds/h. Las ambigüedades del mapping se
  resuelven AHORA directamente desde este editor.
- **Motor corregido (modelo por tarea)**: `q17_PersonaDiaAnalitica` agrega
  el volumen por TASK_WMS (antes por ACTIVIDAD_ANALISIS antes de resolver
  productividad — dos tareas de la misma actividad con productividades
  distintas compartían una sola). Nueva `resolverClasificacionTarea()` con
  prioridad EXACTA: override de tarea → productividad de su actividad →
  default. NUNCA se usa la productividad de otro TASK_WMS.
- `repartirTiemposPorTarea()`: HE_TAREA = UDS_TAREA/PRODUCTIVIDAD_TAREA ·
  PESO_TAREA = HE_TAREA/ΣHE_PERSONA_DÍA · H_ASIGNADAS_TAREA =
  H_ANALIZABLES×PESO_TAREA, conservación < 1e-9.
- Agregación VISUAL por ACTIVIDAD_ANALISIS sumando sus tareas: la fila de
  actividad muestra «varias» cuando sus tareas tienen productividades
  distintas, y el detalle por tarea (TASK_WMS | UDS | Productividad | H eq. |
  Peso | H asignadas | Fuente) se despliega como sub-filas.
- Históricos: guardan el detalle por tarea (TASK_WMS, ACTIVIDAD_ANALISIS,
  PRODUCTIVIDAD, H_EQUIVALENTES, PESO, H_ASIGNADAS) + snapshot de
  `taskOverrides` y `productividades`. Cambiar un override NO modifica los
  históricos existentes; el fingerprint incluye el detalle por tarea → un
  cambio de override genera nueva versión trazable (`previousVersions`).

### Tests (27 unitarios + 8 E2E nuevos)
- `tests/unit/filtro_turnos_real.test.js` (10): MAÑANA→solo 06:30+13:59 ·
  TARDE→solo 14:00+21:59 · NOCHE→solo 22:00+02:00+05:59 · SIN HORA→solo sin
  hora · TODOS · MIXTO · fecha operativa nocturna · day-level sin desplazar.
- `tests/unit/overrides_task.test.js` (17): los 4 casos obligatorios del
  usuario (normal/override/OTRA→actividad/dos tareas misma actividad sin
  mezcla) + prioridad + Fuente + conservación + históricos + fingerprint.
- `tests/e2e/overrides_v612.spec.js` (8): filtro mañana/tarde/noche real,
  SIN HORA con aviso, editar productividad desde la UI, OTRA→PICKING AGV,
  dos tareas misma actividad con productividades distintas, override →
  reprocesar → histórico conserva la versión anterior.
- Fixtures nuevos: `test-data/turnos/{HORAS_OVERRIDE,VOLUMEN_OVERRIDE}.xlsx`
  (límites 13:59/21:59/22:00/02:00 + persona con 3 tareas para overrides).

### Versionado
- package.json / PARAMS.AppVersion / manifest.json (PWA, cache
  `spec-web-v6-1-1`) / sw.js → **6.1.1**. Standalone reconstruido con probes
  v6.1.1. Los históricos nuevos registran `appVersion 6.1.1` (distingue el
  modelo de reparto por tarea del modelo v6.1.0 por actividad).

## v6.1.0 (2026-10-02) — Iteración de mejoras funcionales y analíticas

Seis mejoras solicitadas, todas integradas en la aplicación real y cubiertas
por tests (89 unitarios nuevos + 8 E2E nuevos obligatorios). La equivalencia
con SPEC V0.47.3 queda INTACTA: ninguna de las consultas 01-16 ni el
REPORTE_CAMBIOS_HR se han modificado (14/14 tablas, 0 mismatches, 74.672
celdas re-verificado).

### MEJORA 1 — Filtro de turnos + FECHA_OPERATIVA_TURNO
- `fx_Turno(hora)`: MAÑANA 06:00–14:00 · TARDE 14:00–22:00 · NOCHE 22:00–06:00,
  cobertura completa 0–1439 sin huecos ni solapamientos (test exhaustivo).
- `fx_FechaOperativaTurno(fecha, hora)`: hora < 06:00 → fecha anterior (regla
  del turno nocturno que cruza medianoche); >= 06:00 → fecha actual.
- `extraerHoraFichaje()`: detecta componente horaria real de los seriales Excel
  (serial entero / medianoche exacta = dato day-level → SIN HORA, evita el
  desplazamiento masivo de fechas).
- Filtro turno REAL en Revisar (persona/día y MIXTO) y en Patrones. Convención
  documentada: los archivos day-level actuales se clasifican SIN HORA.

### MEJORA 2 — Carga y Proceso unificados ("Cargar y analizar")
- Las pestañas Carga y Proceso se sustituyen por UNA: **Cargar y analizar**
  (mismo nº total de pestañas, flujo CARGAR → ANALIZAR → REVISAR).
- Zona de carga unificada: drag&drop de TODOS los archivos a la vez con
  detección automática de tipo (estructura de columnas, mutuamente
  excluyente). Se conservan las zonas por tipo (avanzado) y los IDs
  `#drop-*`/`#btn-analizar` (compatibilidad tests/UX).
- Checklist resumen (✓ Horas (N archivos) · Volumen · Volumen sin horas ·
  Mapping) + botón único ANALIZAR + auto-navegación a Revisar incidencias.
- Card "Mapping activo" (nombre, versión, filas, hash, última actualización).

### MEJORA 3 — Mapping persistente por sesión
- IndexedDB `spec_history_db.mappings`: versiones con nombre, fecha, timestamp,
  hash **SHA-256**, versión y nº de filas. Carga automática al abrir la app
  (reconstruye workbook + File para el Worker; sin re-subida).
- "IMPORTAR / ACTUALIZAR MAPPING" con diálogo de confirmación old-vs-new
  (nombre/fecha/hash) antes de sustituir.
- Cada sesión guarda el `mappingHash` (FNV en la cadena de auditoría por
  compatibilidad; SHA-256 en el versionado). Los históricos NO cambian al
  cambiar el mapping (snapshot por registro).

### MEJORA 4 — Revisar incidencias por PERSONA + FECHA_OPERATIVA
- Nueva unidad de análisis: una persona/día = UNA revisión (antes, una
  incidencia por tarea WMS).
- Campo único centralizado `ACTIVIDAD_ANALISIS` (6 actividades + OTRA) con las
  reglas explícitas del usuario; tareas ambiguas → OTRA sin productividad
  inventada (ver reports/MAPPING_AMBIGUITIES.md).
- Reparto de tiempos por horas equivalentes (uds/productividad media):
  HORAS_EQUIVALENTES · PESO · HORAS_ASIGNADAS con conservación EXACTA
  (error flotante ~1e-15; redondeo solo de presentación).
- Productividades editables (editor persistente) + overrides por tarea.
  Productividad implícita claramente etiquetada.
- Vista compacta (persona, fecha, turno, horas, uds, desviación, nº
  actividades, decisión) con detalle desplegable: tabla de actividades con
  reparto + incidencias con acciones.

### MEJORA 5 — UNDO real, persistente y auditable
- Bug fix: `undoDecision` usaba findIndex (la entrada MÁS ANTIGUA del id) →
  con acciones consecutivas restauraba un estado obsoleto. Ahora usa el
  núcleo puro `SPEC.undoApply` (entrada MÁS RECIENTE).
- Cada acción registra `estadoAnterior`/`estadoPosterior` + sessionId +
  timestamp + mappingHash en el audit log (hash chain SHA-256). El undo se
  REGISTRA (no borra auditoría), actualiza IndexedDB, pantalla e históricos.
- El undoStack se persiste en `spec_decisions` (localStorage + IDB backup).

### MEJORA 6 — Patrones con históricos (PERSON_DAILY_RECORD)
- Modelo `PERSON_DAILY_RECORD` (clave `login|fechaOperativaISO`) persistido en
  IndexedDB `spec_history_db.person_daily_records`. Sin duplicados: upsert
  por clave con fingerprint; cambios → nueva versión con `previousVersions`
  (trazabilidad, cap 10).
- Pestaña Patrones rehecha: filtros combinables (fecha, persona, turno,
  actividad, decisión, semana ISO, mes) y vistas RESUMEN (KPIs) · PERSONAS
  (tabla ordenable: días, días con error, horas afectadas, % error, error
  medio) · ACTIVIDADES (+ **ERROR DE ASIGNACIÓN DE TAREA**: volumen, horas,
  personas, tareas origen/destino) · EVOLUCIÓN (gráficos SVG día/semana/mes).
- Métricas transparentes: fórmulas documentadas junto a cada vista.

### Corregido durante la iteración (detectado por los propios tests)
- Bucle infinito de MutationObserver en el checklist de carga (re-entrancia).
- Race condition: dos análisis consecutivos intercalaban sus upserts de
  históricos (persistencia ahora SERIALIZADA con cola).
- Doble recuento de horas en incidencias multi-propuesta (dedupe por registro).
- `dataFingerprint` de los records usaba `calcularMappingHash` con un string
  (todas las huellas colisionaban a un valor constante) → `fnv1aStr` propio.
- Auto-navegación post-análisis ya no pisa pestañas visitadas durante el
  análisis; `UI.activeTab` inicial corregido a `cargaanalizar`.
- Estilos v6.1 con variables temáticas reales (contraste AA en modo oscuro).

### Tests
- **339 Vitest** (250 previos + 89 nuevos: turnos 27, actividad 20, reparto 12,
  persona/día 15, undo 11, mapping persist 8 — desglose por archivo).
- **30 Playwright** (22 previos con selectores adaptados + 8 E2E v6.1
  obligatorios: carga unificada, mapping persistente, cambio de mapping con
  nuevo hash, 2-tareas-una-revisión, reparto correcto, undo restaurado,
  dos días persistentes, filtro NOCHE).
- Fixtures nuevos en `test-data/turnos/` (horas con hora real 23:30/02:15/
  05:59/06:00/14:30 + MIXTO + mapping v2 con hash distinto).

## v6.0.0-post-audit (2026-10-02) — Certified Release

Auditoría de certificación independiente (P9). La fuente de verdad de todas las
cifras es la ejecución real de tests y scripts, no informes previos.

### Corregido (detectado por la auditoría de certificación)

- **Regresión M-07/M-10**: `initMappingData` (ui.js) seguía leyendo
  `archivos.mapping.workbook` (formato legacy) tras el refactor multi-archivo
  que guarda arrays. La pestaña Mapping quedaba VACÍA tras el flujo normal de
  carga. Ahora soporta ambos formatos y fusiona todos los workbooks de mapping
  (mismo criterio que `analizarYConciliar`). Test E2E de regresión añadido.
- **Standalone `SPEC_AUTONOMO_v6.html`**: era un motor antiguo renombrado a v6
  (sin M-01 FORMULA_PREFIXES, sin audit log SHA-256, sin R-06, sin M-04/M-05).
  Reconstruido desde el código v6.0 real. El generador (`06_build_autonomo.py`)
  ahora ABORTA si faltan los probes de seguridad. CSP del standalone con
  hashes SHA-256 de cada script inline (sin `unsafe-inline`). Test E2E añadido.
- **CI `.github/workflows/ci.yml`**: YAML inválido (línea `npm audit ... echo
  "WARN: ..."` con `: ` sin entrecomillar → workflow no-parseable). Corregido
  y validado con parser YAML real (9 jobs).
- **Scripts no portables**: `_cell_count.cjs`, `05_test_equivalencia.js`,
  `07_test_equivalencia_valores.js` (require en proyecto ESM + rutas
  inexistentes), `_manual_cover.cjs` y Python 01-04/06 (rutas absolutas del
  entorno original). Todos convertidos a rutas relativas verificadas desde
  instalación limpia.
- **Estado vacío de filtros Mapping**: tbody en blanco al filtrar 0 filas;
  añadido mensaje explícito.
- **Validador `validate_release.cjs`**: el check de cifras antiguas de tests
  era código muerto (detectaba pero no fallaba). Activado, junto con piso
  estático de recuento de tests, detección de cifras/archivos obsoletos,
  validación heurística de CI YAML, verificación de tags @perf y guard de
  regresión M-07/M-10.
- **Comentarios obsoletos** en `tests/unit/regression_bugs.test.js` que
  afirmaban que el fix de formatNum "NO está aplicado" y describían un
  mecanismo `it.fails` inexistente.

### Añadido (exigido por la auditoría)

- `tests/unit/audit_log_chain.test.js` (22 tests): 6 escenarios de manipulación
  del hash chain SHA-256 (cadena correcta, entrada modificada, entrada
  eliminada, hash eliminado, prevHash modificado, orden alterado) + verificación
  de que no existe fallback FNV.
- `tests/unit/input_validation.test.js` (24 tests): archivo vacío, corrupto,
  columnas incorrectas, demasiado grande, estructura malformada, lenitud
  documentada de SheetJS y cadena de defensa en 4 capas de la app.
- `tests/e2e/indexeddb.spec.js` (2 tests): FASE 9 — ciclo completo de
  persistencia (crear → persistir → reabrir → recuperar → borrar localStorage
  → recuperar desde IndexedDB → integridad del audit log en cada paso).
- `tests/e2e/mapping.spec.js` (1 test): FASE 10 — visualización (167 filas),
  búsqueda, filtros, creación, edición, eliminación, duplicados, ambigüedades
  y audit log íntegro.
- `tests/e2e/pwa.spec.js` (4 tests): FASE 14 — manifest válido, registro real
  del Service Worker, caché de recursos core y funcionamiento OFFLINE.
- `tests/e2e/performance_e2e.spec.js` (3 tests @perf): FASE 17 — `npm run
  test:perf` ejecutaba 0 tests ("No tests found"); ahora mide análisis real
  (<30s), render de tabla de 743 filas con virtual scrolling (<5s, DOM<300) y
  ausencia de degradación en segunda pasada.
- `tests/e2e/multifile_worker.spec.js`: test adicional FASE 3 con 2 archivos
  de CADA tipo (2+2+2+1) procesados íntegramente en el Worker sin fallback.
- `tests/e2e/standalone.spec.js` (1 test): motor v6.0 del standalone, CSP por
  hashes, 214 propuestas equivalentes, audit log SHA-256.

### Cifras de la última ejecución real

- Vitest: **250/250** (14 archivos) · Playwright: **26/26** · Total **276/276**
- Equivalencia: **14/14 tablas, 0 mismatches, 0 structural issues, 74.672 celdas**
- Lint: 0 errores / 16 warnings · Cobertura instrumentada: 0% (documentado)

## v6.0.0 (2026-10-02, previo a certificación) — Post-Audit Release

Port verificado del sistema Excel/VBA/Power Query a vanilla JS. 14/15 mejoras
(M-01..M-12, M-14, M-15), equivalencia 14/14 con 0 mismatches, manifest de
integridad, SBOM CycloneDX, PWA offline, CI/CD. Ver `RELEASE_FINAL.md`.

## v5.x (histórico)

Versión auditada previamente (ver `reports/FINAL_VALIDATION_REPORT.md`,
contexto histórico). El typo "74.172" celdas de su documentación se conserva
como histórico (AUD-MED-001); el valor real verificado es 74.672.
