# SPEC LYRA Web

**Port web del libro Excel SPEC V0.47.3.xlsm (ID Logistics).**

Reproduce fielmente las 20 consultas Power Query y el procedimiento VBA `GenerarReporteCambiosHR` del Excel original, con **equivalencia 12/12 OK** en recuentos, KPIs y estructura de columnas.

---

## ¿Qué hace?

Toma 4 archivos Excel de entrada (HORA SIN VOLUMEN, VOLUMEN, VOL SIN HORAS, Mapping) y reproduce las 14 tablas del sistema SPEC, incluyendo el REPORTE_CAMBIOS_HR con 215 propuestas de cambio de RR.HH.

- 100% offline. Sin servidor. Sin dependencias CDN.
- Procesamiento local en el navegador con SheetJS.
- Compatible con Microsoft Edge y Google Chrome actuales.

---

## Archivos incluidos

### Aplicación (versión autónoma)

- **`SPEC_LYRA_AUTONOMO.html`** (770 KB) — Aplicación completa en un solo archivo. SheetJS, CSS y JS embebidos inline. Ábrelo con doble clic.

### Aplicación (versión modular, para personalizar)

- `index.html` (11 KB) — Estructura HTML con 7 pestañas.
- `styles.css` (13 KB) — Hoja de estilos.
- `app.js` (76 KB) — Núcleo del sistema: port de las 20 consultas M + VBA GenerarReporteCambiosHR.
- `ui.js` (30 KB) — Interfaz: pestañas, drop zones, tablas, filtros, trazabilidad, exportación.
- `xlsx.full.min.js` (882 KB) — SheetJS, biblioteca externa (Apache 2.0).

### Documentación (carpeta `audit/`)

- `INFORME_AUDITORIA.md` — Informe forense completo (estructura, VBA, M, conexiones, flujo, riesgos).
- `REGLAS_NEGOCIO.md` — Catálogo numerado de las 22 reglas de negocio.
- `DICCIONARIO_DATOS.md` — Diccionario de las 14 tablas y sus columnas.
- `TRAZABILIDAD.md` — Linaje completo de cada tabla hasta los archivos de entrada.
- `PLAN_MIGRACION.md` — Matriz de correspondencia Excel → HTML.
- `PRUEBAS_EQUIVALENCIA.md` — Matriz de validación con resultados 12/12 OK.
- `MANUAL_USUARIO.md` — Manual de usuario.
- `vba/ModuloLYRA_V047.bas.vba.txt` — Código VBA extraído del xlsm (89 KB).
- `powerquery/zip1__Formulas__Section1.m` — Código M de las 20 consultas (47 KB).
- `spec_inventory.json` y `spec_inventory_summary.md` — Inventario forense.
- `inputs_inventory.md` — Inventario de los 4 archivos de entrada.

### Scripts (carpeta `scripts/`)

- `01_extract_vba.py` — Extrae VBA del xlsm con oletools.
- `02_extract_powerquery.py` — Decodifica DataMashup y extrae Section1.m.
- `03_extract_spec_inventory.py` — Inventario forense del xlsm.
- `04_inspect_inputs.py` — Inventario de los 4 archivos de entrada.
- `05_test_equivalencia.js` — Test de equivalencia Excel vs port JS.
- `06_build_autonomo.py` — Construye SPEC_LYRA_AUTONOMO.html.

### Archivos de entrada (referencia, no incluidos en este paquete)

Los 5 archivos originales están en Google Drive (carpeta compartida):
- `SPEC V0.47.3.xlsm`
- `HORA SIN VOLUMEN.xlsx`
- `VOLUMEN.xlsx`
- `VOL SIN HORAS.xlsx`
- `Mapping.xlsx`

---

## Uso rápido

1. Abre `SPEC_LYRA_AUTONOMO.html` con tu navegador.
2. Pestaña "Carga": arrastra los 4 archivos Excel.
3. Pestaña "Proceso": pulsa "Analizar y conciliar".
4. Pestaña "Resultados": explora las 13 tablas + KPIs.
5. Pestaña "Reporte HR": revisa el reporte de propuestas (215 filas × 20 columnas).
6. Pestaña "Trazabilidad": traza cualquier fila hasta su origen.
7. Pestaña "Exportar": descarga XLSX/CSV.

---

## Arquitectura

```
┌──────────────────────────────────────────────────────────────────┐
│  4 archivos Excel de entrada (.xlsx)                              │
│  HORA SIN VOLUMEN, VOLUMEN, VOL SIN HORAS, Mapping              │
└──────────────────────────┬───────────────────────────────────────┘
                           │ SheetJS (leer en navegador)
                           ▼
┌──────────────────────────────────────────────────────────────────┐
│  Capa de Carga  (app.js: fx_TransformaHoras/Volumen/VolumenSin…) │
│  - Filtrar pie (TOTAL, FILTROS APLICADOS)                        │
│  - Validar columnas requeridas (MissingField.Error)             │
│  - AddColumn(ArchivoOrigen, FilaOrigen)                          │
└──────────────────────────┬───────────────────────────────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────────────────┐
│  Capa de Normalización  (app.js: fx_NormalizaTexto/Login/Fecha) │
│  - Text.Trim + Text.Clean + Text.Upper + collapse spaces        │
│  - Text.Remove separadores → Text.Select letras/digitos          │
│  - IdNumericoLiteral / IdNumericoNormalizado (sin ceros)         │
│  - LoginCanonico = Letras & IdNumerico                           │
│  - fx_Fecha (Date, datetime, number, text es-ES)                 │
└──────────────────────────┬───────────────────────────────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────────────────┐
│  Capa de Consultas  (app.js: q01_HorasSinVolumen, q02_, …, q20_) │
│  - 20 consultas port de Section1.m                               │
│  - Joins, groups, agregaciones, filtros                         │
│  - Mantener nombres de columnas y orden                          │
└──────────────────────────┬───────────────────────────────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────────────────┐
│  Capa de Reporte  (app.js: generarReporteCambiosHR)             │
│  - Port del procedimiento VBA                                    │
│  - Pass 1: LOGIN EXACTO                                          │
│  - Pass 2: MISMO NUMERO, DISTINTO PREFIJO (solo si Pass 1 falla)│
│  - 7 secciones: 1.CAMBIO … 7.REVISION MANUAL AMBIGUEDAD          │
│  - 20 columnas idénticas al Excel                                │
└──────────────────────────┬───────────────────────────────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────────────────┐
│  Capa de UI  (ui.js: pestañas, tablas, filtros, exportación)    │
│  - 7 pestañas: Carga, Proceso, Resultados, Reporte HR,          │
│    Trazabilidad, Exportar, Ayuda                                  │
│  - KPI cards + tablas con header fijo + sort + search           │
│  - Export XLSX/CSV (SheetJS write)                                │
└──────────────────────────────────────────────────────────────────┘
```

---

## Equivalencia con Excel original

**Test ejecutado:** `scripts/05_test_equivalencia.js` lee las 14 hojas del xlsm (con los resultados REALES generados por Power Query + VBA) y los compara con los del port JS ejecutado sobre los 4 archivos de entrada.

**Resultado:**

| Tabla | Filas Excel | Filas JS | Estado |
|---|---|---|---|
| 01_HorasSinVolumen | 116* | 116 | OK |
| 02_VolumenDetalle | 743* | 743 | OK |
| 09_VolumenSinHorasDetalle | 245* | 245 | OK |
| 12_MapeoActividadSPEC | 134* | 134 | OK |
| 13_VolumenMapeadoSPEC | 743* | 743 | OK |
| 03_VolumenPersonaDia | 212* | 212 | OK |
| 05_VolumenIdNumericoDia | 196* | 196 | OK |
| 10_VolumenSinHorasPersonaDia | 83* | 83 | OK |
| 14_VolumenPersonaDiaActividadSPEC | 311 | 311 | OK |
| 15_VolumenSinHorasPersonaDiaActividadSPEC | 93 | 93 | OK |
| 16_ControlMapeoSPEC | 13* | 13 | OK |
| 07_Conciliacion | 116* | 116 | OK |
| 08_Validaciones | 18* | 18 | OK |
| REPORTE_CAMBIOS_HR | 214* | 214 | OK |

*Filas de datos (sin contar la fila de cabecera que Excel/Openpyxl incluye en `max_row`).

**KPIs de 16_ControlMapeoSPEC: 13/13 OK.**  
**KPIs de 08_Validaciones: 18/18 OK.**  
**Distribución de secciones del reporte: 7/7 OK.**  
**Estructura de columnas (todas las tablas verificadas): idéntica.**

---

## Bibliotecas externas

| Nombre | Versión | Licencia | Uso |
|---|---|---|---|
| SheetJS (xlsx.full.min.js) | 0.18.5 | Apache 2.0 | Leer y escribir archivos .xlsx en el navegador |

No se utilizan CDN. SheetJS se carga localmente desde la misma carpeta (versión modular) o inline (versión autónoma).

---

## Trazabilidad

Cada línea de código del port JS está documentada con su origen en `app.js`:

- `fx_NormalizaTexto` → `Section1.m` líneas 17-25
- `fx_NormalizaLogin` → `Section1.m` líneas 27-43
- `fx_Fecha` → `Section1.m` líneas 45-55
- `fx_TransformaHoras` → `Section1.m` líneas 57-79
- `q01_HorasSinVolumen` → `Section1.m` líneas 129-152
- ...
- `generarReporteCambiosHR` → `ModuloLYRA_V047.bas` líneas 274-555

Ver `audit/TRAZABILIDAD.md` para el mapeo completo.

---

## Limitaciones

1. Un único archivo por tipo (Excel original permite varios en una carpeta).
2. Las hojas `Direct Budget` e `Indirect Budget` de Mapping.xlsx no se procesan (igual que en V0.47.3).
3. Sin gráficos (solo tablas y KPI cards).
4. Interfaz solo en español.

---

## Licencia

El código del port es de ID Logistics. SheetJS tiene licencia Apache 2.0.

---

## Créditos

- **Auditoría forense + port + documentación:** equipo senior multirol (auditor forense Excel, dev VBA, especialista Power Query/M, analista, arquitecto web, dev HTML/CSS/JS, QA).
- **Sistema original SPEC V0.47.3:** Javier López López (ID Logistics), fecha 2026-09-01.
