/* ============================================================================
 * SPEC Web — Charts: visualizaciones SVG vanilla (sin librerías externas)
 *
 * Genera:
 *   - Bar chart horizontal de distribución de secciones del reporte HR
 *   - Bar chart horizontal de distribución de materialidad
 *   - Gauge de cobertura (total vs atribuible)
 * ========================================================================== */
(function () {
'use strict';

const CHARTS = {};

/* Paleta corporativa ID Logistics + complementarios */
const PALETTE = {
  blue: '#1a3256',
  blueLight: '#2a4a78',
  red: '#EA1925',
  redLight: '#ff5a64',
  green: '#1a7f37',
  greenLight: '#4ade80',
  warn: '#b95c00',
  warnLight: '#fbbf24',
  info: '#0969da',
  infoLight: '#60a5fa',
  purple: '#6d38e0',
  purpleLight: '#a78bfa',
  gray: '#4a5568',
  grayLight: '#a0aec0'
};

const SECTION_COLORS = {
  '1. CAMBIO HR TASK PROPUESTO': PALETTE.red,
  '2. VARIAS TASKSPEC CON VOLUMEN': PALETTE.warn,
  '3. HR TASK CORRECTA': PALETTE.green,
  '4. SIN VOLUMEN': PALETTE.gray,
  '5. WMS TASK SIN MAPPING': PALETTE.warnLight,
  '6. REVISION MANUAL - MULTIPLES HR TASK': PALETTE.purple,
  '7. REVISION MANUAL - AMBIGUEDAD ID NUMERICO': PALETTE.redLight
};

const MATERIALIDAD_COLORS = {
  'MICRO < 5 MIN': PALETTE.infoLight,
  'BAJA < 15 MIN': PALETTE.info,
  'MEDIA < 1 H': PALETTE.warn,
  'ALTA 1-4 H': PALETTE.red,
  'CRITICA >= 4 H': PALETTE.redDark || '#8b0a14'
};

/* Crea elemento SVG con atributos */
function svgEl(tag, attrs = {}, children = []) {
  const el = document.createElementNS('http://www.w3.org/2000/svg', tag);
  for (const [k, v] of Object.entries(attrs)) {
    el.setAttribute(k, v);
  }
  for (const c of children) {
    if (c) el.appendChild(c);
  }
  return el;
}

function svgText(x, y, text, opts = {}) {
  return svgEl('text', {
    x, y,
    'text-anchor': opts.anchor || 'start',
    'font-size': opts.size || 10,
    'font-weight': opts.weight || 400,
    'fill': opts.color || '#718096',
    'font-family': 'inherit'
  }, [document.createTextNode(text)]);
}

/* ===================== BAR CHART HORIZONTAL =====================
   data: [{ label, value, color? }]
   opts: { width, height, barHeight, gap, onClick }
*/
function barChartHorizontal(data, opts = {}) {
  const width = opts.width || 320;
  const height = opts.height || 200;
  const barH = opts.barHeight || 18;
  const gap = opts.gap || 8;
  const labelW = opts.labelWidth || 120;
  const valueW = opts.valueWidth || 50;
  const padding = { top: 8, right: 8, bottom: 8, left: 8 };
  const innerW = width - padding.left - padding.right;
  const totalH = data.length * (barH + gap) + padding.top + padding.bottom;
  const finalH = Math.max(height, totalH);

  const maxVal = Math.max(...data.map(d => d.value), 1);
  const barAreaW = innerW - labelW - valueW;

  const svg = svgEl('svg', {
    viewBox: `0 0 ${width} ${finalH}`,
    preserveAspectRatio: 'xMidYMid meet'
  });

  let y = padding.top;
  for (const item of data) {
    const w = barAreaW * (item.value / maxVal);
    const color = item.color || PALETTE.blue;

    // Label (truncado a 22 chars)
    const labelText = item.label.length > 22 ? item.label.slice(0, 22) + '…' : item.label;
    svg.appendChild(svgText(padding.left, y + barH * 0.7, labelText, {
      size: 10, weight: 500, color: '#4a5568', anchor: 'start'
    }));

    // Bar background
    svg.appendChild(svgEl('rect', {
      x: padding.left + labelW, y: y,
      width: barAreaW, height: barH,
      fill: '#f0f3f8', rx: 2
    }));

    // Bar fill
    const bar = svgEl('rect', {
      x: padding.left + labelW, y: y,
      width: w, height: barH,
      fill: color, rx: 2,
      class: 'chart-bar'
    });
    if (opts.onClick) {
      bar.style.cursor = 'pointer';
      bar.addEventListener('click', () => opts.onClick(item));
    }
    svg.appendChild(bar);

    // Value
    svg.appendChild(svgText(
      padding.left + labelW + barAreaW + 4, y + barH * 0.7,
      String(item.value),
      { size: 11, weight: 700, color: '#1a2332', anchor: 'start' }
    ));

    y += barH + gap;
  }

  return svg;
}

/* ===================== GAUGE DE COBERTURA =====================
   Dibuja un gauge semicircular con dos agujas (total + atribuible)
*/
function coverageGauge(total, atribuible) {
  const wrap = document.createElement('div');
  wrap.className = 'gauge-wrap';

  const totalPct = total != null ? total : 0;
  const atribPct = atribuible != null ? atribuible : 0;

  // SVG gauge
  const svg = svgEl('svg', {
    viewBox: '0 0 200 120', width: 200, height: 120
  });
  const cx = 100, cy = 100, r = 80;

  // Background arc (180deg)
  const arcBg = describeArc(cx, cy, r, -90, 90);
  svg.appendChild(svgEl('path', {
    d: arcBg, fill: 'none', stroke: '#e8ecf2', 'stroke-width': 14, 'stroke-linecap': 'round'
  }));

  // Total arc
  const totalEnd = -90 + (totalPct * 180 / 100);
  if (totalPct > 0) {
    const arcTotal = describeArc(cx, cy, r, -90, totalEnd);
    svg.appendChild(svgEl('path', {
      d: arcTotal, fill: 'none', stroke: PALETTE.blue, 'stroke-width': 14, 'stroke-linecap': 'round'
    }));
  }

  // Atribuible arc (más pequeño, superpuesto)
  const atribEnd = -90 + (atribPct * 180 / 100);
  if (atribPct > 0) {
    const arcAtrib = describeArc(cx, cy, r - 16, -90, atribEnd);
    svg.appendChild(svgEl('path', {
      d: arcAtrib, fill: 'none', stroke: PALETTE.red, 'stroke-width': 10, 'stroke-linecap': 'round'
    }));
  }

  // Texto central
  svg.appendChild(svgText(cx, cy - 8, (totalPct * 100).toFixed(1) + '%', {
    size: 22, weight: 700, color: PALETTE.blue, anchor: 'middle'
  }));
  svg.appendChild(svgText(cx, cy + 14, 'Cobertura', {
    size: 10, weight: 600, color: '#718096', anchor: 'middle'
  }));

  wrap.appendChild(svg);

  // Info lado derecho
  const info = document.createElement('div');
  info.className = 'gauge-info';
  const stTotal = totalPct >= 0.9 ? 'OK' : (totalPct >= 0.7 ? 'REVISAR' : 'ERROR');
  const stAtrib = atribPct >= 0.9 ? 'OK' : (atribPct >= 0.7 ? 'REVISAR' : 'ERROR');
  info.innerHTML = `
    <div class="gauge-label">Total mapeado</div>
    <div class="gauge-value">${(totalPct * 100).toFixed(2)}%</div>
    <span class="gauge-state ${stTotal}">${stTotal}</span>
    <div class="gauge-label" style="margin-top: 10px;">Atribuible real</div>
    <div class="gauge-value" style="color: ${PALETTE.red};">${(atribPct * 100).toFixed(2)}%</div>
    <span class="gauge-state ${stAtrib}">${stAtrib}</span>
  `;
  wrap.appendChild(info);

  return wrap;
}

/* Helper: describe un arco SVG (en grados, 0= derecha, sentido horario) */
function describeArc(cx, cy, r, startAngle, endAngle) {
  // Convertir a radianes y rotar para que 0 = arriba
  const start = polarToCartesian(cx, cy, r, endAngle);
  const end = polarToCartesian(cx, cy, r, startAngle);
  const largeArc = endAngle - startAngle <= 180 ? '0' : '1';
  return `M ${start.x} ${start.y} A ${r} ${r} 0 ${largeArc} 0 ${end.x} ${end.y}`;
}
function polarToCartesian(cx, cy, r, angleDeg) {
  const angleRad = (angleDeg - 90) * Math.PI / 180;
  return {
    x: cx + r * Math.cos(angleRad),
    y: cy + r * Math.sin(angleRad)
  };
}

/* ===================== API ===================== */

CHARTS.renderChartsGrid = function (containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = '';

  if (!SPEC.STATE.reporte || SPEC.STATE.reporte.length === 0) {
    container.innerHTML = '<p style="color: var(--c-text-muted); font-size: 13px; padding: 20px;">Procesa los archivos para ver las visualizaciones.</p>';
    return;
  }
  const rep = SPEC.STATE.reporte;

  // 1. Distribución de secciones
  const secCounts = {};
  for (const r of rep) {
    const s = r['SECCION'] || '(sin sección)';
    secCounts[s] = (secCounts[s] || 0) + 1;
  }
  const secData = Object.keys(secCounts).sort().map(s => ({
    label: s,
    value: secCounts[s],
    color: SECTION_COLORS[s] || PALETTE.gray
  }));

  const card1 = document.createElement('div');
  card1.className = 'chart-card';
  card1.innerHTML = '<h4>Distribución de propuestas por sección</h4>';
  const canvas1 = document.createElement('div');
  canvas1.className = 'chart-canvas-wrap';
  canvas1.appendChild(barChartHorizontal(secData, {
    width: 320, height: 220, barHeight: 22, gap: 6, labelWidth: 180,
    onClick: (item) => {
      // Drilldown: filtrar reporte por sección
      const seccionFilter = document.getElementById('reporte-filter-seccion');
      seccionFilter.value = item.label;
      // Trigger change
      const evt = new Event('change');
      seccionFilter.dispatchEvent(evt);
      // Navegar a la pestaña reporte
      document.querySelector('.tab[data-tab="reporte"]').click();
    }
  }));
  card1.appendChild(canvas1);
  const leg1 = document.createElement('div');
  leg1.className = 'chart-legend';
  secData.forEach((d, i) => {
    leg1.innerHTML += `<span class="leg c${i+1}" style="--c:${d.color}"><span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:${d.color};margin-right:6px;"></span>${d.label.split(' ').slice(0, 3).join(' ')} (${d.value})</span>`;
  });
  card1.appendChild(leg1);
  container.appendChild(card1);

  // 2. Distribución de materialidad
  const matCounts = {};
  for (const r of rep) {
    const m = r['MATERIALIDAD'] || '(sin)';
    matCounts[m] = (matCounts[m] || 0) + 1;
  }
  // Orden materialidad: MICRO, BAJA, MEDIA, ALTA, CRITICA
  const matOrder = ['MICRO < 5 MIN', 'BAJA < 15 MIN', 'MEDIA < 1 H', 'ALTA 1-4 H', 'CRITICA >= 4 H'];
  const matData = matOrder.filter(m => matCounts[m] != null).map(m => ({
    label: m,
    value: matCounts[m] || 0,
    color: MATERIALIDAD_COLORS[m] || PALETTE.gray
  }));

  const card2 = document.createElement('div');
  card2.className = 'chart-card';
  card2.innerHTML = '<h4>Distribución por materialidad (horas sin volumen)</h4>';
  const canvas2 = document.createElement('div');
  canvas2.className = 'chart-canvas-wrap';
  canvas2.appendChild(barChartHorizontal(matData, {
    width: 320, height: 200, barHeight: 22, gap: 6, labelWidth: 130,
    onClick: (item) => {
      const mf = document.getElementById('reporte-filter-materialidad');
      mf.value = item.label;
      mf.dispatchEvent(new Event('change'));
      document.querySelector('.tab[data-tab="reporte"]').click();
    }
  }));
  card2.appendChild(canvas2);
  container.appendChild(card2);

  // 3. Gauge de cobertura (de 16_ControlMapeoSPEC)
  const ctrl = SPEC.STATE.queries['16_ControlMapeoSPEC'] || [];
  const totalCov = ctrl.find(r => r.Control && r.Control.indexOf('Cobertura volumen positivo mapeado') === 0);
  const atribCov = ctrl.find(r => r.Control && r.Control.indexOf('Cobertura volumen positivo atribuible') === 0);
  const total = totalCov ? (typeof totalCov.Valor === 'number' ? totalCov.Valor : 0) : 0;
  const atrib = atribCov ? (typeof atribCov.Valor === 'number' ? atribCov.Valor : 0) : 0;

  const card3 = document.createElement('div');
  card3.className = 'chart-card';
  card3.innerHTML = '<h4>Cobertura de mapeo SPEC</h4>';
  const canvas3 = document.createElement('div');
  canvas3.className = 'chart-canvas-wrap';
  canvas3.style.height = 'auto';
  canvas3.style.padding = '12px 0';
  canvas3.appendChild(coverageGauge(total, atrib));
  card3.appendChild(canvas3);
  const note = document.createElement('div');
  note.style.cssText = 'font-size: 11px; color: var(--c-text-muted); margin-top: 12px; line-height: 1.5;';
  note.innerHTML = `<strong style="color: ${PALETTE.blue};">▙ Azul</strong>: cobertura total (volumen mapeado UNICO / volumen positivo total).<br>
    <strong style="color: ${PALETTE.red};">▙ Rojo</strong>: cobertura atribuible real (excluye IdNumericos ambiguos).`;
  card3.appendChild(note);
  container.appendChild(card3);
};

window.SPEC_CHARTS = CHARTS;

})();
