/* ============================================================================
 * SPEC Web v6.2.0 — TENDENCIAS Y EVOLUCIÓN (trendAnalytics.js)
 * ============================================================================
 * Responde: ¿estamos mejorando o empeorando?
 *
 * Series diarias (§14), semanales ISO (§15) y mensuales (§16), rolling 7/28
 * (§47) y comparación de periodos A/B (§17). La media móvil SOLO se calcula
 * cuando existe ventana completa (§14: nunca con información insuficiente).
 * ========================================================================== */
(function (window) {
  'use strict';
  var AN = window.SPEC_AN;
  var safeDiv = AN.safeDiv, pct = AN.pct, round2 = AN.round2;

  /* Serie diaria: para cada fecha operativa presente en el histórico.
   * Métricas por día (todas con denominador explícito en el diccionario):
   *  - registros (persona-día), personas, conError, incidencias, errores,
   *    erroresAsignacion, horasAnalizables, horasAfectadas
   *  - pctPersonaDiaError = conError / registros
   *  - pctHorasAfectadas = horasAfectadas / horasAnalizables
   * mediaMovil7 / mediaMovil28: medias móviles de incidencias y de
   * pctPersonaDiaError (null hasta tener ventana completa). */
  function computeDailySeries(records, cfg) {
    var c = cfg || AN.DEFAULT_CONFIG;
    var by = new Map();
    (records || []).forEach(function (r) {
      var d = by.get(r.fechaISO);
      if (!d) {
        d = {
          fechaISO: r.fechaISO, registros: 0, personas: new Set(), conError: 0,
          incidencias: 0, errores: 0, erroresAsignacion: 0,
          horasAnalizables: 0, horasAfectadas: 0
        };
        by.set(r.fechaISO, d);
      }
      d.registros++;
      d.personas.add(r.login);
      d.incidencias += r.incidencias.length;
      d.errores += r.nErrores;
      d.erroresAsignacion += r.incidencias.filter(function (i) { return i.esErrorAsignacion; }).length;
      d.horasAnalizables += r.horasAnalizables;
      d.horasAfectadas += r.horasErrorDedup;
      if (r.conError) d.conError++;
    });
    var serie = Array.from(by.values()).sort(function (a, b) { return a.fechaISO < b.fechaISO ? -1 : 1; })
      .map(function (d) {
        return {
          fechaISO: d.fechaISO, registros: d.registros, personas: d.personas.size,
          conError: d.conError, incidencias: d.incidencias, errores: d.errores,
          erroresAsignacion: d.erroresAsignacion,
          horasAnalizables: round2(d.horasAnalizables),
          horasAfectadas: round2(d.horasAfectadas),
          pctPersonaDiaError: pct(d.conError, d.registros),
          pctHorasAfectadas: pct(d.horasAfectadas, d.horasAnalizables)
        };
      });
    var mmIncidencias = AN.mediaMovil(serie.map(function (s) { return s.incidencias; }), c.ventanaMediaMovil);
    var mmTasa = AN.mediaMovil(serie.map(function (s) { return s.pctPersonaDiaError; }), c.ventanaMediaMovil);
    var mmHoras = AN.mediaMovil(serie.map(function (s) { return s.horasAfectadas; }), c.ventanaMediaMovil);
    serie.forEach(function (s, i) {
      s.mediaMovilIncidencias = mmIncidencias[i] != null ? round2(mmIncidencias[i]) : null;
      s.mediaMovilTasa = mmTasa[i] != null ? round2(mmTasa[i]) : null;
      s.mediaMovilHoras = mmHoras[i] != null ? round2(mmHoras[i]) : null;
    });
    // Rolling 7/28 (§47): ventana deslizante sobre días CONTIGUOS del
    // calendario (los días sin datos cuentan como 0 registros y 0 errores).
    if (serie.length > 0) {
      var desde = new Date(serie[0].fechaISO + 'T00:00:00Z');
      var hasta = new Date(serie[serie.length - 1].fechaISO + 'T00:00:00Z');
      var dias = Math.round((hasta - desde) / 86400000) + 1;
      if (dias >= 7 && dias <= 400) { // protección de tamaño
        var porFecha = new Map(serie.map(function (s) { return [s.fechaISO, s]; }));
        var cal = [];
        for (var i = 0; i < dias; i++) {
          var dt = new Date(desde.getTime() + i * 86400000);
          var iso = dt.toISOString().slice(0, 10);
          var s = porFecha.get(iso);
          cal.push(s || { fechaISO: iso, registros: 0, conError: 0, incidencias: 0, horasAfectadas: 0, pctPersonaDiaError: 0 });
        }
        var roll7inc = rollingSum(cal.map(function (s) { return s.incidencias; }), 7);
        var roll7reg = rollingSum(cal.map(function (s) { return s.registros; }), 7);
        var roll28inc = rollingSum(cal.map(function (s) { return s.incidencias; }), 28);
        var roll28reg = rollingSum(cal.map(function (s) { return s.registros; }), 28);
        var porFechaOut = new Map();
        serie.forEach(function (s, ix) {
          porFechaOut.set(s.fechaISO, ix);
        });
        var last7 = null, last28 = null;
        for (var j = 0; j < cal.length; j++) {
          var ixOut = porFechaOut.get(cal[j].fechaISO);
          if (ixOut != null && j >= 6) {
            serie[ixOut].rolling7 = {
              incidencias: roll7inc[j], registros: roll7reg[j],
              tasa: round2(pct(roll7inc[j], roll7reg[j]))
            };
            last7 = serie[ixOut].rolling7;
          }
          if (ixOut != null && j >= 27) {
            serie[ixOut].rolling28 = {
              incidencias: roll28inc[j], registros: roll28reg[j],
              tasa: round2(pct(roll28inc[j], roll28reg[j]))
            };
            last28 = serie[ixOut].rolling28;
          }
        }
        return { serie: serie, rolling: { ultimo7: last7, ultimo28: last28 } };
      }
    }
    return { serie: serie, rolling: { ultimo7: null, ultimo28: null } };
  }

  function rollingSum(values, w) {
    var out = new Array(values.length).fill(null);
    var sum = 0;
    for (var i = 0; i < values.length; i++) {
      sum += values[i];
      if (i >= w) sum -= values[i - w];
      if (i >= w - 1) out[i] = sum;
    }
    return out;
  }

  /* Agrupación semanal (semana ISO) y mensual (YYYY-MM). */
  function computeBucketSeries(records, modo, cfg) {
    var c = cfg || AN.DEFAULT_CONFIG;
    var by = new Map();
    (records || []).forEach(function (r) {
      var k = modo === 'semana' ? (r.semana || '?') : (modo === 'mes' ? (r.mes || '?') : r.fechaISO);
      var d = by.get(k);
      if (!d) {
        d = { clave: k, registros: 0, personas: new Set(), conError: 0, incidencias: 0, errores: 0, horasAfectadas: 0, horasAnalizables: 0 };
        by.set(k, d);
      }
      d.registros++;
      d.personas.add(r.login);
      d.incidencias += r.incidencias.length;
      d.errores += r.nErrores;
      d.horasAfectadas += r.horasErrorDedup;
      d.horasAnalizables += r.horasAnalizables;
      if (r.conError) d.conError++;
    });
    var serie = Array.from(by.values()).sort(function (a, b) { return a.clave < b.clave ? -1 : 1; })
      .map(function (d) {
        var o = {
          clave: d.clave, registros: d.registros, personas: d.personas.size,
          conError: d.conError, incidencias: d.incidencias, errores: d.errores,
          horasAfectadas: round2(d.horasAfectadas), horasAnalizables: round2(d.horasAnalizables),
          pctPersonaDiaError: pct(d.conError, d.registros),
          pctHorasAfectadas: pct(d.horasAfectadas, d.horasAnalizables)
        };
        return o;
      });
    // Cambio frente al bucket anterior (para "evolución" semanal/mensual).
    for (var i = 1; i < serie.length; i++) {
      serie[i].deltaIncidencias = serie[i].incidencias - serie[i - 1].incidencias;
      serie[i].deltaPP = round2(serie[i].pctPersonaDiaError - serie[i - 1].pctPersonaDiaError);
    }
    if (serie.length) serie[0].deltaIncidencias = null, serie[0].deltaPP = null;
    var mm = AN.mediaMovil(serie.map(function (s) { return s.incidencias; }), c.ventanaMediaMovil);
    serie.forEach(function (s, i) { s.mediaMovil = mm[i] != null ? round2(mm[i]) : null; });
    return serie;
  }

  /* Matriz frecuencia × impacto (§26) para personas, tareas y actividades.
   * Cada punto: nombre, frecuencia (errores), impacto (horas afectadas) y
   * metadata. Los cuadrantes se definen por las medianas del conjunto
   * (documentado; sin datos → lista vacía). */
  function computeFrecuenciaImpacto(items) {
    var pts = (items || []).filter(function (i) { return i.errores > 0 || i.horasAfectadas > 0; })
      .map(function (i) {
        return {
          nombre: i.nombre, tipo: i.tipo, errores: i.errores || 0,
          horasAfectadas: round2(i.horasAfectadas || 0), extra: i.extra || null
        };
      });
    if (pts.length === 0) return { puntos: [], medianaErrores: 0, medianaHoras: 0 };
    var errs = pts.map(function (p) { return p.errores; }).sort(function (a, b) { return a - b; });
    var hors = pts.map(function (p) { return p.horasAfectadas; }).sort(function (a, b) { return a - b; });
    var mediana = function (arr) { return arr.length ? arr[Math.floor(arr.length / 2)] : 0; };
    var me = mediana(errs), mh = mediana(hors);
    pts.forEach(function (p) {
      p.cuadrante = (p.errores >= me ? 'ALTO' : 'BAJO') + '×' + (p.horasAfectadas >= mh ? 'ALTO' : 'BAJO');
    });
    return { puntos: pts, medianaErrores: me, medianaHoras: mh };
  }

  window.SPEC_AN.trend = {
    computeDailySeries: computeDailySeries,
    computeBucketSeries: computeBucketSeries,
    computeFrecuenciaImpacto: computeFrecuenciaImpacto,
    rollingSum: rollingSum
  };
})(typeof window !== 'undefined' ? window : globalThis);
