/* ============================================================================
 * SPEC Web v6.2.0 — NÚCLEO DE LA CAPA ANALÍTICA (analyticsCore.js)
 * ============================================================================
 * MÓDULO DE ESTADÍSTICA AVANZADA E INTELIGENCIA OPERATIVA (Patrones).
 *
 * Principios (ADVANCED_ANALYTICS_SPEC.md §1):
 *  - Cálculos PUROS y deterministas: ninguna función de este archivo toca el
 *    DOM ni depende de la presentación. Entrada → salida reproducible.
 *  - Sin ML ni modelos opacos: solo reglas deterministas documentadas.
 *  - Nunca NaN/Infinity: toda división pasa por safeDiv (denominador 0 → 0).
 *  - Umbrales CONFIGURABLES y documentados (ninguno oculto en el código):
 *    se persisten en localStorage y se editan desde ⚙ CONFIGURACIÓN ESTADÍSTICA.
 *
 * Este archivo se carga como script clásico en el navegador (antes que ui.js)
 * y en Vitest mediante tests/setup.js (mismo patrón que app.js).
 * Namespace global: window.SPEC_AN.
 * ========================================================================== */
(function (window) {
  'use strict';

  var LS_KEY = 'spec_stat_config_v1';

  /* --------------------------------------------------------------------------
   * CONFIGURACIÓN ESTADÍSTICA — valores por defecto DOCUMENTADOS.
   * Todos editables desde la UI; ver ANALYTICS_METRICS_DICTIONARY.md §Umbrales.
   * ------------------------------------------------------------------------ */
  var DEFAULT_CONFIG = {
    // Mínimo de días analizados por persona para comparar periodos / emitir
    // tendencia (evita conclusiones con 1 día: requisito §19/§63).
    minDiasComparar: 3,
    // Mínimo de observaciones para NO marcar "MUESTRA PEQUEÑA" (§39/§63).
    minObservaciones: 3,
    // Umbral de cambio de tasa (puntos porcentuales) para alertas de
    // crecimiento/mejora significativos (§37 A1).
    umbralCambioPP: 5,
    // Días CONSECUTIVOS con error que activan la alerta de racha (§37 A2).
    rachaDias: 3,
    // Días distintos con el mismo error (persona+tarea) para "habitual" (§23).
    recurrenciaHabitual: 5,
    // Tope de días distintos para "recurrente" (2..N = recurrente) (§23).
    recurrenciaRecurrente: 4,
    // Ventana de tendencia: nº de días usados para la media móvil (§14).
    ventanaMediaMovil: 7,
    // Ventana rolling larga (opcional, §47).
    ventanaRollingLarga: 28,
    // Repeticiones de la misma confusión A→B para alerta (§37 A6).
    repeticionesConfusion: 3,
    // Exceso de tasa de error de un turno sobre la global para alertar (pp) (§37 A4).
    umbralTurnoPP: 10,
    // UDS mínimas de una tarea OTRA para alerta de volumen relevante (§37 A5).
    otraUdsMinimas: 100,
    // Horas mínimas afectadas para considerar impacto alto (§5).
    impactoHorasAltas: 4,
    // Umbral de error de ASIGNACIÓN sobre incidencias para KPI (informativo).
    // Semáforo de calidad de fichaje por persona (§9) — % de días con error
    // de fichaje (secciones ≠ 3; ver clasificarIncidencia). Umbrales abiertos:
    // MUY BUENO < buenoHasta ≤ BUENO < normalHasta ≤ NORMAL < atencionHasta
    // ≤ ATENCIÓN < CRÍTICO.
    semaforoBueno: 10,     // % ≤ 10 → BUENO (y 0% con días mínimos → MUY BUENO)
    semaforoNormal: 25,    // % ≤ 25 → NORMAL
    semaforoAtencion: 50,  // % ≤ 50 → ATENCIÓN
    // % > semaforoAtencion → CRÍTICO
    // Días mínimos por persona para que el semáforo sea firme (si no,
    // MUESTRA PEQUEÑA — el dato se muestra igualmente) (§9/§39).
    semaforoMinDias: 3,
    // Pesos del ÍNDICE DE PRIORIDAD (§6) — transparentes y editables.
    // score = 100·Σ peso_i·(valor_i / máx_i) con máx_i = máximo del conjunto
    // candidato (0 si el máximo es 0). La tendencia entra como max(0, Δpp)/máxΔpp.
    pesoFrecuencia: 20,
    pesoTasa: 20,
    pesoHoras: 20,
    pesoRecurrencia: 15,
    pesoTendencia: 15,
    pesoPersonas: 10,
    // Umbrales de severidad del índice de prioridad (0-100).
    prioridadAlta: 60,
    prioridadMedia: 35
  };

  /* Lee la configuración persistida fusionándola con los defaults (las
   * claves desconocidas o no numéricas se ignoran → nunca rompe el cálculo). */
  function loadConfig(storage) {
    var st = storage || (typeof window !== 'undefined' && window.localStorage) || null;
    var cfg = Object.assign({}, DEFAULT_CONFIG);
    if (!st) return cfg;
    try {
      var raw = st.getItem(LS_KEY);
      if (!raw) return cfg;
      var saved = JSON.parse(raw);
      if (saved && typeof saved === 'object') {
        for (var k in DEFAULT_CONFIG) {
          if (Object.prototype.hasOwnProperty.call(saved, k) &&
              typeof saved[k] === 'number' && isFinite(saved[k])) {
            cfg[k] = saved[k];
          }
        }
      }
    } catch (_e) { /* config corrupta → defaults */ }
    return cfg;
  }

  function saveConfig(cfg, storage) {
    var st = storage || (typeof window !== 'undefined' && window.localStorage) || null;
    if (!st) return false;
    try {
      st.setItem(LS_KEY, JSON.stringify(cfg));
      return true;
    } catch (_e) { return false; }
  }

  function resetConfig(storage) {
    var st = storage || (typeof window !== 'undefined' && window.localStorage) || null;
    if (st) { try { st.removeItem(LS_KEY); } catch (_e) { /* noop */ } }
    return Object.assign({}, DEFAULT_CONFIG);
  }

  /* --------------------------------------------------------------------------
   * UTILIDADES NUMÉRICAS SEGURAS — nunca NaN ni Infinity (§58).
   * ------------------------------------------------------------------------ */
  function safeDiv(num, den) {
    var n = Number(num) || 0, d = Number(den) || 0;
    if (d === 0) return 0;
    var r = n / d;
    if (!isFinite(r)) return 0;
    return r;
  }

  /* Tasa en tanto por uno [0,∞). Puede superar 1 solo si el numerador puede
   * exceder al denominador por definición (p. ej. incidencias/día); las tasas
   * con denominador "oportunidades" acotan naturalmente el resultado. */
  function safeRate(num, den) { return safeDiv(num, den); }

  /* Porcentaje acotado a [0,100] solo cuando la métrica lo garantiza por
   * definición (partes de un todo). Para ratios sin cota se usa safeDiv. */
  function pct(num, den) {
    return Math.min(100, Math.max(0, safeDiv(num, den) * 100));
  }

  function round2(x) { return Math.round((Number(x) || 0) * 100) / 100; }

  /* Media móvil de ventana w sobre una serie de valores numéricos.
   * Devuelve un array de la MISMA longitud; los puntos sin ventana completa
   * (índices < w-1) valen null — NO se calcula con información insuficiente
   * (§14: "no calcularla cuando no haya suficiente histórico"). */
  function mediaMovil(values, w) {
    var n = values.length;
    var win = Math.max(1, Math.floor(Number(w) || 1));
    var out = new Array(n).fill(null);
    if (n < win) return out;
    var sum = 0;
    for (var i = 0; i < n; i++) {
      sum += Number(values[i]) || 0;
      if (i >= win) sum -= Number(values[i - win]) || 0;
      if (i >= win - 1) out[i] = sum / win;
    }
    return out;
  }

  /* Flecha de tendencia determinista a partir de un delta.
   * Devuelve '↑' (crece), '↓' (baja), '→' (estable) o '—' (sin datos). */
  function flechaTendencia(delta, umbralPP) {
    if (delta == null || !isFinite(delta)) return '—';
    var u = Math.abs(Number(umbralPP) || 0);
    if (delta > u) return '↑';
    if (delta < -u) return '↓';
    return '→';
  }

  /* --------------------------------------------------------------------------
   * CLASIFICACIÓN DE INCIDENCIAS (§50 — distinguir tipos de problema)
   * Mapping DOCUMENTADO sección → tipo. La sección 3 no es un error (control);
   * las demás sí se consideran incidencia con impacto.
   * ------------------------------------------------------------------------ */
  var TIPO_ERROR = {
    '1': 'ERROR DE FICHAJE',
    '2': 'AMBIGÜEDAD MAPPING',
    '3': 'REVISIÓN (CORRECTA)',
    '4': 'SIN VOLUMEN',
    '5': 'SIN MAPPING',
    '6': 'MÚLTIPLES HR TASK',
    '7': 'AMBIGÜEDAD IDNUM'
  };

  /* Categoría de causa para separar problema OPERATIVO vs problema de DATOS
   * (§50). Documentado en ANALYTICS_METRICS_DICTIONARY.md:
   *  - OPERATIVO: la persona ficha una tarea que no corresponde (sección 1)
   *    o ficha horas sin volumen asociado (sección 4).
   *  - DATOS/MAPPING: ambigüedad del mapping (2), tarea WMS sin mapping (5).
   *  - REVISIÓN: casos que requieren decisión humana sin imputación clara
   *    (6: varias HR task el mismo día; 7: ambigüedad de id numérico).
   *  - CONTROL: sección 3 (la tarea fichada coincide — no es error).
   */
  var CATEGORIA_CAUSA = {
    '1': 'OPERATIVO',
    '2': 'DATOS',
    '3': 'CONTROL',
    '4': 'OPERATIVO',
    '5': 'DATOS',
    '6': 'REVISIÓN',
    '7': 'REVISIÓN'
  };

  function seccionNumero(seccion) {
    var m = String(seccion || '').match(/^(\d)/);
    return m ? m[1] : '';
  }

  function clasificarIncidencia(inc) {
    var num = seccionNumero(inc && inc.seccion);
    return {
      num: num,
      tipoError: TIPO_ERROR[num] || 'DESCONOCIDA',
      categoria: CATEGORIA_CAUSA[num] || 'REVISIÓN',
      esError: num !== '' && num !== '3',           // toda sección salvo 3 (correcta)
      esErrorFichaje: num === '1',                   // cambio de HR task propuesto
      esErrorAsignacion: num === '1' || inc && inc.decision === 'aceptada',
      esControl: num === '3',
      esSinMapping: num === '5',
      esSinVolumen: num === '4',
      esRevisionManual: num === '6' || num === '7',
      esAmbiguedad: num === '2'
    };
  }

  /* --------------------------------------------------------------------------
   * NORMALIZACIÓN DE REGISTROS HISTÓRICOS
   * Convierte PERSON_DAILY_RECORD crudos (pueden venir de IndexedDB con el
   * esquema de una versión anterior) en un formato estable y defensivo:
   * campos ausentes → valores por defecto; incidencias clasificadas;
   * tareas aplanadas con contexto de persona/día/turno.
   * ------------------------------------------------------------------------ */
  function normalizarRegistro(r) {
    var incs = (r.incidencias || []).map(function (inc, ix) {
      var c = clasificarIncidencia(inc);
      return {
        id: inc.id || (r.key + '#' + ix),
        seccion: inc.seccion || '',
        tipoError: c.tipoError,
        categoria: c.categoria,
        esError: c.esError,
        esErrorFichaje: c.esErrorFichaje,
        esErrorAsignacion: c.esErrorAsignacion,
        esControl: c.esControl,
        esSinMapping: c.esSinMapping,
        esSinVolumen: c.esSinVolumen,
        esRevisionManual: c.esRevisionManual,
        esAmbiguedad: c.esAmbiguedad,
        horasAfectadas: Number(inc.horasAfectadas) || 0,
        tareaOriginal: inc.tareaOriginal || '',
        propuesta: inc.propuesta || '',
        wmsTask: inc.wmsTask || '',      // v6.2: 'WMS TASK CON VOLUMEN'
        volumen: Number(inc.volumen) || 0,
        cliente: inc.cliente || '',      // v6.2: CUSTOMER del volumen
        decision: inc.decision || null
      };
    });
    var tareas = [];
    (r.actividades || []).forEach(function (a) {
      (a.tareas || []).forEach(function (t) {
        tareas.push({
          taskWms: t.taskWms,
          actividad: t.actividad || a.actividad || 'OTRA',
          uds: Number(t.uds) || 0,
          productividad: t.productividad != null ? t.productividad : null,
          fuente: t.fuente || 'DEFAULT',
          horasEquivalentes: Number(t.horasEquivalentes) || 0,
          peso: Number(t.peso) || 0,
          horasAsignadas: Number(t.horasAsignadas) || 0,
          tasksSpec: t.tasksSpec || '',   // v6.2: TASK_SPEC del mapping (si existe)
          cliente: t.cliente || ''
        });
      });
      // Registros antiguos sin detalle por tarea: al menos una fila por
      // actividad con sus tareasWms como filas individuales (uds a nivel de
      // actividad — documentado como pérdida de granularidad).
      if (!(a.tareas && a.tareas.length) && (a.tareasWms || []).length) {
        (a.tareasWms || []).forEach(function (tw) {
          tareas.push({
            taskWms: tw, actividad: a.actividad || 'OTRA',
            uds: Number(a.uds) || 0, productividad: a.productividad != null ? a.productividad : null,
            fuente: 'DEFAULT', horasEquivalentes: 0, peso: 0, horasAsignadas: 0,
            tasksSpec: '', cliente: '', _agregadaLegacy: true
          });
        });
      }
    });
    return {
      key: r.key || '',
      login: r.login || '',
      persona: r.persona || r.login || '',
      fechaISO: r.fechaOperativaISO || '',
      semana: r.semana || '',
      mes: r.mes || '',
      turno: r.turno || 'SIN HORA',
      turnos: (r.turnos || []).slice(),
      horasFichadas: Number(r.horasFichadas) || 0,
      horasAnalizables: Number(r.horasAnalizables) || 0,
      udsTotales: Number(r.udsTotales) || 0,
      udsSinHoras: Number(r.udsSinHoras) || 0,
      horasEquivalentes: Number(r.horasEquivalentes) || 0,
      horasAsignadas: Number(r.horasAsignadas) || 0,
      desviacion: Number(r.desviacion) || 0,
      registros: (r.registros || []).map(function (rg) {
        return {
          idRegistroHoras: rg.idRegistroHoras, hora: rg.hora,
          turno: rg.turno || 'SIN HORA', horas: Number(rg.horas) || 0,
          hrTask: rg.hrTask || ''
        };
      }),
      tareas: tareas,
      incidencias: incs,
      nIncidencias: incs.length,
      nErrores: incs.filter(function (i) { return i.esError; }).length,
      horasConIncidencia: Number(r.horasConIncidencia) || 0,
      // v6.2 §50 — horas afectadas por ERROR REAL (sección ≠ 3), dedup por
      // registro de horas: evita contar como «afectadas» las horas de los
      // controles correctos (sección 3) que el REPORTE reporta siempre.
      horasErrorDedup: (function () {
        var porId = new Map();
        incs.forEach(function (i) {
          if (!i.esError) return;
          var idReg = String(i.id).split('@')[0];
          porId.set(idReg, Math.max(porId.get(idReg) || 0, i.horasAfectadas));
        });
        var s = 0;
        porId.forEach(function (v) { s += v; });
        return s;
      })(),
      conIncidencia: incs.length > 0,
      conError: incs.some(function (i) { return i.esError; }),
      decision: r.decision || 'PENDIENTE',
      mappingHash: r.mappingHash || null,
      mappingVersion: r.mappingVersion != null ? r.mappingVersion : null,
      productivityVersion: r.productivityVersion || null,   // v6.2
      overrideVersion: r.overrideVersion || null,            // v6.2
      datasetFingerprint: r.datasetFingerprint || r.dataFingerprint || null, // v6.2
      appVersion: r.appVersion || '',
      version: r.version || 1,
      previousVersions: (r.previousVersions || []).length,
      createdAt: r.createdAt || '',
      modoVolumen: r.modoVolumen || null
    };
  }

  function normalizarRecords(list) {
    return (list || []).map(normalizarRegistro)
      .filter(function (r) { return r.login && r.fechaISO; })
      .sort(function (a, b) { return a.fechaISO < b.fechaISO ? -1 : (a.fechaISO > b.fechaISO ? 1 : a.login.localeCompare(b.login)); });
  }

  /* --------------------------------------------------------------------------
   * FILTROS GLOBALES (§41/§42) — un único conjunto que afecta a TODAS las
   * vistas. Definición documentada: un registro pasa el filtro de turno si
   * SU turno agregado coincide (MIXTO cuenta como turno propio) — igual que
   * la vista Patrones v6.1. Persona/Task aceptan subcadenas (case-insensitive).
   * ------------------------------------------------------------------------ */
  function filtrarRecords(records, f) {
    var fl = f || {};
    var persona = (fl.persona || '').trim().toLowerCase();
    var task = (fl.taskWms || '').trim().toLowerCase();
    var cliente = (fl.cliente || '').trim().toLowerCase();
    var mapping = (fl.mappingHash || '').trim();
    return (records || []).filter(function (r) {
      if (fl.fechaDesde && r.fechaISO < fl.fechaDesde) return false;
      if (fl.fechaHasta && r.fechaISO > fl.fechaHasta) return false;
      if (fl.semana && r.semana !== fl.semana) return false;
      if (fl.mes && r.mes !== fl.mes) return false;
      if (fl.turno && r.turno !== fl.turno) return false;
      if (fl.actividad && !r.tareas.some(function (t) { return t.actividad === fl.actividad; })) return false;
      if (fl.decision && r.decision !== fl.decision) return false;
      if (mapping && String(r.mappingHash || '') !== mapping) return false;
      if (persona) {
        var hay = (r.persona + ' ' + r.login).toLowerCase();
        if (hay.indexOf(persona) < 0) return false;
      }
      if (task && !r.tareas.some(function (t) { return String(t.taskWms).toLowerCase().indexOf(task) >= 0; })) return false;
      if (cliente && !(
        r.tareas.some(function (t) { return String(t.cliente || '').toLowerCase().indexOf(cliente) >= 0; }) ||
        r.incidencias.some(function (i) { return String(i.cliente || '').toLowerCase().indexOf(cliente) >= 0; })
      )) return false;
      return true;
    });
  }

  /* Dimensiones disponibles en el histórico (para poblar los selects de
   * filtro de forma dinámica y con datos reales). */
  function dimensionesDisponibles(records) {
    var semanas = new Set(), meses = new Set(), actividades = new Set(),
      turnos = new Set(), clientes = new Set(), mappings = new Set();
    (records || []).forEach(function (r) {
      if (r.semana) semanas.add(r.semana);
      if (r.mes) meses.add(r.mes);
      if (r.turno) turnos.add(r.turno);
      if (r.mappingHash) mappings.add(r.mappingHash);
      r.tareas.forEach(function (t) {
        if (t.actividad) actividades.add(t.actividad);
        if (t.cliente) clientes.add(t.cliente);
      });
      r.incidencias.forEach(function (i) { if (i.cliente) clientes.add(i.cliente); });
    });
    var byCount = function (a, b) { return a < b ? -1 : 1; };
    return {
      semanas: Array.from(semanas).sort(byCount),
      meses: Array.from(meses).sort(byCount),
      turnos: Array.from(turnos).sort(),
      actividades: Array.from(actividades).sort(),
      clientes: Array.from(clientes).sort(),
      mappings: Array.from(mappings).sort()
    };
  }

  /* --------------------------------------------------------------------------
   * REPARTO DE PERIODOS (§17/§18/§19) — dos mitades por fecha para la
   * comparación por defecto, o rangos explícitos [desde, hasta].
   * ------------------------------------------------------------------------ */
  function rangoDeRecords(records) {
    var min = '', max = '';
    for (var i = 0; i < (records || []).length; i++) {
      var f = records[i].fechaISO;
      if (!min || f < min) min = f;
      if (!max || f > max) max = f;
    }
    return { desde: min, hasta: max };
  }

  /* Divide los registros en dos mitades por mediana de fechas (A=anterior,
   * B=actual). Determinista: mismas fechas → misma mitad. */
  function partirPorMitades(records) {
    var fechasUnicas = Array.from(new Set((records || []).map(function (r) { return r.fechaISO; }))).sort();
    if (fechasUnicas.length === 0) return { A: [], B: [], fechasA: [], fechasB: [] };
    var mitad = Math.ceil(fechasUnicas.length / 2);
    var fechasA = fechasUnicas.slice(0, mitad);
    var fechasB = fechasUnicas.slice(mitad);
    var setA = new Set(fechasA);
    return {
      A: records.filter(function (r) { return setA.has(r.fechaISO); }),
      B: records.filter(function (r) { return !setA.has(r.fechaISO); }),
      fechasA: fechasA, fechasB: fechasB
    };
  }

  function enRango(records, desde, hasta) {
    return (records || []).filter(function (r) {
      if (desde && r.fechaISO < desde) return false;
      if (hasta && r.fechaISO > hasta) return false;
      return true;
    });
  }

  /* --------------------------------------------------------------------------
   * KPIs base de un conjunto de registros (usados por Resumen y comparación).
   * Definiciones (todas en ANALYTICS_METRICS_DICTIONARY.md):
   *  - personas: logins distintos
   *  - personaDia: registros
   *  - conIncidencia / conError: registros con ≥1 incidencia / ≥1 error (≠ sec. 3)
   *  - horasAnalizables: Σ horas analizables
   *  - horasAfectadas: Σ horas con incidencia (dedup por registro de horas,
   *    tal como las calcula el motor en generarPersonDailyRecords)
   *  - incidencias / errores / erroresAsignacion
   * ------------------------------------------------------------------------ */
  function kpisBase(records) {
    var personas = new Set(), dias = new Set(), horas = 0, horasInc = 0,
      incs = 0, errores = 0, errAsig = 0, conIncidencia = 0, conError = 0;
    (records || []).forEach(function (r) {
      personas.add(r.login);
      dias.add(r.fechaISO);
      horas += r.horasAnalizables;
      horasInc += r.horasErrorDedup; // §50: solo errores reales (≠ sec. 3)
      incs += r.incidencias.length;
      errores += r.nErrores;
      if (r.conIncidencia) conIncidencia++;
      if (r.conError) conError++;
      errAsig += r.incidencias.filter(function (i) { return i.esErrorAsignacion; }).length;
    });
    var n = (records || []).length;
    return {
      personas: personas.size,
      dias: dias.size,
      personaDia: n,
      horasAnalizables: round2(horas),
      horasAfectadas: round2(horasInc),
      incidencias: incs,
      errores: errores,
      erroresAsignacion: errAsig,
      personaDiaConIncidencia: conIncidencia,
      personaDiaConError: conError,
      pctPersonaDiaConIncidencia: pct(conIncidencia, n),
      pctPersonaDiaConError: pct(conError, n),
      pctHorasAfectadas: pct(horasInc, horas),
      pctErroresAsignacion: pct(errAsig, incs),
      incidenciasPorPersonaDia: round2(safeDiv(incs, n))
    };
  }

  /* Compara dos periodos A y B (§4 Evolución): cambios absolutos y
   * relativos; para tasas se usan PUNTOS PORCENTUALES (§18). */
  function compararPeriodos(recA, recB) {
    var a = kpisBase(recA), b = kpisBase(recB);
    function delta(k) { return round2(b[k] - a[k]); }
    function deltaPct(k) {
      if (a[k] === 0) return b[k] === 0 ? 0 : null; // sin base: no se inventa %
      return round2((b[k] - a[k]) / a[k] * 100);
    }
    return {
      A: a, B: b,
      cambios: {
        incidencias: delta('incidencias'),
        incidenciasPct: deltaPct('incidencias'),
        pctPersonaDiaConError: { A: a.pctPersonaDiaConError, B: b.pctPersonaDiaConError, deltaPP: round2(b.pctPersonaDiaConError - a.pctPersonaDiaConError) },
        horasAfectadas: delta('horasAfectadas'),
        horasAfectadasPct: deltaPct('horasAfectadas'),
        erroresAsignacion: delta('erroresAsignacion'),
        personas: delta('personas'),
        errores: delta('errores')
      },
      // Etiqueta determinista (§17): mejora/empeora/sin cambio del % de
      // persona-día con error, con el umbral configurable de pp.
      etiqueta: null
    };
  }

  function etiquetaComparacion(comp, cfg) {
    if (!comp) return 'SIN DATOS';
    var dPP = comp.cambios.pctPersonaDiaConError.deltaPP;
    var u = Number(cfg && cfg.umbralCambioPP) || 0;
    if (dPP < -u) return 'MEJORA';
    if (dPP > u) return 'EMPEORA';
    return 'SIN CAMBIO';
  }

  window.SPEC_AN = {
    DEFAULT_CONFIG: DEFAULT_CONFIG,
    LS_KEY: LS_KEY,
    TIPO_ERROR: TIPO_ERROR,
    CATEGORIA_CAUSA: CATEGORIA_CAUSA,
    loadConfig: loadConfig,
    saveConfig: saveConfig,
    resetConfig: resetConfig,
    safeDiv: safeDiv,
    safeRate: safeRate,
    pct: pct,
    round2: round2,
    mediaMovil: mediaMovil,
    flechaTendencia: flechaTendencia,
    seccionNumero: seccionNumero,
    clasificarIncidencia: clasificarIncidencia,
    normalizarRegistro: normalizarRegistro,
    normalizarRecords: normalizarRecords,
    filtrarRecords: filtrarRecords,
    dimensionesDisponibles: dimensionesDisponibles,
    rangoDeRecords: rangoDeRecords,
    partirPorMitades: partirPorMitades,
    enRango: enRango,
    kpisBase: kpisBase,
    compararPeriodos: compararPeriodos,
    etiquetaComparacion: etiquetaComparacion
  };
})(typeof window !== 'undefined' ? window : globalThis);
