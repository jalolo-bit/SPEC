/* ============================================================================
 * SPEC Web v6.2.0 — ANALÍTICA POR PERSONA (personAnalytics.js)
 * ============================================================================
 * Responde: ¿quién se equivoca más? ¿quién mejora? ¿quién empeora?
 *
 * Principio §8 (NO CASTIGAR POR MÁS DÍAS ANALIZADOS): toda fila muestra
 * SIMULTÁNEAMENTE frecuencia (incidencias), tasa (días con error / días
 * analizados) e impacto (horas), junto con el nº de observaciones. Las
 * personas con menos días que cfg.minObservaciones se marcan MUESTRA PEQUEÑA
 * y quedan EXCLUIDAS de los extremos de los rankings por defecto (los datos
 * se muestran igualmente).
 * ========================================================================== */
(function (window) {
  'use strict';
  var AN = window.SPEC_AN;
  var safeDiv = AN.safeDiv, pct = AN.pct, round2 = AN.round2;

  /* Estadísticas por persona sobre los registros filtrados.
   * Definiciones (ANALYTICS_METRICS_DICTIONARY.md §Personas):
   *  - dias: nº de persona-día analizados
   *  - diasConError: persona-día con ≥1 error (sección ≠ 3)
   *  - tasaError: diasConError / dias
   *  - horasAfectadas: Σ horas con incidencia (dedup motor)
   *  - pctHorasAfectadas: horasAfectadas / horasAnalizables
   *  - cambiosTarea: incidencias sección 1 (cambio propuesto)
   *  - erroresAsignacion: sección 1 + decisiones aceptadas (definición v6.1)
   *  - recurrencia: días distintos con error (= diasConError; se expone
   *    aparte porque su semántica es reincidencia, no cobertura)
   *  - maxRacha: máximo de días CONSECUTIVOS con error (fecha operativa)
   */
  function computePersonStats(records, cfg) {
    var c = cfg || AN.DEFAULT_CONFIG;
    var by = new Map();
    (records || []).forEach(function (r) {
      var p = by.get(r.login);
      if (!p) {
        p = {
          login: r.login, persona: r.persona, dias: 0, diasConIncidencia: 0,
          diasConError: 0, incidencias: 0, errores: 0, erroresAsignacion: 0,
          cambiosTarea: 0, horasAnalizables: 0, horasAfectadas: 0,
          fechas: [], tareasConError: new Set(), turnos: new Set(),
          sinHoraDias: 0, otraUds: 0, udsTotales: 0
        };
        by.set(r.login, p);
      }
      p.dias++;
      p.fechas.push(r.fechaISO);
      p.horasAnalizables += r.horasAnalizables;
      p.horasAfectadas += r.horasErrorDedup; // §50: errores reales
      p.incidencias += r.incidencias.length;
      p.errores += r.nErrores;
      p.udsTotales += r.udsTotales;
      if (r.turno === 'SIN HORA') p.sinHoraDias++;
      r.turnos.forEach(function (t) { p.turnos.add(t); });
      if (r.conIncidencia) p.diasConIncidencia++;
      if (r.conError) p.diasConError++;
      r.incidencias.forEach(function (i) {
        if (i.esErrorFichaje) p.cambiosTarea++;
        if (i.esErrorAsignacion) p.erroresAsignacion++;
        if (i.esError && i.wmsTask) p.tareasConError.add(i.wmsTask);
        if (i.esError && !i.wmsTask && i.tareaOriginal) p.tareasConError.add(i.tareaOriginal);
      });
      r.tareas.forEach(function (t) { if (t.actividad === 'OTRA') p.otraUds += t.uds; });
    });
    var out = [];
    var fechasErrPorLogin = new Map(); // login → Set(fechaISO con error)
    (records || []).forEach(function (r) {
      if (!r.conError) return;
      if (!fechasErrPorLogin.has(r.login)) fechasErrPorLogin.set(r.login, new Set());
      fechasErrPorLogin.get(r.login).add(r.fechaISO);
    });
    by.forEach(function (p) {
      p.fechas.sort();
      // Racha máxima de días consecutivos con error (solo días presentes en
      // el histórico de ESA persona; los huecos rompen la racha).
      var racha = 0, maxRacha = 0, prev = null;
      var fechasErr = fechasErrPorLogin.get(p.login) || new Set();
      p.fechas.forEach(function (f) {
        if (fechasErr.has(f)) {
          racha = (prev && esDiaSiguiente(prev, f)) ? racha + 1 : 1;
          if (racha > maxRacha) maxRacha = racha;
        } else { racha = 0; }
        prev = f;
      });
      p.maxRacha = maxRacha;
      p.tasaError = safeDiv(p.diasConError, p.dias);
      p.pctDiasConError = pct(p.diasConError, p.dias);
      p.incidenciasPorDia = round2(safeDiv(p.incidencias, p.dias));
      p.pctHorasAfectadas = pct(p.horasAfectadas, p.horasAnalizables);
      p.muestraPequena = p.dias < c.minObservaciones;
      p.semaforo = semaforoPersona(p.pctDiasConError, p.dias, c);
      out.push(p);
    });
    out.sort(function (a, b) { return b.tasaError - a.tasaError || b.horasAfectadas - a.horasAfectadas || a.persona.localeCompare(b.persona); });
    return out;
  }

  function esDiaSiguiente(isoA, isoB) {
    try {
      var a = new Date(isoA + 'T00:00:00Z'), b = new Date(isoB + 'T00:00:00Z');
      return Math.round((b - a) / 86400000) === 1;
    } catch (_e) { return false; }
  }

  /* Semáforo de calidad de fichaje (§9) — umbrales DOCUMENTADOS y
   * configurables (cfg.semaforo*). Con menos días que cfg.semaforoMinDias
   * el semáforo se degrada a MUESTRA PEQUEÑA (el dato se muestra igual). */
  function semaforoPersona(pctDiasConError, dias, cfg) {
    if (!(dias >= cfg.semaforoMinDias)) return 'MUESTRA PEQUEÑA';
    var v = Number(pctDiasConError) || 0;
    if (v === 0) return 'MUY BUENO';
    if (v <= cfg.semaforoBueno) return 'BUENO';
    if (v <= cfg.semaforoNormal) return 'NORMAL';
    if (v <= cfg.semaforoAtencion) return 'ATENCIÓN';
    return 'CRÍTICO';
  }

  /* Mejora/empeoramiento por persona (§18/§19): compara dos mitades del
   * rango filtrado (o los periodos A/B que la UI pase). Solo se emite un
   * veredicto si AMBAS mitades tienen ≥ cfg.minDiasComparar días — con eso
   * un cambio basado en 1 día no marca a nadie (§19). */
  function computePersonTendencia(records, cfg) {
    var c = cfg || AN.DEFAULT_CONFIG;
    var partes = AN.partirPorMitades(records);
    var porLoginA = agruparPorLogin(partes.A), porLoginB = agruparPorLogin(partes.B);
    var logins = new Set([].concat(Array.from(porLoginA.keys()), Array.from(porLoginB.keys())));
    var out = [];
    var fechasErrPorLogin = new Map(); // login → Set(fechaISO con error)
    (records || []).forEach(function (r) {
      if (!r.conError) return;
      if (!fechasErrPorLogin.has(r.login)) fechasErrPorLogin.set(r.login, new Set());
      fechasErrPorLogin.get(r.login).add(r.fechaISO);
    });
    logins.forEach(function (login) {
      var a = porLoginA.get(login), b = porLoginB.get(login);
      var diasA = a ? a.dias : 0, diasB = b ? b.dias : 0;
      var tasaA = a ? pct(a.diasConError, a.dias) : null;
      var tasaB = b ? pct(b.diasConError, b.dias) : null;
      var deltaPP = (tasaA != null && tasaB != null) ? round2(tasaB - tasaA) : null;
      var suficiente = diasA >= c.minDiasComparar && diasB >= c.minDiasComparar;
      var horasA = a ? round2(a.horasAfectadas) : 0, horasB = b ? round2(b.horasAfectadas) : 0;
      var res = {
        login: login,
        persona: (b && b.persona) || (a && a.persona) || login,
        diasA: diasA, diasB: diasB,
        tasaA: tasaA, tasaB: tasaB, deltaPP: deltaPP,
        horasA: horasA, horasB: horasB, deltaHoras: round2(horasB - horasA),
        incidA: a ? a.incidencias : 0, incidB: b ? b.incidencias : 0,
        suficiente: suficiente,
        veredicto: 'SIN EVIDENCIA',
        flecha: '—'
      };
      if (suficiente && deltaPP != null) {
        if (deltaPP < -c.umbralCambioPP) res.veredicto = 'MEJORA';
        else if (deltaPP > c.umbralCambioPP) res.veredicto = 'EMPEORA';
        else res.veredicto = 'ESTABLE';
        res.flecha = AN.flechaTendencia(deltaPP, c.umbralCambioPP);
      }
      out.push(res);
    });
    return out;
  }

  function agruparPorLogin(records) {
    var by = new Map();
    (records || []).forEach(function (r) {
      var p = by.get(r.login);
      if (!p) { p = { login: r.login, persona: r.persona, dias: 0, diasConError: 0, incidencias: 0, horasAfectadas: 0 }; by.set(r.login, p); }
      p.dias++;
      p.incidencias += r.incidencias.length;
      p.horasAfectadas += r.horasErrorDedup; // §50: errores reales
      if (r.conError) p.diasConError++;
    });
    return by;
  }

  /* Perfil histórico de UNA persona (§34): métricas agregadas + evolución
   * diaria + tareas con error + recurrencias + turnos. */
  function computePersonProfile(records, login, cfg) {
    var propios = (records || []).filter(function (r) { return r.login === login; });
    if (propios.length === 0) return null;
    var stats = computePersonStats(propios, cfg)[0] || null;
    // Evolución diaria propia
    var porDia = new Map();
    propios.forEach(function (r) {
      var d = porDia.get(r.fechaISO) || { fechaISO: r.fechaISO, turno: r.turno, incidencias: 0, errores: 0, horasAfectadas: 0, horasAnalizables: 0 };
      d.incidencias += r.incidencias.length; d.errores += r.nErrores;
      d.horasAfectadas += r.horasErrorDedup; d.horasAnalizables += r.horasAnalizables;
      porDia.set(r.fechaISO, d);
    });
    // Errores por tarea (WMS si existe; si no, tarea fichada) y recurrencias
    var porTarea = new Map();
    var recurrencias = new Map(); // tareaOriginal→propuesta
    propios.forEach(function (r) {
      r.incidencias.forEach(function (i) {
        if (!i.esError) return;
        var tk = i.wmsTask || i.tareaOriginal || '(sin tarea)';
        var t = porTarea.get(tk) || { tarea: tk, errores: 0, horas: 0, dias: new Set() };
        t.errores++; t.horas += i.horasAfectadas; t.dias.add(r.fechaISO);
        porTarea.set(tk, t);
        if (i.esErrorFichaje && i.propuesta) {
          var rk = i.tareaOriginal + ' → ' + i.propuesta;
          var rr = recurrencias.get(rk) || { pareja: rk, origen: i.tareaOriginal, destino: i.propuesta, casos: 0, dias: new Set(), horas: 0 };
          rr.casos++; rr.dias.add(r.fechaISO); rr.horas += i.horasAfectadas;
          recurrencias.set(rk, rr);
        }
      });
    });
    var tareasDetalle = Array.from(porTarea.values()).map(function (t) {
      return { tarea: t.tarea, errores: t.errores, horas: round2(t.horas), dias: t.dias.size };
    }).sort(function (a, b) { return b.errores - a.errores; });
    var recs = Array.from(recurrencias.values()).map(function (r) {
      return { pareja: r.pareja, casos: r.casos, dias: r.dias.size, horas: round2(r.horas) };
    }).sort(function (a, b) { return b.dias - a.dias || b.casos - a.casos; });
    return {
      stats: stats,
      evolucion: Array.from(porDia.values()).sort(function (a, b) { return a.fechaISO < b.fechaISO ? -1 : 1; }),
      tareasConError: tareasDetalle,
      recurrencias: recs,
      turnos: stats ? Array.from(stats.turnos).sort() : [],
      tendencia: computePersonTendencia(propios, cfg)[0] || null
    };
  }

  window.SPEC_AN.person = {
    computePersonStats: computePersonStats,
    semaforoPersona: semaforoPersona,
    computePersonTendencia: computePersonTendencia,
    computePersonProfile: computePersonProfile
  };
})(typeof window !== 'undefined' ? window : globalThis);
