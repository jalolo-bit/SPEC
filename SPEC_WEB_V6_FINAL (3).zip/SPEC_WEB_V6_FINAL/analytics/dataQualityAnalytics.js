/* ============================================================================
 * SPEC Web v6.2.0 — CALIDAD DE DATOS Y DEL MAPPING (dataQualityAnalytics.js)
 * ============================================================================
 * Responde: ¿cuánto del problema puede venir del mapping o de datos
 * incompletos y no del comportamiento de las personas? (§49/§50)
 *
 * Separa SIEMPRE:
 *  - ERROR DE FICHAJE (operativo, sección 1)
 *  - ERROR DE ASIGNACIÓN (sección 1 + aceptadas — definición v6.1)
 *  - AMBIGÜEDAD MAPPING (sección 2) / SIN MAPPING (sección 5)
 *  - SIN VOLUMEN (sección 4) / MÚLTIPLES HR TASK (6) / AMBIGÜEDAD IDNUM (7)
 *  - SIN HORA (registro day-level) y OTRA (tarea sin clasificar)
 * ========================================================================== */
(function (window) {
  'use strict';
  var AN = window.SPEC_AN;
  var safeDiv = AN.safeDiv, pct = AN.pct, round2 = AN.round2;

  /* Panel de calidad de datos (§49). Todas las métricas con denominador. */
  function computeDataQuality(records) {
    var n = (records || []).length;
    var dias = new Set(), personas = new Set();
    var porTipo = {}; // tipoError → {casos, horas, personas, dias}
    var sinHora = 0, otraRegistros = 0, otraUds = 0, otraTareas = new Set(),
      sinMappingCasos = 0, sinMappingTareas = new Set(), sinMappingPersonas = new Set(),
      duplicadosVersion = 0, desviacionAbs = 0, udsSinHoras = 0,
      modoLogin = 0, modoIdNum = 0, sinModo = 0, incompletos = 0;
    (records || []).forEach(function (r) {
      dias.add(r.fechaISO);
      personas.add(r.login);
      if (r.turno === 'SIN HORA') sinHora++;
      if (r.previousVersions > 0) duplicadosVersion += r.previousVersions;
      desviacionAbs += Math.abs(r.desviacion);
      udsSinHoras += r.udsSinHoras;
      if (r.modoVolumen === 'LOGIN EXACTO') modoLogin++;
      else if (r.modoVolumen === 'MISMO NUMERO, DISTINTO PREFIJO') modoIdNum++;
      else if (r.incidencias.length > 0) sinModo++; // solo cuentan como "sin modo" los días con actividad
      var tieneOtra = false;
      r.tareas.forEach(function (t) {
        if (t.actividad === 'OTRA') {
          tieneOtra = true;
          otraUds += t.uds;
          otraTareas.add(t.taskWms);
        }
      });
      if (tieneOtra) otraRegistros++;
      r.incidencias.forEach(function (i) {
        var t = porTipo[i.tipoError] || { tipo: i.tipoError, casos: 0, horas: 0, personas: new Set(), dias: new Set(), categoria: i.categoria };
        t.casos++; t.horas += i.horasAfectadas;
        t.personas.add(r.login); t.dias.add(r.fechaISO);
        porTipo[i.tipoError] = t;
        if (i.esSinMapping) { sinMappingCasos++; if (i.wmsTask) sinMappingTareas.add(i.wmsTask); sinMappingPersonas.add(r.login); }
        if (i.esSinVolumen || i.esRevisionManual) incompletos++;
      });
    });
    var tipos = Object.keys(porTipo).map(function (k) {
      var t = porTipo[k];
      return {
        tipo: t.tipo, categoria: t.categoria, casos: t.casos,
        horas: round2(t.horas), personas: t.personas.size, dias: t.dias.size,
        pctSobreIncidencias: pct(t.casos, (records || []).reduce(function (s, r) { return s + r.incidencias.length; }, 0))
      };
    }).sort(function (a, b) { return b.casos - a.casos; });
    var totalIncidencias = tipos.reduce(function (s, t) { return s + t.casos; }, 0);
    // Separación operativo vs datos (§50):
    var casosOperativo = tipos.filter(function (t) { return t.categoria === 'OPERATIVO'; }).reduce(function (s, t) { return s + t.casos; }, 0);
    var casosDatos = tipos.filter(function (t) { return t.categoria === 'DATOS'; }).reduce(function (s, t) { return s + t.casos; }, 0);
    var casosRevision = tipos.filter(function (t) { return t.categoria === 'REVISIÓN'; }).reduce(function (s, t) { return s + t.casos; }, 0);
    return {
      diasCargados: dias.size,
      personas: personas.size,
      registros: n,
      registrosValidos: n,
      registrosSinHora: sinHora,
      pctSinHora: pct(sinHora, n),
      registrosOtra: otraRegistros,
      tareasOtra: otraTareas.size,
      udsOtra: round2(otraUds),
      casosSinMapping: sinMappingCasos,
      tareasSinMapping: sinMappingTareas.size,
      personasSinMapping: sinMappingPersonas.size,
      duplicadosVersionados: duplicadosVersion,
      datosIncompletos: incompletos,
      udsSinHorasArchivo: round2(udsSinHoras),
      personasSinVolumen: tipos.filter(function (t) { return t.tipo === 'SIN VOLUMEN'; })[0] || { personas: 0 },
      desviacionAbsMedia: round2(safeDiv(desviacionAbs, n)),
      modoVolumen: { loginExacto: modoLogin, idNumerico: modoIdNum, sinVolumen: sinModo },
      tipos: tipos,
      totalIncidencias: totalIncidencias,
      repartoCausas: {
        operativo: { casos: casosOperativo, pct: pct(casosOperativo, totalIncidencias) },
        datos: { casos: casosDatos, pct: pct(casosDatos, totalIncidencias) },
        revision: { casos: casosRevision, pct: pct(casosRevision, totalIncidencias) },
        control: { casos: tipos.filter(function (t) { return t.categoria === 'CONTROL'; }).reduce(function (s, t) { return s + t.casos; }, 0), pct: pct(tipos.filter(function (t) { return t.categoria === 'CONTROL'; }).reduce(function (s, t) { return s + t.casos; }, 0), totalIncidencias) }
      }
    };
  }

  /* Calidad del mapping (§30/§31): tareas sin mapping, ambiguas, OTRA,
   * overrides activos, cambios de mapping (hashes distintos en el tiempo),
   * nº de tareas clasificadas. Basado SOLO en lo observable en el histórico
   * (no carga el mapping actual — no inventa lo que no está en los datos). */
  function computeMappingQuality(records) {
    var sinMapping = new Map();     // taskWms → casos
    var ambiguas = new Map();        // tarea fichada → casos (sección 2)
    var otra = new Map();           // taskWms → {uds, dias, personas}
    var clasificadas = new Set();
    var mappings = new Map();       // hash → {fechas: Set, versiones}
    (records || []).forEach(function (r) {
      if (r.mappingHash) {
        var m = mappings.get(r.mappingHash) || { hash: r.mappingHash, fechas: new Set(), registros: 0 };
        m.fechas.add(r.fechaISO); m.registros++;
        mappings.set(r.mappingHash, m);
      }
      if (r.mappingVersion != null) {
        var mv = mappings.get(r.mappingHash);
        if (mv) mv.version = r.mappingVersion;
      }
      r.tareas.forEach(function (t) {
        if (t.actividad === 'OTRA') {
          var o = otra.get(t.taskWms) || { taskWms: t.taskWms, uds: 0, dias: new Set(), personas: new Set() };
          o.uds += t.uds; o.dias.add(r.fechaISO); o.personas.add(r.login);
          otra.set(t.taskWms, o);
        } else {
          clasificadas.add(t.taskWms);
        }
      });
      r.incidencias.forEach(function (i) {
        if (i.esSinMapping && i.wmsTask) {
          sinMapping.set(i.wmsTask, (sinMapping.get(i.wmsTask) || 0) + 1);
        }
        if (i.esAmbiguedad) {
          var k = i.wmsTask || i.tareaOriginal || '(sin tarea)';
          ambiguas.set(k, (ambiguas.get(k) || 0) + 1);
        }
      });
    });
    var listaMappings = Array.from(mappings.values()).map(function (m) {
      return { hash: m.hash, registros: m.registros, primeraFecha: Array.from(m.fechas).sort()[0], ultimaFecha: Array.from(m.fechas).sort().pop(), version: m.version != null ? m.version : null };
    }).sort(function (a, b) { return (a.primeraFecha || '') < (b.primeraFecha || '') ? -1 : 1; });
    return {
      tareasSinMapping: Array.from(sinMapping.entries()).map(function (e) { return { taskWms: e[0], casos: e[1] }; }).sort(function (a, b) { return b.casos - a.casos; }),
      tareasAmbiguas: Array.from(ambiguas.entries()).map(function (e) { return { tarea: e[0], casos: e[1] }; }).sort(function (a, b) { return b.casos - a.casos; }),
      tareasOtra: Array.from(otra.values()).map(function (o) { return { taskWms: o.taskWms, uds: round2(o.uds), dias: o.dias.size, personas: o.personas.size }; }).sort(function (a, b) { return b.uds - a.uds; }),
      tareasClasificadas: clasificadas.size,
      cambiosMapping: Math.max(0, listaMappings.length - 1),
      mappings: listaMappings
    };
  }

  window.SPEC_AN.dataQuality = {
    computeDataQuality: computeDataQuality,
    computeMappingQuality: computeMappingQuality
  };
})(typeof window !== 'undefined' ? window : globalThis);
