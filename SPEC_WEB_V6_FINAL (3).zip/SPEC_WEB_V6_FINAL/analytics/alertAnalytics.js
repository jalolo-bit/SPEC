/* ============================================================================
 * SPEC Web v6.2.0 — ALERTAS E INTELIGENCIA OPERATIVA (alertAnalytics.js)
 * ============================================================================
 * Responde: ¿dónde debemos poner el ojo? ¿dónde actuar primero?
 *
 * Reglas DETERMINISTAS documentadas (§37) — sin IA predictiva, sin modelos
 * opacos. Cada alerta lleva: código, título, explicación (por qué se dispara),
 * datos de apoyo y severidad. Los umbrales son los de la CONFIGURACIÓN
 * ESTADÍSTICA (ninguno oculto).
 *
 * ÍNDICE DE PRIORIDAD (§6) — fórmula TRANSPARENTE y ponderada:
 *   score = 100 · Σ (peso_i · valor_i / máx_i)   [0..100]
 * con máx_i = máximo del conjunto candidato y pesos editables
 * (frecuencia 20, tasa 20, horas 20, recurrencia 15, tendencia 15,
 * personas 10 por defecto). El desglose se muestra SIEMPRE (§6: el usuario
 * debe entender por qué algo es ALTA prioridad).
 * ========================================================================== */
(function (window) {
  'use strict';
  var AN = window.SPEC_AN;
  var safeDiv = AN.safeDiv, round2 = AN.round2;

  /* ------------------------------------------------------------------ */
  /* Cálculo de todas las alertas deterministas sobre los registros      */
  /* filtrados (todos los umbrales vienen de cfg).                       */
  /* ------------------------------------------------------------------ */
  function computeAlerts(records, cfg) {
    var c = cfg || AN.DEFAULT_CONFIG;
    var alerts = [];
    if (!(records || []).length) return alerts;

    var kpi = AN.kpisBase(records);
    var tareas = AN.task.computeTaskStats(records, c);
    var personas = AN.person.computePersonStats(records, c);
    var turnos = AN.activity.computeTurnoStats(records, c);
    var matrix = AN.confusion.computeConfusionMatrix(records);
    var tendencias = AN.task.computeTaskTendencia(records, c);

    /* A1 — Tarea con tasa de error en crecimiento (> umbral pp entre
     * mitades, con evidencia suficiente en ambas). */
    tendencias.forEach(function (t) {
      if (t.suficiente && t.deltaPP != null && t.deltaPP > c.umbralCambioPP) {
        alerts.push({
          codigo: 'A1_TASA_CRECIENTE', severidad: 'ALTA',
          titulo: 'La tarea «' + t.taskWms + '» ha aumentado su tasa de error',
          detalle: 'Δ ' + round2(t.deltaPP) + ' pp (' + (t.tasaA != null ? t.tasaA : 0) + '% → ' + (t.tasaB != null ? t.tasaB : 0) + '%) con ' + t.oportA + ' y ' + t.oportB + ' oportunidades por mitad.',
          datos: { taskWms: t.taskWms, deltaPP: t.deltaPP, tendencia: t }
        });
      }
    });

    /* A2 — Persona con racha de días consecutivos con error. */
    personas.forEach(function (p) {
      if (p.maxRacha >= c.rachaDias) {
        alerts.push({
          codigo: 'A2_RACHA_PERSONA', severidad: 'ALTA',
          titulo: p.persona + ' lleva ' + p.maxRacha + ' días consecutivos con errores',
          detalle: 'Tasa de días con error: ' + round2(p.pctDiasConError) + '% (' + p.diasConError + '/' + p.dias + ') · ' + p.incidencias + ' incidencias · ' + round2(p.horasAfectadas) + ' h afectadas.',
          datos: { login: p.login, racha: p.maxRacha, persona: p }
        });
      }
    });

    /* A3 — Concentración: las N primeras tareas explican ≥80% de los errores. */
    var par = AN.pareto.computePareto(tareas, function (t) { return t.errores; });
    if (par.nPara80 != null && par.total > 0) {
      var pctCubierto = par.items[par.nPara80 - 1] ? par.items[par.nPara80 - 1].pctAcumulado : 100;
      alerts.push({
        codigo: 'A3_CONCENTRACION', severidad: par.pctElementos80 <= 20 ? 'ALTA' : 'MEDIA',
        titulo: 'Top ' + par.nPara80 + ' de ' + par.nElementos + ' tareas concentran el ' + round2(pctCubierto) + '% de los ' + par.total + ' errores',
        detalle: 'Top ' + par.nPara80 + ' tareas (' + par.pctElementos80 + '% de las tareas con error) concentran el 80% de los ' + par.total + ' errores.' + (par.cumple8020 ? ' Se cumple la regla 80/20.' : ' NO se cumple la regla 80/20 (el reparto es más uniforme).'),
        datos: { pareto: par }
      });
    }

    /* A4 — Turno con tasa de error significativamente superior. */
    var tasaGlobal = kpi.pctPersonaDiaConError;
    turnos.turnos.forEach(function (t) {
      if (t.registros >= c.minObservaciones && t.pctError > tasaGlobal + c.umbralTurnoPP) {
        alerts.push({
          codigo: 'A4_TURNO_PEOR', severidad: 'MEDIA',
          titulo: 'El turno ' + t.turno + ' presenta una tasa de error superior',
          detalle: round2(t.pctError) + '% de persona-día con error frente al ' + round2(tasaGlobal) + '% global (+' + round2(t.pctError - tasaGlobal) + ' pp) sobre ' + t.registros + ' registros.',
          datos: { turno: t.turno, stats: t }
        });
      }
    });

    /* A5 — Tareas OTRA con volumen relevante (necesidad de mapping). */
    tareas.filter(function (t) { return t.actividad === 'OTRA'; }).forEach(function (t) {
      if (t.uds >= c.otraUdsMinimas || t.horasAfectadas >= c.impactoHorasAltas) {
        alerts.push({
          codigo: 'A5_OTRA_VOLUMEN', severidad: 'MEDIA',
          titulo: 'La tarea OTRA «' + t.taskWms + '» tiene volumen relevante sin clasificación productiva',
          detalle: t.uds + ' uds en ' + t.diasN + ' día(s) y ' + t.personasN + ' persona(s). Clasifícala desde ⚙ Productividades → PRODUCTIVIDAD POR TAREA.',
          datos: { taskWms: t.taskWms, uds: t.uds }
        });
      }
    });

    /* A6 — La misma confusión A→B se repite (≥ repeticionesConfusion veces). */
    matrix.forEach(function (cel) {
      if (cel.casos >= c.repeticionesConfusion) {
        alerts.push({
          codigo: 'A6_CONFUSION_REPETIDA', severidad: cel.dias >= c.recurrenciaHabitual ? 'ALTA' : 'MEDIA',
          titulo: 'La confusión «' + cel.origen + ' → ' + cel.destino + '» se repite ' + cel.casos + ' veces',
          detalle: cel.personas + ' persona(s) en ' + cel.dias + ' día(s) distintos · ' + cel.horas + ' h afectadas.',
          datos: { origen: cel.origen, destino: cel.destino, casos: cel.casos }
        });
      }
    });

    /* A7 — Persona con alta recurrencia (muchos días distintos con error). */
    personas.forEach(function (p) {
      if (p.diasConError >= c.recurrenciaHabitual) {
        alerts.push({
          codigo: 'A7_PERSONA_RECURRENTE', severidad: 'ALTA',
          titulo: p.persona + ' acumula ' + p.diasConError + ' días distintos con error',
          detalle: 'Sobre ' + p.dias + ' días analizados (' + round2(p.pctDiasConError) + '%) · ' + p.incidencias + ' incidencias · ' + round2(p.horasAfectadas) + ' h afectadas.',
          datos: { login: p.login, persona: p }
        });
      }
    });

    /* A8 — Impacto alto: pocos errores, muchas horas. */
    tareas.forEach(function (t) {
      if (t.errores > 0 && t.errores <= c.minObservaciones && t.horasAfectadas >= c.impactoHorasAltas) {
        alerts.push({
          codigo: 'A8_IMPACTO_ALTO', severidad: 'MEDIA',
          titulo: 'La tarea «' + t.taskWms + '» tiene pocos errores pero gran impacto en horas',
          detalle: t.errores + ' error(es) con ' + t.horasAfectadas + ' h afectadas (≥ ' + c.impactoHorasAltas + ' h).',
          datos: { taskWms: t.taskWms, errores: t.errores, horas: t.horasAfectadas }
        });
      }
    });

    /* A9 — Persona EMPEORA de forma sostenida (tendencia por mitades). */
    AN.person.computePersonTendencia(records, c).forEach(function (t) {
      if (t.suficiente && t.veredicto === 'EMPEORA') {
        alerts.push({
          codigo: 'A9_PERSONA_EMPEORA', severidad: 'MEDIA',
          titulo: pNombre(t) + ' empeora: ' + round2(t.tasaA) + '% → ' + round2(t.tasaB) + '% de días con error',
          detalle: 'Δ +' + t.deltaPP + ' pp con ' + t.diasA + ' y ' + t.diasB + ' días por mitad (umbral ' + c.umbralCambioPP + ' pp; mín. ' + c.minDiasComparar + ' días por mitad).',
          datos: { login: t.login, tendencia: t }
        });
      }
    });

    /* A10 — Persona MEJORA (refuerzo positivo, severidad informativa). */
    AN.person.computePersonTendencia(records, c).forEach(function (t) {
      if (t.suficiente && t.veredicto === 'MEJORA') {
        alerts.push({
          codigo: 'A10_PERSONA_MEJORA', severidad: 'INFO',
          titulo: pNombre(t) + ' mejora: ' + round2(t.tasaA) + '% → ' + round2(t.tasaB) + '% de días con error',
          detalle: 'Δ ' + t.deltaPP + ' pp con ' + t.diasA + ' y ' + t.diasB + ' días por mitad.',
          datos: { login: t.login, tendencia: t }
        });
      }
    });

    /* A11 — Calidad del dato: registros SIN HORA relevantes (no es error
     * operativo, es limitación del fichero de entrada — §50). */
    var sinHora = turnos.turnos.filter(function (t) { return t.turno === 'SIN HORA'; })[0];
    if (sinHora && sinHora.registros >= c.minObservaciones && sinHora.pesoRelativo >= 50) {
      alerts.push({
        codigo: 'A11_SIN_HORA', severidad: 'INFO',
        titulo: sinHora.pesoRelativo + '% de los persona-día no tienen hora de fichaje',
        detalle: sinHora.registros + ' registros SIN HORA (' + round2(sinHora.pesoRelativo) + '%). El análisis por turnos pierde cobertura con estos ficheros day-level.',
        datos: { registros: sinHora.registros }
      });
    }

    return alerts;
  }

  function pNombre(t) { return t.persona || t.login; }

  /* ------------------------------------------------------------------ */
  /* ÍNDICE DE PRIORIDAD DE ATENCIÓN (§6) + TOP 5 (§62)                  */
  /* ------------------------------------------------------------------ */
  /* candidatos: [{nombre, tipo, frecuencia, tasa (0..100), horas,
   * recurrencia (días), deltaPP (tendencia, puede ser null), personas}]
   * Devuelve lista con score 0-100, nivel (ALTA/MEDIA/BAJA) y DESGLOSE
   * completo de cada componente (para que el usuario vea el porqué). */
  function computePrioridades(candidatos, cfg) {
    var c = cfg || AN.DEFAULT_CONFIG;
    var list = (candidatos || []).filter(function (x) {
      return (x.frecuencia || 0) > 0 || (x.horas || 0) > 0;
    });
    if (list.length === 0) return [];
    var maxFrec = Math.max.apply(null, list.map(function (x) { return x.frecuencia || 0; }));
    var maxTasa = Math.max.apply(null, list.map(function (x) { return x.tasa || 0; }));
    var maxHoras = Math.max.apply(null, list.map(function (x) { return x.horas || 0; }));
    var maxRec = Math.max.apply(null, list.map(function (x) { return x.recurrencia || 0; }));
    var maxTend = Math.max.apply(null, list.map(function (x) { return x.deltaPP != null ? Math.max(0, x.deltaPP) : 0; }));
    var maxPers = Math.max.apply(null, list.map(function (x) { return x.personas || 0; }));
    var out = list.map(function (x) {
      var cFrec = maxFrec > 0 ? (x.frecuencia || 0) / maxFrec : 0;
      var cTasa = maxTasa > 0 ? (x.tasa || 0) / maxTasa : 0;
      var cHoras = maxHoras > 0 ? (x.horas || 0) / maxHoras : 0;
      var cRec = maxRec > 0 ? (x.recurrencia || 0) / maxRec : 0;
      var cTend = maxTend > 0 ? (x.deltaPP != null ? Math.max(0, x.deltaPP) : 0) / maxTend : 0;
      var cPers = maxPers > 0 ? (x.personas || 0) / maxPers : 0;
      var w = {
        frecuencia: c.pesoFrecuencia, tasa: c.pesoTasa, horas: c.pesoHoras,
        recurrencia: c.pesoRecurrencia, tendencia: c.pesoTendencia, personas: c.pesoPersonas
      };
      var score = Math.round(100 * (
        w.frecuencia * cFrec + w.tasa * cTasa + w.horas * cHoras +
        w.recurrencia * cRec + w.tendencia * cTend + w.personas * cPers
      ) / (w.frecuencia + w.tasa + w.horas + w.recurrencia + w.tendencia + w.personas));
      return {
        nombre: x.nombre, tipo: x.tipo, datos: x,
        score: score,
        nivel: score >= c.prioridadAlta ? 'ALTA' : (score >= c.prioridadMedia ? 'MEDIA' : 'BAJA'),
        desglose: {
          frecuencia: { valor: x.frecuencia || 0, peso: w.frecuencia, contrib: Math.round(w.frecuencia * cFrec) },
          tasa: { valor: round2(x.tasa || 0), peso: w.tasa, contrib: Math.round(w.tasa * cTasa) },
          horas: { valor: round2(x.horas || 0), peso: w.horas, contrib: Math.round(w.horas * cHoras) },
          recurrencia: { valor: x.recurrencia || 0, peso: w.recurrencia, contrib: Math.round(w.recurrencia * cRec) },
          tendencia: { valor: x.deltaPP != null ? round2(x.deltaPP) : null, peso: w.tendencia, contrib: Math.round(w.tendencia * cTend) },
          personas: { valor: x.personas || 0, peso: w.personas, contrib: Math.round(w.personas * cPers) }
        },
        flecha: x.deltaPP != null ? AN.flechaTendencia(x.deltaPP, c.umbralCambioPP) : '—'
      };
    });
    out.sort(function (a, b) { return b.score - a.score; });
    return out;
  }

  /* Construye los candidatos (tareas y personas) y devuelve el TOP N
   * (por defecto 5) con su desglose. */
  function computeTopPrioridades(records, cfg, topN) {
    var c = cfg || AN.DEFAULT_CONFIG;
    var tareas = AN.task.computeTaskStats(records, c);
    var personas = AN.person.computePersonStats(records, c);
    var tendTareas = AN.task.computeTaskTendencia(records, c);
    var tendPersonas = AN.person.computePersonTendencia(records, c);
    var idxT = {}, idxP = {};
    tendTareas.forEach(function (t) { idxT[t.taskWms] = t; });
    tendPersonas.forEach(function (t) { idxP[t.login] = t; });
    var candidatos = [];
    tareas.forEach(function (t) {
      if (t.errores <= 0 && t.horasAfectadas <= 0) return;
      var td = idxT[t.taskWms] || {};
      candidatos.push({
        nombre: t.taskWms, tipo: 'TAREA',
        frecuencia: t.errores, tasa: t.pctError, horas: t.horasAfectadas,
        recurrencia: t.diasN, deltaPP: td.deltaPP != null ? td.deltaPP : null,
        personas: t.personasN
      });
    });
    personas.forEach(function (p) {
      if (p.errores <= 0) return;
      var td = idxP[p.login] || {};
      candidatos.push({
        nombre: p.persona + ' (' + p.login + ')', tipo: 'PERSONA',
        frecuencia: p.errores, tasa: p.pctDiasConError, horas: p.horasAfectadas,
        recurrencia: p.diasConError, deltaPP: td.deltaPP != null ? td.deltaPP : null,
        personas: 1
      });
    });
    var prioridades = computePrioridades(candidatos, c);
    return prioridades.slice(0, topN || 5);
  }

  window.SPEC_AN.alerts = {
    computeAlerts: computeAlerts,
    computePrioridades: computePrioridades,
    computeTopPrioridades: computeTopPrioridades
  };
})(typeof window !== 'undefined' ? window : globalThis);
