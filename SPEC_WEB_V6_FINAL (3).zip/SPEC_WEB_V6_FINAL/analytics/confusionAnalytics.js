/* ============================================================================
 * SPEC Web v6.2.0 — MATRIZ DE CONFUSIONES Y RECURRENCIA (confusionAnalytics.js)
 * ============================================================================
 * Responde: ¿qué tareas se confunden con otras? ¿qué errores se repiten?
 *
 * MATRIZ FICHADA → CORRECTA (§12): sobre incidencias sección 1 (cambio de
 * HR task propuesto). Fila = tarea FICHADA (HR TASK FICHADA), columna =
 * tarea CORRECTA propuesta (TASKSPEC SEGUN MAPPING). Casos, personas, horas
 * (dedup por registro de horas) y días.
 *
 * ERRORES RECURRENTES (§22): persona + pareja (origen→destino) repetida en
 * varios días. PERSISTENCIA (§23): aislado (1 día), recurrente (2..N),
 * habitual (N+1..) con N configurable.
 * ========================================================================== */
(function (window) {
  'use strict';
  var AN = window.SPEC_AN;
  var round2 = AN.round2;

  function normTask(t) { return String(t == null ? '' : t).trim(); }

  /* Matriz fichada→correcta. Cada celda acumula casos (líneas de propuesta),
   * personas, días, horas (dedup) y en qué tareas WMS se originó el volumen. */
  function computeConfusionMatrix(records) {
    var celdas = new Map();
    (records || []).forEach(function (r) {
      r.incidencias.forEach(function (i) {
        if (!i.esErrorFichaje) return;
        var origen = normTask(i.tareaOriginal) || '(vacía)';
        // Sección 2 puede traer varias propuestas separadas por ' | '.
        var propuestas = normTask(i.propuesta).split(' | ').map(function (s) { return s.trim(); }).filter(Boolean);
        if (propuestas.length === 0) propuestas = ['(sin propuesta)'];
        var idReg = String(i.id).split('@')[0];
        propuestas.forEach(function (dest) {
          var k = origen + '→' + dest;
          var cel = celdas.get(k);
          if (!cel) {
            cel = {
              origen: origen, destino: dest, casos: 0, personas: new Set(),
              dias: new Set(), horas: 0, dedup: new Set(), wmsTasks: new Set()
            };
            celdas.set(k, cel);
          }
          cel.casos++;
          cel.personas.add(r.login);
          cel.dias.add(r.fechaISO);
          if (i.wmsTask) cel.wmsTasks.add(i.wmsTask);
          var dk = r.key + '|' + idReg + '|' + dest;
          if (!cel.dedup.has(dk)) { cel.dedup.add(dk); cel.horas += i.horasAfectadas; }
        });
      });
    });
    var out = Array.from(celdas.values()).map(function (cel) {
      return {
        origen: cel.origen, destino: cel.destino, casos: cel.casos,
        personas: cel.personas.size, dias: cel.dias.size,
        horas: round2(cel.horas), wmsTasks: Array.from(cel.wmsTasks).sort()
      };
    });
    out.sort(function (a, b) { return b.casos - a.casos || b.horas - a.horas; });
    return out;
  }

  /* Errores recurrentes (§22): persona + pareja fichada→correcta, con nº de
   * días distintos, casos y horas. La persistencia (§23) se clasifica con
   * los umbrales configurables: 1 día = AISLADO; 2..recurrenciaRecurrente =
   * RECURRENTE; > recurrenciaRecurrente = HABITUAL (por defecto 5+ días). */
  function computeRecurrencias(records, cfg) {
    var c = cfg || AN.DEFAULT_CONFIG;
    var by = new Map();
    (records || []).forEach(function (r) {
      r.incidencias.forEach(function (i) {
        if (!i.esErrorFichaje) return;
        var origen = normTask(i.tareaOriginal) || '(vacía)';
        var dest = normTask(i.propuesta) || '(sin propuesta)';
        var k = r.login + '|' + origen + '→' + dest;
        var x = by.get(k);
        if (!x) {
          x = {
            login: r.login, persona: r.persona, origen: origen, destino: dest,
            casos: 0, dias: new Set(), horas: 0, turnos: new Set()
          };
          by.set(k, x);
        }
        x.casos++;
        x.dias.add(r.fechaISO);
        x.horas += i.horasAfectadas;
        if (r.turno) x.turnos.add(r.turno);
      });
    });
    var out = Array.from(by.values()).map(function (x) {
      var dias = x.dias.size;
      var persistencia = dias <= 1 ? 'AISLADO'
        : (dias <= c.recurrenciaRecurrente ? 'RECURRENTE' : 'HABITUAL');
      return {
        login: x.login, persona: x.persona, origen: x.origen, destino: x.destino,
        casos: x.casos, dias: dias, horas: round2(x.horas),
        turnos: Array.from(x.turnos).sort(), persistencia: persistencia
      };
    });
    out.sort(function (a, b) { return b.dias - a.dias || b.casos - a.casos || b.horas - a.horas; });
    return out;
  }

  /* Matriz como tabla cruzada (para heatmap §13): filas = orígenes,
   * columnas = destinos, valor = casos. Se construye desde la lista plana. */
  function computeConfusionHeatmap(matrix) {
    var origenes = [], destinos = [];
    var seenO = new Set(), seenD = new Set();
    (matrix || []).forEach(function (cel) {
      if (!seenO.has(cel.origen)) { seenO.add(cel.origen); origenes.push(cel.origen); }
      if (!seenD.has(cel.destino)) { seenD.add(cel.destino); destinos.push(cel.destino); }
    });
    var idxO = {}, idxD = {};
    origenes.forEach(function (o, i) { idxO[o] = i; });
    destinos.forEach(function (d, i) { idxD[d] = i; });
    var grid = origenes.map(function () { return destinos.map(function () { return 0; }); });
    (matrix || []).forEach(function (cel) {
      var i = idxO[cel.origen], j = idxD[cel.destino];
      if (i != null && j != null && i >= 0 && j >= 0) grid[i][j] = cel.casos;
    });
    var max = 0;
    grid.forEach(function (row) { row.forEach(function (v) { if (v > max) max = v; }); });
    return { origenes: origenes, destinos: destinos, grid: grid, max: max };
  }

  window.SPEC_AN.confusion = {
    computeConfusionMatrix: computeConfusionMatrix,
    computeRecurrencias: computeRecurrencias,
    computeConfusionHeatmap: computeConfusionHeatmap
  };
})(typeof window !== 'undefined' ? window : globalThis);
