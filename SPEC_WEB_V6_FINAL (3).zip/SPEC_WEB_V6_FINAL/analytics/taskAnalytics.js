/* ============================================================================
 * SPEC Web v6.2.0 — ANALÍTICA POR TAREA (taskAnalytics.js)
 * ============================================================================
 * Responde: ¿qué tareas se fichan peor? ¿qué tareas mejoran/empeoran?
 *
 * DOS ESPACIOS DE NOMBRES (documentado, no se mezclan):
 *  1. TASK_WMS (volumen): oportunidades = persona-día con volumen sobre esa
 *     tarea; errores = incidencias imputadas vía 'WMS TASK CON VOLUMEN'.
 *  2. Tarea fichada / HR Task (fichajes): oportunidades = nº de fichajes de
 *     esa HR Task (registros[].hrTask); errores = incidencias sección 1 con
 *     esa tarea original. Es el espacio de la matriz de confusiones.
 *
 * REGLA DE IMPUTACIÓN (§11): un error se imputa SOLO a la tarea realmente
 * afectada — la TASK_WMS con volumen que genera la propuesta (incidencia) —
 * NUNCA a todas las tareas/actividades del día de la persona.
 * ========================================================================== */
(function (window) {
  'use strict';
  var AN = window.SPEC_AN;
  var safeDiv = AN.safeDiv, pct = AN.pct, round2 = AN.round2;

  /* Normaliza un código de tarea para agrupar (trim + case). */
  function normTask(t) { return String(t == null ? '' : t).trim(); }

  /* ------------------------------------------------------------------ */
  /* RANKING TASK_WMS (espacio de volumen)                              */
  /* ------------------------------------------------------------------ */
  function computeTaskStats(records, cfg) {
    var c = cfg || AN.DEFAULT_CONFIG;
    var by = new Map();
    (records || []).forEach(function (r) {
      var vistas = new Set(); // la tarea cuenta 1 oportunidad por persona-día
      r.tareas.forEach(function (t) {
        var k = normTask(t.taskWms);
        if (!k) return;
        var x = by.get(k);
        if (!x) {
          x = {
            taskWms: k, actividad: t.actividad || 'OTRA', clientes: new Set(),
            oportunidades: 0, errores: 0, horasAfectadas: 0, personas: new Set(),
            dias: new Set(), uds: 0, horasAsignadas: 0, productividad: t.productividad,
            fuente: t.fuente || 'DEFAULT', fichajesErroneos: new Set()
          };
          by.set(k, x);
        }
        if (!vistas.has(k)) { vistas.add(k); x.oportunidades++; }
        x.personas.add(r.login);
        x.dias.add(r.fechaISO);
        x.uds += t.uds;
        x.horasAsignadas += t.horasAsignadas;
        if (t.cliente) x.clientes.add(t.cliente);
      });
      // Imputación: SOLO la tarea con volumen de cada incidencia (§11).
      r.incidencias.forEach(function (i) {
        if (!i.esError) return;
        var k = normTask(i.wmsTask);
        if (!k) return; // incidencias sin tarea WMS asociada no se imputan aquí
        var x = by.get(k);
        if (!x) {
          x = {
            taskWms: k, actividad: 'OTRA', clientes: new Set(), oportunidades: 0,
            errores: 0, horasAfectadas: 0, personas: new Set(), dias: new Set(),
            uds: 0, horasAsignadas: 0, productividad: null, fuente: 'DEFAULT', fichajesErroneos: new Set()
          };
          by.set(k, x);
        }
        x.errores++;
        // Horas afectadas dedup por registro de horas (igual que el motor:
        // cada ID REGISTRO cuenta una vez aunque genere varias propuestas).
        var idReg = String(i.id).split('@')[0];
        if (!x.fichajesErroneos.has(idReg)) {
          x.fichajesErroneos.add(idReg);
          x.horasAfectadas += i.horasAfectadas;
        }
        x.personas.add(r.login);
        x.dias.add(r.fechaISO);
      });
    });
    var out = Array.from(by.values()).map(function (x) {
      x.personasN = x.personas.size;
      x.diasN = x.dias.size;
      x.horasAfectadas = round2(x.horasAfectadas);
      x.tasaError = pct(x.errores, x.oportunidades);
      x.pctError = x.tasaError; // alias semántico (UI)
      x.tasa = safeDiv(x.errores, x.oportunidades);
      x.muestraPequena = x.oportunidades < c.minObservaciones;
      x.clientesN = Array.from(x.clientes).sort();
      delete x.personas; delete x.dias; delete x.clientes; delete x.fichajesErroneos;
      return x;
    });
    // Orden por defecto: errores desc (documentado en la UI).
    out.sort(function (a, b) { return b.errores - a.errores || b.tasa - a.tasa || a.taskWms.localeCompare(b.taskWms); });
    return out;
  }

  /* Tendencia por tarea (§20/§21): tasa en la 1ª mitad vs 2ª mitad del
   * rango filtrado; veredicto solo con evidencia suficiente. */
  function computeTaskTendencia(records, cfg) {
    var c = cfg || AN.DEFAULT_CONFIG;
    var partes = AN.partirPorMitades(records);
    var statsA = indexByTask(computeTaskStats(partes.A, c));
    var statsB = indexByTask(computeTaskStats(partes.B, c));
    var keys = new Set([].concat(Object.keys(statsA), Object.keys(statsB)));
    var out = [];
    keys.forEach(function (k) {
      var a = statsA[k], b = statsB[k];
      var oportA = a ? a.oportunidades : 0, oportB = b ? b.oportunidades : 0;
      var errA = a ? a.errores : 0, errB = b ? b.errores : 0;
      var tasaA = a ? a.tasa : null, tasaB = b ? b.tasa : null;
      var deltaPP = (tasaA != null && tasaB != null) ? round2((tasaB - tasaA) * 100) : null;
      var suficiente = oportA >= c.minObservaciones && oportB >= c.minObservaciones;
      var res = {
        taskWms: k, actividad: (b && b.actividad) || (a && a.actividad) || 'OTRA',
        oportA: oportA, oportB: oportB, errA: errA, errB: errB,
        tasaA: tasaA != null ? round2(tasaA * 100) : null,
        tasaB: tasaB != null ? round2(tasaB * 100) : null,
        deltaPP: deltaPP, suficiente: suficiente, veredicto: 'SIN EVIDENCIA', flecha: '—',
        horasA: a ? a.horasAfectadas : 0, horasB: b ? b.horasAfectadas : 0
      };
      if (suficiente && deltaPP != null) {
        if (deltaPP < -c.umbralCambioPP) res.veredicto = 'MEJORA';
        else if (deltaPP > c.umbralCambioPP) res.veredicto = 'EMPEORA';
        else res.veredicto = 'ESTABLE';
        res.flecha = AN.flechaTendencia(deltaPP, c.umbralCambioPP);
      }
      out.push(res);
    });
    out.sort(function (a, b) { return (b.deltaPP || 0) - (a.deltaPP || 0); });
    return out;
  }

  function indexByTask(list) {
    var o = {};
    (list || []).forEach(function (x) { o[x.taskWms] = x; });
    return o;
  }

  /* ------------------------------------------------------------------ */
  /* TAREAS FICHADAS (espacio HR Task) — ¿qué tareas se fichan mal?      */
  /* Oportunidad = cada fichaje (registro de horas) con esa HR Task.     */
  /* Error = incidencia sección 1 (cambio propuesto) sobre esa tarea.    */
  /* ------------------------------------------------------------------ */
  function computeFichajeStats(records, cfg) {
    var c = cfg || AN.DEFAULT_CONFIG;
    var by = new Map();
    (records || []).forEach(function (r) {
      var fichadas = new Map(); // hrTask → nº fichajes ese persona-día
      (r.registros || []).forEach(function (rg) {
        var k = normTask(rg.hrTask);
        if (!k) return;
        fichadas.set(k, (fichadas.get(k) || 0) + 1);
      });
      fichadas.forEach(function (_n, k) {
        var x = by.get(k);
        if (!x) {
          x = {
            hrTask: k, fichajes: 0, erroresCambio: 0, correctas: 0,
            personas: new Set(), dias: new Set(), horasAfectadas: 0,
            dedup: new Set(), propuestas: new Map()
          };
          by.set(k, x);
        }
        x.fichajes += _n;
        x.personas.add(r.login);
        x.dias.add(r.fechaISO);
      });
      r.incidencias.forEach(function (i) {
        var k = normTask(i.tareaOriginal);
        if (!k) return;
        var x = by.get(k);
        if (!x) {
          x = { hrTask: k, fichajes: 0, erroresCambio: 0, correctas: 0, personas: new Set(), dias: new Set(), horasAfectadas: 0, dedup: new Set(), propuestas: new Map() };
          by.set(k, x);
          x.personas.add(r.login); x.dias.add(r.fechaISO);
        }
        if (i.esControl) x.correctas++;
        if (i.esErrorFichaje) {
          x.erroresCambio++;
          var idReg = String(i.id).split('@')[0];
          if (!x.dedup.has(idReg)) { x.dedup.add(idReg); x.horasAfectadas += i.horasAfectadas; }
          if (i.propuesta) {
            var pk = normTask(i.propuesta);
            var pr = x.propuestas.get(pk) || { tarea: pk, casos: 0 };
            pr.casos++;
            x.propuestas.set(pk, pr);
          }
        }
      });
    });
    var out = Array.from(by.values()).map(function (x) {
      var propuestas = Array.from(x.propuestas.values()).sort(function (a, b) { return b.casos - a.casos; });
      var solucion = propuestas.length === 1 && x.erroresCambio > 0 ? propuestas[0].tarea : null;
      return {
        hrTask: x.hrTask,
        fichajes: x.fichajes,
        erroresCambio: x.erroresCambio,
        correctas: x.correctas,
        // Tasa documentada: cambios propuestos / (cambios + correctas).
        // El denominador son las incidencias RESUELTAS contra mapping, no
        // el total de fichajes (algunos fichajes no generan propuesta).
        tasaCambio: pct(x.erroresCambio, x.erroresCambio + x.correctas),
        tasaSobreFichajes: pct(x.erroresCambio, x.fichajes),
        personas: x.personas.size,
        dias: x.dias.size,
        horasAfectadas: round2(x.horasAfectadas),
        muestraPequena: (x.erroresCambio + x.correctas) < c.minObservaciones,
        topPropuestas: propuestas.slice(0, 5),
        propuestaHabitual: solucion
      };
    });
    out.sort(function (a, b) { return b.erroresCambio - a.erroresCambio || b.tasaCambio - a.tasaCambio; });
    return out;
  }

  /* Detalle de UNA TASK_WMS (§35): días, personas, errores, horas, tareas
   * destino (fichadas), tendencia, personas más afectadas, mapping usado. */
  function computeTaskProfile(records, taskWms, cfg) {
    var k = normTask(taskWms);
    var propios = (records || []).filter(function (r) {
      return r.tareas.some(function (t) { return normTask(t.taskWms) === k; }) ||
        r.incidencias.some(function (i) { return normTask(i.wmsTask) === k; });
    });
    if (propios.length === 0) return null;
    var todas = computeTaskStats(records, cfg).filter(function (t) { return t.taskWms === k; });
    var base = todas[0] || null;
    var porPersona = new Map();
    var porDia = new Map();
    var mappings = new Set();
    propios.forEach(function (r) {
      if (r.mappingHash) mappings.add(r.mappingHash);
      var d = porDia.get(r.fechaISO) || { fechaISO: r.fechaISO, errores: 0, uds: 0 };
      r.tareas.forEach(function (t) { if (normTask(t.taskWms) === k) d.uds += t.uds; });
      r.incidencias.forEach(function (i) { if (normTask(i.wmsTask) === k && i.esError) { d.errores++; } });
      porDia.set(r.fechaISO, d);
      var p = porPersona.get(r.login) || { login: r.login, persona: r.persona, errores: 0, dias: new Set() };
      r.incidencias.forEach(function (i) { if (normTask(i.wmsTask) === k && i.esError) { p.errores++; p.dias.add(r.fechaISO); } });
      porPersona.set(r.login, p);
    });
    return {
      stats: base,
      personasAfectadas: Array.from(porPersona.values())
        .map(function (p) { return { login: p.login, persona: p.persona, errores: p.errores, dias: p.dias.size }; })
        .sort(function (a, b) { return b.errores - a.errores; }),
      evolucion: Array.from(porDia.values()).sort(function (a, b) { return a.fechaISO < b.fechaISO ? -1 : 1; }),
      mappingsUsados: Array.from(mappings)
    };
  }

  window.SPEC_AN.task = {
    normTask: normTask,
    computeTaskStats: computeTaskStats,
    computeTaskTendencia: computeTaskTendencia,
    computeFichajeStats: computeFichajeStats,
    computeTaskProfile: computeTaskProfile
  };
})(typeof window !== 'undefined' ? window : globalThis);
