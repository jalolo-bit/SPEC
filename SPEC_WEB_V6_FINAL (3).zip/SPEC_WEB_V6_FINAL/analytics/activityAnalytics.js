/* ============================================================================
 * SPEC Web v6.2.0 — ANALÍTICA POR ACTIVIDAD (activityAnalytics.js)
 * ============================================================================
 * Responde: ¿qué actividad concentra más errores? ¿en qué turno?
 *
 * REGLA DE IMPUTACIÓN (§11): los errores se imputan a la actividad de la
 * TASK_WMS realmente afectada (la tarea con volumen de la incidencia). Si la
 * incidencia no tiene tarea WMS asociada (secciones 4/6/7), NO se imputa a
 * ninguna actividad productiva (se contabiliza aparte como DATOS/REVISIÓN).
 * ========================================================================== */
(function (window) {
  'use strict';
  var AN = window.SPEC_AN;
  var safeDiv = AN.safeDiv, pct = AN.pct, round2 = AN.round2;
  var ACTIVIDADES = ['AUDITORIA AGV', 'AUDITORIA MANUAL', 'UBICACION AGV', 'UBICACION MANUAL', 'PICKING AGV', 'PICKING MANUAL', 'OTRA'];

  function computeActivityStats(records, cfg) {
    var c = cfg || AN.DEFAULT_CONFIG;
    var by = new Map();
    (records || []).forEach(function (r) {
      var vistas = new Set();
      r.tareas.forEach(function (t) {
        var k = t.actividad || 'OTRA';
        var x = by.get(k);
        if (!x) {
          x = {
            actividad: k, oportunidades: 0, errores: 0, horasAfectadas: 0,
            personas: new Set(), dias: new Set(), uds: 0, horasAsignadas: 0,
            turnos: new Map(), tareas: new Set(), dedup: new Set()
          };
          by.set(k, x);
        }
        if (!vistas.has(k)) {
          vistas.add(k);
          x.oportunidades++;
          var tu0 = x.turnos.get(r.turno) || { registros: 0, errores: 0 };
          tu0.registros++; // 1 por persona-día con esa actividad (no por tarea)
          x.turnos.set(r.turno, tu0);
        }
        x.personas.add(r.login);
        x.dias.add(r.fechaISO);
        x.uds += t.uds;
        x.horasAsignadas += t.horasAsignadas;
        x.tareas.add(t.taskWms);
      });
      r.incidencias.forEach(function (i) {
        if (!i.esError || !i.wmsTask) return;
        // Actividad de la tarea afectada (no de todo el día — §11).
        var act = null;
        for (var ti = 0; ti < r.tareas.length; ti++) {
          if (r.tareas[ti].taskWms === i.wmsTask) { act = r.tareas[ti].actividad; break; }
        }
        if (act == null) act = 'OTRA'; // tarea con volumen pero sin fila de reparto (p. ej. sin productividad)
        var x = by.get(act);
        if (!x) {
          x = { actividad: act, oportunidades: 0, errores: 0, horasAfectadas: 0, personas: new Set(), dias: new Set(), uds: 0, horasAsignadas: 0, turnos: new Map(), tareas: new Set(), dedup: new Set() };
          by.set(act, x);
        }
        x.errores++;
        var idReg = String(i.id).split('@')[0];
        if (!x.dedup.has(idReg)) { x.dedup.add(idReg); x.horasAfectadas += i.horasAfectadas; }
        x.personas.add(r.login);
        x.dias.add(r.fechaISO);
        var tu = x.turnos.get(r.turno) || { registros: 0, errores: 0 };
        tu.errores++;
        x.turnos.set(r.turno, tu);
      });
    });
    var out = Array.from(by.values()).map(function (x) {
      var turnos = {};
      x.turnos.forEach(function (v, t) { turnos[t] = v; });
      return {
        actividad: x.actividad,
        oportunidades: x.oportunidades,
        errores: x.errores,
        tasa: safeDiv(x.errores, x.oportunidades),
        pctError: pct(x.errores, x.oportunidades),
        personas: x.personas.size,
        dias: x.dias.size,
        uds: round2(x.uds),
        horasAsignadas: round2(x.horasAsignadas),
        horasAfectadas: round2(x.horasAfectadas),
        nTareas: x.tareas.size,
        turnos: turnos,
        muestraPequena: x.oportunidades < c.minObservaciones
      };
    });
    // Orden canónico: las 7 actividades de ACTIVIDADES_ANALISIS primero.
    out.sort(function (a, b) {
      var ia = ACTIVIDADES.indexOf(a.actividad), ib = ACTIVIDADES.indexOf(b.actividad);
      if (ia < 0) ia = 99; if (ib < 0) ib = 99;
      if (ia !== ib) return ia - ib;
      return b.errores - a.errores;
    });
    return out;
  }

  /* Detalle de UNA actividad (§36): tareas, errores, personas, horas,
   * tendencia y distribución por turno. */
  function computeActivityProfile(records, actividad, cfg) {
    var stats = computeActivityStats(records, cfg).filter(function (a) { return a.actividad === actividad; });
    if (stats.length === 0) return null;
    var tareas = AN.task.computeTaskStats(records, cfg).filter(function (t) { return t.actividad === actividad; });
    var tendencia = AN.task.computeTaskTendencia(records, cfg).filter(function (t) { return t.actividad === actividad; });
    var errA = 0, errB = 0, oportA = 0, oportB = 0;
    var partes = AN.partirPorMitades(records);
    [partes.A, partes.B].forEach(function (parte, ix) {
      var st = computeActivityStats(parte, cfg).filter(function (a) { return a.actividad === actividad; })[0];
      if (st) { if (ix === 0) { errA = st.errores; oportA = st.oportunidades; } else { errB = st.errores; oportB = st.oportunidades; } }
    });
    return {
      stats: stats[0],
      tareas: tareas,
      tendenciaTareas: tendencia,
      tendencia: {
        errA: errA, errB: errB, oportA: oportA, oportB: oportB,
        tasaA: round2(pct(errA, oportA)), tasaB: round2(pct(errB, oportB)),
        deltaPP: round2(pct(errB, oportB) - pct(errA, oportA))
      }
    };
  }

  /* Análisis por TURNO (§27): tasa de error, incidencias, horas afectadas.
   * Los registros SIN HORA permanecen como SIN HORA (nunca se reparten).
   * La tendencia por turno usa mitades del rango. */
  function computeTurnoStats(records, cfg) {
    var c = cfg || AN.DEFAULT_CONFIG;
    var by = new Map();
    (records || []).forEach(function (r) {
      var x = by.get(r.turno);
      if (!x) { x = { turno: r.turno, registros: 0, conError: 0, incidencias: 0, errores: 0, erroresAsignacion: 0, horasAfectadas: 0, horasAnalizables: 0, personas: new Set() }; by.set(r.turno, x); }
      x.registros++;
      x.incidencias += r.incidencias.length;
      x.errores += r.nErrores;
      x.horasAfectadas += r.horasErrorDedup;
      x.horasAnalizables += r.horasAnalizables;
      x.personas.add(r.login);
      x.erroresAsignacion += r.incidencias.filter(function (i) { return i.esErrorAsignacion; }).length;
      if (r.conError) x.conError++;
    });
    var total = (records || []).length;
    var out = Array.from(by.values()).map(function (x) {
      return {
        turno: x.turno, registros: x.registros, conError: x.conError,
        tasa: safeDiv(x.conError, x.registros),
        pctError: pct(x.conError, x.registros),
        incidencias: x.incidencias, errores: x.errores,
        erroresAsignacion: x.erroresAsignacion,
        horasAfectadas: round2(x.horasAfectadas),
        pctHorasAfectadas: pct(x.horasAfectadas, x.horasAnalizables),
        personas: x.personas.size,
        pesoRelativo: pct(x.registros, total)
      };
    });
    var orden = ['MAÑANA', 'TARDE', 'NOCHE', 'MIXTO', 'SIN HORA'];
    out.sort(function (a, b) {
      var ia = orden.indexOf(a.turno), ib = orden.indexOf(b.turno);
      if (ia < 0) ia = 99; if (ib < 0) ib = 99;
      if (ia !== ib) return ia - ib;
      return b.pctError - a.pctError;
    });
    // Tendencia por turno (mitades)
    var partes = AN.partirPorMitades(records);
    var tend = {};
    out.forEach(function (t) {
      var a = 0, b = 0, nA = 0, nB = 0;
      partes.A.forEach(function (r) { if (r.turno === t.turno) { nA++; if (r.conError) a++; } });
      partes.B.forEach(function (r) { if (r.turno === t.turno) { nB++; if (r.conError) b++; } });
      var tA = pct(a, nA), tB = pct(b, nB);
      tend[t.turno] = {
        nA: nA, nB: nB, pctA: tA, pctB: tB,
        deltaPP: (nA >= c.minDiasComparar && nB >= c.minDiasComparar) ? round2(tB - tA) : null
      };
    });
    return { turnos: out, tendencia: tend };
  }

  window.SPEC_AN.activity = {
    ACTIVIDADES: ACTIVIDADES,
    computeActivityStats: computeActivityStats,
    computeActivityProfile: computeActivityProfile,
    computeTurnoStats: computeTurnoStats
  };
})(typeof window !== 'undefined' ? window : globalThis);
