/* ============================================================================
 * SPEC Web v6.2.0 — PARETO Y CONCENTRACIÓN (paretoAnalytics.js)
 * ============================================================================
 * Responde: ¿qué porcentaje de errores explican las principales tareas?
 *
 * Curva de Pareto (§24): elementos ordenados por valor desc, con % individual
 * y % ACUMULADO. La regla 80/20 SOLO se afirma si los datos la cumplen:
 * se reporta el nº de elementos necesario para cubrir el 80% y el % que
 * representan, y un flag booleano `cumple8020` con la comprobación real
 * (≤ 20% de elementos cubre ≥ 80% del valor).
 * ========================================================================== */
(function (window) {
  'use strict';
  var AN = window.SPEC_AN;
  var round2 = AN.round2, safeDiv = AN.safeDiv;

  /* items: [{nombre, valor, ...}]; valorFn opcional (por defecto item.valor).
   * Devuelve { items (ordenados + pctIndividual + pctAcumulado), total,
   * nPara80 (% de elementos para el 80% del valor), cumple8020 }. */
  function computePareto(items, valorFn) {
    var get = valorFn || function (i) { return i.valor; };
    var list = (items || []).map(function (i) {
      var o = Object.assign({}, i);
      o.valor = Number(get(i)) || 0;
      return o;
    }).filter(function (i) { return i.valor > 0; })
      .sort(function (a, b) { return b.valor - a.valor || String(a.nombre).localeCompare(String(b.nombre)); });
    var total = list.reduce(function (s, i) { return s + i.valor; }, 0);
    if (total <= 0 || list.length === 0) {
      return { items: [], total: 0, nElementos: (items || []).length, nPara80: null, pctElementos80: null, cumple8020: false };
    }
    var acum = 0;
    var nPara80 = list.length, pctElementos80 = 100;
    for (var i = 0; i < list.length; i++) {
      acum += list[i].valor;
      list[i].pctIndividual = round2(safeDiv(list[i].valor, total) * 100);
      list[i].pctAcumulado = round2(safeDiv(acum, total) * 100);
      if (nPara80 === list.length && list[i].pctAcumulado >= 80) {
        nPara80 = i + 1;
        pctElementos80 = round2(safeDiv(nPara80, list.length) * 100);
      }
    }
    return {
      items: list,
      total: round2(total),
      nElementos: list.length,
      nPara80: nPara80,
      pctElementos80: pctElementos80,
      // Comprobación REAL de la regla (nunca afirmada sin datos §24):
      cumple8020: pctElementos80 <= 20
    };
  }

  /* Pareto de tareas (por errores y por horas afectadas) — §24/§25. */
  function computeParetoTareas(taskStats) {
    var porErrores = computePareto(taskStats, function (t) { return t.errores; });
    var porHoras = computePareto(taskStats, function (t) { return t.horasAfectadas; });
    return { porErrores: porErrores, porHoras: porHoras };
  }

  /* Pareto de personas y de actividades. */
  function computeParetoPersonas(personStats) {
    return computePareto(personStats, function (p) { return p.errores; });
  }

  function computeParetoActividades(activityStats) {
    return computePareto(activityStats, function (a) { return a.errores; });
  }

  window.SPEC_AN.pareto = {
    computePareto: computePareto,
    computeParetoTareas: computeParetoTareas,
    computeParetoPersonas: computeParetoPersonas,
    computeParetoActividades: computeParetoActividades
  };
})(typeof window !== 'undefined' ? window : globalThis);
