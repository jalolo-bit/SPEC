/* ============================================================================
 * SISTEMA DE CONCILIACIÓN SPEC — Web (port de SPEC V0.47.3)
 *
 * Este archivo ESPEC (sustituto web del xlsm V0.47.3 de ID Logistics).
 * Reproduce de manera equivalente:
 *   - Las 20 consultas Power Query (Section1.m)
 *   - El procedimiento VBA GenerarReporteCambiosHR (módulo VBA principal)
 *   - Las 14 tablas resultantes y el reporte REPORTE_CAMBIOS_HR
 *
 * Trazabilidad completa por consulta y por regla en:
 *   /audit/INFORME_AUDITORIA.md
 *   /audit/REGLAS_NEGOCIO.md
 *   /audit/DICCIONARIO_DATOS.md
 *   /audit/TRAZABILIDAD.md
 *
 * Bibliotecas externas: SheetJS (xlsx.full.min.js) — solo para leer/escribir .xlsx
 * ========================================================================== */

(function (global) {
'use strict';

/* ============================================================================
 * PARÁMETROS GLOBALES (equivalente a 00_Parametros)
 * ========================================================================== */
const PARAMS = {
  ExtensionesPermitidas: ['.xlsx', '.xlsm', '.xlsb'],
  UmbralMicroHoras: 0.0833333333,
  Cultura: 'es-ES',
  // R-06 / AUD-MED-005 mitigation — strict input file validation
  // Max file size configurable. 50 MB is generous (sample files are < 32 KB each);
  // anything bigger is suspicious. Set to 0 to disable.
  TamanoMaximoArchivoMB: 50,
  // SheetJS 0.18.5 has known HIGH vulnerabilities (Prototype Pollution +
  // ReDoS). Refusing files >TamanoMaximoArchivoMB mitigates the most likely
  // attack vector (crafted large file). Documented as AUD-MED-005 mitigation.
  SheetJSVersionVulnerable: '0.18.5',
  SheetJSMitigacion: 'limite tamano + validacion estructura + offline',
  // R-12 — threshold above which IdNumerico must use BigInt to avoid
  // precision loss (Number is safe up to 2^53 = ~9e15, i.e., 16-digit max).
  // 15 is conservative: any login numeric portion > 15 digits uses BigInt.
  UmbralBigIntDigitos: 15,
  // Audit log schema version
  AppVersion: '6.2.0',
  SchemaVersion: '1.1.0',
  MappingSchemaVersion: '1.1.0',
  /* ======================================================================
   * v6.1 — MEJORA 1: Turnos
   * Límites de turno en minutos desde medianoche:
   *   MAÑANA: 06:00 (360) <= h < 14:00 (840)
   *   TARDE:  14:00 (840) <= h < 22:00 (1320)
   *   NOCHE:  22:00 (1320) <= h < 06:00 (360, día siguiente)
   * Cobertura total sin huecos ni solapamientos (verificado por tests).
   * ====================================================================== */
  TurnoMananaInicio: 360,
  TurnoTardeInicio: 840,
  TurnoNocheInicio: 1320,
  /* ======================================================================
   * v6.1 — MEJORA 4: Productividades medias de referencia (NETAS, uds/h).
   * Son medias de referencia, NO tiempos exactos. Editables por el usuario
   * (se persisten en localStorage 'spec_productividades' desde la UI).
   * Las tareas clasificadas como OTRA NO reciben productividad inventada.
   * ====================================================================== */
  ProductividadesReferencia: {
    'AUDITORIA AGV': 35,
    'AUDITORIA MANUAL': 23,
    'UBICACION MANUAL': 260,
    'UBICACION AGV': 240,
    'PICKING MANUAL': 100,
    'PICKING AGV': 150
  }
};

/* ============================================================================
 * ESTADO GLOBAL
 * ========================================================================== */
const STATE = {
  archivos: {
    horas: null,        // { name, sheetName, rows, warnings }
    volumen: null,
    volSinHoras: null,
    mapping: null
  },
  queries: {},          // Resultado de cada una de las 20 consultas
  reporte: null,       // Resultado de GenerarReporteCambiosHR (array de filas)
  log: [],              // Entradas de log del último procesado
  stats: {}             // Estadísticas de ejecución (timings)
};

/* ============================================================================
 * HELPERS GENERALES
 * ========================================================================== */

function log(msg, level = 'info') {
  STATE.log.push({ ts: new Date(), level, msg: String(msg) });
  // Conservar máximo 1000 entradas
  if (STATE.log.length > 1000) STATE.log = STATE.log.slice(-1000);
  if (typeof window !== 'undefined' && window.__appendLog) window.__appendLog(level, msg);
}

function formatNum(n) {
  if (n == null) return '';
  if (typeof n !== 'number') n = Number(n);
  if (!isFinite(n)) return '';
  // F11 fix — useGrouping:false para coincidir con M/Excel que NO usa
  // separador de miles en Number.ToText(n) (default format). Bug histórico
  // #3 estaba parcialmente fixeado (formatNum2/formatNum0 ya usaban false),
  // pero formatNum seguía con true, mostrando "1.234,5" donde Excel muestra
  // "1234,5". Esto no rompía la equivalencia de tests (que normalizan ambos
  // lados sin separadores) pero era una discrepancia visual real en UI.
  return n.toLocaleString('es-ES', { maximumFractionDigits: 4, useGrouping: false });
}

/* Number.ToText(n, "0.00", "es-ES") - exactamente 2 decimales, SIN separador de miles (formato M "0.00") */
function formatNum2(n) {
  if (n == null) return '';
  if (typeof n !== 'number') n = Number(n);
  if (!isFinite(n)) return '';
  return n.toLocaleString('es-ES', { minimumFractionDigits: 2, maximumFractionDigits: 2, useGrouping: false });
}

/* Number.ToText(n, "0", "es-ES") - 0 decimales, SIN separador de miles (formato M "0") */
function formatNum0(n) {
  if (n == null) return '';
  if (typeof n !== 'number') n = Number(n);
  if (!isFinite(n)) return '';
  return n.toLocaleString('es-ES', { maximumFractionDigits: 0, useGrouping: false });
}

function formatFecha(d) {
  if (!d) return '';
  if (!(d instanceof Date)) return String(d);
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(d.getUTCDate()).padStart(2, '0');
  return `${dd}/${m}/${y}`;
}

function formatFechaISO(d) {
  if (!d) return '';
  if (!(d instanceof Date)) return String(d);
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(d.getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${dd}`;
}

function deepClone(obj) {
  if (obj === null || typeof obj !== 'object') return obj;
  // IMPORTANTE: Date es typeof 'object' pero NO debe clonarse como objeto plano.
  // Sin este check, deepClone(new Date()) devuelve {} y rompe todas las fechas.
  if (obj instanceof Date) return new Date(obj.getTime());
  if (obj instanceof RegExp) return new RegExp(obj);
  if (obj instanceof Map) {
    const m = new Map();
    for (const [k, v] of obj) m.set(k, deepClone(v));
    return m;
  }
  if (obj instanceof Set) {
    const s = new Set();
    for (const v of obj) s.add(deepClone(v));
    return s;
  }
  if (Array.isArray(obj)) return obj.map(deepClone);
  const out = {};
  for (const k of Object.keys(obj)) out[k] = deepClone(obj[k]);
  return out;
}

/* ============================================================================
 * fx_NormalizaTexto  (Section1.m líneas 17-25)
 * ========================================================================== */
function fx_NormalizaTexto(v) {
  if (v == null) return null;
  let s;
  if (v instanceof Date) s = formatFechaISO(v);
  else if (typeof v === 'number') s = String(v);
  else if (typeof v === 'boolean') s = v ? 'TRUE' : 'FALSE';
  else s = String(v);
  // Text.Clean: eliminar chars de control 0x00-0x1F y 0x7F
  s = s.replace(/[\x00-\x1F\x7F]/g, '');
  // Text.Trim
  s = s.replace(/^\s+|\s+$/g, '');
  if (s === '') return null;
  // Text.Upper
  s = s.toUpperCase();
  // Text.SplitAny por \s + collapse
  s = s.split(/\s+/).join(' ');
  return s;
}

/* ============================================================================
 * fx_NormalizaLogin  (Section1.m líneas 27-43)
 * ========================================================================== */
function fx_NormalizaLogin(v) {
  const original = (v == null) ? null : String(v);
  const limpio = fx_NormalizaTexto(v);
  let sinSeparadores = null;
  if (limpio) {
    // Text.Remove(T0, {" ", "-", ".", "_", "/", "\\"})
    sinSeparadores = limpio.replace(/[ \-._/\\]/g, '');
  }
  // Letras = Text.Select(T1, {"A".."Z"})
  const letras = sinSeparadores ? sinSeparadores.replace(/[^A-Z]/g, '') : null;
  // Digitos = Text.Select(T1, {"0".."9"})
  const digitos = sinSeparadores ? sinSeparadores.replace(/[^0-9]/g, '') : null;
  // IdNumericoLiteral = Digitos (vacío si no hay)
  const idLiteral = (digitos && digitos !== '') ? digitos : null;
  // IdNumericoNormalizado = try Number.FromText(Digitos) otherwise Digitos
  // R-12 fix: si el número de dígitos supera PARAMS.UmbralBigIntDigitos,
  // Number() pierde precisión > 2^53. Usamos BigInt para no alterar el valor.
  // El resultado se devuelve como String para mantener compatibilidad con M
  // (que usa Number.FromText, pero en M los enteros largos conservan precisión).
  let idNormalizado = idLiteral;
  if (idLiteral) {
    try {
      if (idLiteral.length > PARAMS.UmbralBigIntDigitos) {
        // Intentar BigInt; si tiene ceros a la izquierda, preservarlos
        if (/^0+$/.test(idLiteral)) {
          idNormalizado = '0';  // todos ceros → 0
        } else if (/^0\d/.test(idLiteral)) {
          // Tiene ceros a la izquierda significativos: preservar literal
          idNormalizado = idLiteral.replace(/^0+/, '') || '0';
        } else {
          const bi = BigInt(idLiteral);
          idNormalizado = bi.toString();
        }
      } else {
        const n = Number(idLiteral);
        if (isFinite(n)) idNormalizado = String(n);
        else idNormalizado = idLiteral;
      }
    } catch (e) {
      idNormalizado = idLiteral;
    }
  }
  // IdNumerico = IdNumericoLiteral (alias)
  const idNumerico = idLiteral;
  // Canonico
  let canonico = null;
  if (limpio) {
    if (letras && idNumerico) canonico = letras + idNumerico;
    else canonico = limpio;
  }
  // Prefijo
  const prefijo = letras ? letras : null;
  return {
    LoginOriginal: original,
    LoginOriginalLimpio: limpio,
    LoginCanonico: canonico,
    IdNumerico: idNumerico,
    IdNumericoLiteral: idLiteral,
    IdNumericoNormalizado: idNormalizado,
    Prefijo: prefijo
  };
}

/* ============================================================================
 * fx_Fecha  (Section1.m líneas 45-55)
 * ========================================================================== */
function stripTime(d) {
  // Devuelve un Date UTC con sólo año/mes/día
  return new Date(Date.UTC(d.getUTCFullYear ? d.getUTCFullYear() : d.getFullYear(),
                            (d.getUTCMonth ? d.getUTCMonth() : d.getMonth()),
                            (d.getUTCDate ? d.getUTCDate() : d.getDate())));
}

/* Devuelve timestamp numérico (ms) para una fecha, o null si no es válida */
function fechaToLong(v) {
  if (v == null) return null;
  if (v instanceof Date) {
    const t = v.getTime();
    return isNaN(t) ? null : t;
  }
  // Si no es Date, intentar fx_Fecha
  const d = fx_Fecha(v);
  if (d == null) return null;
  return d.getTime();
}

/* Devuelve clave de grupo Fecha|LoginCanonico */
function fechaLoginKey(fecha, login) {
  const t = fechaToLong(fecha);
  if (t == null) return null;
  return t + '|' + (login == null ? '' : String(login));
}

function fx_Fecha(v) {
  if (v == null) return null;
  if (v instanceof Date) {
    // Date.From ya descarta hora; construimos date-only
    return stripTime(v);
  }
  if (typeof v === 'number') {
    // Fecha serial Excel: base 1899-12-30 (serial 0 = 1899-12-30)
    const base = Date.UTC(1899, 11, 30); // 11 = December
    const days = Math.floor(v);
    const ms = base + days * 86400000;
    return new Date(ms);
  }
  if (typeof v === 'string') {
    const s = v.trim();
    if (s === '') return null;
    // Probar es-ES: dd/MM/yyyy o dd-MM-yyyy o dd.MM.yyyy
    let m = s.match(/^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2,4})$/);
    if (m) {
      const dd = parseInt(m[1], 10);
      const mm = parseInt(m[2], 10) - 1;
      let yyyy = parseInt(m[3], 10);
      if (yyyy < 100) yyyy = 2000 + yyyy;
      const d = new Date(Date.UTC(yyyy, mm, dd));
      if (!isNaN(d.getTime())) return d;
    }
    // ISO: yyyy-MM-dd
    m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
    if (m) {
      const yyyy = parseInt(m[1], 10);
      const mm = parseInt(m[2], 10) - 1;
      const dd = parseInt(m[3], 10);
      const d = new Date(Date.UTC(yyyy, mm, dd));
      if (!isNaN(d.getTime())) return d;
    }
    // Fallback general
    const d = new Date(s);
    if (!isNaN(d.getTime())) return stripTime(d);
    return null;
  }
  return null;
}

/* ============================================================================
 * v6.1 — MEJORA 1: TURNOS (funciones puras, centralizadas)
 *
 * Clasificación exacta (una y solo una por cada hora del día):
 *   MAÑANA: 06:00:00 <= hora < 14:00:00
 *   TARDE:  14:00:00 <= hora < 22:00:00
 *   NOCHE:  22:00:00 <= hora < 06:00:00 (atraviesa medianoche)
 *
 * FECHA_OPERATIVA_TURNO (regla especial del turno NOCHE):
 *   Si hora >= 22:00 → fecha actual
 *   Si hora <  06:00 → fecha anterior
 *   Si 06:00 <= hora < 22:00 → fecha actual (turnos MAÑANA/TARDE)
 * ========================================================================== */

/* fx_Turno — Devuelve 'MAÑANA' | 'TARDE' | 'NOCHE' para una hora dada.
 * @param hora  minutos del día (0-1439) o Date (usa su componente horaria UTC).
 * @throws Error si la hora no es válida (fuera de 0-1439 o tipo desconocido). */
function fx_Turno(hora) {
  let min;
  if (hora instanceof Date) {
    if (isNaN(hora.getTime())) throw new Error('fx_Turno: Date inválida');
    min = hora.getUTCHours() * 60 + hora.getUTCMinutes();
  } else if (typeof hora === 'number' && isFinite(hora)) {
    min = hora;
  } else {
    throw new Error('fx_Turno: hora debe ser número de minutos (0-1439) o Date');
  }
  if (min < 0 || min >= 1440) throw new Error('fx_Turno: hora fuera de rango [0,1440): ' + min);
  if (min >= PARAMS.TurnoMananaInicio && min < PARAMS.TurnoTardeInicio) return 'MAÑANA';
  if (min >= PARAMS.TurnoTardeInicio && min < PARAMS.TurnoNocheInicio) return 'TARDE';
  return 'NOCHE'; // 22:00-23:59 + 00:00-05:59 (sin huecos ni solapamientos)
}

/* filtrarRegistrosPorTurno — v6.1.1 — FILTRO REAL DE TURNOS (centralizado).
 *
 * Única función de filtrado por turno usada en Revisar incidencias,
 * Patrones, Persona/Día e históricos. Los elementos son registros con
 * campo .turno ('MAÑANA'|'TARDE'|'NOCHE'|'MIXTO'|'SIN HORA') y opcionalmente
 * .turnos (array de turnos de sus fichajes individuales).
 *
 * Reglas del usuario:
 *   - turno vacío/falsy → TODOS (sin filtro).
 *   - 'MAÑANA'/'TARDE'/'NOCHE' → solo registros que pertenezcan a ese turno
 *     (el turno agregado coincide O ALGUNO de sus fichajes es de ese turno:
 *     un día MIXTO que trabajó de noche aparece al filtrar NOCHE).
 *   - 'SIN HORA' → solo registros SIN hora de fichaje real (archivos day-level).
 *     Un registro sin hora NUNCA aparece al filtrar un turno concreto:
 *     no se inventa la pertenencia a ningún turno.
 */
function filtrarRegistrosPorTurno(registros, turno) {
  if (!Array.isArray(registros)) return [];
  if (!turno) return registros.slice();
  return registros.filter(r =>
    r.turno === turno ||
    (Array.isArray(r.turnos) && r.turnos.indexOf(turno) >= 0)
  );
}

/* fx_FechaOperativaTurno — Fecha operativa del turno.
 * @param fecha Date con sólo año/mes/día (la fecha calendario del registro).
 * @param hora  minutos del día (0-1439) o Date con hora. null → devuelve fecha tal cual.
 * Regla: hora >= 22:00 → fecha actual; hora < 06:00 → fecha anterior. */
function fx_FechaOperativaTurno(fecha, hora) {
  if (!(fecha instanceof Date) || isNaN(fecha.getTime())) return fecha;
  if (hora == null) return fecha;
  let min;
  if (hora instanceof Date) {
    min = hora.getUTCHours() * 60 + hora.getUTCMinutes();
  } else if (typeof hora === 'number' && isFinite(hora)) {
    min = hora;
  } else {
    return fecha;
  }
  // NOCHE que cruza medianoche: 00:00-05:59 pertenece a la fecha operativa anterior
  if (min < PARAMS.TurnoMananaInicio) {
    return new Date(fecha.getTime() - 86400000); // un día menos (UTC, day-level)
  }
  return fecha; // >= 06:00 (incluye >= 22:00 → fecha actual)
}

/* extraerHoraFichaje — Extrae la hora del día (minutos 0-1439) de un valor
 * de fecha de entrada. Devuelve null cuando el dato es de nivel DÍA
 * (sin componente horaria).
 *
 * Convención de datos: los export WMS/HR usan seriales Excel. Un serial
 * ENTERO (o Date exactamente a medianoche UTC) significa fecha sin hora.
 * Esto evita clasificar como NOCHE-fecha-anterior todos los registros
 * day-level (que produciría un desplazamiento masivo de fechas).
 *
 * Limitación documentada: un fichaje real exactamente a las 00:00:00.000
 * es indistinguible de "sin hora" y se trata como tal (caso raro). */
function extraerHoraFichaje(v) {
  if (v == null) return null;
  if (v instanceof Date) {
    if (isNaN(v.getTime())) return null;
    if (v.getUTCHours() === 0 && v.getUTCMinutes() === 0 &&
        v.getUTCSeconds() === 0 && v.getUTCMilliseconds() === 0) return null;
    return v.getUTCHours() * 60 + v.getUTCMinutes();
  }
  if (typeof v === 'number' && isFinite(v)) {
    const frac = v - Math.floor(v);
    if (frac <= 0) return null; // serial entero = fecha day-level
    const totalMin = Math.round(frac * 1440) % 1440;
    if (totalMin === 0) return null; // p.ej. 46259.999998 (≈ medianoche)
    return totalMin;
  }
  return null; // strings y otros tipos: sin hora conocida
}

/* ============================================================================
 * Number.From equivalente
 * ========================================================================== */
function numberFrom(v) {
  if (v == null) return null;
  if (typeof v === 'number') return v;
  if (v instanceof Date) return null;
  let s = String(v).trim();
  if (s === '') return null;
  // Probar coma decimal es-ES
  s = s.replace(/\./g, '').replace(',', '.');
  // Si queda como "1234" o "12.34"
  const n = Number(s);
  return isFinite(n) ? n : null;
}

/* ============================================================================
 * LECTURA DE ARCHIVOS XLSX (SheetJS)
 * Implementa fx_Transforma* + apertura de carpetas
 * ========================================================================== */

/* R-06 / AUD-MED-005 — Validación robusta de archivos de entrada.
 * Devuelve { ok: boolean, error: string|null, warnings: string[] }.
 * No lanza excepción; es el caller quien decide cómo manejar el error.
 */
function validarArchivoEntrada(file, tipo) {
  const warnings = [];
  if (!file) return { ok: false, error: 'Archivo no proporcionado', warnings };
  // Nombre y extensión
  const name = file.name || '';
  const ext = name.slice(((name.lastIndexOf('.')) || -1) + (name.lastIndexOf('.') >= 0 ? 1 : 0)).toLowerCase();
  if (!ext || !PARAMS.ExtensionesPermitidas.includes('.' + ext)) {
    return {
      ok: false,
      error: `Extensión no permitida ".${ext}". Extensiones válidas: ${PARAMS.ExtensionesPermitidas.join(', ')}`,
      warnings
    };
  }
  // Tipo MIME (File.type puede ser vacío para algunos navegadores/extensiones)
  // Tipos aceptados: spreadsheetml / msexcel / oleObject
  if (file.type) {
    const t = file.type.toLowerCase();
    const tiposOk = [
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/vnd.ms-excel',
      'application/vnd.ms-excel.sheet.macroEnabled.12',
      'application/vnd.ms-excel.sheet.binary.macroEnabled.12',
      'application/octet-stream'  // Firefox reporta .xlsb como octet-stream
    ];
    if (!tiposOk.includes(t)) {
      warnings.push(`Tipo MIME "${t}" inesperado; puede que el contenido no sea Excel real.`);
    }
  }
  // Tamaño máximo configurable
  const tamMaxBytes = PARAMS.TamanoMaximoArchivoMB * 1024 * 1024;
  if (tamMaxBytes > 0 && file.size > tamMaxBytes) {
    return {
      ok: false,
      error: `Archivo demasiado grande: ${(file.size / 1024 / 1024).toFixed(2)} MB. Máximo permitido: ${PARAMS.TamanoMaximoArchivoMB} MB.`,
      warnings
    };
  }
  // Tamaño cero
  if (file.size === 0) {
    return { ok: false, error: 'Archivo vacío (0 bytes).', warnings };
  }
  // Cabecera de firma (primeros 4 bytes indican ZIP / OLE2 / etc.)
  // No podemos leer el contenido aquí (es async); el caller debe validar estructura
  // después de la lectura con validarWorkbook(wb, tipo).
  return { ok: true, error: null, warnings };
}

/* R-06 — Validación de workbook ya leído por SheetJS.
 * Verifica estructura, hojas esperadas, número de columnas, filas corruptas,
 * duplicados inesperados (a nivel de clave natural).
 */
function validarWorkbook(wb, tipo, filename) {
  const warnings = [];
  if (!wb || !wb.SheetNames || wb.SheetNames.length === 0) {
    return { ok: false, error: 'El archivo no contiene hojas visibles.', warnings };
  }
  // Hoja esperada según tipo
  let hojaEsperada = 'EXPORT';
  if (tipo === 'mapping') hojaEsperada = 'MAPPING';
  // Buscar hoja
  const sheetName = encontrarHojaExport(wb);
  if (!sheetName) {
    return {
      ok: false,
      error: `No se encontró hoja "${hojaEsperada}". Hojas disponibles: ${wb.SheetNames.join(', ')}`,
      warnings
    };
  }
  // Verificar contenido
  const rows = sheetAJson(wb, sheetName);
  if (!rows || rows.length === 0) {
    return { ok: false, error: `La hoja "${sheetName}" está vacía.`, warnings };
  }
  if (rows.length < 2) {
    return { ok: false, error: `La hoja "${sheetName}" no contiene datos (solo cabecera?).`, warnings };
  }
  const headers = rows[0];
  if (!headers || headers.length === 0) {
    return { ok: false, error: `La hoja "${sheetName}" no tiene cabecera.`, warnings };
  }
  // Número de columnas razonable (8-50 es típico; >100 sospechoso)
  if (headers.length > 100) {
    warnings.push(`Número de columnas alto (${headers.length}); verificar que el archivo sea el correcto.`);
  }
  // Detección de filas corruptas (celdas undefined/null en posiciones críticas)
  // Sólo un sanity check; no validamos tipos hasta fx_Transforma*.
  return { ok: true, error: null, warnings, sheetName, headers };
}

function leerArchivoExcel(file) {
  return new Promise((resolve, reject) => {
    // R-06 — pre-validación antes de leer
    const preValid = validarArchivoEntrada(file, file._tipoSpec);
    if (!preValid.ok) {
      reject(new Error(preValid.error));
      return;
    }
    const reader = new FileReader();
    reader.onload = function (e) {
      try {
        const data = new Uint8Array(e.target.result);
        // Sanity check: el buffer no puede ser más pequeño que la firma mínima ZIP (4 bytes)
        if (data.length < 4) {
          reject(new Error('Archivo demasiado corto para ser un Excel válido (menos de 4 bytes).'));
          return;
        }
        const wb = XLSX.read(data, { type: 'array', cellDates: true });
        resolve(wb);
      } catch (err) {
        // SheetJS puede lanzar si el archivo está corrupto o no es ZIP/OLE2
        reject(new Error('No se pudo interpretar el archivo como Excel. ¿Está corrupto o no es un .xlsx/.xlsm/.xlsb real? — ' + (err && err.message ? err.message : String(err))));
      }
    };
    reader.onerror = () => reject(new Error('No se pudo leer el archivo'));
    reader.readAsArrayBuffer(file);
  });
}

/* Verifica que el workbook tiene una hoja/tabla llamada "EXPORT"
   y devuelve el nombre de la primera coincidencia */
function encontrarHojaExport(wb) {
  // Buscar nombre "EXPORT" exacto (case insensitive)
  const nombresUpper = wb.SheetNames.map(n => n.toUpperCase().trim());
  for (let i = 0; i < nombresUpper.length; i++) {
    if (nombresUpper[i] === 'EXPORT') return wb.SheetNames[i];
  }
  // Si no, primera hoja
  if (wb.SheetNames.length > 0) return wb.SheetNames[0];
  return null;
}

function sheetAJson(wb, sheetName) {
  const ws = wb.Sheets[sheetName];
  if (!ws) return [];
  return XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: null });
}

/* fx_TransformaHoras  (Section1.m líneas 57-79)
   - Recibe workbook ya leído
   - Devuelve array de objetos {Site name, Department, Activity, Subactivity, FechaOriginal, HR Task, WMSLoginOriginal, Name, HorasSinVolumen, ArchivoOrigen, FilaOrigen}
*/
function fx_TransformaHoras(wb, archivoNombre) {
  const sheetName = encontrarHojaExport(wb);
  if (!sheetName) throw new Error(`El archivo no tiene hojas válidas: ${archivoNombre}`);
  const rows = sheetAJson(wb, sheetName);
  if (rows.length === 0) throw new Error(`Hoja vacía: ${sheetName}`);
  // Promote headers
  const headers = rows[0];
  const dataRows = rows.slice(1);
  // Filtrar pie: Site name != null AND not StartsWith("TOTAL") AND not Contains("FILTROS APLICADOS")
  const filtrado = dataRows.filter(row => {
    const sn = row[0]; // asume primera columna = Site name
    if (sn == null || String(sn).trim() === '') return false;
    const su = String(sn).toUpperCase();
    if (su.startsWith('TOTAL')) return false;
    if (su.indexOf('FILTROS APLICADOS') >= 0) return false;
    return true;
  });
  // Columnas requeridas
  const requeridas = ['Site name', 'Department', 'Activity', 'Subactivity', 'Date', 'HR Task', 'WMS Login', 'Name', 'Hours without volume'];
  // Mapear nombre → índice
  const idxMap = {};
  for (let i = 0; i < headers.length; i++) {
    const h = String(headers[i] == null ? '' : headers[i]).trim();
    idxMap[h] = i;
  }
  const faltantes = requeridas.filter(c => idxMap[c] === undefined);
  if (faltantes.length > 0) {
    throw new Error(`Faltan columnas en ${archivoNombre} (hoja ${sheetName}): ${faltantes.join(', ')}`);
  }
  // Construir salida
  const out = filtrado.map((row, idx) => {
    return {
      'Site name': row[idxMap['Site name']],
      'Department': row[idxMap['Department']],
      'Activity': row[idxMap['Activity']],
      'Subactivity': row[idxMap['Subactivity']],
      'FechaOriginal': row[idxMap['Date']],
      'HR Task': row[idxMap['HR Task']],
      'WMSLoginOriginal': row[idxMap['WMS Login']],
      'Name': row[idxMap['Name']],
      'HorasSinVolumen': row[idxMap['Hours without volume']],
      'ArchivoOrigen': archivoNombre,
      'FilaOrigen': idx + 2  // fila 1 es cabecera
    };
  });
  return out;
}

/* fx_TransformaVolumen  (Section1.m líneas 81-103) */
function fx_TransformaVolumen(wb, archivoNombre) {
  const sheetName = encontrarHojaExport(wb);
  if (!sheetName) throw new Error(`El archivo no tiene hojas válidas: ${archivoNombre}`);
  const rows = sheetAJson(wb, sheetName);
  if (rows.length === 0) throw new Error(`Hoja vacía: ${sheetName}`);
  const headers = rows[0];
  const dataRows = rows.slice(1);
  // FiltrarPie (como en M): [DATE] <> null AND not StartsWith("TOTAL") AND not Contains("FILTROS APLICADOS")
  const idxDate = headers.findIndex(h => String(h == null ? '' : h).trim().toUpperCase() === 'DATE');
  const filtrado = dataRows.filter(row => {
    const v = idxDate >= 0 ? row[idxDate] : row[0];
    if (v == null || String(v).trim() === '') return false;
    const su = String(v).toUpperCase();
    if (su.startsWith('TOTAL')) return false;
    if (su.indexOf('FILTROS APLICADOS') >= 0) return false;
    return true;
  });
  const requeridas = ['DATE', 'SAP_CODE', 'CUSTOMER', 'WMS_TASK', 'WMS_LOGIN', 'USER_NAME', 'WMS_UOM'];
  const idxMap = {};
  for (let i = 0; i < headers.length; i++) {
    const h = String(headers[i] == null ? '' : headers[i]).trim();
    idxMap[h] = i;
  }
  const faltantes = requeridas.filter(c => idxMap[c] === undefined);
  if (faltantes.length > 0) {
    throw new Error(`Faltan columnas en ${archivoNombre} (hoja ${sheetName}): ${faltantes.join(', ')}`);
  }
  const out = filtrado.map((row, idx) => {
    return {
      'FechaOriginal': row[idxMap['DATE']],
      'SAP_CODE': row[idxMap['SAP_CODE']],
      'CUSTOMER': row[idxMap['CUSTOMER']],
      'WMS_TASK': row[idxMap['WMS_TASK']],
      'WMSLoginOriginal': row[idxMap['WMS_LOGIN']],
      'USER_NAME': row[idxMap['USER_NAME']],
      'VolumenNeto': row[idxMap['WMS_UOM']],
      'ArchivoOrigen': archivoNombre,
      'FilaOrigen': idx + 2
    };
  });
  return out;
}

/* fx_TransformaVolumenSinHoras  (Section1.m líneas 105-127) */
function fx_TransformaVolumenSinHoras(wb, archivoNombre) {
  const sheetName = encontrarHojaExport(wb);
  if (!sheetName) throw new Error(`El archivo no tiene hojas válidas: ${archivoNombre}`);
  const rows = sheetAJson(wb, sheetName);
  if (rows.length === 0) throw new Error(`Hoja vacía: ${sheetName}`);
  const headers = rows[0];
  const dataRows = rows.slice(1);
  const filtrado = dataRows.filter(row => {
    const sn = row[0];
    if (sn == null || String(sn).trim() === '') return false;
    const su = String(sn).toUpperCase();
    if (su.startsWith('TOTAL')) return false;
    if (su.indexOf('FILTROS APLICADOS') >= 0) return false;
    return true;
  });
  const requeridas = ['Site name', 'Department', 'Activity', 'Subactivity', 'Date', 'HR Task', 'WMS Login', 'Name', 'Volume Without Hours'];
  const idxMap = {};
  for (let i = 0; i < headers.length; i++) {
    const h = String(headers[i] == null ? '' : headers[i]).trim();
    idxMap[h] = i;
  }
  const faltantes = requeridas.filter(c => idxMap[c] === undefined);
  if (faltantes.length > 0) {
    throw new Error(`Faltan columnas en ${archivoNombre} (hoja ${sheetName}): ${faltantes.join(', ')}`);
  }
  const out = filtrado.map((row, idx) => {
    return {
      'Site name': row[idxMap['Site name']],
      'Department': row[idxMap['Department']],
      'Activity': row[idxMap['Activity']],
      'Subactivity': row[idxMap['Subactivity']],
      'FechaOriginalVSH': row[idxMap['Date']],
      'HRTaskVSH': row[idxMap['HR Task']],
      'WMSLoginOriginalVSH': row[idxMap['WMS Login']],
      'Name': row[idxMap['Name']],
      'VolumenSinHoras': row[idxMap['Volume Without Hours']],
      'ArchivoOrigenVSH': archivoNombre,
      'FilaOrigenVSH': idx + 2
    };
  });
  return out;
}

/* Lee Mapping.xlsx hoja Mapping  (12_MapeoActividadSPEC pasos iniciales) */
function leerMapping(wb) {
  // Búsqueda exacta "MAPPING"
  let sheetName = null;
  for (const n of wb.SheetNames) {
    if (n.toUpperCase().trim() === 'MAPPING') { sheetName = n; break; }
  }
  if (!sheetName) {
    for (const n of wb.SheetNames) {
      if (n.toUpperCase().indexOf('MAPPING') >= 0) { sheetName = n; break; }
    }
  }
  if (!sheetName) {
    throw new Error('No existe una hoja cuyo nombre contenga "Mapping" en Mapping.xlsx. Hojas disponibles: ' + wb.SheetNames.join(', '));
  }
  const rows = sheetAJson(wb, sheetName);
  if (rows.length === 0) throw new Error('La hoja Mapping existe, pero no contiene registros.');
  // Promote headers + normalizar nombres
  const headers = rows[0].map(h => h == null ? '' : String(h));
  const normalizarNombre = h => {
    return h.toUpperCase()
      .replace(/[\x00-\x1F\x7F]/g, '')
      .replace(/\u00A0/g, ' ')
      .replace(/\s+/g, '_')
      .trim();
  };
  const headersNorm = headers.map(normalizarNombre);
  const columnasEsperadas = ['SAP_CODE', 'WMS_DC', 'CUSTOMER', 'DEPARTMENT', 'ACTIVITY', 'SUB_ACTIVITY', 'TASK_WMS', 'TASK_SPEC'];
  const faltantes = columnasEsperadas.filter(c => !headersNorm.includes(c));
  if (faltantes.length > 0) {
    throw new Error('La hoja Mapping existe, pero faltan estas columnas obligatorias: ' + faltantes.join(', '));
  }
  const idx = {};
  columnasEsperadas.forEach(c => { idx[c] = headersNorm.indexOf(c); });
  const dataRows = rows.slice(1);
  const out = dataRows.map(row => ({
    'SAP_CODE': row[idx['SAP_CODE']],
    'WMS_DC': row[idx['WMS_DC']],
    'CUSTOMER': row[idx['CUSTOMER']],
    'DEPARTMENT': row[idx['DEPARTMENT']],
    'ACTIVITY': row[idx['ACTIVITY']],
    'SUB_ACTIVITY': row[idx['SUB_ACTIVITY']],
    'TASK_WMS': row[idx['TASK_WMS']],
    'TASK_SPEC': row[idx['TASK_SPEC']]
  }));
  return out;
}

/* ============================================================================
 * HELPERS DE TABLAS (equivalentes a Table.Group, NestedJoin, etc.)
 * ========================================================================== */

function distinctList(arr) {
  // Lista de valores no nulos, distintos, ordenados
  const set = new Set();
  for (const v of arr) {
    if (v == null) continue;
    if (typeof v === 'string' && v.trim() === '') continue;
    set.add(String(v));
  }
  return Array.from(set).sort((a, b) => a < b ? -1 : (a > b ? 1 : 0));
}

function joinDistinct(arr, sep = ' | ') {
  return distinctList(arr).join(sep);
}

function sumList(arr) {
  let s = 0;
  for (const v of arr) {
    if (v == null) continue;
    const n = typeof v === 'number' ? v : Number(v);
    if (isFinite(n)) s += n;
  }
  return s;
}

function countTrue(arr) {
  let c = 0;
  for (const v of arr) if (v === true) c++;
  return c;
}

function anyTrue(arr) {
  for (const v of arr) if (v === true) return true;
  return false;
}

function groupBy(rows, keys) {
  // Devuelve array de { key: {k1:v1, k2:v2}, items: [...] }
  const map = new Map();
  for (const r of rows) {
    const k = keys.map(kk => r[kk] == null ? null : String(r[kk]));
    const kstr = k.join('|');
    if (!map.has(kstr)) {
      const keyObj = {};
      for (let i = 0; i < keys.length; i++) keyObj[keys[i]] = r[keys[i]];
      map.set(kstr, { key: keyObj, items: [] });
    }
    map.get(kstr).items.push(r);
  }
  return Array.from(map.values());
}

function leftOuterJoin(left, right, leftKeys, rightKeys, rightFields) {
  // Index right by key
  const rightMap = new Map();
  for (const r of right) {
    const k = rightKeys.map(kk => r[kk] == null ? null : String(r[kk]));
    const kstr = k.join('|');
    if (!rightMap.has(kstr)) rightMap.set(kstr, []);
    rightMap.get(kstr).push(r);
  }
  return left.map(l => {
    const k = leftKeys.map(kk => l[kk] == null ? null : String(l[kk]));
    const matches = rightMap.get(k.join('|')) || [];
    // Tomar el primer match (Power Query expand usa el primer match de cada nested)
    const first = matches[0] || null;
    const out = Object.assign({}, l);
    if (first) {
      for (const f of rightFields) out[f] = first[f];
    } else {
      for (const f of rightFields) out[f] = null;
    }
    out.__matches = matches; // útil para el VBA ProcesarFilaVolumen
    return out;
  });
}

function leftOuterJoinAll(left, right, leftKeys, rightKeys, rightFields) {
  // Devuelve todas las filas left, una por cada match right (no solo el primero).
  // Útil para emparejamientos donde un left puede tener N matches.
  const rightMap = new Map();
  for (const r of right) {
    const k = rightKeys.map(kk => r[kk] == null ? null : String(r[kk]));
    const kstr = k.join('|');
    if (!rightMap.has(kstr)) rightMap.set(kstr, []);
    rightMap.get(kstr).push(r);
  }
  const out = [];
  for (const l of left) {
    const k = leftKeys.map(kk => l[kk] == null ? null : String(l[kk]));
    const matches = rightMap.get(k.join('|')) || [];
    if (matches.length === 0) {
      const o = Object.assign({}, l);
      for (const f of rightFields) o[f] = null;
      o.__matches = [];
      out.push(o);
    } else {
      for (const m of matches) {
        const o = Object.assign({}, l);
        for (const f of rightFields) o[f] = m[f];
        o.__matches = [m];
        out.push(o);
      }
    }
  }
  return out;
}

/* ============================================================================
 * CONSULTAS M — TRADUCCIÓN A JAVASCRIPT
 * ========================================================================== */

/* 01_HorasSinVolumen (Section1.m q08) */
function q01_HorasSinVolumen(rawRows) {
  // rawRows = salida de fx_TransformaHoras (con cabeceras y ArchivoOrigen)
  // Renombrar Date→FechaOriginal, WMS Login→WMSLoginOriginal, Hours without volume→HorasSinVolumen (ya hecho en loader)
  // Aplicar fx_Fecha, normalizar textos, fx_NormalizaLogin, RegistroValido, MotivoInvalido, ClaveNatural, RepeticionesClave, PosibleDuplicado, IdRegistroHoras, Filtro RegistroValido=true

  let rows = rawRows.map(r => {
    const fecha = fx_Fecha(r['FechaOriginal']);
    let horas = r['HorasSinVolumen'];
    horas = numberFrom(horas);
    const siteName = fx_NormalizaTexto(r['Site name']);
    const department = fx_NormalizaTexto(r['Department']);
    const activity = fx_NormalizaTexto(r['Activity']);
    const subactivity = fx_NormalizaTexto(r['Subactivity']);
    const hrTask = fx_NormalizaTexto(r['HR Task']);
    const name = fx_NormalizaTexto(r['Name']);
    const loginRec = fx_NormalizaLogin(r['WMSLoginOriginal']);
    return {
      'Site name': siteName,
      'Department': department,
      'Activity': activity,
      'Subactivity': subactivity,
      'FechaOriginal': r['FechaOriginal'],
      'HR Task': hrTask,
      'WMSLoginOriginal': r['WMSLoginOriginal'],
      'Name': name,
      'HorasSinVolumen': horas,
      'ArchivoOrigen': r['ArchivoOrigen'],
      'FilaOrigen': r['FilaOrigen'],
      'Fecha': fecha,
      'LoginOriginal': loginRec.LoginOriginal,
      'LoginOriginalLimpio': loginRec.LoginOriginalLimpio,
      'LoginCanonico': loginRec.LoginCanonico,
      'IdNumerico': loginRec.IdNumerico,
      'IdNumericoLiteral': loginRec.IdNumericoLiteral,
      'IdNumericoNormalizado': loginRec.IdNumericoNormalizado,
      'PrefijoLogin': loginRec.Prefijo
    };
  });

  // RegistroValido + MotivoInvalido
  rows = rows.map(r => {
    let valido = true;
    let motivo = null;
    if (r['Fecha'] == null) { valido = false; motivo = 'FECHA INVALIDA'; }
    else if (r['LoginCanonico'] == null) { valido = false; motivo = 'LOGIN VACIO'; }
    else if (r['Activity'] == null) { valido = false; motivo = 'ACTIVITY VACIA'; }
    else if (r['HorasSinVolumen'] == null) { valido = false; motivo = 'HORAS NO NUMERICAS'; }
    else if (r['HorasSinVolumen'] <= 0) { valido = false; motivo = 'HORAS CERO O NEGATIVAS'; }
    r['RegistroValido'] = valido;
    r['MotivoInvalido'] = motivo;
    return r;
  });

  // ClaveNatural
  rows = rows.map(r => {
    const parts = [
      r['Site name'],
      r['Fecha'] ? formatFechaISO(r['Fecha']) : '',
      r['LoginCanonico'],
      r['Department'],
      r['Activity'],
      r['Subactivity'],
      r['HR Task'],
      r['HorasSinVolumen'] != null ? formatNumExact(r['HorasSinVolumen']) : ''
    ].map(x => x == null ? '' : String(x));
    r['ClaveNatural'] = parts.join('|');
    return r;
  });

  // RepeticionesClave (GROUP BY ClaveNatural)
  const counts = {};
  for (const r of rows) counts[r['ClaveNatural']] = (counts[r['ClaveNatural']] || 0) + 1;
  rows.forEach(r => { r['RepeticionesClave'] = counts[r['ClaveNatural']]; });

  // PosibleDuplicado
  rows.forEach(r => { r['PosibleDuplicado'] = r['RepeticionesClave'] > 1; });

  // IdRegistroHoras
  let id = 1;
  rows.forEach(r => { r['IdRegistroHoras'] = id++; });

  // Filtro RegistroValido = true
  return rows.filter(r => r['RegistroValido'] === true);
}

/* Number.ToText(n, "0.############", "en-US") equivalente */
function formatNumExact(n) {
  if (n == null) return '0';
  if (typeof n !== 'number') n = Number(n);
  if (!isFinite(n)) return '0';
  // Hasta 12 decimales sin ceros sobrantes, separador punto
  const s = n.toLocaleString('en-US', { maximumFractionDigits: 12, useGrouping: false });
  return s;
}

/* 02_VolumenDetalle (Section1.m q09) */
function q02_VolumenDetalle(rawRows) {
  let rows = rawRows.map(r => {
    const fecha = fx_Fecha(r['FechaOriginal']);
    let vol = numberFrom(r['VolumenNeto']);
    const sap = fx_NormalizaTexto(r['SAP_CODE']);
    const cust = fx_NormalizaTexto(r['CUSTOMER']);
    const wmsTask = fx_NormalizaTexto(r['WMS_TASK']);
    const userName = fx_NormalizaTexto(r['USER_NAME']);
    const loginRec = fx_NormalizaLogin(r['WMSLoginOriginal']);
    return {
      'FechaOriginal': r['FechaOriginal'],
      'SAP_CODE': sap,
      'CUSTOMER': cust,
      'WMS_TASK': wmsTask,
      'WMSLoginOriginal': r['WMSLoginOriginal'],
      'USER_NAME': userName,
      'VolumenNeto': vol,
      'ArchivoOrigen': r['ArchivoOrigen'],
      'FilaOrigen': r['FilaOrigen'],
      'Fecha': fecha,
      'LoginOriginal': loginRec.LoginOriginal,
      'LoginOriginalLimpio': loginRec.LoginOriginalLimpio,
      'LoginCanonico': loginRec.LoginCanonico,
      'IdNumerico': loginRec.IdNumerico,
      'IdNumericoLiteral': loginRec.IdNumericoLiteral,
      'IdNumericoNormalizado': loginRec.IdNumericoNormalizado,
      'PrefijoLogin': loginRec.Prefijo
    };
  });
  // VolumenPositivo, VolumenNegativo, EsVolumenCero
  rows.forEach(r => {
    const v = r['VolumenNeto'];
    r['VolumenPositivo'] = (v != null && v > 0) ? v : 0;
    r['VolumenNegativo'] = (v != null && v < 0) ? v : 0;
    r['EsVolumenCero'] = (v === 0);
  });
  // RegistroValido
  rows.forEach(r => {
    r['RegistroValido'] = (r['Fecha'] != null && r['VolumenNeto'] != null && r['WMS_TASK'] != null);
  });
  // ClaveNatural
  rows = rows.map(r => {
    const parts = [
      r['Fecha'] ? formatFechaISO(r['Fecha']) : '',
      r['SAP_CODE'],
      r['CUSTOMER'],
      r['WMS_TASK'],
      r['LoginCanonico'],
      r['VolumenNeto'] != null ? formatNumExact(r['VolumenNeto']) : ''
    ].map(x => x == null ? '' : String(x));
    r['ClaveNatural'] = parts.join('|');
    return r;
  });
  // RepeticionesClave
  const counts = {};
  for (const r of rows) counts[r['ClaveNatural']] = (counts[r['ClaveNatural']] || 0) + 1;
  rows.forEach(r => { r['RepeticionesClave'] = counts[r['ClaveNatural']]; });
  // PosibleDuplicado
  rows.forEach(r => { r['PosibleDuplicado'] = r['RepeticionesClave'] > 1; });
  // Filtro
  return rows.filter(r => r['RegistroValido'] === true);
}

/* 09_VolumenSinHorasDetalle (Section1.m q10) */
function q09_VolumenSinHorasDetalle(rawRows) {
  let rows = rawRows.map(r => {
    const fecha = fx_Fecha(r['FechaOriginalVSH']);
    let vol = numberFrom(r['VolumenSinHoras']);
    const site = fx_NormalizaTexto(r['Site name']);
    const dept = fx_NormalizaTexto(r['Department']);
    const act = fx_NormalizaTexto(r['Activity']);
    const sub = fx_NormalizaTexto(r['Subactivity']);
    const hrTask = fx_NormalizaTexto(r['HRTaskVSH']);
    const name = fx_NormalizaTexto(r['Name']);
    const loginRec = fx_NormalizaLogin(r['WMSLoginOriginalVSH']);
    return {
      'Site name': site,
      'Department': dept,
      'Activity': act,
      'Subactivity': sub,
      'FechaOriginalVSH': r['FechaOriginalVSH'],
      'HRTaskVSH': hrTask,
      'WMSLoginOriginalVSH': r['WMSLoginOriginalVSH'],
      'Name': name,
      'VolumenSinHoras': vol,
      'ArchivoOrigenVSH': r['ArchivoOrigenVSH'],
      'FilaOrigenVSH': r['FilaOrigenVSH'],
      'Fecha': fecha,
      'LoginOriginalVSH': loginRec.LoginOriginal,
      'LoginOriginalLimpioVSH': loginRec.LoginOriginalLimpio,
      'LoginCanonico': loginRec.LoginCanonico,
      'IdNumerico': loginRec.IdNumerico,
      'IdNumericoLiteralVSH': loginRec.IdNumericoLiteral,
      'IdNumericoNormalizadoVSH': loginRec.IdNumericoNormalizado,
      'PrefijoLoginVSH': loginRec.Prefijo
    };
  });
  // RegistroValidoVSH
  rows.forEach(r => {
    r['RegistroValidoVSH'] = (
      r['Fecha'] != null &&
      r['VolumenSinHoras'] != null &&
      r['VolumenSinHoras'] > 0 &&
      r['HRTaskVSH'] != null
    );
  });
  // ClaveNaturalVSH
  rows = rows.map(r => {
    const parts = [
      r['Fecha'] ? formatFechaISO(r['Fecha']) : '',
      r['LoginCanonico'],
      r['Activity'],
      r['Subactivity'],
      r['HRTaskVSH'],
      r['VolumenSinHoras'] != null ? formatNumExact(r['VolumenSinHoras']) : ''
    ].map(x => x == null ? '' : String(x));
    r['ClaveNaturalVSH'] = parts.join('|');
    return r;
  });
  // RepeticionesVSH
  const counts = {};
  for (const r of rows) counts[r['ClaveNaturalVSH']] = (counts[r['ClaveNaturalVSH']] || 0) + 1;
  rows.forEach(r => { r['RepeticionesVSH'] = counts[r['ClaveNaturalVSH']]; });
  // PosibleDuplicadoVSH
  rows.forEach(r => { r['PosibleDuplicadoVSH'] = r['RepeticionesVSH'] > 1; });
  // Filtro
  return rows.filter(r => r['RegistroValidoVSH'] === true);
}

/* 12_MapeoActividadSPEC (Section1.m q11) */
function q12_MapeoActividadSPEC(rawMappingRows) {
  // Normalizar textos en 8 columnas
  const textNorm = rawMappingRows.map(r => ({
    'SAP_CODE': fx_NormalizaTexto(r['SAP_CODE']),
    'WMS_DC': fx_NormalizaTexto(r['WMS_DC']),
    'CUSTOMER': fx_NormalizaTexto(r['CUSTOMER']),
    'DEPARTMENT': fx_NormalizaTexto(r['DEPARTMENT']),
    'ACTIVITY': fx_NormalizaTexto(r['ACTIVITY']),
    'SUB_ACTIVITY': fx_NormalizaTexto(r['SUB_ACTIVITY']),
    'TASK_WMS': fx_NormalizaTexto(r['TASK_WMS']),
    'TASK_SPEC': fx_NormalizaTexto(r['TASK_SPEC'])
  }));
  // Filas válidas: SAP_CODE<>null AND CUSTOMER<>null AND TASK_WMS<>null
  const filasValidas = textNorm.filter(r => r['SAP_CODE'] != null && r['CUSTOMER'] != null && r['TASK_WMS'] != null);

  // Verificar WMS_DC: agrupado por (SAP_CODE, CUSTOMER, TASK_WMS) → TieneMultipleWMS_DC
  const wmsDcCheck = {};
  for (const r of filasValidas) {
    const k = r['SAP_CODE'] + '|' + r['CUSTOMER'] + '|' + r['TASK_WMS'];
    if (!wmsDcCheck[k]) wmsDcCheck[k] = new Set();
    if (r['WMS_DC'] != null) wmsDcCheck[k].add(r['WMS_DC']);
  }
  const wmsDcMulti = {};
  for (const k of Object.keys(wmsDcCheck)) {
    wmsDcMulti[k] = wmsDcCheck[k].size > 1;
  }

  // Agrupación principal
  const groups = groupBy(filasValidas, ['SAP_CODE', 'CUSTOMER', 'TASK_WMS']);
  const out = groups.map(g => {
    const items = g.items;
    const sap = g.key['SAP_CODE'];
    const cust = g.key['CUSTOMER'];
    const wms = g.key['TASK_WMS'];
    const k = sap + '|' + cust + '|' + wms;
    const actividades = distinctList(items.map(r => r['ACTIVITY']));
    const tasksSpec = distinctList(items.map(r => r['TASK_SPEC']));
    const departamentos = distinctList(items.map(r => r['DEPARTMENT']));
    const subactividades = distinctList(items.map(r => r['SUB_ACTIVITY']));
    const wmsDcs = distinctList(items.map(r => r['WMS_DC']));
    const numTasksSPEC = tasksSpec.length;
    let estadoMapeoSPEC;
    if (numTasksSPEC === 0) estadoMapeoSPEC = 'SIN TASK_SPEC';
    else if (numTasksSPEC === 1) estadoMapeoSPEC = 'UNICO';
    else estadoMapeoSPEC = 'AMBIGUO';
    return {
      'SAP_CODE': sap,
      'CUSTOMER': cust,
      'TASK_WMS': wms,
      'NumeroActividadesSPEC': actividades.length,
      'ActividadesSPECPosibles': actividades.join(' | '),
      'ActividadSPEC': actividades.length === 1 ? actividades[0] : null,
      'NumeroTasksSPEC': numTasksSPEC,
      'TasksSPECPosibles': tasksSpec.join(' | '),
      'TasksSPEC': tasksSpec.join(' | '),
      'DepartamentosSPEC': departamentos.join(' | '),
      'SubactividadesSPEC': subactividades.join(' | '),
      'WMS_DCs': wmsDcs.join(' | '),
      'TieneMultipleWMS_DC': wmsDcMulti[k] || false,
      'EstadoMapeoSPEC': estadoMapeoSPEC
    };
  });
  return out;
}

/* 13_VolumenMapeadoSPEC (Section1.m q12) */
function q13_VolumenMapeadoSPEC(volumenDetalle, mapeoSPEC) {
  const rightFields = ['NumeroActividadesSPEC', 'ActividadesSPECPosibles', 'ActividadSPEC', 'NumeroTasksSPEC', 'TasksSPECPosibles', 'TasksSPEC', 'DepartamentosSPEC', 'SubactividadesSPEC', 'WMS_DCs', 'TieneMultipleWMS_DC', 'EstadoMapeoSPEC'];
  const joined = leftOuterJoin(volumenDetalle, mapeoSPEC, ['SAP_CODE', 'CUSTOMER', 'WMS_TASK'], ['SAP_CODE', 'CUSTOMER', 'TASK_WMS'], rightFields);
  joined.forEach(r => {
    r['EstadoMapeoFinal'] = r['EstadoMapeoSPEC'] == null ? 'SIN MAPEO' : r['EstadoMapeoSPEC'];
    delete r.__matches;
  });
  return joined;
}

/* 03_VolumenPersonaDia (Section1.m q13) */
function q03_VolumenPersonaDia(volumenDetalle) {
  const src = volumenDetalle.filter(r => r['LoginCanonico'] != null);
  const groups = groupBy(src, ['Fecha', 'LoginCanonico']);
  return groups.map(g => {
    const items = g.items;
    return {
      'Fecha': g.key['Fecha'],
      'LoginCanonico': g.key['LoginCanonico'],
      'VolumenTotalPositivo': sumList(items.map(r => r['VolumenPositivo'])),
      'VolumenTotalNegativo': sumList(items.map(r => r['VolumenNegativo'])),
      'VolumenTotalNeto': sumList(items.map(r => r['VolumenNeto'])),
      'RegistrosVolumen': items.length,
      'RegistrosCero': countTrue(items.map(r => r['EsVolumenCero'])),
      'RegistrosNegativos': items.filter(r => r['VolumenNeto'] != null && r['VolumenNeto'] < 0).length,
      'NumeroTareasWMS': distinctList(items.map(r => r['WMS_TASK'])).length,
      'TareasWMS': joinDistinct(items.map(r => r['WMS_TASK'])),
      'ClientesWMS': joinDistinct(items.map(r => r['CUSTOMER'])),
      'SAPsWMS': joinDistinct(items.map(r => r['SAP_CODE'])),
      'TieneDuplicadosVolumen': anyTrue(items.map(r => r['PosibleDuplicado']))
    };
  });
}

/* 05_VolumenIdNumericoDia (Section1.m q14) */
function q05_VolumenIdNumericoDia(volumenDetalle) {
  const src = volumenDetalle.filter(r => r['IdNumericoNormalizado'] != null && r['LoginCanonico'] != null);
  const groups = groupBy(src, ['Fecha', 'IdNumericoNormalizado']);
  return groups.map(g => {
    const items = g.items;
    const logins = distinctList(items.map(r => r['LoginCanonico']));
    const prefijos = distinctList(items.map(r => r['PrefijoLogin']));
    return {
      'Fecha': g.key['Fecha'],
      'IdNumericoNormalizado': g.key['IdNumericoNormalizado'],
      'VolumenIdPositivo': sumList(items.map(r => r['VolumenPositivo'])),
      'NumeroLoginsDistintos': logins.length,
      'LoginsMismoNumero': logins.join(' | '),
      'PrefijosMismoNumero': prefijos.join(' | '),
      'EsAmbiguoIdNumerico': logins.length > 1
    };
  });
}

/* 10_VolumenSinHorasPersonaDia (Section1.m q15) */
function q10_VolumenSinHorasPersonaDia(vshDetalle) {
  const src = vshDetalle.filter(r => r['LoginCanonico'] != null);
  const groups = groupBy(src, ['Fecha', 'LoginCanonico']);
  return groups.map(g => {
    const items = g.items;
    return {
      'Fecha': g.key['Fecha'],
      'LoginCanonico': g.key['LoginCanonico'],
      'VolumenSinHorasPersonaDia': sumList(items.map(r => r['VolumenSinHoras'])),
      'NumeroRegistrosVSH': items.length,
      'ActividadesVSH': joinDistinct(items.map(r => r['Activity'])),
      'SubactividadesVSH': joinDistinct(items.map(r => r['Subactivity'])),
      'TareasVSH': joinDistinct(items.map(r => r['HRTaskVSH'])),
      'TieneDuplicadosVSH': anyTrue(items.map(r => r['PosibleDuplicadoVSH']))
    };
  });
}

/* 14_VolumenPersonaDiaActividadSPEC (Section1.m q16) */
function q14_VolumenPersonaDiaActividadSPEC(volumenMapeado) {
  const src = volumenMapeado.filter(r => r['LoginCanonico'] != null && r['ActividadSPEC'] != null && r['EstadoMapeoFinal'] === 'UNICO');
  const groups = groupBy(src, ['Fecha', 'LoginCanonico', 'ActividadSPEC']);
  return groups.map(g => {
    const items = g.items;
    return {
      'Fecha': g.key['Fecha'],
      'LoginCanonico': g.key['LoginCanonico'],
      'ActividadSPEC': g.key['ActividadSPEC'],
      'VolumenMismaActivitySPECPositivo': sumList(items.map(r => r['VolumenPositivo'])),
      'VolumenMismaActivitySPECNegativo': sumList(items.map(r => r['VolumenNegativo'])),
      'VolumenMismaActivitySPECNeto': sumList(items.map(r => r['VolumenNeto'])),
      'TareasWMSMismaActivitySPEC': joinDistinct(items.map(r => r['WMS_TASK'])),
      'TasksSPECUna': joinDistinct(items.map(r => r['TasksSPEC']))
    };
  });
}

/* 15_VolumenSinHorasPersonaDiaActividadSPEC (Section1.m q17) */
function q15_VolumenSinHorasPersonaDiaActividadSPEC(vshDetalle) {
  const src = vshDetalle.filter(r => r['LoginCanonico'] != null && r['Activity'] != null);
  const groups = groupBy(src, ['Fecha', 'LoginCanonico', 'Activity']);
  return groups.map(g => {
    const items = g.items;
    return {
      'Fecha': g.key['Fecha'],
      'LoginCanonico': g.key['LoginCanonico'],
      'Activity': g.key['Activity'],
      'VolumenSinHorasMismaActivitySPEC': sumList(items.map(r => r['VolumenSinHoras'])),
      'TareasVSHMismaActivitySPEC': joinDistinct(items.map(r => r['HRTaskVSH']))
    };
  });
}

/* 16_ControlMapeoSPEC (Section1.m q18) */
function q16_ControlMapeoSPEC(mapeoSPEC, volumenMapeado, vid) {
  const clavesVolumen = distinctOf(volumenMapeado.filter(r => r['WMS_TASK'] != null).map(r => ({ a: r['SAP_CODE'], b: r['CUSTOMER'], c: r['WMS_TASK'] })));
  const clavesUnicas = distinctOf(volumenMapeado.filter(r => r['EstadoMapeoFinal'] === 'UNICO').map(r => ({ a: r['SAP_CODE'], b: r['CUSTOMER'], c: r['WMS_TASK'] })));
  const clavesAmbiguas = distinctOf(volumenMapeado.filter(r => r['EstadoMapeoFinal'] === 'AMBIGUO').map(r => ({ a: r['SAP_CODE'], b: r['CUSTOMER'], c: r['WMS_TASK'] })));
  const clavesSinMapeo = distinctOf(volumenMapeado.filter(r => r['EstadoMapeoFinal'] === 'SIN MAPEO' && r['WMS_TASK'] != null).map(r => ({ a: r['SAP_CODE'], b: r['CUSTOMER'], c: r['WMS_TASK'] })));

  const volumenTotalPositivo = sumList(volumenMapeado.map(r => r['VolumenPositivo']));
  const volumenMapeadoPositivo = sumList(volumenMapeado.filter(r => r['EstadoMapeoFinal'] === 'UNICO').map(r => r['VolumenPositivo']));
  const volumenAmbiguoPositivo = sumList(volumenMapeado.filter(r => r['EstadoMapeoFinal'] === 'AMBIGUO').map(r => r['VolumenPositivo']));
  const volumenSinMapeoPositivo = sumList(volumenMapeado.filter(r => r['EstadoMapeoFinal'] === 'SIN MAPEO').map(r => r['VolumenPositivo']));
  const volumenSinLoginPositivo = sumList(volumenMapeado.filter(r => r['LoginCanonico'] == null).map(r => r['VolumenPositivo']));

  const volConLoginUnico = volumenMapeado.filter(r => r['EstadoMapeoFinal'] === 'UNICO' && r['LoginCanonico'] != null);
  const idNumAmbiguos = new Set(vid.filter(r => r['EsAmbiguoIdNumerico'] === true).map(r => r['IdNumericoNormalizado']));
  const volSinAmbiguedadId = volConLoginUnico.filter(r => !idNumAmbiguos.has(r['IdNumericoNormalizado']));
  const volumenUnicoAtribuible = sumList(volSinAmbiguedadId.map(r => r['VolumenPositivo']));

  const coberturaTotal = volumenTotalPositivo === 0 ? null : volumenMapeadoPositivo / volumenTotalPositivo;
  const coberturaAtribuible = volumenTotalPositivo === 0 ? null : volumenUnicoAtribuible / volumenTotalPositivo;

  function stCobertura(c) {
    if (c == null) return 'SIN DATOS';
    if (c >= 0.9) return 'OK';
    if (c >= 0.7) return 'REVISAR';
    return 'ERROR BLOQUEANTE';
  }
  function stCoberturaAtrib(c) {
    if (c == null) return 'SIN DATOS';
    if (c >= 0.9) return 'OK';
    if (c >= 0.7) return 'REVISAR';
    return 'DATOS INSUFICIENTES - calidad de fuentes (volumen sin login, mapeos ambiguos)';
  }

  const res = [];
  res.push({ Control: 'Mapeos TASK_WMS cargados', Valor: mapeoSPEC.length, Estado: mapeoSPEC.length > 0 ? 'OK' : 'ERROR BLOQUEANTE' });
  res.push({ Control: 'WMS Task distintas en volumen', Valor: clavesVolumen.length, Estado: 'INFORMATIVO' });
  res.push({ Control: 'WMS Task con mapeo unico (TASK_SPEC)', Valor: clavesUnicas.length, Estado: clavesUnicas.length > 0 ? 'OK' : 'ERROR BLOQUEANTE' });
  res.push({ Control: 'WMS Task con mapeo ambiguo (TASK_SPEC)', Valor: clavesAmbiguas.length, Estado: clavesAmbiguas.length === 0 ? 'OK' : 'REVISAR' });
  res.push({ Control: 'WMS Task sin mapeo', Valor: clavesSinMapeo.length, Estado: clavesSinMapeo.length === 0 ? 'OK' : 'REVISAR' });
  res.push({ Control: 'Volumen positivo total', Valor: volumenTotalPositivo, Estado: 'INFORMATIVO' });
  res.push({ Control: 'Volumen positivo mapeado UNICO', Valor: volumenMapeadoPositivo, Estado: 'INFORMATIVO' });
  res.push({ Control: 'Volumen positivo AMBIGUO', Valor: volumenAmbiguoPositivo, Estado: 'INFORMATIVO' });
  res.push({ Control: 'Volumen positivo SIN MAPEO', Valor: volumenSinMapeoPositivo, Estado: 'INFORMATIVO' });
  res.push({ Control: 'Volumen positivo SIN LOGIN (no atribuible)', Valor: volumenSinLoginPositivo, Estado: 'INFORMATIVO' });
  res.push({ Control: 'Volumen positivo UNICO sin ambiguedad IdNumerico', Valor: volumenUnicoAtribuible, Estado: 'INFORMATIVO' });
  res.push({ Control: 'Cobertura volumen positivo mapeado (total)', Valor: coberturaTotal, Estado: stCobertura(coberturaTotal) });
  res.push({ Control: 'Cobertura volumen positivo atribuible (real)', Valor: coberturaAtribuible, Estado: stCoberturaAtrib(coberturaAtribuible) });
  return res;
}

function distinctOf(arr) {
  // arr es lista de objetos con claves a,b,c
  const seen = new Set();
  const out = [];
  for (const o of arr) {
    const k = (o.a || '') + '|' + (o.b || '') + '|' + (o.c || '');
    if (!seen.has(k)) { seen.add(k); out.push(o); }
  }
  return out;
}

/* 07_Conciliacion (Section1.m q19) — la consulta central */
function q07_Conciliacion(horasSinVolumen, volPersonaDia, volIdNumDia, vshPersonaDia, volPersonaDiaActSpec, vshPersonaDiaActSpec) {
  // Base = H = 01_HorasSinVolumen
  let H = horasSinVolumen.map(deepClone);

  // M1: LEFT OUTER JOIN con 03_VolumenPersonaDia por (Fecha, LoginCanonico)
  H = leftOuterJoin(H, volPersonaDia, ['Fecha', 'LoginCanonico'], ['Fecha', 'LoginCanonico'],
    ['VolumenTotalPositivo', 'VolumenTotalNegativo', 'VolumenTotalNeto', 'RegistrosVolumen', 'RegistrosCero', 'RegistrosNegativos', 'NumeroTareasWMS', 'TareasWMS', 'ClientesWMS', 'SAPsWMS', 'TieneDuplicadosVolumen']);

  // M2: LEFT OUTER JOIN con 14_VolumenPersonaDiaActividadSPEC por (Fecha, LoginCanonico, Activity=ActividadSPEC)
  H = leftOuterJoinAll(H, volPersonaDiaActSpec, ['Fecha', 'LoginCanonico', 'Activity'], ['Fecha', 'LoginCanonico', 'ActividadSPEC'],
    ['VolumenMismaActivitySPECPositivo', 'VolumenMismaActivitySPECNegativo', 'VolumenMismaActivitySPECNeto', 'TareasWMSMismaActivitySPEC', 'TasksSPECUna']);
  // Renombrar a VolumenMismaActividad*
  H.forEach(r => {
    r['VolumenMismaActividadPositivo'] = r['VolumenMismaActivitySPECPositivo'];
    r['VolumenMismaActividadNegativo'] = r['VolumenMismaActivitySPECNegativo'];
    r['VolumenMismaActividadNeto'] = r['VolumenMismaActivitySPECNeto'];
    r['TareasWMSMismaActividad'] = r['TareasWMSMismaActivitySPEC'];
    r['TasksSPECUnaMismaActividad'] = r['TasksSPECUna'];
  });

  // M3: LEFT OUTER JOIN con 05_VolumenIdNumericoDia por (Fecha, IdNumericoNormalizado)
  H = leftOuterJoin(H, volIdNumDia, ['Fecha', 'IdNumericoNormalizado'], ['Fecha', 'IdNumericoNormalizado'],
    ['VolumenIdPositivo', 'NumeroLoginsDistintos', 'LoginsMismoNumero', 'PrefijosMismoNumero', 'EsAmbiguoIdNumerico']);
  // Renombrar VolumenIdPositivo → VolumenMismoNumeroPositivo
  H.forEach(r => {
    r['VolumenMismoNumeroPositivo'] = r['VolumenIdPositivo'];
  });

  // M4: LEFT OUTER JOIN con 10_VolumenSinHorasPersonaDia por (Fecha, LoginCanonico)
  H = leftOuterJoin(H, vshPersonaDia, ['Fecha', 'LoginCanonico'], ['Fecha', 'LoginCanonico'],
    ['VolumenSinHorasPersonaDia', 'NumeroRegistrosVSH', 'ActividadesVSH', 'SubactividadesVSH', 'TareasVSH', 'TieneDuplicadosVSH']);

  // M5: LEFT OUTER JOIN con 15_VolumenSinHorasPersonaDiaActividadSPEC por (Fecha, LoginCanonico, Activity)
  H = leftOuterJoin(H, vshPersonaDiaActSpec, ['Fecha', 'LoginCanonico', 'Activity'], ['Fecha', 'LoginCanonico', 'Activity'],
    ['VolumenSinHorasMismaActivitySPEC', 'TareasVSHMismaActivitySPEC']);
  H.forEach(r => {
    r['VolumenSinHorasMismaActividad'] = r['VolumenSinHorasMismaActivitySPEC'];
    r['TareasVSHMismaActividad'] = r['TareasVSHMismaActivitySPEC'];
  });

  // Numeros: ReplaceValue null→0 en 15 columnas numéricas
  const numCols = ['VolumenTotalPositivo', 'VolumenTotalNegativo', 'VolumenTotalNeto', 'RegistrosVolumen', 'RegistrosCero', 'RegistrosNegativos', 'NumeroTareasWMS', 'VolumenMismaActividadPositivo', 'VolumenMismaActividadNegativo', 'VolumenMismaActividadNeto', 'VolumenMismoNumeroPositivo', 'NumeroLoginsDistintos', 'VolumenSinHorasPersonaDia', 'NumeroRegistrosVSH', 'VolumenSinHorasMismaActividad'];
  H.forEach(r => {
    for (const c of numCols) {
      if (r[c] == null) r[c] = 0;
    }
  });

  // Booleanos: null→false
  H.forEach(r => {
    if (r['TieneDuplicadosVolumen'] == null) r['TieneDuplicadosVolumen'] = false;
    if (r['TieneDuplicadosVSH'] == null) r['TieneDuplicadosVSH'] = false;
    if (r['EsAmbiguoIdNumerico'] == null) r['EsAmbiguoIdNumerico'] = false;
  });

  // Otras: VolumenOtrasActividadesPositivo
  H.forEach(r => {
    const diff = (r['VolumenTotalPositivo'] || 0) - (r['VolumenMismaActividadPositivo'] || 0);
    r['VolumenOtrasActividadesPositivo'] = diff > 0 ? diff : 0;
  });

  // NumActHR: GROUP BY (Fecha, LoginCanonico) de H original
  const groupsH = groupBy(horasSinVolumen, ['Fecha', 'LoginCanonico']);
  const numActHRMap = new Map();
  for (const g of groupsH) {
    const k = fechaLoginKey(g.key['Fecha'], g.key['LoginCanonico']);
    if (k == null) continue;
    const acts = distinctList(g.items.map(r => r['Activity']));
    const hrTasks = distinctList(g.items.map(r => r['HR Task']));
    numActHRMap.set(k, {
      NumeroActividadesHR: acts.length,
      NumeroHRTaskDistintas: hrTasks.length,
      HRTaskDistintas: hrTasks.join(' | '),
      HorasTotalesPersonaDia: sumList(g.items.map(r => r['HorasSinVolumen']))
    });
  }
  // M6: JOIN con NumActHR por (Fecha, LoginCanonico)
  H.forEach(r => {
    const k = fechaLoginKey(r['Fecha'], r['LoginCanonico']);
    const v = k ? numActHRMap.get(k) : null;
    if (v) {
      r['NumeroActividadesHR'] = v.NumeroActividadesHR;
      r['NumeroHRTaskDistintas'] = v.NumeroHRTaskDistintas;
      r['HRTaskDistintas'] = v.HRTaskDistintas;
      r['HorasTotalesPersonaDia'] = v.HorasTotalesPersonaDia;
    } else {
      r['NumeroActividadesHR'] = 0;
      r['NumeroHRTaskDistintas'] = 0;
      r['HRTaskDistintas'] = '';
      r['HorasTotalesPersonaDia'] = 0;
    }
  });

  // Clasificacion
  H.forEach(r => {
    let c;
    if (r['PosibleDuplicado'] || r['TieneDuplicadosVolumen'] || r['TieneDuplicadosVSH']) c = 'POSIBLE DUPLICIDAD';
    else if (r['EsAmbiguoIdNumerico'] && r['VolumenMismoNumeroPositivo'] > 0 && r['VolumenTotalPositivo'] === 0) c = 'REVISION MANUAL - AMBIGUEDAD ID NUMERICO';
    else if (r['VolumenSinHorasMismaActividad'] > 0) c = 'DESCUADRE RECIPROCO EN LA MISMA ACTIVITY SPEC';
    else if (r['VolumenSinHorasPersonaDia'] > 0) c = 'VOLUMEN SIN HORAS EN OTRA ACTIVITY SPEC';
    else if (r['VolumenMismaActividadPositivo'] > 0) c = 'VOLUMEN EN LA MISMA ACTIVITY SPEC';
    else if (r['VolumenOtrasActividadesPositivo'] > 0) c = 'VOLUMEN EN OTRA ACTIVITY SPEC O SIN MAPEO';
    else if (r['VolumenTotalPositivo'] === 0 && r['VolumenMismoNumeroPositivo'] > 0) c = 'POSIBLE ERROR DE IDENTIFICACION O PREFIJO';
    else if (r['VolumenTotalPositivo'] === 0 && r['RegistrosVolumen'] > 0) c = 'SOLO REGISTROS CERO O AJUSTES';
    else if (r['VolumenTotalPositivo'] === 0) c = 'SIN EVIDENCIA DE ACTIVIDAD PRODUCTIVA';
    else c = 'CASO NO DETERMINABLE';
    r['Clasificacion'] = c;
  });

  // NivelConfianza
  H.forEach(r => {
    const c = r['Clasificacion'];
    let n;
    if (c === 'POSIBLE DUPLICIDAD' || c === 'DESCUADRE RECIPROCO EN LA MISMA ACTIVITY SPEC' || c === 'VOLUMEN SIN HORAS EN OTRA ACTIVITY SPEC' || c === 'VOLUMEN EN LA MISMA ACTIVITY SPEC') n = 'ALTA';
    else if (c === 'VOLUMEN EN OTRA ACTIVITY SPEC O SIN MAPEO' || c === 'POSIBLE ERROR DE IDENTIFICACION O PREFIJO' || c === 'SOLO REGISTROS CERO O AJUSTES') n = 'MEDIA';
    else if (c.indexOf('REVISION MANUAL') === 0) n = 'MEDIA';
    else n = 'NO DETERMINABLE';
    r['NivelConfianza'] = n;
  });

  // Evidencia
  H.forEach(r => {
    const parts = [];
    parts.push('Horas sin volumen: ' + formatNum2(r['HorasSinVolumen']) + ' h');
    parts.push('Activity SPEC fichada: ' + (r['Activity'] || ''));
    parts.push('HR Task fichada: ' + (r['HR Task'] || ''));
    if (r['NumeroHRTaskDistintas'] > 1) parts.push('Multiples HR Task el mismo dia: ' + (r['HRTaskDistintas'] || ''));
    if (r['EsAmbiguoIdNumerico'] && r['VolumenMismoNumeroPositivo'] > 0) parts.push('Ambiguedad IdNumerico: ' + (r['LoginsMismoNumero'] || ''));
    if (r['VolumenMismaActividadPositivo'] > 0) parts.push('Volumen WMS mapeado a la misma Activity SPEC: ' + formatNum0(r['VolumenMismaActividadPositivo']));
    if (r['VolumenOtrasActividadesPositivo'] > 0) parts.push('Volumen en otras actividades o sin mapeo: ' + formatNum0(r['VolumenOtrasActividadesPositivo']));
    if (r['VolumenSinHorasMismaActividad'] > 0) parts.push('Alerta reciproca VSH en misma Activity SPEC: ' + formatNum0(r['VolumenSinHorasMismaActividad']));
    if (r['VolumenSinHorasPersonaDia'] > 0) parts.push('Volumen sin horas total persona/dia: ' + formatNum0(r['VolumenSinHorasPersonaDia']));
    if (r['RegistrosCero'] > 0) parts.push('Registros WMS cero: ' + r['RegistrosCero']);
    if (r['RegistrosNegativos'] > 0) parts.push('Registros WMS negativos: ' + r['RegistrosNegativos']);
    if (r['VolumenMismoNumeroPositivo'] > 0 && r['VolumenTotalPositivo'] === 0) parts.push('Volumen con mismo numero y otro prefijo: ' + (r['LoginsMismoNumero'] || ''));
    r['Evidencia'] = parts.filter(s => s != null && s !== '').join('; ');
  });

  // Explicacion
  const explMap = {
    'REVISION MANUAL - AMBIGUEDAD ID NUMERICO': 'Existen multiples logins candidatos con el mismo IdNumerico normalizado. No se puede atribuir el volumen a un usuario unico.',
    'DESCUADRE RECIPROCO EN LA MISMA ACTIVITY SPEC': 'La misma persona y Activity SPEC aparecen con horas sin volumen y tambien con volumen sin horas. Es evidencia directa de desacople entre ambas imputaciones.',
    'VOLUMEN SIN HORAS EN OTRA ACTIVITY SPEC': 'La persona tiene horas sin volumen en una Activity SPEC y volumen sin horas en otra. Es compatible con una asignacion incorrecta de actividad.',
    'VOLUMEN EN LA MISMA ACTIVITY SPEC': 'El volumen WMS ha sido mapeado a la misma Activity. Debe revisarse por que la alerta no reconoce ese volumen.',
    'VOLUMEN EN OTRA ACTIVITY SPEC O SIN MAPEO': 'La persona tiene volumen positivo, pero no se ha podido atribuir a la misma Activity SPEC.',
    'POSIBLE ERROR DE IDENTIFICACION O PREFIJO': 'No hay volumen para el login completo, pero si para el mismo numero con otro prefijo.',
    'SOLO REGISTROS CERO O AJUSTES': 'Existen trazas WMS de la persona, pero no volumen positivo.',
    'SIN EVIDENCIA DE ACTIVIDAD PRODUCTIVA': 'No se ha localizado volumen individual positivo ni una alerta reciproca atribuible.',
    'POSIBLE DUPLICIDAD': 'Hay claves repetidas que pueden distorsionar los resultados.',
    'CASO NO DETERMINABLE': 'La evidencia disponible no permite determinar una causa.'
  };
  H.forEach(r => { r['Explicacion'] = explMap[r['Clasificacion']] || explMap['CASO NO DETERMINABLE']; });

  // AccionRecomendada
  const accMap = {
    'REVISION MANUAL - AMBIGUEDAD ID NUMERICO': 'Revisar manualmente los logins candidatos y validar alias/prefijos.',
    'DESCUADRE RECIPROCO EN LA MISMA ACTIVITY SPEC': 'Revisar conjuntamente ambas alertas y corregir el desacople.',
    'VOLUMEN SIN HORAS EN OTRA ACTIVITY SPEC': 'Contrastar las dos Activity SPEC y reasignar las horas si procede.',
    'VOLUMEN EN LA MISMA ACTIVITY SPEC': 'Revisar la regla de enlace SPID-WMS para esa Activity SPEC.',
    'VOLUMEN EN OTRA ACTIVITY SPEC O SIN MAPEO': 'Revisar la tabla de mapeo SPEC y completar las WMS Task sin mapeo o ambiguas.',
    'POSIBLE ERROR DE IDENTIFICACION O PREFIJO': 'Validar alias y prefijos de login.',
    'POSIBLE DUPLICIDAD': 'Eliminar solapamientos de archivos antes del analisis.',
    'SOLO REGISTROS CERO O AJUSTES': 'Revisar actividad indirecta, incidencia operativa o dato faltante.',
    'SIN EVIDENCIA DE ACTIVIDAD PRODUCTIVA': 'Revisar actividad indirecta, incidencia operativa o dato faltante.',
    'CASO NO DETERMINABLE': 'Revisar actividad indirecta, incidencia operativa o dato faltante.'
  };
  H.forEach(r => { r['AccionRecomendada'] = accMap[r['Clasificacion']] || accMap['CASO NO DETERMINABLE']; });

  // Materialidad
  H.forEach(r => { r['Materialidad'] = calcularMaterialidad(r['HorasSinVolumen']); });

  // Limpiar campos auxiliares
  H.forEach(r => { delete r.__matches; delete r['VolumenMismaActivitySPECPositivo']; delete r['VolumenMismaActivitySPECNegativo']; delete r['VolumenMismaActivitySPECNeto']; delete r['TareasWMSMismaActivitySPEC']; delete r['TasksSPECUna']; delete r['VolumenIdPositivo']; delete r['VolumenSinHorasMismaActivitySPEC']; delete r['TareasVSHMismaActivitySPEC']; });

  return H;
}

/* 08_Validaciones (Section1.m q20) */
function q08_Validaciones(H, V, VSH, C, VM, VID) {
  const out = [];
  function diff(a, b) { return Math.abs((a || 0) - (b || 0)) < 0.000001; }
  out.push({ Control: 'Registros horas validos', ValorOrigen: H.length, ValorResultado: C.length, Estado: H.length === C.length ? 'OK' : 'ERROR', Detalle: 'Una fila de conciliacion por registro valido de horas' });
  out.push({ Control: 'Horas totales conservadas', ValorOrigen: sumList(H.map(r => r['HorasSinVolumen'])), ValorResultado: sumList(C.map(r => r['HorasSinVolumen'])), Estado: diff(sumList(H.map(r => r['HorasSinVolumen'])), sumList(C.map(r => r['HorasSinVolumen']))) ? 'OK' : 'ERROR', Detalle: 'No se multiplican ni pierden horas' });
  out.push({ Control: 'Volumen neto (antes vs despues mapping)', ValorOrigen: sumList(V.map(r => r['VolumenNeto'])), ValorResultado: sumList(VM.map(r => r['VolumenNeto'])), Estado: diff(sumList(V.map(r => r['VolumenNeto'])), sumList(VM.map(r => r['VolumenNeto']))) ? 'OK' : 'ERROR', Detalle: 'El mapeo SPEC no multiplica volumen' });
  out.push({ Control: 'Volumen positivo (antes vs despues mapping)', ValorOrigen: sumList(V.map(r => r['VolumenPositivo'])), ValorResultado: sumList(VM.map(r => r['VolumenPositivo'])), Estado: diff(sumList(V.map(r => r['VolumenPositivo'])), sumList(VM.map(r => r['VolumenPositivo']))) ? 'OK' : 'ERROR', Detalle: 'Volumen positivo conservado' });
  out.push({ Control: 'Volumen negativo (antes vs despues mapping)', ValorOrigen: sumList(V.map(r => r['VolumenNegativo'])), ValorResultado: sumList(VM.map(r => r['VolumenNegativo'])), Estado: diff(sumList(V.map(r => r['VolumenNegativo'])), sumList(VM.map(r => r['VolumenNegativo']))) ? 'OK' : 'ERROR', Detalle: 'Volumen negativo conservado' });
  out.push({ Control: 'Registros volumen (antes vs despues mapping)', ValorOrigen: V.length, ValorResultado: VM.length, Estado: V.length === VM.length ? 'OK' : 'ERROR', Detalle: 'El mapeo conserva el detalle (no multiplica filas)' });
  out.push({ Control: 'Registros VSH en 09_VolumenSinHorasDetalle', ValorOrigen: VSH.length, ValorResultado: null, Estado: VSH.length > 0 ? 'OK' : 'REVISAR', Detalle: 'VSH cargado en consulta 09' });
  out.push({ Control: 'Total volumen sin horas en 09_VolumenSinHorasDetalle', ValorOrigen: sumList(VSH.map(r => r['VolumenSinHoras'])), ValorResultado: null, Estado: sumList(VSH.map(r => r['VolumenSinHoras'])) > 0 ? 'OK' : 'REVISAR', Detalle: 'Total VSH en consulta 09' });
  out.push({ Control: 'Duplicados horas (claves repetidas)', ValorOrigen: H.filter(r => r['PosibleDuplicado'] === true).length, ValorResultado: null, Estado: H.filter(r => r['PosibleDuplicado'] === true).length === 0 ? 'OK' : 'REVISAR', Detalle: 'Posible solapamiento de archivos de horas' });
  out.push({ Control: 'Duplicados volumen (claves repetidas)', ValorOrigen: V.filter(r => r['PosibleDuplicado'] === true).length, ValorResultado: null, Estado: V.filter(r => r['PosibleDuplicado'] === true).length === 0 ? 'OK' : 'REVISAR', Detalle: 'Posible solapamiento de archivos de volumen' });
  out.push({ Control: 'Duplicados VSH (claves repetidas)', ValorOrigen: VSH.filter(r => r['PosibleDuplicadoVSH'] === true).length, ValorResultado: null, Estado: VSH.filter(r => r['PosibleDuplicadoVSH'] === true).length === 0 ? 'OK' : 'REVISAR', Detalle: 'Posible solapamiento de archivos VSH' });
  out.push({ Control: 'WMS Task sin mapeo SPEC', ValorOrigen: distinctOf(VM.filter(r => r['EstadoMapeoFinal'] === 'SIN MAPEO').map(r => ({ a: r['WMS_TASK'] }))).length, ValorResultado: null, Estado: 'REVISAR', Detalle: 'WMS Task en volumen sin fila en Mapping' });
  out.push({ Control: 'WMS Task con mapeo ambiguo (TASK_SPEC)', ValorOrigen: distinctOf(VM.filter(r => r['EstadoMapeoFinal'] === 'AMBIGUO').map(r => ({ a: r['WMS_TASK'] }))).length, ValorResultado: null, Estado: distinctOf(VM.filter(r => r['EstadoMapeoFinal'] === 'AMBIGUO').map(r => ({ a: r['WMS_TASK'] }))).length === 0 ? 'OK' : 'REVISAR', Detalle: 'WMS Task con multiples TASK_SPEC en mapping' });
  out.push({ Control: 'Volumen sin login (registros)', ValorOrigen: V.filter(r => r['LoginCanonico'] == null).length, ValorResultado: null, Estado: 'INFORMATIVO', Detalle: 'No atribuible individualmente' });
  out.push({ Control: 'Volumen sin login (unidades positivas)', ValorOrigen: sumList(V.filter(r => r['LoginCanonico'] == null).map(r => r['VolumenPositivo'])), ValorResultado: null, Estado: 'INFORMATIVO', Detalle: 'Unidades positivas no atribuibles' });
  out.push({ Control: 'Logins unicos sin volumen positivo', ValorOrigen: distinctList(C.filter(r => r['VolumenTotalPositivo'] === 0).map(r => r['LoginCanonico'])).length, ValorResultado: null, Estado: 'INFORMATIVO', Detalle: 'Logins (no filas) sin volumen positivo' });
  out.push({ Control: 'Casos unicos multi HR Task persona+dia', ValorOrigen: distinctOf(C.filter(r => r['NumeroHRTaskDistintas'] > 1).map(r => ({ a: formatFechaISO(r['Fecha']), b: r['LoginCanonico'] }))).length, ValorResultado: null, Estado: 'REVISAR', Detalle: 'Casos persona+fecha con varias HR Task (distintos, no filas)' });
  out.push({ Control: 'Colisiones IdNumerico (multiples logins)', ValorOrigen: VID.filter(r => r['EsAmbiguoIdNumerico'] === true).length, ValorResultado: null, Estado: 'REVISAR', Detalle: 'IdNumericos normalizados compartidos por multiples logins' });
  return out;
}

/* ============================================================================
 * VBA — CalcularMaterialidad (líneas 126-138)
 * ========================================================================== */
function calcularMaterialidad(horas) {
  if (horas == null) horas = 0;
  if (typeof horas !== 'number') horas = Number(horas) || 0;
  if (horas < PARAMS.UmbralMicroHoras) return 'MICRO < 5 MIN';
  if (horas < 0.25) return 'BAJA < 15 MIN';
  if (horas < 1) return 'MEDIA < 1 H';
  if (horas < 4) return 'ALTA 1-4 H';
  return 'CRITICA >= 4 H';
}

/* ============================================================================
 * VBA — GenerarReporteCambiosHR (líneas 274-555)
 * ========================================================================== */
function generarReporteCambiosHR(H, VM, C) {
  // H = 01_HorasSinVolumen, VM = 13_VolumenMapeadoSPEC, C = 07_Conciliacion
  // Cabeceras
  const hh = buildHeaderIndex(H, ['IdRegistroHoras', 'Fecha', 'Name', 'LoginCanonico', 'IdNumerico', 'IdNumericoNormalizado', 'HR Task', 'HorasSinVolumen']);
  const hv = buildHeaderIndex(VM, ['Fecha', 'LoginCanonico', 'IdNumericoNormalizado', 'WMS_TASK', 'SAP_CODE', 'CUSTOMER', 'VolumenPositivo', 'TasksSPEC', 'EstadoMapeoFinal', 'WMS_DCs', 'ArchivoOrigen', 'FilaOrigen']);
  const hc = buildHeaderIndex(C, ['IdRegistroHoras', 'Fecha', 'LoginCanonico', 'NumeroHRTaskDistintas', 'HRTaskDistintas', 'EsAmbiguoIdNumerico', 'LoginsMismoNumero']);

  // Pre-indexar 13_VolumenMapeadoSPEC
  const dRowsExacto = new Map(); // clave: fecha_long|login → [filas]
  const dRowsIdNum = new Map();
  for (let fv = 0; fv < VM.length; fv++) {
    const row = VM[fv];
    const fechaV = row['Fecha'];
    if (!(fechaV instanceof Date) || isNaN(fechaV)) continue;
    const fechaLong = fechaV.getTime();
    const loginV = (row['LoginCanonico'] || '').toString().toUpperCase().trim();
    const idnumV = (row['IdNumericoNormalizado'] || '').toString().toUpperCase().trim();
    if (loginV.length > 0) {
      const key = fechaLong + '|' + loginV;
      if (!dRowsExacto.has(key)) dRowsExacto.set(key, []);
      dRowsExacto.get(key).push(fv);
    }
    if (idnumV.length > 0) {
      const key = fechaLong + '|' + idnumV;
      if (!dRowsIdNum.has(key)) dRowsIdNum.set(key, []);
      dRowsIdNum.get(key).push(fv);
    }
  }

  // Pre-indexar 07_Conciliacion por IdRegistroHoras
  const concMap = new Map();
  for (let i = 0; i < C.length; i++) {
    const id = C[i]['IdRegistroHoras'];
    if (id != null) concMap.set(id, i);
  }

  const out = [];

  for (let fh = 0; fh < H.length; fh++) {
    const rowH = H[fh];
    const fechaV = rowH['Fecha'];
    if (!(fechaV instanceof Date) || isNaN(fechaV)) continue;
    const fechaLong = fechaV.getTime();
    const fecha = fechaV;
    const loginH = (rowH['LoginCanonico'] || '').toString().toUpperCase().trim();
    const idH = (rowH['IdNumericoNormalizado'] || '').toString().toUpperCase().trim();
    const hrTask = (rowH['HR Task'] || '').toString().trim();
    const idRegH = rowH['IdRegistroHoras'];

    // Buscar fila en 07_Conciliacion
    let es_multi_hr_task = false;
    let es_ambiguo_idnum_conc = false;
    let filaConc = -1;
    if (concMap.has(idRegH)) {
      filaConc = concMap.get(idRegH);
      const conc = C[filaConc];
      es_multi_hr_task = (conc['NumeroHRTaskDistintas'] > 1);
      es_ambiguo_idnum_conc = (conc['EsAmbiguoIdNumerico'] === true);
    }

    const dFilas = [];
    let encontrados = 0;
    let modo = 'LOGIN EXACTO';

    // Pass 1
    if (loginH.length > 0) {
      const key = fechaLong + '|' + loginH;
      if (dRowsExacto.has(key)) {
        const idxs = dRowsExacto.get(key);
        for (const idx of idxs) {
          const r = VM[idx];
          const vol = Number(r['VolumenPositivo']) || 0;
          if (vol <= 0) continue;
          dFilas.push({
            ts: r['TasksSPEC'] || '',
            vol: vol,
            wms: r['WMS_TASK'] || '',
            sap: r['SAP_CODE'] || '',
            cust: r['CUSTOMER'] || '',
            dc: r['WMS_DCs'] || '',
            arch: r['ArchivoOrigen'] || '',
            fila: String(r['FilaOrigen'] != null ? r['FilaOrigen'] : ''),
            loginV: r['LoginCanonico'] || '',
            estado: r['EstadoMapeoFinal'] || ''
          });
          encontrados++;
        }
      }
    }

    // Pass 2
    if (encontrados === 0 && idH.length > 0) {
      modo = 'MISMO NUMERO, DISTINTO PREFIJO';
      const key = fechaLong + '|' + idH;
      if (dRowsIdNum.has(key)) {
        const idxs = dRowsIdNum.get(key);
        for (const idx of idxs) {
          const r = VM[idx];
          const vol = Number(r['VolumenPositivo']) || 0;
          if (vol <= 0) continue;
          dFilas.push({
            ts: r['TasksSPEC'] || '',
            vol: vol,
            wms: r['WMS_TASK'] || '',
            sap: r['SAP_CODE'] || '',
            cust: r['CUSTOMER'] || '',
            dc: r['WMS_DCs'] || '',
            arch: r['ArchivoOrigen'] || '',
            fila: String(r['FilaOrigen'] != null ? r['FilaOrigen'] : ''),
            loginV: r['LoginCanonico'] || '',
            estado: r['EstadoMapeoFinal'] || ''
          });
          encontrados++;
        }
      }
      if (es_ambiguo_idnum_conc) {
        modo = 'REVISION MANUAL - AMBIGUEDAD ID NUMERICO';
      }
    }

    if (es_multi_hr_task) {
      modo = 'REVISION MANUAL - MULTIPLES HR TASK';
    }

    if (encontrados === 0) {
      let requiere = 'REVISAR';
      let obs = 'No existe volumen positivo por fecha y login ni por fecha y numero.';
      if (es_multi_hr_task) {
        const hrTasksStr = filaConc >= 0 ? (C[filaConc]['HRTaskDistintas'] || '').trim() : '(desconocidas)';
        obs += ' Ademas, la persona ficho varias HR Task el mismo dia (' + hrTasksStr + '): revision manual necesaria.';
      }
      if (es_ambiguo_idnum_conc) {
        const loginsStr = filaConc >= 0 ? (C[filaConc]['LoginsMismoNumero'] || '').trim() : '(desconocidos)';
        obs += ' Ademas, existe ambiguedad de IdNumerico (' + loginsStr + ').';
      }
      out.push(crearPropuesta('4. SIN VOLUMEN', rowH, '', 0, '', modo, '', '', '', '', '', '', requiere, obs));
    } else {
      // H-05 FIX: contar TasksSPEC distintas (no filas)
      // H-05b FIX: excluir TasksSPEC con " | " del conteo de únicas
      const dTsUnicas = {};
      for (const item of dFilas) {
        const ts = item.ts;
        if (ts.length > 0 && ts.indexOf(' | ') < 0) {
          dTsUnicas[ts] = true;
        }
      }
      const nTasksSpecDistintas = Object.keys(dTsUnicas).length;

      for (const item of dFilas) {
        let sec, obs, requiere;
        if (item.estado !== 'UNICO' || item.ts.length === 0 || item.ts.indexOf(' | ') >= 0) {
          sec = '5. WMS TASK SIN MAPPING';
          obs = 'Existe volumen, pero no hay una TASKSPEC unica documentada.';
          requiere = 'REVISAR';
        } else if (es_multi_hr_task) {
          sec = '6. REVISION MANUAL - MULTIPLES HR TASK';
          obs = 'La persona tiene multiples HR Task el mismo dia. No se puede determinar automaticamente cual HR Task debe modificarse.';
          requiere = 'REVISAR';
        } else if (es_ambiguo_idnum_conc && modo === 'REVISION MANUAL - AMBIGUEDAD ID NUMERICO') {
          sec = '7. REVISION MANUAL - AMBIGUEDAD ID NUMERICO';
          obs = 'Multiples logins candidatos con el mismo IdNumerico normalizado.';
          requiere = 'REVISAR';
        } else if (nTasksSpecDistintas > 1) {
          sec = '2. VARIAS TASKSPEC CON VOLUMEN';
          obs = 'Se muestran todas las TASKSPEC diferentes con sus volumenes. No se reparte el tiempo automaticamente.';
          requiere = 'REVISAR';
        } else if (hrTask.toUpperCase().trim() === item.ts.toUpperCase().trim()) {
          sec = '3. HR TASK CORRECTA';
          obs = 'La HR Task fichada coincide con la TASKSPEC del Mapping.';
          requiere = 'NO';
        } else {
          sec = '1. CAMBIO HR TASK PROPUESTO';
          obs = 'La TASKSPEC procede del Mapping de las WMS Task cuantificadas.';
          requiere = 'SI';
        }
        if (modo === 'MISMO NUMERO, DISTINTO PREFIJO') {
          obs += ' El volumen se ha asociado por coincidencia del numero de usuario.';
        }
        out.push(crearPropuesta(sec, rowH, item.ts, item.vol, item.wms, modo, item.loginV, item.sap, item.cust, item.dc, item.arch, item.fila, requiere, obs));
      }
    }
  }

  return out;
}

function crearPropuesta(seccion, rowH, ts, vol, wms, modo, loginV, sap, cust, dc, arch, filaOr, requiere, obs) {
  return {
    'SECCION': seccion,
    'ID REGISTRO': rowH['IdRegistroHoras'],
    'FECHA': rowH['Fecha'],
    'PERSONA': rowH['Name'],
    'LOGIN HORAS': rowH['LoginCanonico'],
    'HORAS SIN VOLUMEN': rowH['HorasSinVolumen'],
    'MATERIALIDAD': calcularMaterialidad(rowH['HorasSinVolumen']),
    'HR TASK FICHADA': rowH['HR Task'],
    'TASKSPEC SEGUN MAPPING': ts,
    'VOLUMEN POSITIVO': vol,
    'WMS TASK CON VOLUMEN': wms,
    'TIPO COINCIDENCIA': modo,
    'LOGIN UTILIZADO EN VOLUMEN': loginV,
    'SAP_CODE': sap,
    'CUSTOMER': cust,
    'WMS_DC': dc,
    'ARCHIVO ORIGEN': arch,
    'FILA ORIGEN': filaOr,
    'REQUIERE CAMBIO RRHH': requiere,
    'OBSERVACION': obs
  };
}

function buildHeaderIndex(rows, cols) {
  // rows ya son objetos con claves; solo validamos que existan
  if (rows.length === 0) return {};
  const first = rows[0];
  const missing = cols.filter(c => !(c in first));
  if (missing.length > 0) throw new Error('Faltan columnas: ' + missing.join(', '));
  return cols.reduce((acc, c) => { acc[c] = c; return acc; }, {});
}

/* ============================================================================
 * v6.1 — MEJORA 4: CLASIFICACIÓN CENTRALIZADA DE ACTIVIDADES
 *
 * Campo único ACTIVIDAD_ANALISIS con valores:
 *   AUDITORIA AGV | AUDITORIA MANUAL | UBICACION AGV | UBICACION MANUAL |
 *   PICKING AGV | PICKING MANUAL | OTRA
 *
 * Reglas (normalización: mayúsculas, sin \r\n, espacios colapsados):
 *   1. REPARTO POR CUADRANTE AGV* / REPARTO POR SUPERCUADRANTE AGV* → PICKING AGV
 *      (regla explícita del usuario)
 *   2. PICKING ECOMMERCE A MATRÍCULA* / PICKING POR CUADRANTE GUIADO* /
 *      PICKING SIN PAPEL* → PICKING MANUAL (regla explícita del usuario)
 *   3. UBICACIÓN* → UBICACIÓN; AGV si contiene "AGV" o "AUTOMATIZADA",
 *      manual en caso contrario (regla "Tipo movimiento comienza por
 *      Ubicación" del usuario + reglas AGV del proyecto)
 *   4. AUDITORÍA* → AUDITORÍA; AGV si contiene "AGV", manual en caso contrario
 *   5. PICKING LIBRE* → PICKING MANUAL (misma TASK_SPEC 20051 que las tres
 *      explícitas del usuario; decisión documentada)
 *   6. Todo lo demás → OTRA (NO se inventa productividad ni asignación).
 *      Incluye las tareas ambiguas del mapping (ver reports/MAPPING_AMBIGUITIES.md):
 *      REPARTO A TIENDA AGV* (2 TASK_SPEC posibles), PICKING POR TIENDA GUIADO*
 *      (20062, picking de transferencias), PICKING DE DEVOLUCIÓN DE
 *      LOCALIZACIÓN*, TRASPASOS AGV*, etc.
 *
 * taskOverrides: mapa opcional { [tareaNormalizada]: {actividad, productividad} }
 * que permite al usuario reasignar actividades y productividades por tarea
 * desde la UI (resolución de ambigüedades por decisión explícita del usuario).
 * ========================================================================== */
const ACTIVIDADES_ANALISIS = ['AUDITORIA AGV', 'AUDITORIA MANUAL', 'UBICACION AGV', 'UBICACION MANUAL', 'PICKING AGV', 'PICKING MANUAL', 'OTRA'];

/* Normaliza un nombre de tarea WMS para comparación robusta
 * (mayúsculas, sin saltos de línea, sin espacios múltiples). */
function normalizarTareaWms(t) {
  if (t == null) return '';
  return String(t)
    .replace(/[\x00-\x1F\x7F]/g, ' ')
    .replace(/\u00A0/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .toUpperCase()
    .replace(/[ÁÀ]/g, 'A').replace(/[ÉÈ]/g, 'E').replace(/[ÍÌ]/g, 'I')
    .replace(/[ÓÒ]/g, 'O').replace(/[ÚÙ]/g, 'U');
}

function fx_ActividadAnalisis(taskWms, taskOverrides) {
  const t = normalizarTareaWms(taskWms);
  if (!t) return 'OTRA';
  // Override explícito del usuario (resolución de ambigüedades)
  if (taskOverrides && Object.prototype.hasOwnProperty.call(taskOverrides, t)) {
    const o = taskOverrides[t];
    if (o && ACTIVIDADES_ANALISIS.indexOf(o.actividad) >= 0) return o.actividad;
  }
  // 1. PICKING AGV — reglas explícitas del usuario
  if (t.startsWith('REPARTO POR CUADRANTE AGV') || t.startsWith('REPARTO POR SUPERCUADRANTE AGV')) return 'PICKING AGV';
  // 2. PICKING MANUAL — reglas explícitas del usuario
  if (t.startsWith('PICKING ECOMMERCE A MATRICULA') ||
      t.startsWith('PICKING POR CUADRANTE GUIADO') ||
      t.startsWith('PICKING SIN PAPEL')) return 'PICKING MANUAL';
  // 3. UBICACIÓN — Tipo movimiento que comienza por "Ubicación"
  if (t.startsWith('UBICACION')) {
    return (t.indexOf('AGV') >= 0 || t.indexOf('AUTOMATIZADA') >= 0) ? 'UBICACION AGV' : 'UBICACION MANUAL';
  }
  // 4. AUDITORÍA
  if (t.startsWith('AUDITORIA')) {
    return t.indexOf('AGV') >= 0 ? 'AUDITORIA AGV' : 'AUDITORIA MANUAL';
  }
  // 5. PICKING LIBRE — misma TASK_SPEC que las picking manuales explícitas
  if (t.startsWith('PICKING LIBRE')) return 'PICKING MANUAL';
  // 6. Todo lo demás → OTRA (sin productividad inventada)
  return 'OTRA';
}

/* Resuelve la productividad de referencia de una actividad.
 * Orden: overrides por tarea → productividades del usuario → default PARAMS.
 * OTRA nunca recibe productividad (null).
 * NOTA v6.1.1: esta función resuelve a nivel de ACTIVIDAD. Para el reparto
 * real por TAREA usar resolverClasificacionTarea() (prioridad completa). */
function resolverProductividad(actividad, tareaNormalizada, opciones) {
  if (actividad === 'OTRA') return null;
  const o = opciones || {};
  if (tareaNormalizada && o.taskOverrides && Object.prototype.hasOwnProperty.call(o.taskOverrides, tareaNormalizada)) {
    const ov = o.taskOverrides[tareaNormalizada];
    if (ov && isFinite(ov.productividad) && Number(ov.productividad) > 0) return Number(ov.productividad);
  }
  const fuente = o.productividades || PARAMS.ProductividadesReferencia;
  const v = fuente[actividad];
  return (v != null && isFinite(v) && Number(v) > 0) ? Number(v) : null;
}

/* resolverClasificacionTarea — v6.1.1 — RESOLUCIÓN COMPLETA POR TASK_WMS.
 *
 * Devuelve { actividad, productividad, fuente } para UNA tarea concreta con
 * la prioridad EXACTA exigida por el usuario:
 *   1. Override específico de TASK_WMS (actividad Y productividad)
 *   2. Productividad de su ACTIVIDAD_ANALISIS (editada por el usuario)
 *   3. Default PARAMS.ProductividadesReferencia
 * NUNCA se usa la productividad de OTRO TASK_WMS.
 *
 * fuente (columna «Fuente» del editor de productividades):
 *   'OVERRIDE TASK_WMS'      — productividad del override de esta tarea
 *   'PRODUCTIVIDAD ACTIVIDAD' — productividad de actividad personalizada
 *   'DEFAULT'                — valor por defecto de PARAMS
 *   'OTRA'                   — tarea OTRA sin productividad (no inventada)
 *   'SIN PRODUCTIVIDAD'      — actividad productiva sin valor válido (anomalía)
 *
 * Una tarea OTRA puede reasignarse vía override a cualquier actividad
 * productiva (se exigirá productividad > 0 al guardar desde la UI). */
function resolverClasificacionTarea(taskWms, opciones) {
  const o = opciones || {};
  const t = normalizarTareaWms(taskWms);
  const ovr = (o.taskOverrides && Object.prototype.hasOwnProperty.call(o.taskOverrides, t))
    ? o.taskOverrides[t] : null;
  // Actividad: override válido → su actividad; si no, reglas explícitas
  const actividad = (ovr && ovr.actividad && ACTIVIDADES_ANALISIS.indexOf(ovr.actividad) >= 0)
    ? ovr.actividad
    : fx_ActividadAnalisis(taskWms, o.taskOverrides);
  if (actividad === 'OTRA') {
    return { actividad: 'OTRA', productividad: null, fuente: 'OTRA' };
  }
  // 1. Override específico de la tarea
  if (ovr && isFinite(ovr.productividad) && Number(ovr.productividad) > 0) {
    return { actividad, productividad: Number(ovr.productividad), fuente: 'OVERRIDE TASK_WMS' };
  }
  // 2/3. Productividad de la actividad (usuario) o default
  const prods = o.productividades || PARAMS.ProductividadesReferencia;
  const defaults = o.productividadesDefault || PARAMS.ProductividadesReferencia;
  const v = prods[actividad];
  if (v != null && isFinite(v) && Number(v) > 0) {
    const esDefault = defaults[actividad] != null && Number(defaults[actividad]) === Number(v);
    return { actividad, productividad: Number(v), fuente: esDefault ? 'DEFAULT' : 'PRODUCTIVIDAD ACTIVIDAD' };
  }
  return { actividad, productividad: null, fuente: 'SIN PRODUCTIVIDAD' };
}

/* ============================================================================
 * v6.1 — MEJORA 4: REPARTO DE TIEMPOS (modelo matemático)
 *
 * HORAS_EQUIVALENTES = UDS / PRODUCTIVIDAD_MEDIA   (estimación productiva)
 * PESO_ACTIVIDAD     = HE_ACTIVIDAD / SUMA_HE_PERSONA_DIA
 * TIEMPO_ASIGNADO    = TIEMPO_ANALIZABLE_PERSONA_DIA × PESO_ACTIVIDAD
 *
 * Conservación: SUM(TIEMPO_ASIGNADO) = TIEMPO_ANALIZABLE (precisión completa
 * durante el cálculo; el redondeo es SOLO de presentación).
 * Las actividades OTRA no participan en el reparto (quedan fuera del cálculo
 * de pesos). Si no hay actividades clasificables, no se reparte nada.
 * ========================================================================== */
function repartirTiempos(tiempoAnalizable, actividades) {
  // actividades: [{actividad, uds, productividad, ...}] — se mutan añadiendo
  // horasEquivalentes, peso, horasAsignadas, productividadImplicita.
  const clasificables = actividades.filter(a => a.actividad !== 'OTRA' && a.productividad != null && a.productividad > 0);
  let sumaHE = 0;
  for (const a of clasificables) {
    a.horasEquivalentes = (a.uds || 0) / a.productividad;
    sumaHE += a.horasEquivalentes;
  }
  if (sumaHE > 0) {
    for (const a of clasificables) {
      a.peso = a.horasEquivalentes / sumaHE; // fracción exacta
      a.horasAsignadas = tiempoAnalizable * a.peso;
    }
  }
  for (const a of actividades) {
    if (a.horasAsignadas == null) { a.horasAsignadas = 0; a.peso = clasificables.length === 0 ? null : 0; }
    if (a.horasEquivalentes == null) a.horasEquivalentes = null;
    a.productividadImplicita = (a.horasAsignadas > 0 && a.uds > 0) ? a.uds / a.horasAsignadas : null;
  }
  return {
    sumaHorasEquivalentes: sumaHE,
    sumaHorasAsignadas: clasificables.reduce((s, a) => s + a.horasAsignadas, 0),
    nClasificables: clasificables.length
  };
}

/* repartirTiemposPorTarea — v6.1.1 — MODELO CORRECTO POR TASK_WMS.
 *
 * El cálculo del reparto se realiza a nivel de TAREA (no de actividad) para
 * que dos tareas de la misma actividad con productividades distintas NO
 * compartan una única productividad:
 *
 *   HORAS_EQUIVALENTES_TAREA = UDS_TAREA / PRODUCTIVIDAD_TAREA
 *   PESO_TAREA               = HE_TAREA / SUMA_HE_PERSONA_DIA
 *   HORAS_ASIGNADAS_TAREA    = HORAS_ANALIZABLES × PESO_TAREA
 *
 * Conservación exacta: SUM(HORAS_ASIGNADAS_TAREA) = HORAS_ANALIZABLES con
 * tolerancia < 1e-9 (fracciones exactas, sin redondeo intermedio). Las
 * tareas OTRA (o sin productividad válida) quedan fuera del reparto.
 *
 * tareas: [{taskWms, actividad, uds, productividad, fuente}] — se mutan
 * añadiendo horasEquivalentes, peso, horasAsignadas, productividadImplicita. */
function repartirTiemposPorTarea(tiempoAnalizable, tareas) {
  const clasificables = tareas.filter(t =>
    t.actividad !== 'OTRA' && t.productividad != null && t.productividad > 0);
  let sumaHE = 0;
  for (const t of clasificables) {
    t.horasEquivalentes = (t.uds || 0) / t.productividad;
    sumaHE += t.horasEquivalentes;
  }
  if (sumaHE > 0) {
    for (const t of clasificables) {
      t.peso = t.horasEquivalentes / sumaHE; // fracción exacta
      t.horasAsignadas = tiempoAnalizable * t.peso;
    }
  }
  for (const t of tareas) {
    if (t.horasAsignadas == null) { t.horasAsignadas = 0; t.peso = clasificables.length === 0 ? null : 0; }
    if (t.horasEquivalentes == null) t.horasEquivalentes = null;
    t.productividadImplicita = (t.horasAsignadas > 0 && t.uds > 0) ? t.uds / t.horasAsignadas : null;
  }
  return {
    sumaHorasEquivalentes: sumaHE,
    sumaHorasAsignadas: clasificables.reduce((s, t) => s + t.horasAsignadas, 0),
    nClasificables: clasificables.length
  };
}

/* Semana ISO 8601 (YYYY-Www) de una fecha UTC day-level. */
function isoSemana(d) {
  const date = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  const dayNum = date.getUTCDay() || 7; // domingo=7
  date.setUTCDate(date.getUTCDate() + 4 - dayNum); // jueves de la semana ISO
  const yearStart = Date.UTC(date.getUTCFullYear(), 0, 1);
  const week = Math.ceil((((date.getTime() - yearStart) / 86400000) + 1) / 7);
  return date.getUTCFullYear() + '-W' + String(week).padStart(2, '0');
}

/* Mes (YYYY-MM) de una fecha UTC day-level. */
function isoMes(d) {
  return d.getUTCFullYear() + '-' + String(d.getUTCMonth() + 1).padStart(2, '0');
}

/* ============================================================================
 * v6.1 — MEJORA 4: q17_PersonaDiaAnalitica
 *
 * Nueva unidad de análisis: PERSONA + FECHA_OPERATIVA (no PERSONA + TASK_WMS).
 * Agrupa los registros de horas por (LoginCanonico, FECHA_OPERATIVA) y agrega
 * el volumen WMS del día por ACTIVIDAD_ANALISIS, aplicando el reparto de
 * tiempos sobre TIEMPO_ANALIZABLE con las horas productivas equivalentes
 * como ponderación.
 *
 * Entradas (todas salidas EXISTENTES del motor — no se modifican, preservando
 * la equivalencia con SPEC V0.47.3):
 *   H   = 01_HorasSinVolumen
 *   VM  = 13_VolumenMapeadoSPEC
 *   VSH = 09_VolumenSinHorasDetalle (solo informativo: udsSinHoras)
 *
 * opciones = { productividades: {ACT: uds/h}, taskOverrides: {TAREA: {actividad, productividad}} }
 *
 * La búsqueda de volumen replica la lógica de generarReporteCambiosHR:
 * Pass 1 LOGIN EXACTO (fecha operativa + login canónico), Pass 2 MISMO
 * NUMERO DISTINTO PREFIJO (fecha operativa + IdNumericoNormalizado).
 * ========================================================================== */
function q17_PersonaDiaAnalitica(H, VM, VSH, opciones) {
  const o = opciones || {};
  // --- Índices de VM por (fechaLong, login) y (fechaLong, idNum) ---
  const vmExacto = new Map();
  const vmIdNum = new Map();
  for (let i = 0; i < VM.length; i++) {
    const r = VM[i];
    const f = r['Fecha'];
    if (!(f instanceof Date) || isNaN(f)) continue;
    const fl = f.getTime();
    const login = (r['LoginCanonico'] || '').toString().toUpperCase().trim();
    const idnum = (r['IdNumericoNormalizado'] || '').toString().toUpperCase().trim();
    if (login) {
      const k = fl + '|' + login;
      if (!vmExacto.has(k)) vmExacto.set(k, []);
      vmExacto.get(k).push(r);
    }
    if (idnum) {
      const k = fl + '|' + idnum;
      if (!vmIdNum.has(k)) vmIdNum.set(k, []);
      vmIdNum.get(k).push(r);
    }
  }
  // --- Índice de VSH por (fechaLong, login) para udsSinHoras ---
  const vshExacto = new Map();
  for (const r of VSH) {
    const f = r['Fecha'];
    if (!(f instanceof Date) || isNaN(f)) continue;
    const login = (r['LoginCanonico'] || '').toString().toUpperCase().trim();
    if (!login) continue;
    const k = f.getTime() + '|' + login;
    if (!vshExacto.has(k)) vshExacto.set(k, []);
    vshExacto.get(k).push(r);
  }

  // --- Agrupar H por (LoginCanonico, FECHA_OPERATIVA) ---
  const grupos = new Map(); // key → grupo
  for (const rowH of H) {
    const fechaCal = rowH['Fecha']; // Date day-level (fx_Fecha)
    if (!(fechaCal instanceof Date) || isNaN(fechaCal)) continue;
    const login = (rowH['LoginCanonico'] || '').toString().toUpperCase().trim();
    if (!login) continue;
    const hora = extraerHoraFichaje(rowH['FechaOriginal']);
    const turno = hora == null ? 'SIN HORA' : fx_Turno(hora);
    const fechaOp = fx_FechaOperativaTurno(fechaCal, hora);
    const key = login + '|' + formatFechaISO(fechaOp);
    let g = grupos.get(key);
    if (!g) {
      g = {
        key,
        login,
        persona: rowH['Name'] || '',
        fechaOperativa: fechaOp,
        turnos: new Set(),
        horasFichadas: 0,
        horasAnalizables: 0,
        udsSinHoras: 0,
        registros: [],   // {idRegistroHoras, hora, turno, horas, hrTask}
        actividades: [],
        modoVolumen: null
      };
      grupos.set(key, g);
    }
    g.turnos.add(turno);
    const hs = Number(rowH['HorasSinVolumen']) || 0;
    g.horasFichadas += hs;
    g.horasAnalizables += hs;
    g.registros.push({
      idRegistroHoras: rowH['IdRegistroHoras'],
      hora: hora,
      turno: turno,
      horas: hs,
      hrTask: rowH['HR Task'] || ''
    });
    if (!g.persona && rowH['Name']) g.persona = rowH['Name'];
  }

  // --- VSH por persona/día (informativo) ---
  for (const g of grupos.values()) {
    const vshRows = vshExacto.get(g.fechaOperativa.getTime() + '|' + g.login) || [];
    g.udsSinHoras = vshRows.reduce((s, r) => s + (Number(r['VolumenSinHoras']) || 0), 0);
  }

  // --- Volumen por persona/día → actividades ---
  for (const g of grupos.values()) {
    const flOp = g.fechaOperativa.getTime();
    let volRows = (vmExacto.get(flOp + '|' + g.login) || []).filter(r => (Number(r['VolumenPositivo']) || 0) > 0);
    if (volRows.length > 0) {
      g.modoVolumen = 'LOGIN EXACTO';
    } else {
      // IdNumerico del login del grupo: derivarlo del propio login canónico
      // (mismo criterio que fx_NormalizaLogin: parte numérica)
      const m = g.login.match(/(\d+)/);
      const idnumGrupo = m ? m[1] : '';
      if (idnumGrupo) {
        volRows = (vmIdNum.get(flOp + '|' + idnumGrupo) || []).filter(r => (Number(r['VolumenPositivo']) || 0) > 0);
        if (volRows.length > 0) g.modoVolumen = 'MISMO NUMERO, DISTINTO PREFIJO';
      }
    }
    // v6.1.1 — Agregar volumen por TASK_WMS (NO por actividad): cada tarea
    // resuelve SU clasificación y SU productividad con prioridad
    // override tarea → productividad actividad → default. Así dos tareas de
    // la misma actividad con productividades distintas NO se mezclan.
    // v6.2 — Se conservan además TASK_SPEC (del mapping) y CUSTOMER por tarea
    // (dimensiones de análisis del módulo Patrones; aditivo, no altera el
    // reparto ni el dataFingerprint).
    const taskMap = new Map(); // tareaNormalizada → {taskWms, uds, tasksSpec, cliente}
    for (const r of volRows) {
      const tarea = String(r['WMS_TASK'] || '').trim();
      const tareaNorm = normalizarTareaWms(tarea);
      let tk = taskMap.get(tareaNorm);
      if (!tk) {
        tk = { taskWms: tarea || '(sin tarea)', uds: 0, tasksSpec: '', cliente: '' };
        taskMap.set(tareaNorm, tk);
      }
      tk.uds += Number(r['VolumenPositivo']) || 0;
      if (!tk.tasksSpec && r['TasksSPEC']) tk.tasksSpec = String(r['TasksSPEC']);
      if (!tk.cliente && r['CUSTOMER']) tk.cliente = String(r['CUSTOMER']);
    }
    const tareasDia = [];
    for (const tk of taskMap.values()) {
      const cls = resolverClasificacionTarea(tk.taskWms, o);
      tareasDia.push({
        taskWms: tk.taskWms,
        actividad: cls.actividad,
        uds: tk.uds,
        productividad: cls.productividad,
        fuente: cls.fuente,
        tasksSpec: tk.tasksSpec || '',   // v6.2: TASK_SPEC del mapping
        cliente: tk.cliente || ''         // v6.2: CUSTOMER del volumen
      });
    }
    // Reparto de tiempos a nivel de TAREA sobre TIEMPO_ANALIZABLE
    const rep = repartirTiemposPorTarea(g.horasAnalizables, tareasDia);
    // Agregación VISUAL por ACTIVIDAD_ANALISIS (sumando sus tareas)
    const actMap = new Map();
    for (const t of tareasDia) {
      let a = actMap.get(t.actividad);
      if (!a) {
        a = { actividad: t.actividad, uds: 0, horasEquivalentes: 0, horasAsignadas: 0, peso: 0, tareas: [] };
        actMap.set(t.actividad, a);
      }
      a.uds += t.uds;
      a.horasEquivalentes += (t.horasEquivalentes || 0);
      a.horasAsignadas += (t.horasAsignadas || 0);
      a.peso += (t.peso || 0);
      a.tareas.push(t);
    }
    g.actividades = Array.from(actMap.values()).map(a => {
      const prods = Array.from(new Set(a.tareas.filter(t => t.productividad != null).map(t => t.productividad)));
      return {
        actividad: a.actividad,
        uds: a.uds,
        tareasWms: a.tareas.map(t => t.taskWms).sort(), // compatibilidad display
        tareas: a.tareas,                                 // detalle por tarea (v6.1.1)
        productividad: prods.length === 1 ? prods[0] : null, // común; null = varias
        horasEquivalentes: a.horasEquivalentes,
        peso: a.peso,
        horasAsignadas: a.horasAsignadas,
        productividadImplicita: (a.horasAsignadas > 0 && a.uds > 0) ? a.uds / a.horasAsignadas : null
      };
    });
    // Orden estable: clasificables primero, OTRA al final, luego por uds desc
    g.actividades.sort((x, y) => {
      const ox = x.actividad === 'OTRA' ? 1 : 0, oy = y.actividad === 'OTRA' ? 1 : 0;
      if (ox !== oy) return ox - oy;
      return y.uds - x.uds;
    });
    g.sumaHorasEquivalentes = rep.sumaHorasEquivalentes;
    g.sumaHorasAsignadas = rep.sumaHorasAsignadas;
    g.udsTotales = g.actividades.reduce((s, a) => s + a.uds, 0);
    g.desviacion = g.horasAnalizables - rep.sumaHorasEquivalentes;
    // Turno agregado del día
    const ts = Array.from(g.turnos).filter(t => t !== 'SIN HORA');
    g.turno = g.turnos.has('SIN HORA') && ts.length === 0 ? 'SIN HORA'
      : (ts.length > 1 ? 'MIXTO' : ts[0]);
  }

  return Array.from(grupos.values());
}

/* FNV-1a 32-bit sobre un string — determinista y rápido (misma familia que
 * calcularMappingHash, pero sobre el string completo en vez de campos de
 * objeto). Usado por el dataFingerprint de los PERSON_DAILY_RECORD. */
function fnv1aStr(str) {
  let hash = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash = (hash + ((hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24))) >>> 0;
  }
  return hash.toString(16).padStart(8, '0');
}

/* ============================================================================
 * v6.1 — MEJORA 6: PERSON_DAILY_RECORD
 *
 * Construye los registros diarios históricos a partir de los grupos de q17 y
 * del REPORTE_CAMBIOS_HR (incidencias vinculadas por ID REGISTRO).
 * La clave estable es login + '|' + fechaOperativaISO → reprocesar el mismo
 * persona/día NO duplica históricos (upsert en IndexedDB por clave).
 * Si los datos cambian, se crea una nueva versión dejando trazabilidad
 * (previousVersions, ver ui.js persistencia).
 *
 * Cada registro conserva el mappingHash/productividades usados: los
 * históricos NO cambian aunque posteriormente cambie el mapping.
 * ========================================================================== */
function generarPersonDailyRecords(grupos, reporte, meta) {
  const m = meta || {};
  const idRegToGrupo = new Map();
  for (const g of grupos) {
    for (const r of g.registros) idRegToGrupo.set(String(r.idRegistroHoras), g.key);
  }
  // Vincular incidencias del reporte a cada grupo
  const incidenciasPorGrupo = new Map();
  for (const inc of (reporte || [])) {
    const gk = idRegToGrupo.get(String(inc['ID REGISTRO']));
    if (!gk) continue;
    if (!incidenciasPorGrupo.has(gk)) incidenciasPorGrupo.set(gk, []);
    incidenciasPorGrupo.get(gk).push({
      id: (inc['ID REGISTRO'] || '?') + '@' + (inc['FILA ORIGEN'] || ''),
      seccion: inc['SECCION'] || '',
      horasAfectadas: Number(inc['HORAS SIN VOLUMEN']) || 0,
      requiereCambio: inc['REQUIERE CAMBIO RRHH'] || '',
      tareaOriginal: inc['HR TASK FICHADA'] || '',
      propuesta: inc['TASKSPEC SEGUN MAPPING'] || '',
      // v6.2 — campos para el módulo de analítica (aditivos):
      wmsTask: inc['WMS TASK CON VOLUMEN'] || '',
      volumen: Number(inc['VOLUMEN POSITIVO']) || 0,
      tipoCoincidencia: inc['TIPO COINCIDENCIA'] || '',
      cliente: inc['CUSTOMER'] || '',
      sapCode: inc['SAP_CODE'] || '',
      decision: null // se rellena desde STATE.decisions en la UI
    });
  }

  const records = [];
  for (const g of grupos) {
    const incs = incidenciasPorGrupo.get(g.key) || [];
    // horasConIncidencia: cada registro de horas cuenta UNA sola vez aunque
    // genere varias propuestas (sección 2 muestra la misma fila N veces).
    const horasPorIdReg = new Map();
    for (const i of incs) {
      const idReg = String(i.id).split('@')[0];
      if (!horasPorIdReg.has(idReg)) horasPorIdReg.set(idReg, 0);
      horasPorIdReg.set(idReg, Math.max(horasPorIdReg.get(idReg), i.horasAfectadas || 0));
    }
    let horasConIncidencia = 0;
    for (const h of horasPorIdReg.values()) horasConIncidencia += h;
    records.push({
      // Clave estable de identidad
      key: g.key,
      login: g.login,
      persona: g.persona,
      fechaOperativa: g.fechaOperativa,
      fechaOperativaISO: formatFechaISO(g.fechaOperativa),
      semana: isoSemana(g.fechaOperativa),
      mes: isoMes(g.fechaOperativa),
      turno: g.turno,
      turnos: Array.from(g.turnos).sort(),
      // Tiempo
      horasFichadas: g.horasFichadas,
      horasAnalizables: g.horasAnalizables,
      // Fichajes del día (v6.1.1): hora + turno por registro para el
      // detalle y el aviso «Este registro no contiene hora de fichaje.»
      registros: (g.registros || []).map(rg => ({
        idRegistroHoras: rg.idRegistroHoras,
        hora: rg.hora,
        turno: rg.turno,
        horas: rg.horas,
        hrTask: rg.hrTask
      })),
      // Volumen y reparto
      udsTotales: g.udsTotales,
      udsSinHoras: g.udsSinHoras,
      horasEquivalentes: g.sumaHorasEquivalentes,
      horasAsignadas: g.sumaHorasAsignadas,
      desviacion: g.desviacion,
      nActividades: g.actividades.length,
      actividades: g.actividades,
      modoVolumen: g.modoVolumen,
      // Incidencias
      incidencias: incs,
      nIncidencias: incs.length,
      horasConIncidencia,
      decision: incs.length === 0 ? 'SIN INCIDENCIAS' : 'PENDIENTE',
      // Trazabilidad
      mappingHash: m.mappingHash || null,
      mappingVersion: m.mappingVersion != null ? m.mappingVersion : null,
      productividades: m.productividades || null,
      taskOverrides: m.taskOverrides || null,
      // v6.2 — versionado analítico (hashes deterministas de la configuración
      // con la que se calculó el registro; no alteran el dataFingerprint)
      productivityVersion: m.productividades ? fnv1aStr(JSON.stringify(m.productividades)) : null,
      overrideVersion: m.taskOverrides ? fnv1aStr(JSON.stringify(m.taskOverrides)) : null,
      appVersion: m.appVersion || PARAMS.AppVersion,
      sessionId: m.sessionId || null,
      // Versionado (gestión en persistencia UI)
      version: 1,
      dataFingerprint: null, // calculado abajo
      datasetFingerprint: null, // v6.2: alias estable del fingerprint (spec §3)
      createdAt: m.timestamp || new Date().toISOString(),
      updatedAt: m.timestamp || new Date().toISOString(),
      previousVersions: []
    });
  }
  // Fingerprint determinista del núcleo de datos (para detectar cambios al reprocesar).
  // v6.1.1: incluye el detalle POR TAREA (taskWms/actividad/uds/productividad)
  // para que un cambio de override o de productividad genere nueva versión.
  for (const rec of records) {
    const core = JSON.stringify([
      rec.login, rec.fechaOperativaISO, rec.horasAnalizables, rec.udsTotales,
      rec.actividades.map(a => [
        a.actividad, a.uds, a.productividad,
        (a.tareas || []).map(t => [t.taskWms, t.actividad, t.uds, t.productividad])
      ]),
      rec.incidencias.map(i => [i.seccion, i.horasAfectadas, i.tareaOriginal, i.propuesta])
    ]);
    rec.dataFingerprint = fnv1aStr(core);
    rec.datasetFingerprint = rec.dataFingerprint; // v6.2: identidad spec §3
  }
  return records;
}

/* ============================================================================
 * v6.1 — MEJORA 5: NÚCLEO PURO DE UNDO
 *
 * Funciones puras (sin DOM) para el undo real + persistente + auditable.
 * El bug original: undoDecision usaba findIndex (la PRIMERA entrada del id,
 * es decir la más antigua) → con acciones consecutivas restauraba un estado
 * obsoleto. La corrección: buscar la ÚLTIMA entrada del id.
 * ========================================================================== */

/* Índice de la entrada MÁS RECIENTE del undoStack para un id (o -1). */
function undoFindLatestIndex(undoStack, id) {
  if (!Array.isArray(undoStack)) return -1;
  for (let i = undoStack.length - 1; i >= 0; i--) {
    if (undoStack[i] && undoStack[i].id === id) return i;
  }
  return -1;
}

/* Aplica el undo de un id sobre el mapa de decisiones.
 * Devuelve { ok, restored, removedEntry, decisions } — NO muta los inputs
 * (devuelve un mapa nuevo); el caller asigna el resultado a STATE. */
function undoApply(undoStack, decisions, id) {
  const idx = undoFindLatestIndex(undoStack, id);
  if (idx < 0) return { ok: false, restored: false, removedEntry: null, decisions: decisions };
  const removed = undoStack[idx];
  const newUndo = undoStack.slice(0, idx).concat(undoStack.slice(idx + 1));
  const newDecisions = Object.assign({}, decisions);
  if (removed.prev) {
    newDecisions[id] = Object.assign({}, removed.prev);
  } else {
    delete newDecisions[id];
  }
  return {
    ok: true,
    restored: true,
    removedEntry: removed,
    undoStack: newUndo,
    decisions: newDecisions,
    estadoAnterior: removed.prev ? (removed.prev.decision || null) : null,
    estadoPosterior: null // tras undo: sin decisión o la previa
  };
}

/* ============================================================================
 * v6.1 — MEJORA 3: hash SHA-256 del mapping (versionado criptográfico)
 *
 * El hash FNV (calcularMappingHash) se mantiene por compatibilidad con la
 * cadena de auditoría existente; el versionado de mapping persistente usa
 * SHA-256 real (async, crypto.subtle). Si crypto.subtle no está disponible,
 * rechaza (no se afirman propiedades criptográficas falsas).
 * ========================================================================== */
async function calcularMappingHashSHA256(rows) {
  if (typeof globalThis === 'undefined' || !globalThis.crypto || !globalThis.crypto.subtle) {
    throw new Error('calcularMappingHashSHA256: crypto.subtle no disponible en este contexto');
  }
  const data = JSON.stringify((rows || []).map(r =>
    [r.SAP_CODE, r.WMS_DC, r.CUSTOMER, r.DEPARTMENT, r.ACTIVITY, r.SUB_ACTIVITY, r.TASK_WMS, r.TASK_SPEC]
  ));
  const buf = await globalThis.crypto.subtle.digest('SHA-256', new TextEncoder().encode(data));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

/* ============================================================================
 * ORQUESTADOR PRINCIPAL (equivalente al macro de instalación completo)
 * ========================================================================== */

/* FASE 3 — Genera un sessionId único por sesión de aplicación.
 * Persiste en localStorage para sobrevivir recargas dentro de la misma sesión
 * lógica de trabajo, pero se regenera al cerrar el navegador.
 */
function generarSessionId() {
  const KEY = 'spec_session_id';
  // En Node (tests) localStorage no existe; usar un id efímero
  const hasLS = typeof localStorage !== 'undefined';
  if (hasLS) {
    let sid = localStorage.getItem(KEY);
    if (!sid) {
      sid = 'sess-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
      try { localStorage.setItem(KEY, sid); } catch (e) { /* quota? */ }
    }
    return sid;
  }
  return 'sess-node-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
}

/* FASE 3 — Calcula un hash determinista del mapping cargado.
 * No es criptográfico (no hay crypto.subtle síncrono), pero detecta cambios
 * en el contenido. Se usa como identificador de mapping en el audit log.
 */
function calcularMappingHash(rows) {
  if (!rows || rows.length === 0) return 'empty';
  // FNV-1a 32-bit — determinista y rápido
  let hash = 0x811c9dc5;
  const str = JSON.stringify(rows.map(r =>
    [r.SAP_CODE, r.CUSTOMER, r.TASK_WMS, r.TASK_SPEC].join('|')
  ));
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash = (hash + ((hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24))) >>> 0;
  }
  return hash.toString(16).padStart(8, '0');
}

/* FASE 3 — Calcula el siguiente hash de la cadena del audit log (hash chain).
 * Cada entrada del audit log debe llevar el hash de la entrada anterior,
 * permitiendo detectar manipulaciones. Implementado con Web Crypto API.
 * Devuelve una Promise<string>.
 *
 * P12-cierre — NO se usa FNV como fallback. Si crypto.subtle no está
 * disponible (Node antiguo sin WebCrypto, contexto inseguro), se rechaza
 * con un Error explícito — la entrada NO se marca como criptográficamente
 * protegida. El caller debe decidir cómo etiquetarla (e.g. flag
 * `entryHash = null` + `integrity = 'INSECURE_CONTEXT'`).
 */
async function calcularEntryHash(entry, prevHash) {
  const data = JSON.stringify({
    prev: prevHash || 'genesis',
    ts: entry.timestamp,
    action: entry.action,
    id: entry.id,
    idRegistro: entry.idRegistro,
    persona: entry.persona,
    seccion: entry.seccion,
    tareaOriginal: entry.tareaOriginal,
    propuesta: entry.propuesta,
    tareaFinal: entry.tareaFinal,
    motivo: entry.motivo,
    nivelConfianza: entry.nivelConfianza,
    sessionId: entry.sessionId || '',
    mappingHash: entry.mappingHash || '',
    appVersion: entry.appVersion || ''
  });
  // P12-cierre — SHA-256 obligatorio. No se admite FNV fallback.
  // Si crypto.subtle no está disponible, rechazar.
  if (typeof globalThis === 'undefined' || !globalThis.crypto || !globalThis.crypto.subtle) {
    throw new Error('calcularEntryHash: crypto.subtle no disponible. La cadena del audit log NO puede ser criptográficamente protegida en este contexto.');
  }
  const buf = await globalThis.crypto.subtle.digest('SHA-256', new TextEncoder().encode(data));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

/* Verifica la integridad de la cadena del audit log.
 *
 * P12-cierre — verificación ESTRICTA:
 *   - Entrada sin entryHash → INVÁLIDA (no se acepta recalcular)
 *   - Entrada sin prevHash cuando no es la primera → INVÁLIDA
 *   - entryHash no coincide con el calculado → INVÁLIDA
 *   - prevHash no coincide con el entryHash anterior → INVÁLIDA (cadena rota)
 *   - Cualquier excepción al calcular hash → INVÁLIDA
 *
 * Devuelve { ok, brokenAt, expectedHash, actualHash, reason }.
 */
async function verificarAuditLogChain(auditLog) {
  if (!auditLog || auditLog.length === 0) {
    return { ok: true, brokenAt: null, expectedHash: '', actualHash: '', reason: 'empty' };
  }
  let prevHash = null;
  for (let i = 0; i < auditLog.length; i++) {
    const entry = auditLog[i];
    // P12-cierre — entryHash ausente → INVÁLIDO
    if (!entry.entryHash) {
      return { ok: false, brokenAt: i, expectedHash: '', actualHash: '', reason: 'missing_entryHash' };
    }
    // P12-cierre — prevHash ausente cuando no es la primera entrada → INVÁLIDO
    if (i > 0 && !entry.prevHash) {
      return { ok: false, brokenAt: i, expectedHash: '', actualHash: '', reason: 'missing_prevHash' };
    }
    // P12-cierre — prevHash debe coincidir con el entryHash anterior
    if (i === 0 && entry.prevHash && entry.prevHash !== null) {
      // La primera entrada puede tener prevHash = null (génesis) — OK
      // Si tiene un prevHash no nulo, debe coincidir con... nada (génesis = null)
      return { ok: false, brokenAt: i, expectedHash: 'null', actualHash: String(entry.prevHash), reason: 'invalid_genesis_prevHash' };
    }
    if (i > 0 && entry.prevHash !== prevHash) {
      return { ok: false, brokenAt: i, expectedHash: String(prevHash), actualHash: String(entry.prevHash), reason: 'broken_chain_prevHash' };
    }
    // P12-cierre — recalcular y comparar entryHash
    let expected;
    try {
      expected = await calcularEntryHash(entry, prevHash);
    } catch (err) {
      return { ok: false, brokenAt: i, expectedHash: '', actualHash: entry.entryHash || '', reason: 'hash_computation_failed: ' + err.message };
    }
    if (entry.entryHash !== expected) {
      return { ok: false, brokenAt: i, expectedHash: expected, actualHash: entry.entryHash || '', reason: 'entryHash_mismatch' };
    }
    prevHash = entry.entryHash;
  }
  return { ok: true, brokenAt: null, expectedHash: '', actualHash: '', reason: 'valid' };
}

async function analizarYConciliar(onProgress) {
  STATE.queries = {};
  STATE.reporte = null;
  STATE.log = [];
  // FASE 3 — metadatos de sesión y aplicación
  STATE.stats = {
    sessionId: generarSessionId(),
    appVersion: PARAMS.AppVersion,
    schemaVersion: PARAMS.SchemaVersion,
    mappingSchemaVersion: PARAMS.MappingSchemaVersion,
    mappingHash: null,  // se rellenará tras leerMapping
    inputFiles: {}      // {horas: {name,size}, ...}
  };
  const t0 = performance.now();

  // Validar archivos cargados
  // M-10 (Tarea F9) — STATE.archivos[k] ahora puede ser:
  //   - un array de { name, workbook, file } (estructura nueva multi-archivo)
  //   - un objeto { name, workbook, file } (estructura legacy, aún usada
  //     por worker.js y por tests antiguos)
  // Normalizamos a array para procesar de forma uniforme.
  const needed = { horas: 'HORA SIN VOLUMEN', volumen: 'VOLUMEN', volSinHoras: 'VOL SIN HORAS', mapping: 'MAPPING' };
  const toArray = (v) => Array.isArray(v) ? v : (v ? [v] : []);
  const archivosArr = {
    horas: toArray(STATE.archivos.horas),
    volumen: toArray(STATE.archivos.volumen),
    volSinHoras: toArray(STATE.archivos.volSinHoras),
    mapping: toArray(STATE.archivos.mapping)
  };
  for (const k of Object.keys(needed)) {
    if (archivosArr[k].length === 0) {
      throw new Error('Falta el archivo ' + needed[k]);
    }
  }

  onProgress && onProgress(0, 'Leyendo archivos de entrada...');

  // 1. Transformadores (fx_Transforma*)
  // M-10 — Concatenamos las filas de todos los archivos del mismo tipo.
  // Cada fila ya lleva ArchivoOrigen (set en fx_Transforma*), así que el
  // motor es multi-file ready a nivel de fila. Para mapping, concatenamos
  // los arrays de mapeo; el dedup por (SAP_CODE, CUSTOMER, TASK_WMS) ya lo
  // hace q12_MapeoActividadSPEC vía groupBy.
  const rawHoras = archivosArr.horas.flatMap(a => fx_TransformaHoras(a.workbook, a.name));
  const rawVolumen = archivosArr.volumen.flatMap(a => fx_TransformaVolumen(a.workbook, a.name));
  const rawVSH = archivosArr.volSinHoras.flatMap(a => fx_TransformaVolumenSinHoras(a.workbook, a.name));
  const rawMapping = archivosArr.mapping.flatMap(a => leerMapping(a.workbook));

  // FASE 3 — hash del mapping para trazabilidad
  STATE.stats.mappingHash = calcularMappingHash(rawMapping);
  // M-10 — inputFiles reporta el número de archivos cargados por tipo.
  // Si solo hay 1 (legacy path o single-file UI), name = ese archivo.
  // Si hay varios, name = lista separada por comas (truncada si muy larga).
  const summarizeNames = (arr) => {
    if (arr.length === 1) return arr[0].name;
    const all = arr.map(a => a.name).join(', ');
    return all.length > 200 ? all.slice(0, 197) + '...' : all;
  };
  STATE.stats.inputFiles = {
    horas: { name: summarizeNames(archivosArr.horas), files: archivosArr.horas.length, rows: rawHoras.length },
    volumen: { name: summarizeNames(archivosArr.volumen), files: archivosArr.volumen.length, rows: rawVolumen.length },
    volSinHoras: { name: summarizeNames(archivosArr.volSinHoras), files: archivosArr.volSinHoras.length, rows: rawVSH.length },
    mapping: { name: summarizeNames(archivosArr.mapping), files: archivosArr.mapping.length, rows: rawMapping.length }
  };

  onProgress && onProgress(10, 'Cargadas filas: horas=' + rawHoras.length + ', volumen=' + rawVolumen.length + ', VSH=' + rawVSH.length + ', mapping=' + rawMapping.length);

  // 2. 01_HorasSinVolumen
  const H = q01_HorasSinVolumen(rawHoras);
  STATE.queries['01_HorasSinVolumen'] = H;
  onProgress && onProgress(20, '01_HorasSinVolumen: ' + H.length + ' filas válidas');

  // 3. 02_VolumenDetalle
  const V = q02_VolumenDetalle(rawVolumen);
  STATE.queries['02_VolumenDetalle'] = V;
  onProgress && onProgress(30, '02_VolumenDetalle: ' + V.length + ' filas válidas');

  // 4. 09_VolumenSinHorasDetalle
  const VSH = q09_VolumenSinHorasDetalle(rawVSH);
  STATE.queries['09_VolumenSinHorasDetalle'] = VSH;
  onProgress && onProgress(40, '09_VolumenSinHorasDetalle: ' + VSH.length + ' filas válidas');

  // 5. 12_MapeoActividadSPEC
  const M = q12_MapeoActividadSPEC(rawMapping);
  STATE.queries['12_MapeoActividadSPEC'] = M;
  onProgress && onProgress(50, '12_MapeoActividadSPEC: ' + M.length + ' mapeos');

  // 6. 13_VolumenMapeadoSPEC
  const VM = q13_VolumenMapeadoSPEC(V, M);
  STATE.queries['13_VolumenMapeadoSPEC'] = VM;
  onProgress && onProgress(60, '13_VolumenMapeadoSPEC: ' + VM.length + ' filas');

  // 7. 03_VolumenPersonaDia
  const VPD = q03_VolumenPersonaDia(V);
  STATE.queries['03_VolumenPersonaDia'] = VPD;
  onProgress && onProgress(65, '03_VolumenPersonaDia: ' + VPD.length);

  // 8. 05_VolumenIdNumericoDia
  const VID = q05_VolumenIdNumericoDia(V);
  STATE.queries['05_VolumenIdNumericoDia'] = VID;
  onProgress && onProgress(70, '05_VolumenIdNumericoDia: ' + VID.length);

  // 9. 10_VolumenSinHorasPersonaDia
  const VSPD = q10_VolumenSinHorasPersonaDia(VSH);
  STATE.queries['10_VolumenSinHorasPersonaDia'] = VSPD;

  // 10. 14_VolumenPersonaDiaActividadSPEC
  const VPDAS = q14_VolumenPersonaDiaActividadSPEC(VM);
  STATE.queries['14_VolumenPersonaDiaActividadSPEC'] = VPDAS;

  // 11. 15_VolumenSinHorasPersonaDiaActividadSPEC
  const VSPDAS = q15_VolumenSinHorasPersonaDiaActividadSPEC(VSH);
  STATE.queries['15_VolumenSinHorasPersonaDiaActividadSPEC'] = VSPDAS;

  onProgress && onProgress(80, 'Agregaciones completas');

  // 12. 16_ControlMapeoSPEC
  const CTRL = q16_ControlMapeoSPEC(M, VM, VID);
  STATE.queries['16_ControlMapeoSPEC'] = CTRL;

  // 13. 07_Conciliacion (la consulta central)
  const C = q07_Conciliacion(H, VPD, VID, VSPD, VPDAS, VSPDAS);
  STATE.queries['07_Conciliacion'] = C;
  onProgress && onProgress(90, '07_Conciliacion: ' + C.length + ' filas conciliadas');

  // 14. 08_Validaciones
  const VAL = q08_Validaciones(H, V, VSH, C, VM, VID);
  STATE.queries['08_Validaciones'] = VAL;

  // 15. REPORTE_CAMBIOS_HR (VBA)
  const REP = generarReporteCambiosHR(H, VM, C);
  STATE.reporte = REP;
  onProgress && onProgress(95, 'REPORTE_CAMBIOS_HR: ' + REP.length + ' propuestas');

  // 16. v6.1 — 17_PersonaDiaAnalitica (MEJORA 4: unidad PERSONA + FECHA_OPERATIVA)
  // Se calcula con las productividades/overrides POR DEFECTO del motor. La UI
  // la recalcula con las preferencias del usuario tras recibir el resultado
  // (ver ui.js recomputarPersonaDia). No toca las consultas 01-16 → la
  // equivalencia con SPEC V0.47.3 queda intacta.
  const PD = q17_PersonaDiaAnalitica(H, VM, VSH, { productividades: PARAMS.ProductividadesReferencia, taskOverrides: {} });
  STATE.queries['17_PersonaDiaAnalitica'] = PD;
  // v6.1 — MEJORA 6: PERSON_DAILY_RECORD (histórico diario)
  STATE.personaDiaRecords = generarPersonDailyRecords(PD, REP, {
    mappingHash: STATE.stats.mappingHash,
    mappingVersion: null, // la UI lo rellena desde el mapping persistente
    productividades: PARAMS.ProductividadesReferencia,
    appVersion: PARAMS.AppVersion,
    sessionId: STATE.stats.sessionId,
    timestamp: STATE.stats.fecha ? STATE.stats.fecha.toISOString() : new Date().toISOString()
  });
  onProgress && onProgress(100, '17_PersonaDiaAnalitica: ' + PD.length + ' persona/día');

  STATE.stats.totalMs = Math.round(performance.now() - t0);
  STATE.stats.fecha = new Date();

  return STATE;
}

/* ============================================================================
 * EXPORTACIÓN A XLSX / CSV
 * ========================================================================== */

function exportToXlsx(data, filename, sheetName) {
  // data: array de objetos
  if (!data || data.length === 0) {
    const ws = XLSX.utils.json_to_sheet([{}]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, sheetName || 'Hoja');
    XLSX.writeFile(wb, filename);
    return;
  }
  // Preservar orden de columnas del primer row
  const cols = Object.keys(data[0]);
  const aoa = [cols, ...data.map(r => cols.map(c => serializeCell(r[c])))];
  const ws = XLSX.utils.aoa_to_sheet(aoa);
  // Aplicar formatos: fechas a dd/mm/yyyy
  for (let i = 1; i <= data.length; i++) {
    for (let j = 0; j < cols.length; j++) {
      const v = data[i - 1][cols[j]];
      if (v instanceof Date) {
        const cell = ws[XLSX.utils.encode_cell({ r: i, c: j })];
        if (cell) {
          cell.v = v;
          cell.t = 'd';
          cell.z = 'dd/mm/yyyy';
        }
      }
    }
  }
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheetName || 'Hoja');
  XLSX.writeFile(wb, filename);
}

function serializeCell(v) {
  if (v instanceof Date) return v;
  return v;
}

function exportToCsv(data, filename) {
  if (!data || data.length === 0) {
    const blob = new Blob([''], { type: 'text/csv;charset=utf-8' });
    saveAs(blob, filename);
    return;
  }
  const cols = Object.keys(data[0]);
  // M-01 / R-05 fix — CSV Formula Injection protection.
  // Values starting with =, +, -, @ could be interpreted as formulas by Excel/LibreOffice.
  // We prepend a single quote to neutralize them. We also escape the actual
  // delimiter (;) and the quote/newline chars.
  // AUD-MED-007 fix: original code only escaped , " \n (but delimiter is ;, not ,).
  const FORMULA_PREFIXES = /^[=+\-@]/;
  const escapeCsv = v => {
    if (v == null) return '';
    if (v instanceof Date) return formatFecha(v);
    let s = typeof v === 'string' ? v : String(v);
    // Neutralize CSV formula injection
    if (FORMULA_PREFIXES.test(s)) {
      s = "'" + s;
    }
    // Quote if contains delimiter, quote, or newline (covers ; too)
    if (s.indexOf(',') >= 0 || s.indexOf(';') >= 0 || s.indexOf('"') >= 0 || s.indexOf('\n') >= 0 || s.indexOf('\r') >= 0) {
      s = '"' + s.replace(/"/g, '""') + '"';
    }
    return s;
  };
  const lines = [cols.join(';')];
  for (const r of data) lines.push(cols.map(c => escapeCsv(r[c])).join(';'));
  const blob = new Blob(['\ufeff' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
  saveAs(blob, filename);
}

function saveAs(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/* ============================================================================
 * API pública
 * ========================================================================== */
global.SPEC = {
  PARAMS,
  STATE,
  // Funciones expuestas (para depuración y trazabilidad)
  fx_NormalizaTexto,
  fx_NormalizaLogin,
  fx_Fecha,
  numberFrom,
  calcularMaterialidad,
  // Consultas M
  q01_HorasSinVolumen,
  q02_VolumenDetalle,
  q09_VolumenSinHorasDetalle,
  q12_MapeoActividadSPEC,
  q13_VolumenMapeadoSPEC,
  q03_VolumenPersonaDia,
  q05_VolumenIdNumericoDia,
  q10_VolumenSinHorasPersonaDia,
  q14_VolumenPersonaDiaActividadSPEC,
  q15_VolumenSinHorasPersonaDiaActividadSPEC,
  q16_ControlMapeoSPEC,
  q07_Conciliacion,
  q08_Validaciones,
  // v6.1 — MEJORA 1: turnos
  fx_Turno,
  fx_FechaOperativaTurno,
  filtrarRegistrosPorTurno,
  extraerHoraFichaje,
  // v6.1 — MEJORA 4: actividad analisis + reparto + persona-día
  ACTIVIDADES_ANALISIS,
  normalizarTareaWms,
  fx_ActividadAnalisis,
  resolverProductividad,
  resolverClasificacionTarea,
  repartirTiempos,
  repartirTiemposPorTarea,
  q17_PersonaDiaAnalitica,
  generarPersonDailyRecords,
  isoSemana,
  isoMes,
  // v6.1 — MEJORA 5: núcleo undo
  undoFindLatestIndex,
  undoApply,
  // v6.1 — MEJORA 3: hash SHA-256 mapping
  calcularMappingHashSHA256,
  // VBA
  generarReporteCambiosHR,
  // Orquestador
  analizarYConciliar,
  // Exportación
  exportToXlsx,
  exportToCsv,
  // Lectura
  leerArchivoExcel,
  fx_TransformaHoras,
  fx_TransformaVolumen,
  fx_TransformaVolumenSinHoras,
  leerMapping,
  // FASE 2 — R-06 validación de entradas
  validarArchivoEntrada,
  validarWorkbook,
  // FASE 3 — Trazabilidad / audit log
  generarSessionId,
  calcularMappingHash,
  calcularEntryHash,
  verificarAuditLogChain,
  // Utilidades
  formatNum,
  formatNum2,
  formatNum0,
  formatFecha,
  formatFechaISO,
  log
};

})(typeof window !== 'undefined' ? window : globalThis);
