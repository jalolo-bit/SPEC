// FASE 8 (auditoría de certificación) — Tests de integridad criptográfica del
// audit log (hash chain SHA-256).
//
// La fuente de verdad es app.js: calcularEntryHash usa SHA-256 vía Web Crypto
// (crypto.subtle) SIN fallback FNV (P12-cierre), y verificarAuditLogChain
// aplica verificación ESTRICTA. Estos tests ejecutan los 6 escenarios de
// manipulación exigidos por la auditoría independiente:
//
//   1. Cadena correcta        → ok:true
//   2. Entrada modificada     → entryHash_mismatch
//   3. Entrada eliminada      → broken_chain_prevHash (la cadena queda rota)
//   4. Hash eliminado         → missing_entryHash
//   5. prevHash modificado    → broken_chain_prevHash / invalid_genesis_prevHash
//   6. Orden alterado         → entryHash_mismatch (los hashes dejan de cuadrar)
//
// Además: verificación de que NO existe fallback FNV — calcularEntryHash debe
// lanzar/depender de crypto.subtle, y los entryHash producidos son SHA-256
// de 64 hex chars.

import { describe, it, expect } from 'vitest';

const SPEC = globalThis.SPEC;

// Construye una entrada del audit log con el mismo shape que
// registrarDecision (ui.js) — sin depender del DOM.
function makeEntry(overrides = {}) {
  return Object.assign({
    timestamp: new Date().toISOString(),
    action: 'aceptada',
    id: 'test-id-1',
    idRegistro: 'REG-0001',
    persona: 'PERSONA_TEST',
    seccion: '1. CAMBIO HR TASK PROPUESTO',
    tareaOriginal: 'TAREA_ORIG',
    propuesta: 'TAREA_PROP',
    tareaFinal: 'TAREA_PROP',
    motivo: 'test',
    nivelConfianza: 'ALTA',
    sessionId: 'sess-test-1234',
    mappingHash: 'abcd1234',
    appVersion: '6.0.0-post-audit',
    schemaVersion: '1.0'
  }, overrides);
}

// Construye una cadena válida de N entradas (cada una con prevHash y
// entryHash correctamente calculados con SHA-256).
async function buildValidChain(n) {
  const chain = [];
  let prevHash = null;
  for (let i = 0; i < n; i++) {
    const entry = makeEntry({
      id: 'test-id-' + (i + 1),
      idRegistro: 'REG-' + String(i + 1).padStart(4, '0'),
      timestamp: new Date(Date.UTC(2026, 0, 1, 0, 0, i)).toISOString()
    });
    entry.prevHash = prevHash;
    entry.entryHash = await SPEC.calcularEntryHash(entry, prevHash);
    chain.push(entry);
    prevHash = entry.entryHash;
  }
  return chain;
}

describe('FASE 8 — Audit log: hash chain SHA-256 (sin FNV)', () => {
  it('calcularEntryHash produce un SHA-256 de 64 caracteres hex', async () => {
    const entry = makeEntry();
    const h = await SPEC.calcularEntryHash(entry, null);
    expect(h).toMatch(/^[a-f0-9]{64}$/);
  });

  it('calcularEntryHash es determinista (misma entrada → mismo hash)', async () => {
    const e1 = makeEntry();
    const e2 = makeEntry();
    const h1 = await SPEC.calcularEntryHash(e1, null);
    const h2 = await SPEC.calcularEntryHash(e2, null);
    expect(h1).toBe(h2);
  });

  it('calcularEntryHash cambia si cambia el contenido (avalanche mínimo)', async () => {
    const h1 = await SPEC.calcularEntryHash(makeEntry(), null);
    const h2 = await SPEC.calcularEntryHash(makeEntry({ persona: 'OTRA' }), null);
    expect(h1).not.toBe(h2);
  });

  it('calcularEntryHash cambia si cambia el prevHash', async () => {
    const e = makeEntry();
    const h1 = await SPEC.calcularEntryHash(e, null);
    const h2 = await SPEC.calcularEntryHash(e, 'deadbeef');
    expect(h1).not.toBe(h2);
  });

  it('NO hay fallback FNV: crypto.subtle es la única vía (P12-cierre)', () => {
    // El contrato P12-cierre: si crypto.subtle no existe, calcularEntryHash
    // DEBE rechazar — nunca debe degradar silenciosamente a FNV-1a.
    // Simulamos su ausencia parcheando globalThis.crypto y verificamos el rechazo.
    const realCrypto = globalThis.crypto;
    try {
      Object.defineProperty(globalThis, 'crypto', { value: undefined, configurable: true });
      const p = SPEC.calcularEntryHash(makeEntry(), null);
      return p.then(
        () => { throw new Error('ESPERABA rechazo sin crypto.subtle (no fallback FNV)'); },
        (err) => { expect(String(err.message)).toContain('crypto.subtle'); }
      );
    } finally {
      Object.defineProperty(globalThis, 'crypto', { value: realCrypto, configurable: true });
    }
  });
});

describe('FASE 8 — Escenario 1: cadena correcta → ok', () => {
  it('verificarAuditLogChain devuelve ok:true para cadena válida de 5 entradas', async () => {
    const chain = await buildValidChain(5);
    const r = await SPEC.verificarAuditLogChain(chain);
    expect(r.ok).toBe(true);
    expect(r.reason).toBe('valid');
  });

  it('verificarAuditLogChain acepta cadena vacía (ok, reason=empty)', async () => {
    const r = await SPEC.verificarAuditLogChain([]);
    expect(r.ok).toBe(true);
    expect(r.reason).toBe('empty');
  });

  it('verificarAuditLogChain acepta cadena null/undefined (ok, reason=empty)', async () => {
    const r1 = await SPEC.verificarAuditLogChain(null);
    const r2 = await SPEC.verificarAuditLogChain(undefined);
    expect(r1.ok).toBe(true);
    expect(r2.ok).toBe(true);
  });
});

describe('FASE 8 — Escenario 2: entrada modificada → detectado', () => {
  it('modificar el motivo de una entrada intermedia rompe entryHash', async () => {
    const chain = await buildValidChain(4);
    chain[2].motivo = 'MOTIVO_FALSIFICADO';
    const r = await SPEC.verificarAuditLogChain(chain);
    expect(r.ok).toBe(false);
    expect(r.reason).toBe('entryHash_mismatch');
    expect(r.brokenAt).toBe(2);
  });

  it('modificar la persona de la PRIMERA entrada rompe entryHash', async () => {
    const chain = await buildValidChain(3);
    chain[0].persona = 'HACKER';
    const r = await SPEC.verificarAuditLogChain(chain);
    expect(r.ok).toBe(false);
    expect(r.reason).toBe('entryHash_mismatch');
    expect(r.brokenAt).toBe(0);
  });

  it('modificar la ÚLTIMA entrada rompe entryHash (sin continuación que lo tape)', async () => {
    const chain = await buildValidChain(3);
    chain[2].tareaFinal = 'TAREA_FALSA';
    const r = await SPEC.verificarAuditLogChain(chain);
    expect(r.ok).toBe(false);
    expect(r.reason).toBe('entryHash_mismatch');
    expect(r.brokenAt).toBe(2);
  });
});

describe('FASE 8 — Escenario 3: entrada eliminada → detectado', () => {
  it('borrar una entrada intermedia rompe la cadena (prevHash deja de cuadrar)', async () => {
    const chain = await buildValidChain(5);
    chain.splice(2, 1); // elimina la entrada 2
    const r = await SPEC.verificarAuditLogChain(chain);
    expect(r.ok).toBe(false);
    // La entrada que ahora ocupa el índice 2 tiene un prevHash que apunta al
    // entryHash de la entrada borrada — no coincide con el anterior vivo.
    expect(r.reason).toBe('broken_chain_prevHash');
  });

  it('borrar la PRIMERA entrada rompe la cadena', async () => {
    const chain = await buildValidChain(4);
    chain.shift();
    const r = await SPEC.verificarAuditLogChain(chain);
    expect(r.ok).toBe(false);
    // La nueva primera entrada lleva prevHash no nulo → génesis inválida
    expect(['broken_chain_prevHash', 'invalid_genesis_prevHash']).toContain(r.reason);
  });
});

describe('FASE 8 — Escenario 4: entryHash eliminado → detectado', () => {
  it('borrar el entryHash de una entrada → missing_entryHash', async () => {
    const chain = await buildValidChain(4);
    delete chain[1].entryHash;
    const r = await SPEC.verificarAuditLogChain(chain);
    expect(r.ok).toBe(false);
    expect(r.reason).toBe('missing_entryHash');
    expect(r.brokenAt).toBe(1);
  });

  it('borrar el entryHash de la primera entrada → missing_entryHash', async () => {
    const chain = await buildValidChain(3);
    delete chain[0].entryHash;
    const r = await SPEC.verificarAuditLogChain(chain);
    expect(r.ok).toBe(false);
    expect(r.reason).toBe('missing_entryHash');
    expect(r.brokenAt).toBe(0);
  });
});

describe('FASE 8 — Escenario 5: prevHash modificado → detectado', () => {
  it('falsificar el prevHash de una entrada intermedia → broken_chain_prevHash', async () => {
    const chain = await buildValidChain(4);
    chain[2].prevHash = 'ff'.repeat(32); // hash falso de 64 chars
    const r = await SPEC.verificarAuditLogChain(chain);
    expect(r.ok).toBe(false);
    expect(r.reason).toBe('broken_chain_prevHash');
    expect(r.brokenAt).toBe(2);
  });

  it('inyectar prevHash no nulo en la entrada génesis → invalid_genesis_prevHash', async () => {
    const chain = await buildValidChain(3);
    chain[0].prevHash = 'ab'.repeat(32);
    const r = await SPEC.verificarAuditLogChain(chain);
    expect(r.ok).toBe(false);
    expect(r.reason).toBe('invalid_genesis_prevHash');
    expect(r.brokenAt).toBe(0);
  });

  it('borrar el prevHash de una entrada intermedia → missing_prevHash', async () => {
    const chain = await buildValidChain(4);
    delete chain[2].prevHash;
    const r = await SPEC.verificarAuditLogChain(chain);
    expect(r.ok).toBe(false);
    expect(r.reason).toBe('missing_prevHash');
    expect(r.brokenAt).toBe(2);
  });
});

describe('FASE 8 — Escenario 6: orden alterado → detectado', () => {
  it('intercambiar dos entradas intermedias rompe la verificación', async () => {
    const chain = await buildValidChain(5);
    const tmp = chain[1];
    chain[1] = chain[2];
    chain[2] = tmp;
    const r = await SPEC.verificarAuditLogChain(chain);
    expect(r.ok).toBe(false);
    expect(['entryHash_mismatch', 'broken_chain_prevHash', 'missing_prevHash']).toContain(r.reason);
  });

  it('invertir toda la cadena rompe la verificación', async () => {
    const chain = await buildValidChain(5);
    chain.reverse();
    const r = await SPEC.verificarAuditLogChain(chain);
    expect(r.ok).toBe(false);
  });
});

describe('FASE 8 — Metadatos de trazabilidad (sessionId / appVersion / mappingHash)', () => {
  it('el entryHash cubre sessionId, appVersion y mappingHash (P12-cierre)', async () => {
    // Cambiar CUALQUIER metadato firmado debe cambiar el hash → un atacante
    // no puede reescribir la sesión o la versión sin romper la cadena.
    const base = makeEntry();
    const h0 = await SPEC.calcularEntryHash(base, null);

    const h1 = await SPEC.calcularEntryHash(makeEntry({ sessionId: 'sess-OTRA' }), null);
    const h2 = await SPEC.calcularEntryHash(makeEntry({ appVersion: '5.0.0-falso' }), null);
    const h3 = await SPEC.calcularEntryHash(makeEntry({ mappingHash: '0000ffff' }), null);

    expect(h1).not.toBe(h0);
    expect(h2).not.toBe(h0);
    expect(h3).not.toBe(h0);
  });

  it('calcularMappingHash es un identificador FNV determinista (NO se usa como integridad)', () => {
    // El mappingHash es un ID de contenido (FNV-1a 32-bit documentado).
    // NO sustituye a SHA-256 en la cadena: la integridad del audit log es
    // exclusivamente SHA-256 (calcularEntryHash). Aquí solo verificamos
    // determinismo para que no haya sorpresas.
    const rows = [
      { SAP_CODE: 'A', CUSTOMER: 'C', TASK_WMS: 'T1', TASK_SPEC: 'S1' },
      { SAP_CODE: 'B', CUSTOMER: 'D', TASK_WMS: 'T2', TASK_SPEC: 'S2' }
    ];
    expect(SPEC.calcularMappingHash(rows)).toBe(SPEC.calcularMappingHash(JSON.parse(JSON.stringify(rows))));
    expect(SPEC.calcularMappingHash([])).toBe('empty');
  });
});
