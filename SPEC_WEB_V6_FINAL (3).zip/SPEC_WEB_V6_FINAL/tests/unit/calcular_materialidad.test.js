// Unit tests for SPEC.calcularMaterialidad  (VBA líneas 126-138)
//
// Covers the 5-tier classification (MICRO / BAJA / MEDIA / ALTA / CRITICA)
// with boundary tests, plus the coercion / fallback behavior for null, NaN
// and string inputs.
//
// Boundaries (defined in app.js PARAMS):
//   UmbralMicroHoras = 0.0833333333  (5 minutes = 5/60)
//   BAJA     threshold = 0.25        (15 minutes)
//   MEDIA    threshold = 1            (1 hour)
//   ALTA     threshold = 4           (4 hours)
//
// The classifier uses strict `<` at each tier — so a value EQUAL to a
// threshold falls into the NEXT tier up. This is intentional and matches
// the original VBA semantics (the labels say "< 5 MIN", "< 15 MIN", etc.).

import { describe, it, expect } from 'vitest';

const SPEC = globalThis.SPEC;

const T = {
  MICRO:   'MICRO < 5 MIN',
  BAJA:    'BAJA < 15 MIN',
  MEDIA:   'MEDIA < 1 H',
  ALTA:    'ALTA 1-4 H',
  CRITICA: 'CRITICA >= 4 H'
};

describe('calcularMaterialidad (VBA líneas 126-138)', () => {
  describe('MICRO tier (< 5 min = 0.0833... h)', () => {
    it('0 → MICRO (zero hours is the trivially smallest case)', () => {
      expect(SPEC.calcularMaterialidad(0)).toBe(T.MICRO);
    });

    it('0.08 → MICRO (just below the 5-minute threshold)', () => {
      expect(SPEC.calcularMaterialidad(0.08)).toBe(T.MICRO);
    });

    it('0.0833 → MICRO (well below threshold)', () => {
      expect(SPEC.calcularMaterialidad(0.0833)).toBe(T.MICRO);
    });

    it('0.0833333333 → BAJA (exactly at threshold; strict < means equal values fall to the next tier)', () => {
      // The task description claimed this should return MICRO. The actual
      // implementation uses `horas < PARAMS.UmbralMicroHoras` (strict <), so
      // a value EQUAL to the threshold (5 min exactly) is classified as BAJA.
      // This matches the VBA label "MICRO < 5 MIN" — strictly less than.
      expect(SPEC.calcularMaterialidad(0.0833333333)).toBe(T.BAJA);
    });
  });

  describe('BAJA tier (< 15 min = 0.25 h)', () => {
    it('0.084 → BAJA (just above MICRO threshold)', () => {
      expect(SPEC.calcularMaterialidad(0.084)).toBe(T.BAJA);
    });

    it('0.24 → BAJA (just below MEDIA threshold)', () => {
      expect(SPEC.calcularMaterialidad(0.24)).toBe(T.BAJA);
    });

    it('0.25 → MEDIA (exactly at threshold; strict < means equal falls to next tier)', () => {
      expect(SPEC.calcularMaterialidad(0.25)).toBe(T.MEDIA);
    });
  });

  describe('MEDIA tier (< 1 h)', () => {
    it('0.5 → MEDIA (mid range)', () => {
      expect(SPEC.calcularMaterialidad(0.5)).toBe(T.MEDIA);
    });

    it('0.99 → MEDIA (just below 1 h)', () => {
      expect(SPEC.calcularMaterialidad(0.99)).toBe(T.MEDIA);
    });

    it('1 → ALTA (exactly at threshold; strict < means equal falls to next tier)', () => {
      expect(SPEC.calcularMaterialidad(1)).toBe(T.ALTA);
    });
  });

  describe('ALTA tier (< 4 h)', () => {
    it('1.5 → ALTA', () => {
      expect(SPEC.calcularMaterialidad(1.5)).toBe(T.ALTA);
    });

    it('3.99 → ALTA (just below CRITICA threshold)', () => {
      expect(SPEC.calcularMaterialidad(3.99)).toBe(T.ALTA);
    });

    it('4 → CRITICA (exactly at threshold; strict < means equal falls to next tier)', () => {
      expect(SPEC.calcularMaterialidad(4)).toBe(T.CRITICA);
    });
  });

  describe('CRITICA tier (>= 4 h)', () => {
    it('4 → CRITICA', () => {
      expect(SPEC.calcularMaterialidad(4)).toBe(T.CRITICA);
    });

    it('100 → CRITICA (extreme value)', () => {
      expect(SPEC.calcularMaterialidad(100)).toBe(T.CRITICA);
    });

    it('1e6 → CRITICA (no overflow)', () => {
      expect(SPEC.calcularMaterialidad(1e6)).toBe(T.CRITICA);
    });
  });

  describe('null / undefined / non-numeric input (coerced to 0)', () => {
    it('null → coerced to 0 → MICRO', () => {
      // The function body: `if (horas == null) horas = 0;`
      expect(SPEC.calcularMaterialidad(null)).toBe(T.MICRO);
    });

    it('undefined → coerced to 0 → MICRO', () => {
      // `undefined == null` is true, so the same branch fires.
      expect(SPEC.calcularMaterialidad(undefined)).toBe(T.MICRO);
    });

    it('"string" (non-numeric) → Number("string")=NaN → `|| 0` → 0 → MICRO', () => {
      // The function body: `if (typeof horas !== 'number') horas = Number(horas) || 0;`
      // Number("string") = NaN, NaN || 0 = 0.
      expect(SPEC.calcularMaterialidad('string')).toBe(T.MICRO);
    });

    it('"3" (numeric string) → Number("3")=3 → ALTA', () => {
      // Numeric strings are coerced to numbers via Number().
      expect(SPEC.calcularMaterialidad('3')).toBe(T.ALTA);
    });

    it('NaN → CRITICA (NaN comparisons all return false, so it falls through every tier)', () => {
      // IMPORTANT divergence from a naive reading: NaN passes both guards
      // (typeof NaN === 'number', NaN != null) but every `NaN < x` returns
      // false, so the classifier falls through to the CRITICA tier. This is
      // the documented VBA/JS behavior. The implementation does NOT coerce
      // NaN to 0 (it only coerces when `typeof horas !== 'number'`).
      expect(SPEC.calcularMaterialidad(NaN)).toBe(T.CRITICA);
    });
  });

  describe('negative numbers (edge case — not part of the business domain but tested for safety)', () => {
    it('-1 → MICRO (negative is < 0.0833, falls into the first tier)', () => {
      // The classifier doesn't reject negative input. A future spec change
      // could throw or return null; until then, this is the documented behavior.
      expect(SPEC.calcularMaterialidad(-1)).toBe(T.MICRO);
    });

    it('-0.0001 → MICRO', () => {
      expect(SPEC.calcularMaterialidad(-0.0001)).toBe(T.MICRO);
    });
  });
});
