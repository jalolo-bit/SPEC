// Unit tests v6.1 — MEJORA 4: reparto de tiempos entre actividades
//
// Modelo: HORAS_EQUIVALENTES = UDS / PRODUCTIVIDAD_MEDIA
//         PESO = HE_act / Σ HE          TIEMPO_ASIGNADO = TIEMPO_ANALIZABLE × PESO
// Conservación exacta: SUM(HORAS_ASIGNADAS) = TIEMPO_ANALIZABLE
// (precisión interna completa; el redondeo es solo de presentación)
//
// Casos obligatorios del usuario:
//   1, 2, 3 actividades · actividad con 0 unidades · tareas OTRA ·
//   varias actividades del mismo tipo · unidades muy grandes ·
//   productividades diferentes

import { describe, it, expect } from 'vitest';

const SPEC = globalThis.SPEC;
const TOL = 1e-9; // tolerancia numérica mínima (ruido flotante)

function suma(acts, campo) {
  return acts.reduce((s, a) => s + (a[campo] || 0), 0);
}

describe('v6.1 MEJORA 4 — repartirTiempos (modelo matemático)', () => {
  it('EJEMPLO DEL USUARIO: 900 uds Picking AGV + 520 uds Ubicación AGV sobre 8 h', () => {
    const acts = [
      { actividad: 'PICKING AGV', uds: 900, productividad: 150 },
      { actividad: 'UBICACION AGV', uds: 520, productividad: 240 }
    ];
    const rep = SPEC.repartirTiempos(8, acts);
    // HE: 900/150 = 6 h · 520/240 = 2.1667 h · total 8.1667 h
    expect(acts[0].horasEquivalentes).toBeCloseTo(6, 10);
    expect(acts[1].horasEquivalentes).toBeCloseTo(520 / 240, 10);
    expect(rep.sumaHorasEquivalentes).toBeCloseTo(6 + 520 / 240, 10);
    // Pesos: 6/8.1667 y 2.1667/8.1667
    expect(acts[0].peso).toBeCloseTo(6 / (6 + 520 / 240), 10);
    expect(acts[1].peso).toBeCloseTo((520 / 240) / (6 + 520 / 240), 10);
    expect(acts[0].peso + acts[1].peso).toBeCloseTo(1, 10);
    // Asignación conserva el tiempo total
    expect(Math.abs(suma(acts, 'horasAsignadas') - 8)).toBeLessThan(TOL);
    expect(rep.sumaHorasAsignadas).toBeCloseTo(8, 10);
    // Productividad implícita = uds / hAsignadas
    expect(acts[0].productividadImplicita).toBeCloseTo(900 / acts[0].horasAsignadas, 6);
  });

  it('1 actividad → todo el tiempo a esa actividad', () => {
    const acts = [{ actividad: 'PICKING MANUAL', uds: 500, productividad: 100 }];
    SPEC.repartirTiempos(7.5, acts);
    expect(acts[0].horasEquivalentes).toBe(5);
    expect(acts[0].peso).toBe(1);
    expect(acts[0].horasAsignadas).toBe(7.5);
    expect(Math.abs(suma(acts, 'horasAsignadas') - 7.5)).toBeLessThan(TOL);
  });

  it('2 actividades con reparto proporcional exacto', () => {
    const acts = [
      { actividad: 'AUDITORIA AGV', uds: 35, productividad: 35 },  // 1 h equiv
      { actividad: 'AUDITORIA MANUAL', uds: 46, productividad: 23 } // 2 h equiv
    ];
    SPEC.repartirTiempos(6, acts);
    expect(acts[0].horasAsignadas).toBeCloseTo(2, 10); // 1/3 de 6
    expect(acts[1].horasAsignadas).toBeCloseTo(4, 10); // 2/3 de 6
    expect(Math.abs(suma(acts, 'horasAsignadas') - 6)).toBeLessThan(TOL);
  });

  it('3 actividades', () => {
    const acts = [
      { actividad: 'PICKING AGV', uds: 150, productividad: 150 }, // 1h
      { actividad: 'UBICACION AGV', uds: 240, productividad: 240 }, // 1h
      { actividad: 'PICKING MANUAL', uds: 200, productividad: 100 } // 2h
    ];
    SPEC.repartirTiempos(8, acts);
    expect(acts[0].horasAsignadas).toBeCloseTo(2, 10);
    expect(acts[1].horasAsignadas).toBeCloseTo(2, 10);
    expect(acts[2].horasAsignadas).toBeCloseTo(4, 10);
    expect(Math.abs(suma(acts, 'horasAsignadas') - 8)).toBeLessThan(TOL);
  });

  it('Actividad con 0 unidades → peso 0, sin NaN', () => {
    const acts = [
      { actividad: 'PICKING AGV', uds: 300, productividad: 150 }, // 2h
      { actividad: 'UBICACION AGV', uds: 0, productividad: 240 }  // 0h
    ];
    SPEC.repartirTiempos(5, acts);
    expect(acts[1].horasEquivalentes).toBe(0);
    expect(acts[1].peso).toBe(0);
    expect(acts[1].horasAsignadas).toBe(0);
    expect(Number.isNaN(acts[1].peso)).toBe(false);
    expect(acts[0].horasAsignadas).toBeCloseTo(5, 10); // todo al que tiene uds
    expect(Math.abs(suma(acts, 'horasAsignadas') - 5)).toBeLessThan(TOL);
  });

  it('Persona con SOLO tareas OTRA → no se reparte nada', () => {
    const acts = [
      { actividad: 'OTRA', uds: 999, productividad: null },
      { actividad: 'OTRA', uds: 500, productividad: null }
    ];
    const rep = SPEC.repartirTiempos(8, acts);
    expect(acts[0].horasEquivalentes).toBeNull();
    expect(acts[0].peso).toBeNull();
    expect(acts[0].horasAsignadas).toBe(0);
    expect(acts[1].horasAsignadas).toBe(0);
    expect(rep.sumaHorasEquivalentes).toBe(0);
    expect(rep.sumaHorasAsignadas).toBe(0);
    expect(rep.nClasificables).toBe(0);
    // El tiempo analizable NO desaparece del registro: queda sin asignar
  });

  it('Mezcla de tareas OTRA + clasificables → OTRA fuera del reparto', () => {
    const acts = [
      { actividad: 'PICKING AGV', uds: 300, productividad: 150 }, // 2h equiv
      { actividad: 'OTRA', uds: 10000, productividad: null }
    ];
    SPEC.repartirTiempos(6, acts);
    expect(acts[0].peso).toBe(1); // el 100% del reparto
    expect(acts[0].horasAsignadas).toBeCloseTo(6, 10);
    expect(acts[1].horasAsignadas).toBe(0);
    expect(acts[1].productividadImplicita).toBeNull();
  });

  it('Varias actividades del mismo tipo se agregan antes del reparto (nivel q17)', () => {
    // Simulamos la agregación: dos tareas WMS distintas, misma actividad
    const uds = [600, 300]; // p.ej. dos tareas de picking AGV
    const total = uds.reduce((s, x) => s + x, 0);
    const acts = [{ actividad: 'PICKING AGV', uds: total, productividad: 150 }];
    SPEC.repartirTiempos(9, acts);
    expect(acts[0].horasEquivalentes).toBe(6);
    expect(acts[0].horasAsignadas).toBe(9);
  });

  it('Unidades muy grandes (1e9) — sin overflow ni pérdida de conservación', () => {
    const acts = [
      { actividad: 'UBICACION MANUAL', uds: 1e9, productividad: 260 },
      { actividad: 'PICKING MANUAL', uds: 3e8, productividad: 100 }
    ];
    SPEC.repartirTiempos(12345.678, acts);
    expect(Math.abs(suma(acts, 'horasAsignadas') - 12345.678)).toBeLessThan(1e-6);
    expect(acts[0].horasEquivalentes).toBeCloseTo(1e9 / 260, 3);
  });

  it('Productividades diferentes (las del usuario por defecto)', () => {
    const acts = [
      { actividad: 'AUDITORIA AGV', uds: 350, productividad: 35 },    // 10h
      { actividad: 'AUDITORIA MANUAL', uds: 230, productividad: 23 }, // 10h
      { actividad: 'UBICACION MANUAL', uds: 2600, productividad: 260 }, // 10h
      { actividad: 'UBICACION AGV', uds: 2400, productividad: 240 },   // 10h
      { actividad: 'PICKING MANUAL', uds: 1000, productividad: 100 },  // 10h
      { actividad: 'PICKING AGV', uds: 1500, productividad: 150 }      // 10h
    ];
    SPEC.repartirTiempos(24, acts);
    // Todas con la misma HE (10h) → reparto equitativo 24/6 = 4h
    for (const a of acts) {
      expect(a.peso).toBeCloseTo(1 / 6, 10);
      expect(a.horasAsignadas).toBeCloseTo(4, 10);
    }
    expect(Math.abs(suma(acts, 'horasAsignadas') - 24)).toBeLessThan(TOL);
  });

  it('El redondeo es SOLO de presentación: internamente no se redondea', () => {
    const acts = [
      { actividad: 'PICKING AGV', uds: 1, productividad: 3 },   // 0.3333...h
      { actividad: 'UBICACION AGV', uds: 1, productividad: 7 }  // 0.1428...h
    ];
    SPEC.repartirTiempos(1, acts);
    // Valores completos (no 2 decimales)
    expect(acts[0].horasAsignadas).toBeCloseTo((1 / 3) / (1 / 3 + 1 / 7), 12);
    expect(acts[1].horasAsignadas).toBeCloseTo((1 / 7) / (1 / 3 + 1 / 7), 12);
    expect(Math.abs(suma(acts, 'horasAsignadas') - 1)).toBeLessThan(TOL);
  });

  it('Tiempo analizable 0 → reparto nulo sin NaN', () => {
    const acts = [{ actividad: 'PICKING AGV', uds: 100, productividad: 100 }];
    SPEC.repartirTiempos(0, acts);
    expect(acts[0].horasAsignadas).toBe(0);
    expect(acts[0].peso).toBe(1);
  });
});
