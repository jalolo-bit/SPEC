// Unit tests v6.1 — MEJORA 4/6: q17_PersonaDiaAnalitica + PERSON_DAILY_RECORD
//
// La nueva unidad de análisis es PERSONA + FECHA_OPERATIVA:
//   - una persona con varias tareas WMS el mismo día = UN solo grupo
//   - el volumen se agrega por ACTIVIDAD_ANALISIS
//   - el reparto conserva TIEMPO_ANALIZABLE exactamente
//   - registros con clave estable login|fechaOperativaISO (sin duplicados)
//   - los records conservan mappingHash (históricos inmutables al cambiar mapping)

import { describe, it, expect, beforeAll } from 'vitest';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const SPEC = globalThis.SPEC;
const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(__dirname, '..', '..');
const TOL = 1e-9;

// ---------- Builders de filas con la MISMA estructura que las queries del motor ----------
let __idReg = 0;
function hRow({ fecha, login, name, horas, hrTask = '20099 ONTIGOLA-ECOM-STOCK-ENTRADAS-AUDITORIAS' }) {
  __idReg++;
  return {
    'Site name': 'ONTIGOLA INDITEX',
    'Department': '5-ITX-QUALITY',
    'Activity': '5.1',
    'Subactivity': '5.2',
    'FechaOriginal': fecha,
    'HR Task': hrTask,
    'WMSLoginOriginal': login,
    'Name': name,
    'HorasSinVolumen': horas,
    'ArchivoOrigen': 'test.xlsx',
    'FilaOrigen': 2,
    'Fecha': SPEC.fx_Fecha(fecha),
    'LoginOriginal': login,
    'LoginOriginalLimpio': login,
    'LoginCanonico': login,
    'IdNumerico': '0499',
    'IdNumericoLiteral': '0499',
    'IdNumericoNormalizado': '499',
    'PrefijoLogin': 'OTO',
    'IdRegistroHoras': __idReg
  };
}

function vmRow({ fecha, login, task, uds }) {
  return {
    'Fecha': SPEC.fx_Fecha(fecha),
    'LoginCanonico': login,
    'IdNumericoNormalizado': String(login).replace(/\D/g, ''),
    'WMS_TASK': task,
    'SAP_CODE': 'ES146L',
    'CUSTOMER': 'INDITEX ECOM',
    'VolumenPositivo': uds,
    'TasksSPEC': '20051 ONTIGOLA-ECOM-PICKING',
    'EstadoMapeoFinal': 'UNICO',
    'WMS_DCs': 'ONTIGOLA',
    'ArchivoOrigen': 'v.xlsx',
    'FilaOrigen': 2
  };
}

const OPCIONES = { productividades: SPEC.PARAMS.ProductividadesReferencia, taskOverrides: {} };

describe('v6.1 MEJORA 4 — q17_PersonaDiaAnalitica (unidad PERSONA + FECHA_OPERATIVA)', () => {
  it('Persona con 2 tareas WMS el mismo día → UN solo grupo con 2 actividades', () => {
    const H = [
      hRow({ fecha: 46259, login: 'OTO0499', name: 'PEREZ LOPEZ JUAN', horas: 8 })
    ];
    const VM = [
      vmRow({ fecha: 46259, login: 'OTO0499', task: 'Picking ecommerce a matrícula - Bershka', uds: 600 }),
      vmRow({ fecha: 46259, login: 'OTO0499', task: 'Ubicación con cantidad - Oysho', uds: 1040 })
    ];
    const grupos = SPEC.q17_PersonaDiaAnalitica(H, VM, [], OPCIONES);
    expect(grupos.length).toBe(1); // UNA revisión
    const g = grupos[0];
    expect(g.login).toBe('OTO0499');
    expect(g.actividades.length).toBe(2); // PICKING MANUAL + UBICACION MANUAL
    expect(g.horasAnalizables).toBe(8);
    expect(Math.abs(g.actividades.reduce((s, a) => s + a.horasAsignadas, 0) - 8)).toBeLessThan(TOL);
  });

  it('Persona con 3 tareas WMS → reparto correcto del tiempo (ejemplo del usuario)', () => {
    const H = [
      hRow({ fecha: 46259, login: 'OTO0500', name: 'GARCIA MARTA', horas: 8 })
    ];
    const VM = [
      vmRow({ fecha: 46259, login: 'OTO0500', task: 'Picking ecommerce a matrícula - Bershka', uds: 900 }),
      vmRow({ fecha: 46259, login: 'OTO0500', task: 'Picking sin papel - Oysho', uds: 600 }),
      vmRow({ fecha: 46259, login: 'OTO0500', task: 'Ubicación directa AGV - Bershka', uds: 520 })
    ];
    const grupos = SPEC.q17_PersonaDiaAnalitica(H, VM, [], OPCIONES);
    const g = grupos[0];
    // Picking manual agregado: 900 + 600 = 1500 uds / 100 = 15 h equiv
    // Ubicación AGV: 520 / 240 = 2.1667 h equiv
    const pick = g.actividades.find(a => a.actividad === 'PICKING MANUAL');
    const ubic = g.actividades.find(a => a.actividad === 'UBICACION AGV');
    expect(pick.uds).toBe(1500);
    expect(pick.horasEquivalentes).toBeCloseTo(15, 10);
    expect(ubic.horasEquivalentes).toBeCloseTo(520 / 240, 10);
    // Reparto de las 8 h reales con esos pesos
    const totalHe = 15 + 520 / 240;
    expect(pick.horasAsignadas).toBeCloseTo(8 * 15 / totalHe, 10);
    expect(ubic.horasAsignadas).toBeCloseTo(8 * (520 / 240) / totalHe, 10);
    expect(Math.abs(pick.horasAsignadas + ubic.horasAsignadas - 8)).toBeLessThan(TOL);
    // Productividad implícita
    expect(pick.productividadImplicita).toBeCloseTo(1500 / pick.horasAsignadas, 6);
  });

  it('Varias personas/días → grupos independientes con clave estable', () => {
    const H = [
      hRow({ fecha: 46259, login: 'OTO0001', name: 'A', horas: 8 }),
      hRow({ fecha: 46259, login: 'OTO0002', name: 'B', horas: 6 }),
      hRow({ fecha: 46260, login: 'OTO0001', name: 'A', horas: 7 }) // día distinto
    ];
    const grupos = SPEC.q17_PersonaDiaAnalitica(H, [], [], OPCIONES);
    expect(grupos.length).toBe(3);
    const keys = grupos.map(g => g.key).sort();
    expect(keys).toContain('OTO0001|' + SPEC.formatFechaISO(SPEC.fx_Fecha(46259)));
    expect(keys).toContain('OTO0002|' + SPEC.formatFechaISO(SPEC.fx_Fecha(46259)));
    expect(keys).toContain('OTO0001|' + SPEC.formatFechaISO(SPEC.fx_Fecha(46260)));
  });

  it('Persona con varias horas fichadas el mismo día → horasAnalizables = suma', () => {
    const H = [
      hRow({ fecha: 46259, login: 'OTO0003', name: 'C', horas: 2.5, hrTask: '20051 ONTIGOLA-ECOM-PICKING' }),
      hRow({ fecha: 46259, login: 'OTO0003', name: 'C', horas: 1.25, hrTask: '20080 ONTIGOLA-ECOM-UBICACION-CD' }),
      hRow({ fecha: 46259, login: 'OTO0003', name: 'C', horas: 0.75, hrTask: '20091 ONTIGOLA-ECOM-STOCK-AUDITORIAS' })
    ];
    const grupos = SPEC.q17_PersonaDiaAnalitica(H, [], [], OPCIONES);
    expect(grupos.length).toBe(1);
    expect(grupos[0].horasAnalizables).toBeCloseTo(4.5, 10);
    expect(grupos[0].horasFichadas).toBeCloseTo(4.5, 10);
    expect(grupos[0].registros.length).toBe(3);
  });

  it('Fecha operativa nocturna: registro 26/08 02:15 se agrupa en el día 25/08', () => {
    const H = [
      hRow({ fecha: 46260 + 2.25 / 24, login: 'OTO0004', name: 'D', horas: 3 }) // 26/08 02:15
    ];
    const grupos = SPEC.q17_PersonaDiaAnalitica(H, [], [], OPCIONES);
    expect(grupos.length).toBe(1);
    expect(grupos[0].turno).toBe('NOCHE');
    expect(SPEC.formatFechaISO(grupos[0].fechaOperativa)).toBe(SPEC.formatFechaISO(SPEC.fx_Fecha(46259)));
    // Y el volumen del 25/08 es el que se le asocia (fecha operativa)
    const VM = [
      vmRow({ fecha: 46259, login: 'OTO0004', task: 'Picking sin papel - Oysho', uds: 400 })
    ];
    const grupos2 = SPEC.q17_PersonaDiaAnalitica(H, VM, [], OPCIONES);
    expect(grupos2[0].udsTotales).toBe(400);
    expect(grupos2[0].actividades[0].actividad).toBe('PICKING MANUAL');
  });

  it('Datos day-level (sin hora) → turno SIN HORA, fecha operativa = fecha', () => {
    const H = [hRow({ fecha: 46259, login: 'OTO0005', name: 'E', horas: 8 })];
    const grupos = SPEC.q17_PersonaDiaAnalitica(H, [], [], OPCIONES);
    expect(grupos[0].turno).toBe('SIN HORA');
    expect(SPEC.formatFechaISO(grupos[0].fechaOperativa)).toBe(SPEC.formatFechaISO(SPEC.fx_Fecha(46259)));
  });

  it('Tareas OTRA quedan fuera del reparto productivo', () => {
    const H = [hRow({ fecha: 46259, login: 'OTO0006', name: 'F', horas: 8 })];
    const VM = [
      vmRow({ fecha: 46259, login: 'OTO0006', task: 'Mover SKU - Bershka', uds: 500 }),
      vmRow({ fecha: 46259, login: 'OTO0006', task: 'REPARTO A TIENDA AGV - BERSHKA', uds: 300 })
    ];
    const grupos = SPEC.q17_PersonaDiaAnalitica(H, VM, [], OPCIONES);
    const g = grupos[0];
    expect(g.udsTotales).toBe(800);
    expect(g.actividades.every(a => a.actividad === 'OTRA')).toBe(true);
    expect(g.actividades.every(a => a.horasAsignadas === 0)).toBe(true);
    expect(g.sumaHorasEquivalentes).toBe(0);
    // La desviación es todo el tiempo (no hay HE estimadas)
    expect(g.desviacion).toBe(8);
  });

  it('desviacion = horasAnalizables − Σ horasEquivalentes', () => {
    const H = [hRow({ fecha: 46259, login: 'OTO0007', name: 'G', horas: 5 })];
    const VM = [vmRow({ fecha: 46259, login: 'OTO0007', task: 'Picking sin papel - Oysho', uds: 250 })]; // 2.5 HE
    const g = SPEC.q17_PersonaDiaAnalitica(H, VM, [], OPCIONES)[0];
    expect(g.sumaHorasEquivalentes).toBeCloseTo(2.5, 10);
    expect(g.desviacion).toBeCloseTo(2.5, 10);
  });

  it('Fallback MISMO NUMERO, DISTINTO PREFIJO cuando no hay login exacto', () => {
    const H = [hRow({ fecha: 46259, login: 'OTO0008', name: 'H', horas: 4 })];
    const VM = [vmRow({ fecha: 46259, login: 'ZH0008', task: 'Picking sin papel - Oysho', uds: 200 })];
    const g = SPEC.q17_PersonaDiaAnalitica(H, VM, [], OPCIONES)[0];
    expect(g.modoVolumen).toBe('MISMO NUMERO, DISTINTO PREFIJO');
    expect(g.udsTotales).toBe(200);
  });
});

describe('v6.1 MEJORA 6 — generarPersonDailyRecords (modelo histórico)', () => {
  const H = [
    hRow({ fecha: 46259, login: 'OTO0499', name: 'PEREZ LOPEZ JUAN', horas: 8 })
  ];
  const VM = [
    vmRow({ fecha: 46259, login: 'OTO0499', task: 'Picking ecommerce a matrícula - Bershka', uds: 900 }),
    vmRow({ fecha: 46259, login: 'OTO0499', task: 'Ubicación directa AGV - Bershka', uds: 520 })
  ];

  function construirReporte(grupos) {
    // Mínimo reporte sintético vinculado por ID REGISTRO real del grupo
    const idReg = grupos[0].registros[0].idRegistroHoras;
    return [{
      'SECCION': '1. CAMBIO HR TASK PROPUESTO',
      'ID REGISTRO': idReg,
      'FILA ORIGEN': '2',
      'HORAS SIN VOLUMEN': 8,
      'HR TASK FICHADA': '20099 ONTIGOLA-ECOM-STOCK-ENTRADAS-AUDITORIAS',
      'TASKSPEC SEGUN MAPPING': '20051 ONTIGOLA-ECOM-PICKING',
      'REQUIERE CAMBIO RRHH': 'SI'
    }];
  }

  it('Estructura completa del registro (todos los campos obligatorios)', () => {
    const grupos = SPEC.q17_PersonaDiaAnalitica(H, VM, [], OPCIONES);
    const recs = SPEC.generarPersonDailyRecords(grupos, construirReporte(grupos), {
      mappingHash: 'abc123', mappingVersion: 3, productividades: OPCIONES.productividades,
      appVersion: '6.1.0-test', sessionId: 'sess-test'
    });
    expect(recs.length).toBe(1);
    const r = recs[0];
    expect(r.key).toBe('OTO0499|' + SPEC.formatFechaISO(SPEC.fx_Fecha(46259)));
    expect(r.login).toBe('OTO0499');
    expect(r.persona).toBe('PEREZ LOPEZ JUAN');
    expect(typeof r.fechaOperativaISO).toBe('string');
    expect(r.semana).toMatch(/^\d{4}-W\d{2}$/);
    expect(r.mes).toMatch(/^\d{4}-\d{2}$/);
    expect(r.turno).toBe('SIN HORA');
    expect(r.horasFichadas).toBe(8);
    expect(r.horasAnalizables).toBe(8);
    expect(r.udsTotales).toBe(1420);
    expect(typeof r.horasEquivalentes).toBe('number');
    expect(typeof r.horasAsignadas).toBe('number');
    expect(Math.abs(r.horasAsignadas - 8)).toBeLessThan(TOL);
    expect(r.nActividades).toBe(2);
    expect(Array.isArray(r.actividades)).toBe(true);
    expect(Array.isArray(r.incidencias)).toBe(true);
    expect(r.nIncidencias).toBe(1);
    expect(r.mappingHash).toBe('abc123');
    expect(r.mappingVersion).toBe(3);
    expect(r.appVersion).toBe('6.1.0-test');
    expect(r.sessionId).toBe('sess-test');
    expect(r.version).toBe(1);
    expect(typeof r.dataFingerprint).toBe('string');
    expect(Array.isArray(r.previousVersions)).toBe(true);
  });

  it('Clave estable: reprocesar el mismo persona/día NO duplica (misma key)', () => {
    const g1 = SPEC.q17_PersonaDiaAnalitica(H, VM, [], OPCIONES);
    const g2 = SPEC.q17_PersonaDiaAnalitica(H, VM, [], OPCIONES);
    const r1 = SPEC.generarPersonDailyRecords(g1, construirReporte(g1), {})[0];
    const r2 = SPEC.generarPersonDailyRecords(g2, construirReporte(g2), {})[0];
    expect(r1.key).toBe(r2.key);
    expect(r1.dataFingerprint).toBe(r2.dataFingerprint); // mismos datos → mismo fingerprint
  });

  it('Los históricos NO cambian si cambia el mapping: el record conserva SU hash', () => {
    const g = SPEC.q17_PersonaDiaAnalitica(H, VM, [], OPCIONES);
    const r = SPEC.generarPersonDailyRecords(g, construirReporte(g), { mappingHash: 'HASH_ANTIGUO' })[0];
    // Simulamos que después se procesa con otro mapping...
    const r2 = SPEC.generarPersonDailyRecords(g, construirReporte(g), { mappingHash: 'HASH_NUEVO' })[0];
    // ...el registro original sigue siendo interpretable con SU mappingHash
    expect(r.mappingHash).toBe('HASH_ANTIGUO');
    expect(r2.mappingHash).toBe('HASH_NUEVO');
    expect(r.key).toBe(r2.key); // mismo persona/día → upsert con versionado en la UI
  });

  it('Cambian los datos → cambia el fingerprint (nueva versión trazable)', () => {
    const g1 = SPEC.q17_PersonaDiaAnalitica(H, VM, [], OPCIONES);
    const VM2 = [vmRow({ fecha: 46259, login: 'OTO0499', task: 'Picking ecommerce a matrícula - Bershka', uds: 1000 })];
    const g2 = SPEC.q17_PersonaDiaAnalitica(H, VM2, [], OPCIONES);
    const r1 = SPEC.generarPersonDailyRecords(g1, construirReporte(g1), {})[0];
    const r2 = SPEC.generarPersonDailyRecords(g2, construirReporte(g2), {})[0];
    expect(r1.dataFingerprint).not.toBe(r2.dataFingerprint);
  });

  it('horasConIncidencia cuenta cada registro de horas UNA vez (dedupe)', () => {
    const g = SPEC.q17_PersonaDiaAnalitica(H, VM, [], OPCIONES);
    const idReg = g[0].registros[0].idRegistroHoras;
    const reporteMulti = [
      { 'SECCION': '2. VARIAS TASKSPEC CON VOLUMEN', 'ID REGISTRO': idReg, 'FILA ORIGEN': '2', 'HORAS SIN VOLUMEN': 8, 'HR TASK FICHADA': 'X', 'TASKSPEC SEGUN MAPPING': 'A', 'REQUIERE CAMBIO RRHH': 'REVISAR' },
      { 'SECCION': '2. VARIAS TASKSPEC CON VOLUMEN', 'ID REGISTRO': idReg, 'FILA ORIGEN': '5', 'HORAS SIN VOLUMEN': 8, 'HR TASK FICHADA': 'X', 'TASKSPEC SEGUN MAPPING': 'B', 'REQUIERE CAMBIO RRHH': 'REVISAR' },
      { 'SECCION': '4. SIN VOLUMEN', 'ID REGISTRO': idReg, 'FILA ORIGEN': '', 'HORAS SIN VOLUMEN': 8, 'HR TASK FICHADA': 'X', 'TASKSPEC SEGUN MAPPING': '', 'REQUIERE CAMBIO RRHH': 'REVISAR' }
    ];
    const r = SPEC.generarPersonDailyRecords(g, reporteMulti, {})[0];
    expect(r.nIncidencias).toBe(3); // 3 propuestas
    expect(r.horasConIncidencia).toBe(8); // pero las horas solo UNA vez
  });

  it('Semana y mes ISO correctos (validado contra isocalendar de Python)', () => {
    // 46259 = 2026-08-25 (martes) → semana 2026-W35, mes 2026-08
    const d = SPEC.fx_Fecha(46259);
    expect(SPEC.isoSemana(d)).toBe('2026-W35');
    expect(SPEC.isoMes(d)).toBe('2026-08');
    // 46251 = 2026-08-17 (lunes) → 2026-W34
    const d2 = SPEC.fx_Fecha(46251);
    expect(SPEC.isoSemana(d2)).toBe('2026-W34');
    // 2026-01-01 (jueves) → W01
    const d3 = new Date(Date.UTC(2026, 0, 1));
    expect(SPEC.isoSemana(d3)).toBe('2026-W01');
    // 2027-01-01 (viernes) → 2026-W53 (año ISO largo)
    const d4 = new Date(Date.UTC(2027, 0, 1));
    expect(SPEC.isoSemana(d4)).toBe('2026-W53');
    // 2026-09-26 (sábado) → W39 (cruce de límite de año ISO no aplica, sanity)
    const d5 = new Date(Date.UTC(2026, 8, 26));
    expect(SPEC.isoSemana(d5)).toBe('2026-W39');
  });
});
