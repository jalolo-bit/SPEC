/* Tests v6.2 — calidad de datos y del mapping (dataQualityAnalytics.js).
 * §29/§30/§31/§49/§50: separación operativo vs datos, SIN HORA, OTRA,
 * sin mapping, cambios de mapping, versiones. */
import { describe, it, expect } from 'vitest';
import { mkRecord, SEC, incSec } from '../helpers/analyticsFixtures.js';

const AN = globalThis.SPEC_AN;
const N = AN.normalizarRecords;
const D = AN.DEFAULT_CONFIG;

describe('dataQualityAnalytics — calidad de datos (§49)', () => {
  it('cuenta días, registros, sin hora, OTRA y tipos de incidencia', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', turno: 'SIN HORA', turnos: ['SIN HORA'], tareas: [{ taskWms: 'OTRA1', actividad: 'OTRA', uds: 100, productividad: null }], incidencias: [incSec(SEC.cambio, { horasAfectadas: 2 }), incSec(SEC.correcta)] }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-25', incidencias: [incSec(SEC.sinMap, { wmsTask: 'SIN MAPEO', horasAfectadas: 1 })] }),
      mkRecord({ login: 'C', fechaOperativaISO: '2026-08-26', incidencias: [incSec(SEC.sinVol, { horasAfectadas: 8 })] })
    ]);
    const dq = AN.dataQuality.computeDataQuality(recs);
    expect(dq.diasCargados).toBe(2);
    expect(dq.registros).toBe(3);
    expect(dq.registrosSinHora).toBe(1);
    expect(dq.pctSinHora).toBeCloseTo(33.33, 1);
    expect(dq.registrosOtra).toBe(1);
    expect(dq.tareasOtra).toBe(1);
    expect(dq.udsOtra).toBe(100);
    expect(dq.casosSinMapping).toBe(1);
    expect(dq.tareasSinMapping).toBe(1); // contador; el detalle vive en computeMappingQuality
    expect(dq.datosIncompletos).toBe(1); // sección 4
  });

  it('§50 separa causas operativo / datos / revisión / control', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', incidencias: [incSec(SEC.cambio), incSec(SEC.sinVol)] }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-26', incidencias: [incSec(SEC.sinMap), incSec(SEC.varias)] }),
      mkRecord({ login: 'C', fechaOperativaISO: '2026-08-27', incidencias: [incSec(SEC.multi), incSec(SEC.correcta)] })
    ]);
    const dq = AN.dataQuality.computeDataQuality(recs);
    expect(dq.totalIncidencias).toBe(6);
    expect(dq.repartoCausas.operativo.casos).toBe(2); // secciones 1+4
    expect(dq.repartoCausas.datos.casos).toBe(2);     // secciones 2+5
    expect(dq.repartoCausas.revision.casos).toBe(1);  // sección 6
    expect(dq.repartoCausas.control.casos).toBe(1);  // sección 3
    // los porcentajes suman ~100
    const suma = dq.repartoCausas.operativo.pct + dq.repartoCausas.datos.pct + dq.repartoCausas.revision.pct + dq.repartoCausas.control.pct;
    expect(suma).toBeCloseTo(100, 0);
  });

  it('tipos con categoría, casos, horas, personas y días', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', incidencias: [incSec(SEC.cambio, { horasAfectadas: 3 })] }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-26', incidencias: [incSec(SEC.cambio, { horasAfectadas: 2 })] })
    ]);
    const dq = AN.dataQuality.computeDataQuality(recs);
    const fichaje = dq.tipos.find(t => t.tipo === 'ERROR DE FICHAJE');
    expect(fichaje.casos).toBe(2);
    expect(fichaje.horas).toBe(5);
    expect(fichaje.personas).toBe(1);
    expect(fichaje.dias).toBe(2);
    expect(fichaje.categoria).toBe('OPERATIVO');
  });

  it('versiones por reprocesado y uds de VOL SIN HORAS', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', previousVersions: [{ version: 1 }], udsSinHoras: 50 })
    ]);
    const dq = AN.dataQuality.computeDataQuality(recs);
    expect(dq.duplicadosVersionados).toBe(1); // trazabilidad, NO duplicado
    expect(dq.udsSinHorasArchivo).toBe(50);
  });

  it('modoVolumen (login exacto vs id numérico vs sin volumen)', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', modoVolumen: 'LOGIN EXACTO' }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-25', modoVolumen: 'MISMO NUMERO, DISTINTO PREFIJO' }),
      mkRecord({ login: 'C', fechaOperativaISO: '2026-08-25', modoVolumen: null, incidencias: [incSec(SEC.sinVol)] })
    ]);
    const dq = AN.dataQuality.computeDataQuality(recs);
    expect(dq.modoVolumen.loginExacto).toBe(1);
    expect(dq.modoVolumen.idNumerico).toBe(1);
    expect(dq.modoVolumen.sinVolumen).toBe(1);
  });

  it('histórico vacío → ceros sin NaN (§58)', () => {
    const dq = AN.dataQuality.computeDataQuality([]);
    for (const k of ['diasCargados', 'registros', 'registrosSinHora', 'pctSinHora', 'casosSinMapping', 'datosIncompletos']) {
      expect(dq[k], k).toBeTypeOf('number');
      expect(isFinite(dq[k]), k).toBe(true);
    }
    expect(dq.pctSinHora).toBe(0);
  });
});

describe('dataQualityAnalytics — calidad del mapping (§30/§31)', () => {
  it('detecta tareas sin mapping, ambiguas, OTRA y clasificadas', () => {
    const recs = N([
      mkRecord({
        login: 'A', fechaOperativaISO: '2026-08-25', mappingHash: 'h1',
        tareas: [
          { taskWms: 'CLASIFICADA 1', actividad: 'PICKING MANUAL', uds: 100 },
          { taskWms: 'OTRA X', actividad: 'OTRA', uds: 200, productividad: null }
        ],
        incidencias: [incSec(SEC.sinMap, { wmsTask: 'SIN MAP 1' }), incSec(SEC.varias, { tareaOriginal: 'AMB 1' })]
      })
    ]);
    const mq = AN.dataQuality.computeMappingQuality(recs);
    expect(mq.tareasSinMapping.length).toBe(1);
    expect(mq.tareasSinMapping[0].taskWms).toBe('SIN MAP 1');
    expect(mq.tareasAmbiguas.length).toBe(1);
    expect(mq.tareasOtra.length).toBe(1);
    expect(mq.tareasOtra[0].uds).toBe(200);
    expect(mq.tareasClasificadas).toBe(1);
    expect(mq.cambiosMapping).toBe(0);
  });

  it('histórico de mappings usados: cambio de mapping NO mezcla periodos (§31)', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', mappingHash: 'h1' }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-26', mappingHash: 'h2' }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-27', mappingHash: 'h2' })
    ]);
    const mq = AN.dataQuality.computeMappingQuality(recs);
    expect(mq.mappings.length).toBe(2);
    expect(mq.cambiosMapping).toBe(1);
    expect(mq.mappings[0].hash).toBe('h1');
    expect(mq.mappings[0].registros).toBe(1);
    expect(mq.mappings[1].registros).toBe(2);
    expect(mq.mappings[1].primeraFecha).toBe('2026-08-26');
  });

  it('sin datos → todo vacío y sin NaN', () => {
    const mq = AN.dataQuality.computeMappingQuality([]);
    expect(mq.tareasSinMapping).toEqual([]);
    expect(mq.tareasClasificadas).toBe(0);
    expect(mq.cambiosMapping).toBe(0);
    expect(mq.mappings).toEqual([]);
  });
});
