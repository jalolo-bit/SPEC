// Smoke test for the tests/setup.js infrastructure.
//
// Confirms that vitest's setupFiles correctly attaches XLSX and SPEC to the
// Node global scope. This test file lives in tests/unit/ so it doubles as
// a placeholder until the main agent or another subagent adds real unit
// tests for app.js functions (which would assert specific business-rule
// behavior of fx_NormalizaTexto / fx_NormalizaLogin / fx_Fecha etc.).
//
// This file intentionally does NOT assert business-rule behavior — those
// expectations belong in dedicated unit tests, not in the smoke test.

import { describe, it, expect } from 'vitest';

describe('tests/setup.js smoke test', () => {
  it('exposes XLSX on globalThis', () => {
    expect(globalThis.XLSX).toBeDefined();
    expect(typeof globalThis.XLSX.read).toBe('function');
    expect(typeof globalThis.XLSX.utils).toBe('object');
  });

  it('exposes SPEC on globalThis after eval-ing app.js', () => {
    expect(globalThis.SPEC).toBeDefined();
    expect(typeof globalThis.SPEC).toBe('object');
  });

  it('exposes the public SPEC API surface we rely on', () => {
    expect(typeof globalThis.SPEC.PARAMS).toBe('object');
    expect(typeof globalThis.SPEC.STATE).toBe('object');
    // Pure-function exports from app.js — these are the unit-testable surface.
    expect(typeof globalThis.SPEC.fx_NormalizaTexto).toBe('function');
    expect(typeof globalThis.SPEC.fx_NormalizaLogin).toBe('function');
    expect(typeof globalThis.SPEC.fx_Fecha).toBe('function');
    expect(typeof globalThis.SPEC.numberFrom).toBe('function');
    expect(typeof globalThis.SPEC.calcularMaterialidad).toBe('function');
    // The async entrypoint used by the equivalence tests.
    expect(typeof globalThis.SPEC.analizarYConciliar).toBe('function');
    // Export helpers.
    expect(typeof globalThis.SPEC.exportToXlsx).toBe('function');
    expect(typeof globalThis.SPEC.exportToCsv).toBe('function');
  });
});
