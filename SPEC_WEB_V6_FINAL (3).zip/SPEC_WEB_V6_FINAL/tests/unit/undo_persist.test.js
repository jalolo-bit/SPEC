// Unit tests v6.1 — MEJORA 5: núcleo puro de UNDO (real + persistente + auditable)
//
// Casos obligatorios del usuario:
//   aceptar → undo · rechazar → undo · mantener → undo ·
//   varias acciones → varios undo · persistencia del undo (estructura)
// El bug original: undoDecision usaba findIndex (la entrada MÁS ANTIGUA del id)
// → con acciones consecutivas restauraba un estado obsoleto.

import { describe, it, expect } from 'vitest';

const SPEC = globalThis.SPEC;

describe('v6.1 MEJORA 5 — undoFindLatestIndex / undoApply (núcleo puro)', () => {
  it('aceptar → undo → estado vuelve al anterior (sin decisión)', () => {
    const decisions = {};
    const undoStack = [];
    // Acción ACEPTAR: antes no había decisión → prev = null
    undoStack.push({ id: 'X', prev: null, timestamp: 1 });
    decisions['X'] = { decision: 'aceptada', timestamp: 2 };
    const res = SPEC.undoApply(undoStack, decisions, 'X');
    expect(res.ok).toBe(true);
    expect(res.restored).toBe(true);
    expect(res.decisions['X']).toBeUndefined(); // vuelve a pendiente
    expect(res.undoStack.length).toBe(0);
    expect(res.estadoAnterior).toBeNull();
  });

  it('aceptar → undo restaura los campos completos de la decisión previa', () => {
    const decisions = {};
    const undoStack = [];
    const previa = { decision: 'revisar', tareaFinal: 'T1', motivo: 'revisar mañana', timestamp: 100 };
    decisions['X'] = previa;
    undoStack.push({ id: 'X', prev: Object.assign({}, previa), timestamp: 101 });
    decisions['X'] = { decision: 'aceptada', tareaFinal: 'T2', timestamp: 102 };
    const res = SPEC.undoApply(undoStack, decisions, 'X');
    expect(res.decisions['X'].decision).toBe('revisar');
    expect(res.decisions['X'].tareaFinal).toBe('T1');
    expect(res.decisions['X'].motivo).toBe('revisar mañana');
    expect(res.decisions['X']).not.toBe(previa); // copia, no la misma referencia
  });

  it('rechazar → undo → restaurado', () => {
    const decisions = {};
    const undoStack = [];
    undoStack.push({ id: 'R', prev: null });
    decisions['R'] = { decision: 'rechazada' };
    const res = SPEC.undoApply(undoStack, decisions, 'R');
    expect(res.decisions['R']).toBeUndefined();
  });

  it('mantener → undo → restaurado', () => {
    const decisions = {};
    const undoStack = [];
    undoStack.push({ id: 'M', prev: null });
    decisions['M'] = { decision: 'mantenida' };
    const res = SPEC.undoApply(undoStack, decisions, 'M');
    expect(res.decisions['M']).toBeUndefined();
  });

  it('CAMBIO DE MOTIVO → undo restaura el motivo anterior', () => {
    const decisions = {};
    const undoStack = [];
    decisions['C'] = { decision: 'aceptada', motivo: 'motivo v1' };
    undoStack.push({ id: 'C', prev: { decision: 'aceptada', motivo: 'motivo v1' } });
    decisions['C'] = { decision: 'aceptada', motivo: 'motivo v2' };
    const res = SPEC.undoApply(undoStack, decisions, 'C');
    expect(res.decisions['C'].motivo).toBe('motivo v1');
  });

  it('ACCIONES CONSECUTIVAS: aceptar → mantener → undo → vuelve a ACEPTADA (bug fix)', () => {
    const decisions = {};
    const undoStack = [];
    // 1ª acción: aceptar
    undoStack.push({ id: 'X', prev: null, timestamp: 1 });
    decisions['X'] = { decision: 'aceptada', timestamp: 1 };
    // 2ª acción: mantener (guarda la aceptada como previa)
    undoStack.push({ id: 'X', prev: { decision: 'aceptada', timestamp: 1 }, timestamp: 2 });
    decisions['X'] = { decision: 'mantenida', timestamp: 2 };
    expect(undoStack.length).toBe(2);
    // UNDO: debe restaurar la MÁS RECIENTE (aceptada), no la primera (null)
    const r1 = SPEC.undoApply(undoStack, decisions, 'X');
    expect(r1.decisions['X'].decision).toBe('aceptada');
    expect(r1.undoStack.length).toBe(1);
    // Segundo UNDO: vuelve a pendiente
    const r2 = SPEC.undoApply(r1.undoStack, r1.decisions, 'X');
    expect(r2.decisions['X']).toBeUndefined();
    expect(r2.undoStack.length).toBe(0);
  });

  it('VARIOS UNDO sobre distintas incidencias mezcladas', () => {
    const decisions = {};
    const undoStack = [];
    undoStack.push({ id: 'A', prev: null });
    decisions['A'] = { decision: 'aceptada' };
    undoStack.push({ id: 'B', prev: null });
    decisions['B'] = { decision: 'mantenida' };
    undoStack.push({ id: 'A', prev: { decision: 'aceptada' } });
    decisions['A'] = { decision: 'revisar' };
    // Undo de B (posición 1)
    const rb = SPEC.undoApply(undoStack, decisions, 'B');
    expect(rb.decisions['B']).toBeUndefined();
    expect(rb.decisions['A'].decision).toBe('revisar'); // A intacta
    expect(rb.undoStack.length).toBe(2);
    // Undo de A (la más reciente de A → vuelve a aceptada)
    const ra = SPEC.undoApply(rb.undoStack, rb.decisions, 'A');
    expect(ra.decisions['A'].decision).toBe('aceptada');
    expect(ra.undoStack.length).toBe(1);
  });

  it('undo de un id sin entradas → ok=false sin efectos', () => {
    const decisions = { 'X': { decision: 'aceptada' } };
    const undoStack = [{ id: 'Y', prev: null }];
    const res = SPEC.undoApply(undoStack, decisions, 'X');
    expect(res.ok).toBe(false);
    expect(res.restored).toBe(false);
    expect(res.decisions).toBe(decisions); // mismas referencias, sin cambios
    expect(res.decisions['X'].decision).toBe('aceptada');
  });

  it('undoFindLatestIndex devuelve el ÍNDICE de la entrada más reciente', () => {
    const stack = [
      { id: 'A', prev: null },
      { id: 'B', prev: null },
      { id: 'A', prev: { decision: 'x' } }
    ];
    expect(SPEC.undoFindLatestIndex(stack, 'A')).toBe(2); // la última, no la 0
    expect(SPEC.undoFindLatestIndex(stack, 'B')).toBe(1);
    expect(SPEC.undoFindLatestIndex(stack, 'Z')).toBe(-1);
    expect(SPEC.undoFindLatestIndex([], 'A')).toBe(-1);
    expect(SPEC.undoFindLatestIndex(null, 'A')).toBe(-1);
  });

  it('No muta los inputs (pureza): decisions y undoStack originales intactos', () => {
    const decisions = { 'X': { decision: 'mantenida' } };
    const undoStack = [{ id: 'X', prev: { decision: 'aceptada' } }];
    const res = SPEC.undoApply(undoStack, decisions, 'X');
    expect(res.decisions['X'].decision).toBe('aceptada');
    expect(decisions['X'].decision).toBe('mantenida'); // original sin tocar
    expect(undoStack.length).toBe(1); // original sin tocar
  });

  it('Estructura de persistencia del undo (formato guardado en localStorage/IDB)', () => {
    // Lo que persistDecisions guarda en 'spec_decisions' debe incluir undoStack
    // (verificado en E2E; aquí validamos la forma de las entradas)
    const entry = { id: 'X', prev: { decision: 'aceptada', tareaFinal: 'T', motivo: 'M', timestamp: 1 }, timestamp: 2 };
    expect(typeof entry.id).toBe('string');
    expect(entry.prev === null || typeof entry.prev === 'object').toBe(true);
    expect(typeof entry.timestamp).toBe('number');
  });
});
