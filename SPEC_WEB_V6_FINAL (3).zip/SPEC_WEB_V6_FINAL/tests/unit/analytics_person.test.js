/* Tests v6.2 — analítica por persona (personAnalytics.js).
 * §7/§8/§9/§18/§19/§22: rankings, no castigar por más días, semáforo,
 * muestra pequeña, mejora/empeoramiento con evidencia, rachas. */
import { describe, it, expect } from 'vitest';
import { mkRecord, SEC, incSec } from '../helpers/analyticsFixtures.js';

const AN = globalThis.SPEC_AN;
const N = AN.normalizarRecords;

describe('personAnalytics — estadísticas por persona (§7)', () => {
  it('agrega días, errores, horas y recurrencia por login', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', horasAnalizables: 8, incidencias: [incSec(SEC.cambio, { horasAfectadas: 2 }), incSec(SEC.correcta)] }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-26', horasAnalizables: 8 }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-27', horasAnalizables: 8, incidencias: [incSec(SEC.cambio, { horasAfectadas: 1 })] })
    ]);
    const st = AN.person.computePersonStats(recs, AN.DEFAULT_CONFIG);
    expect(st.length).toBe(1);
    const p = st[0];
    expect(p.dias).toBe(3);
    expect(p.diasConError).toBe(2); // la sección 3 no es error
    expect(p.pctDiasConError).toBeCloseTo(66.67, 1);
    expect(p.incidencias).toBe(3);
    expect(p.errores).toBe(2);
    expect(p.horasAfectadas).toBe(3);
    expect(p.pctHorasAfectadas).toBeCloseTo(12.5, 2);
    expect(p.cambiosTarea).toBe(2);
    expect(p.erroresAsignacion).toBe(2);
  });

  it('§8 NO castiga a quien tiene más días: 10/100 NO es peor que 5/5', () => {
    const a = [], b = [];
    for (let i = 0; i < 100; i++) {
      const conErr = i < 10;
      a.push(mkRecord({ login: 'MUCHOS', fechaOperativaISO: '2026-' + String(Math.floor(i / 28) + 1).padStart(2, '0') + '-' + String(i % 28 + 1).padStart(2, '0'), incidencias: conErr ? [incSec(SEC.cambio)] : [] }));
    }
    for (let i = 0; i < 5; i++) {
      b.push(mkRecord({ login: 'POCOS', fechaOperativaISO: '2026-09-0' + (i + 1), incidencias: [incSec(SEC.cambio)] }));
    }
    const st = AN.person.computePersonStats(N(a.concat(b)), AN.DEFAULT_CONFIG);
    const muchos = st.find(p => p.login === 'MUCHOS'), pocos = st.find(p => p.login === 'POCOS');
    // Frecuencia vs tasa visibles a la vez:
    expect(muchos.errores).toBe(10);
    expect(muchos.pctDiasConError).toBe(10);
    expect(pocos.errores).toBe(5);
    expect(pocos.pctDiasConError).toBe(100);
    // El orden por tasa sitúa a POCOS peor (100%), pero MUCHOS queda marcado
    // con muestra pequeña para POCOS (5 < 3? no: 5 ≥ 3 → muestra válida) y
    // MUCHOS no se penaliza por frecuencia: su tasa es 10%.
    expect(pocos.muestraPequena).toBe(false);
    expect(st[0].login).toBe('POCOS'); // peor tasa primero
    // Pero el ranking muestra AMBOS datos: la persona con más días NO
    // aparece automáticamente peor:
    expect(muchos.semaforo).toBe('BUENO'); // 10% ≤ 10
    expect(pocos.semaforo).toBe('CRÍTICO'); // 100% > 50
  });

  it('muestra pequeña marcada por debajo del mínimo configurable (§39/§63)', () => {
    const recs = N([mkRecord({ login: 'UNO', fechaOperativaISO: '2026-08-25' }), mkRecord({ login: 'UNO', fechaOperativaISO: '2026-08-26' })]);
    const st = AN.person.computePersonStats(recs, AN.DEFAULT_CONFIG);
    expect(st[0].muestraPequena).toBe(true); // 2 < minObservaciones (3)
    const st2 = AN.person.computePersonStats(recs, Object.assign({}, AN.DEFAULT_CONFIG, { minObservaciones: 1 }));
    expect(st2[0].muestraPequena).toBe(false);
  });

  it('racha máxima de días consecutivos con error (huecos rompen)', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', incidencias: [incSec(SEC.cambio)] }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-26', incidencias: [incSec(SEC.cambio)] }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-27' }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-28', incidencias: [incSec(SEC.cambio)] })
    ]);
    const st = AN.person.computePersonStats(recs, AN.DEFAULT_CONFIG)[0];
    expect(st.maxRacha).toBe(2);
    expect(st.diasConError).toBe(3);
  });

  it('acumula turnos y días SIN HORA por persona', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', turno: 'SIN HORA', turnos: ['SIN HORA'] }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-26', turno: 'NOCHE', turnos: ['NOCHE'] })
    ]);
    const st = AN.person.computePersonStats(recs, AN.DEFAULT_CONFIG)[0];
    expect(st.sinHoraDias).toBe(1);
    expect(Array.from(st.turnos).sort()).toEqual(['NOCHE', 'SIN HORA']);
  });
});

describe('personAnalytics — semáforo (§9: umbrales documentados y configurables)', () => {
  const sem = (pct, dias, cfg) => AN.person.semaforoPersona(pct, dias, cfg || AN.DEFAULT_CONFIG);
  it('clasifica según los umbrales por defecto', () => {
    expect(sem(0, 5)).toBe('MUY BUENO');
    expect(sem(5, 5)).toBe('BUENO');
    expect(sem(20, 5)).toBe('NORMAL');
    expect(sem(40, 5)).toBe('ATENCIÓN');
    expect(sem(80, 5)).toBe('CRÍTICO');
  });
  it('con pocos días degrada a MUESTRA PEQUEÑA aunque el % sea alto', () => {
    expect(sem(100, 2)).toBe('MUESTRA PEQUEÑA');
    expect(sem(0, 2)).toBe('MUESTRA PEQUEÑA');
  });
  it('los umbrales son configurables', () => {
    const cfg = Object.assign({}, AN.DEFAULT_CONFIG, { semaforoBueno: 50, semaforoMinDias: 1 });
    expect(sem(40, 1, cfg)).toBe('BUENO');
    expect(sem(60, 2, cfg)).toBe('CRÍTICO');
  });
});

describe('personAnalytics — mejora/empeoramiento (§18/§19)', () => {
  it('detecta mejora sostenida con evidencia suficiente', () => {
    const recs = [];
    // 1ª mitad: 3 días con error de 4 → 75%
    for (let i = 1; i <= 4; i++) recs.push(mkRecord({ login: 'A', fechaOperativaISO: '2026-08-0' + i, incidencias: i <= 3 ? [incSec(SEC.cambio)] : [] }));
    // 2ª mitad: 0 de 4 → 0%
    for (let i = 10; i <= 13; i++) recs.push(mkRecord({ login: 'A', fechaOperativaISO: '2026-08-' + i }));
    const t = AN.person.computePersonTendencia(N(recs), AN.DEFAULT_CONFIG)[0];
    expect(t.suficiente).toBe(true); // 4 y 4 días por mitad ≥ 3
    expect(t.veredicto).toBe('MEJORA');
    expect(t.deltaPP).toBe(-75);
  });
  it('NO marca empeoramiento con 1 solo día de evidencia (§19)', () => {
    const recs = [
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25' }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-26' }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-27' }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-30', incidencias: [incSec(SEC.cambio)] })
    ];
    const t = AN.person.computePersonTendencia(N(recs), Object.assign({}, AN.DEFAULT_CONFIG, { minDiasComparar: 3 }))[0];
    expect(t.suficiente).toBe(false); // 2ª mitad solo 1 día
    expect(t.veredicto).toBe('SIN EVIDENCIA');
  });
  it('detecta empeoramiento sostenido', () => {
    const recs = [];
    for (let i = 1; i <= 3; i++) recs.push(mkRecord({ login: 'A', fechaOperativaISO: '2026-08-0' + i }));
    for (let i = 10; i <= 12; i++) recs.push(mkRecord({ login: 'A', fechaOperativaISO: '2026-08-' + i, incidencias: [incSec(SEC.cambio)] }));
    const t = AN.person.computePersonTendencia(N(recs), AN.DEFAULT_CONFIG)[0];
    expect(t.veredicto).toBe('EMPEORA');
    expect(t.deltaPP).toBeCloseTo(100, 5);
  });
  it('sin cambio dentro del umbral → ESTABLE', () => {
    const recs = [];
    for (let i = 1; i <= 5; i++) recs.push(mkRecord({ login: 'A', fechaOperativaISO: '2026-08-0' + i, incidencias: [incSec(SEC.cambio)] }));
    for (let i = 10; i <= 14; i++) recs.push(mkRecord({ login: 'A', fechaOperativaISO: '2026-08-' + i, incidencias: [incSec(SEC.cambio)] }));
    const t = AN.person.computePersonTendencia(N(recs), AN.DEFAULT_CONFIG)[0];
    expect(t.veredicto).toBe('ESTABLE');
  });
});

describe('personAnalytics — perfil histórico (§34)', () => {
  it('construye perfil completo: stats, evolución, tareas con error, recurrencias', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', incidencias: [incSec(SEC.cambio, { horasAfectadas: 2, wmsTask: 'PICKING SIN PAPEL - PULL & BEAR' })] }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-26', incidencias: [incSec(SEC.cambio, { horasAfectadas: 1, wmsTask: 'PICKING SIN PAPEL - PULL & BEAR' })] }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-26' })
    ]);
    const prof = AN.person.computePersonProfile(recs, 'A', AN.DEFAULT_CONFIG);
    expect(prof).not.toBeNull();
    expect(prof.stats.dias).toBe(2);
    expect(prof.evolucion.length).toBe(2);
    expect(prof.evolucion[0].errores).toBe(1);
    expect(prof.tareasConError[0].tarea).toContain('PICKING');
    expect(prof.tareasConError[0].dias).toBe(2);
    expect(prof.recurrencias.length).toBe(1); // misma confusión 2 días
    expect(prof.recurrencias[0].dias).toBe(2);
  });
  it('perfil de persona inexistente devuelve null', () => {
    expect(AN.person.computePersonProfile(N([mkRecord({})]), 'NADIE', AN.DEFAULT_CONFIG)).toBeNull();
  });
});
