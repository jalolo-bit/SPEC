/* Tests v6.2 — analítica por actividad y turnos (activityAnalytics.js).
 * §11/§27/§28/§29/§36: imputación por actividad afectada, turnos SIN HORA,
 * OTRA visible, detalle de actividad. */
import { describe, it, expect } from 'vitest';
import { mkRecord, SEC, incSec } from '../helpers/analyticsFixtures.js';

const AN = globalThis.SPEC_AN;
const N = AN.normalizarRecords;

describe('activityAnalytics — ranking de actividades (§11/§28)', () => {
  it('ordena las 7 actividades canónicas y agrega oportunidades/errores', () => {
    const recs = N([
      mkRecord({
        login: 'A', fechaOperativaISO: '2026-08-25',
        tareas: [
          { taskWms: 'PICK AGV 1', actividad: 'PICKING AGV', uds: 150 },
          { taskWms: 'UBI MAN 1', actividad: 'UBICACION MANUAL', uds: 260 }
        ]
      }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-25', tareas: [{ taskWms: 'PICK AGV 1', actividad: 'PICKING AGV', uds: 300 }] })
    ]);
    const st = AN.activity.computeActivityStats(recs, AN.DEFAULT_CONFIG);
    const nombres = st.map(a => a.actividad);
    // Orden canónico documentado (§11): Aud. AGV/Manual → Ubi. AGV/Manual →
    // Picking AGV/Manual → OTRA. UBICACION MANUAL precede a PICKING AGV.
    expect(nombres).toEqual(['UBICACION MANUAL', 'PICKING AGV']);
    const pagv = st.find(x => x.actividad === 'PICKING AGV');
    expect(pagv.oportunidades).toBe(2);
    expect(pagv.personas).toBe(2);
    expect(pagv.uds).toBe(450);
    expect(pagv.nTareas).toBe(1);
  });

  it('§11 el error se imputa SOLO a la actividad de la tarea afectada', () => {
    const recs = N([
      mkRecord({
        login: 'A', fechaOperativaISO: '2026-08-25',
        tareas: [
          { taskWms: 'PICK A', actividad: 'PICKING MANUAL', uds: 100 },
          { taskWms: 'AUD A', actividad: 'AUDITORIA AGV', uds: 35 }
        ],
        incidencias: [incSec(SEC.cambio, { wmsTask: 'AUD A', horasAfectadas: 1.5 })]
      })
    ]);
    const st = AN.activity.computeActivityStats(recs, AN.DEFAULT_CONFIG);
    const aud = st.find(a => a.actividad === 'AUDITORIA AGV');
    const pick = st.find(a => a.actividad === 'PICKING MANUAL');
    expect(aud.errores).toBe(1);
    expect(aud.horasAfectadas).toBe(1.5);
    expect(pick.errores).toBe(0); // NO se copia a la otra actividad del día
  });

  it('OTRA siempre visible con su volumen (§29: no se oculta)', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', tareas: [{ taskWms: 'REPARTO A TIENDA AGV - BERSHKA', actividad: 'OTRA', uds: 300, productividad: null, horasAsignadas: 0 }] })
    ]);
    const st = AN.activity.computeActivityStats(recs, AN.DEFAULT_CONFIG);
    const otra = st.find(a => a.actividad === 'OTRA');
    expect(otra).toBeDefined();
    expect(otra.uds).toBe(300);
    expect(otra.oportunidades).toBe(1);
  });

  it('tasa con denominador oportunidades y muestra pequeña', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', tareas: [{ taskWms: 'T1', actividad: 'PICKING MANUAL', uds: 100 }], incidencias: [incSec(SEC.cambio, { wmsTask: 'T1' })] }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-25', tareas: [{ taskWms: 'T1', actividad: 'PICKING MANUAL', uds: 100 }] }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-26', tareas: [{ taskWms: 'T1', actividad: 'PICKING MANUAL', uds: 100 }] })
    ]);
    const st = AN.activity.computeActivityStats(recs, AN.DEFAULT_CONFIG);
    expect(st[0].oportunidades).toBe(3);
    expect(st[0].errores).toBe(1);
    expect(st[0].pctError).toBeCloseTo(33.33, 1);
    expect(st[0].muestraPequena).toBe(false);
  });
});

describe('activityAnalytics — turnos (§27)', () => {
  it('compara turnos con tasa, horas y SIN HORA separado (nunca repartido)', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', turno: 'NOCHE', turnos: ['NOCHE'], incidencias: [incSec(SEC.cambio, { horasAfectadas: 2 })] }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-25', turno: 'NOCHE', turnos: ['NOCHE'], incidencias: [incSec(SEC.cambio, { horasAfectadas: 1 })] }),
      mkRecord({ login: 'C', fechaOperativaISO: '2026-08-25', turno: 'MAÑANA', turnos: ['MAÑANA'] }),
      mkRecord({ login: 'D', fechaOperativaISO: '2026-08-25', turno: 'SIN HORA', turnos: ['SIN HORA'], hora: null })
    ]);
    const t = AN.activity.computeTurnoStats(recs, AN.DEFAULT_CONFIG);
    const noche = t.turnos.find(x => x.turno === 'NOCHE');
    const mañana = t.turnos.find(x => x.turno === 'MAÑANA');
    const sinHora = t.turnos.find(x => x.turno === 'SIN HORA');
    expect(noche.registros).toBe(2);
    expect(noche.conError).toBe(2);
    expect(noche.pctError).toBe(100);
    expect(noche.horasAfectadas).toBe(3);
    expect(mañana.pctError).toBe(0);
    expect(sinHora.registros).toBe(1); // permanece como SIN HORA
    // orden canónico: MAÑANA, TARDE, NOCHE, MIXTO, SIN HORA (solo presentes)
    const idx = t.turnos.map(x => x.turno);
    expect(idx.indexOf('MAÑANA')).toBeLessThan(idx.indexOf('NOCHE'));
    expect(idx.indexOf('NOCHE')).toBeLessThan(idx.indexOf('SIN HORA'));
  });

  it('tendencia por turno con mínimo de registros por mitad', () => {
    const recs = [];
    for (let i = 1; i <= 4; i++) recs.push(mkRecord({ login: 'A' + i, fechaOperativaISO: '2026-08-0' + i, turno: 'NOCHE', turnos: ['NOCHE'] }));
    for (let i = 10; i <= 13; i++) recs.push(mkRecord({ login: 'B' + i, fechaOperativaISO: '2026-08-' + i, turno: 'NOCHE', turnos: ['NOCHE'], incidencias: [incSec(SEC.cambio)] }));
    const t = AN.activity.computeTurnoStats(N(recs), AN.DEFAULT_CONFIG);
    const td = t.tendencia['NOCHE'];
    expect(td.nA).toBe(4); expect(td.nB).toBe(4);
    expect(td.deltaPP).toBe(100);
  });
});

describe('activityAnalytics — detalle de actividad (§36)', () => {
  it('incluye tareas, tendencia y distribución por turno', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', turno: 'MAÑANA', turnos: ['MAÑANA'], tareas: [{ taskWms: 'T1', actividad: 'PICKING MANUAL', uds: 100 }], incidencias: [incSec(SEC.cambio, { wmsTask: 'T1', horasAfectadas: 2 })] }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-26', turno: 'NOCHE', turnos: ['NOCHE'], tareas: [{ taskWms: 'T1', actividad: 'PICKING MANUAL', uds: 100 }] })
    ]);
    const prof = AN.activity.computeActivityProfile(recs, 'PICKING MANUAL', AN.DEFAULT_CONFIG);
    expect(prof.stats.oportunidades).toBe(2);
    expect(prof.stats.errores).toBe(1);
    expect(prof.tareas[0].taskWms).toBe('T1');
    expect(prof.stats.turnos['MAÑANA'].errores).toBe(1);
    expect(prof.stats.turnos['NOCHE'].errores).toBe(0);
    expect(prof.tendencia.deltaPP).toBeTypeOf('number');
  });
  it('actividad inexistente devuelve null', () => {
    expect(AN.activity.computeActivityProfile(N([mkRecord({})]), 'NOEXISTE', AN.DEFAULT_CONFIG)).toBeNull();
  });
});
