/* Tests v6.2 — BATERÍA DE CASOS EXTREMOS (§58).
 * Nunca NaN, Infinity, divisiones inválidas ni porcentajes >100 sin
 * justificación. Cubre: cero errores, cero personas, cero horas, cero uds,
 * un solo día, una sola persona, una sola tarea, muestras pequeñas, todos /
 * ninguno con error, cambio de mapping, mapping incompleto, tarea OTRA,
 * noche cruzando medianoche, históricos vacíos. */
import { describe, it, expect } from 'vitest';
import { mkRecord, SEC, incSec } from '../helpers/analyticsFixtures.js';

const AN = globalThis.SPEC_AN;
const N = AN.normalizarRecords;
const D = AN.DEFAULT_CONFIG;

/* Recorre TODAS las propiedades numéricas (anidadas) buscando no-finitos. */
function sinNoFinitos(obj, path) {
  const p = path || 'raíz';
  if (obj == null) return;
  if (typeof obj === 'number') {
    if (!isFinite(obj)) throw new Error('Valor no finito en ' + p + ': ' + obj);
    return;
  }
  if (Array.isArray(obj)) { obj.forEach((v, i) => sinNoFinitos(v, p + '[' + i + ']')); return; }
  if (typeof obj === 'object') {
    for (const k of Object.keys(obj)) sinNoFinitos(obj[k], p + '.' + k);
  }
}

/* Ejecuta TODA la capa analítica sobre un conjunto y verifica que no haya
 * NaN/Infinity en ningún resultado. */
function correrTodo(recs, cfg) {
  const c = cfg || D;
  const r = N(recs);
  const resultados = {
    kpi: AN.kpisBase(r),
    comp: AN.compararPeriodos(AN.partirPorMitades(r).A, AN.partirPorMitades(r).B),
    personas: AN.person.computePersonStats(r, c),
    tendPersonas: AN.person.computePersonTendencia(r, c),
    tareas: AN.task.computeTaskStats(r, c),
    tendTareas: AN.task.computeTaskTendencia(r, c),
    fichaje: AN.task.computeFichajeStats(r, c),
    actividades: AN.activity.computeActivityStats(r, c),
    turnos: AN.activity.computeTurnoStats(r, c),
    matrix: AN.confusion.computeConfusionMatrix(r),
    recurrencias: AN.confusion.computeRecurrencias(r, c),
    daily: AN.trend.computeDailySeries(r, c),
    semanal: AN.trend.computeBucketSeries(r, 'semana', c),
    mensual: AN.trend.computeBucketSeries(r, 'mes', c),
    pareto: AN.pareto.computeParetoTareas(AN.task.computeTaskStats(r, c)),
    alerts: AN.alerts.computeAlerts(r, c),
    top: AN.alerts.computeTopPrioridades(r, c, 5),
    dq: AN.dataQuality.computeDataQuality(r),
    mq: AN.dataQuality.computeMappingQuality(r)
  };
  sinNoFinitos(resultados, 'analytics');
  return resultados;
}

describe('edge cases §58 — cero errores / cero personas / cero horas / cero uds', () => {
  it('histórico vacío: toda la capa responde sin NaN', () => {
    const res = correrTodo([]);
    expect(res.kpi.personaDia).toBe(0);
    expect(res.alerts).toEqual([]);
    expect(res.top).toEqual([]);
  });

  it('cero errores (todo correcto)', () => {
    const res = correrTodo([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', incidencias: [incSec(SEC.correcta)] }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-25' })
    ]);
    expect(res.kpi.errores).toBe(0);
    expect(res.kpi.pctPersonaDiaConError).toBe(0);
    expect(res.pareto.porErrores.items).toEqual([]);
    expect(res.top).toEqual([]);
  });

  it('cero horas analizables (división 0/0 no produce NaN)', () => {
    const res = correrTodo([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', horasAnalizables: 0, horasFichadas: 0, registros: [{ idRegistroHoras: '1', hora: '08:00', turno: 'MAÑANA', horas: 0, hrTask: 'X' }], horasConIncidencia: 0 })
    ]);
    expect(res.kpi.pctHorasAfectadas).toBe(0);
    expect(res.personas[0].pctHorasAfectadas).toBe(0);
  });

  it('cero uds (tarea sin volumen productivo)', () => {
    const res = correrTodo([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', tareas: [{ taskWms: 'T0', uds: 0, horasEquivalentes: 0, horasAsignadas: 0, peso: 0 }], udsTotales: 0, horasEquivalentes: 0 })
    ]);
    expect(res.tareas[0].uds).toBe(0);
    expect(res.tareas[0].pctError).toBe(0);
  });
});

describe('edge cases §58 — un solo día / persona / tarea / muestras pequeñas', () => {
  it('un solo día, una sola persona, una sola tarea', () => {
    const res = correrTodo([
      mkRecord({ login: 'UNICA', fechaOperativaISO: '2026-08-25', tareas: [{ taskWms: 'UNICA TAREA', uds: 10 }], incidencias: [incSec(SEC.cambio, { wmsTask: 'UNICA TAREA' })] })
    ]);
    expect(res.kpi.personaDia).toBe(1);
    expect(res.kpi.pctPersonaDiaConError).toBe(100);
    expect(res.tareas[0].oportunidades).toBe(1);
    expect(res.tareas[0].muestraPequena).toBe(true); // 1 < 3
    expect(res.personas[0].semaforo).toBe('MUESTRA PEQUEÑA');
    expect(res.tendPersonas[0].suficiente).toBe(false); // no conclusiones fuertes
    expect(res.daily.serie.length).toBe(1);
    expect(res.daily.serie[0].mediaMovilTasa).toBeNull(); // sin ventana
  });

  it('todas las personas con error', () => {
    const recs = ['A', 'B', 'C'].map(l => mkRecord({ login: l, fechaOperativaISO: '2026-08-25', incidencias: [incSec(SEC.cambio)] }));
    const res = correrTodo(recs);
    expect(res.kpi.pctPersonaDiaConError).toBe(100);
    expect(res.personas.every(p => p.pctDiasConError === 100)).toBe(true);
  });

  it('ninguna persona con error', () => {
    const recs = ['A', 'B'].map(l => mkRecord({ login: l, fechaOperativaISO: '2026-08-25' }));
    const res = correrTodo(recs);
    expect(res.kpi.pctPersonaDiaConError).toBe(0);
    expect(res.personas.every(p => p.semaforo === 'MUY BUENO' || p.semaforo === 'MUESTRA PEQUEÑA')).toBe(true);
  });
});

describe('edge cases §58 — mapping', () => {
  it('cambio de mapping: dos hashes coexisten sin mezclarse (§31)', () => {
    const res = correrTodo([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', mappingHash: 'hAAA' }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-26', mappingHash: 'hBBB' })
    ]);
    expect(res.mq.mappings.length).toBe(2);
    expect(res.mq.cambiosMapping).toBe(1);
    expect(res.dq.duplicadosVersionados).toBe(0);
  });

  it('mapping incompleto (tareas sin mapping + ambiguas)', () => {
    const res = correrTodo([
      mkRecord({
        login: 'A', fechaOperativaISO: '2026-08-25',
        tareas: [{ taskWms: 'T1', uds: 10 }],
        incidencias: [incSec(SEC.sinMap, { wmsTask: 'SINMAP' }), incSec(SEC.varias, { tareaOriginal: 'AMB', propuesta: 'A | B' })]
      })
    ]);
    expect(res.dq.casosSinMapping).toBe(1);
    expect(res.mq.tareasSinMapping.length).toBe(1);
    expect(res.mq.tareasAmbiguas.length).toBe(1);
    // la causa queda clasificada como DATOS, no operativo:
    expect(res.dq.repartoCausas.datos.casos).toBe(2);
  });
});

describe('edge cases §58 — OTRA y SIN HORA y noche cruzando medianoche', () => {
  it('tarea OTRA: visible, con alerta de volumen y fuera del reparto', () => {
    const res = correrTodo([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', tareas: [{ taskWms: 'OTRA GRANDE', actividad: 'OTRA', uds: 900, productividad: null, horasAsignadas: 0 }] })
    ]);
    const otra = res.actividades.find(a => a.actividad === 'OTRA');
    expect(otra).toBeDefined();
    expect(otra.uds).toBe(900);
    expect(res.alerts.some(a => a.codigo === 'A5_OTRA_VOLUMEN')).toBe(true);
  });

  it('SIN HORA: permanece como categoría propia, nunca se reparte a un turno', () => {
    const res = correrTodo([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', turno: 'SIN HORA', turnos: ['SIN HORA'], hora: null }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-25', turno: 'MAÑANA', turnos: ['MAÑANA'] })
    ]);
    const turnos = res.turnos.turnos.map(t => t.turno);
    expect(turnos).toContain('SIN HORA');
    expect(turnos).toContain('MAÑANA');
    const sh = res.turnos.turnos.find(t => t.turno === 'SIN HORA');
    expect(sh.registros).toBe(1);
  });

  it('noche cruzando medianoche: fecha operativa del día anterior (27/28 → turno NOCHE)', () => {
    // 26/08 02:15 → NOCHE con fecha operativa 25/08 (regla fx_FechaOperativaTurno)
    const res = correrTodo([
      mkRecord({ login: 'NOC', fechaOperativaISO: '2026-08-25', turno: 'NOCHE', turnos: ['NOCHE'], hora: '02:15', registros: [{ idRegistroHoras: '9', hora: '02:15', turno: 'NOCHE', horas: 8, hrTask: 'X' }] })
    ]);
    expect(res.turnos.turnos[0].turno).toBe('NOCHE');
    expect(res.turnos.turnos[0].registros).toBe(1);
    expect(res.daily.serie[0].fechaISO).toBe('2026-08-25');
  });
});

describe('edge cases §58 — invariantes numéricos globales', () => {
  it('ningún porcentaje de parte-de-un-total supera 100 en toda la capa', () => {
    const recs = [];
    for (let i = 0; i < 12; i++) {
      recs.push(mkRecord({
        login: 'P' + (i % 4), fechaOperativaISO: '2026-08-' + String(i + 1).padStart(2, '0'),
        tareas: [{ taskWms: 'T' + (i % 3), uds: 50 }],
        incidencias: [
          incSec(SEC.cambio, { wmsTask: 'T' + (i % 3), horasAfectadas: 2 }),
          incSec(SEC.cambio, { wmsTask: 'T' + (i % 3), horasAfectadas: 2 }),
          incSec(SEC.correcta)
        ]
      }));
    }
    const res = correrTodo(recs);
    // pctError por tarea (errores/imputaciones vs oportunidades puede superar
    // 100 SOLO si una oportunidad genera 2 errores — justificado y tasado:
    expect(res.tareas[0].pctError).toBeLessThanOrEqual(200);
    // Tasas de persona-día (partes de un total) acotadas a 100:
    for (const p of res.personas) expect(p.pctDiasConError).toBeLessThanOrEqual(100);
    // Pareto acumulado termina en 100:
    const par = res.pareto.porErrores;
    if (par.items.length) expect(par.items[par.items.length - 1].pctAcumulado).toBe(100);
  });

  it('records legacy de la v6.1 (sin campos v6.2) no rompen nada', () => {
    const legacy = {
      key: 'LEG|2026-08-25', login: 'LEG', persona: 'LEGADO', fechaOperativaISO: '2026-08-25',
      turno: 'MAÑANA', turnos: ['MAÑANA'], horasAnalizables: 8, horasConIncidencia: 0,
      actividades: [{ actividad: 'PICKING MANUAL', uds: 100, tareasWms: ['TAREA L'], horasAsignadas: 8, tareas: [] }],
      incidencias: [{ id: 'a@1', seccion: '1. CAMBIO HR TASK PROPUESTO', horasAfectadas: 1, tareaOriginal: 'X', propuesta: 'Y', decision: null }],
      mappingHash: 'h', decision: 'PENDIENTE', version: 2, previousVersions: [{}]
    };
    const res = correrTodo([legacy]);
    expect(res.personas[0].login).toBe('LEG');
    expect(res.tareas[0].taskWms).toBe('TAREA L');
    expect(res.kpi.incidencias).toBe(1);
  });
});
