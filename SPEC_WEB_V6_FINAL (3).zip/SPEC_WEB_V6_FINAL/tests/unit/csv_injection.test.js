// CSV Formula Injection tests (M-01 / R-05 / AUD-MED-007)
//
// SPEC.exportToCsv(data, filename) writes a CSV using `Blob` + `saveAs`. In
// Node, we mock URL.createObjectURL + document.createElement and capture the
// Blob content. The CSV must:
//
//   1. Neutralize formula injection: prepend `'` to any value starting with
//      `=`, `+`, `-`, or `@` (the OWASP-recommended vectors for
//      Excel/LibreOffice/Google Sheets formula injection).
//   2. Properly quote values that contain the CSV delimiter (`;`), a quote
//      (`"`), or a newline (`\n` / `\r`).
//   3. Leave normal values untouched (no `'` prefix, no quoting).
//
// The escapeCsv closure inside exportToCsv is the security boundary. A
// regression here would let a malicious input value execute formulas when
// the CSV is opened in a spreadsheet.

import { describe, it, expect, beforeAll, beforeEach, vi } from 'vitest';

const SPEC = globalThis.SPEC;

// Capture the most recent Blob's content across the test.
let capturedBlobs = [];
let capturedAnchor = null;

beforeAll(() => {
  // Minimal DOM + URL stubs that let exportToCsv's `saveAs` reach the Blob.
  globalThis.Blob = class Blob {
    constructor(parts, opts) {
      this.parts = parts;
      this.opts = opts;
      capturedBlobs.push(this);
    }
    // Some implementations call .text() — provide it for completeness.
    async text() {
      let out = '';
      for (const p of this.parts) {
        if (p instanceof Uint8Array) out += new TextDecoder().decode(p);
        else out += String(p);
      }
      return out;
    }
  };
  globalThis.URL = globalThis.URL || {};
  globalThis.URL.createObjectURL = vi.fn(() => 'blob:fake-url');
  globalThis.URL.revokeObjectURL = vi.fn();
  globalThis.document = globalThis.document || {};
  globalThis.document.createElement = vi.fn((tag) => {
    if (String(tag).toLowerCase() !== 'a') return { style: {} };
    const a = {
      tagName: 'A',
      style: {},
      href: '',
      download: '',
      click: vi.fn(),
      setAttribute() {},
      addEventListener() {}
    };
    capturedAnchor = a;
    return a;
  });
  // Ensure document.body has both appendChild AND removeChild (tests/setup.js
  // only provides appendChild). Replace body entirely so we control both.
  globalThis.document.body = {
    appendChild: vi.fn(),
    removeChild: vi.fn()
  };
});

beforeEach(() => {
  capturedBlobs = [];
});

function lastBlobText() {
  const blob = capturedBlobs[capturedBlobs.length - 1];
  if (!blob) throw new Error('no Blob was captured');
  // Reconstruct the text synchronously (don't await .text()).
  let out = '';
  for (const p of blob.parts) {
    if (p instanceof Uint8Array) out += new TextDecoder().decode(p);
    else out += String(p);
  }
  return out;
}

describe('CSV Formula Injection protection (M-01 / R-05 / AUD-MED-007)', () => {
  it('values starting with = are prefixed with a single quote (and double-quoted because the value contains ")', () => {
    const data = [{ name: '=CMD("calc.exe")', age: 30 }];
    SPEC.exportToCsv(data, 'test.csv');
    const csv = lastBlobText();
    // The cell starts with `=` → prefix `'`. The value also contains `"`
    // → those `"` are doubled to `""` and the cell is wrapped in `"..."`.
    // Order of operations: first the `'` prefix is added, THEN the cell is
    // quoted. Final cell content: `"'=CMD(""calc.exe"")"` — opening quote,
    // apostrophe prefix, =CMD, doubled-quotes around calc.exe, closing quote.
    // The wrapping `"` comes BEFORE the `'` prefix.
    expect(csv).toContain("\"'=CMD(\"\"calc.exe\"\")\"");
    // Sanity: the first char of the data cell (after the wrapping `"`) is the
    // `'` prefix — so even when Excel opens the CSV, the `=` is no longer the
    // first character and is not interpreted as a formula.
    const lines = csv.split('\r\n');
    expect(lines[1]).toBe("\"'=CMD(\"\"calc.exe\"\")\";30");
  });

  it('values starting with + are prefixed with a single quote', () => {
    const data = [{ name: '+1+1', age: 25 }];
    SPEC.exportToCsv(data, 'test.csv');
    const csv = lastBlobText();
    expect(csv).toContain("'+1+1");
  });

  it('values starting with - are prefixed with a single quote', () => {
    const data = [{ name: '-10', age: 40 }];
    SPEC.exportToCsv(data, 'test.csv');
    const csv = lastBlobText();
    expect(csv).toContain("'-10");
  });

  it('values starting with @ are prefixed with a single quote', () => {
    const data = [{ name: '@SUM(A1:A2)', age: 50 }];
    SPEC.exportToCsv(data, 'test.csv');
    const csv = lastBlobText();
    expect(csv).toContain("'@SUM(A1:A2)");
  });

  it('normal values are NOT prefixed with a single quote', () => {
    const data = [{ name: 'normal', age: 20 }];
    SPEC.exportToCsv(data, 'test.csv');
    const csv = lastBlobText();
    expect(csv).toContain('normal;20');
    expect(csv).not.toContain("'normal");
  });

  it('multiple injection vectors in one batch are all neutralized', () => {
    const data = [
      { name: '=CMD(\'calc.exe\')', age: 30 },
      { name: '+1+1', age: 25 },
      { name: '-10', age: 40 },
      { name: '@SUM(A1:A2)', age: 50 },
      { name: 'normal', age: 20 }
    ];
    SPEC.exportToCsv(data, 'test.csv');
    const csv = lastBlobText();
    // Note: this `=CMD(...)` value uses single quotes around calc.exe, so it
    // contains NO `"` and is NOT wrapped in CSV quotes — just the formula
    // prefix `'` is prepended.
    expect(csv).toContain("'=CMD('calc.exe')");
    expect(csv).toContain("'+1+1");
    expect(csv).toContain("'-10");
    expect(csv).toContain("'@SUM(A1:A2)");
    // The "normal" cell has NO leading quote.
    const lines = csv.split('\r\n');
    expect(lines[5]).toBe('normal;20');
  });

  it('values containing the ; delimiter are properly quoted', () => {
    const data = [{ name: 'a;b;c', age: 1 }];
    SPEC.exportToCsv(data, 'test.csv');
    const csv = lastBlobText();
    expect(csv).toContain('"a;b;c"');
    // The leading quote is the CSV quote, not the formula-prefix quote.
    expect(csv).not.toContain("'\"a;b;c\""); // would be a bug: prefix-then-quote
  });

  it('values containing both a formula prefix AND a delimiter get BOTH the prefix and the quotes', () => {
    // =1;2;3 — starts with `=` (so gets prefix) AND contains `;` (so gets
    // quoted). The expected output is `"'=1;2;3"` (quote, then prefix, then
    // value). The implementation does `escapeCsv` which:
    //   1. checks FORMULA_PREFIXES → prepends `'` → s = "'=1;2;3"
    //   2. checks if `;` is in s → yes → wraps in `"` and doubles internal
    //      quotes → '"\'=1;2;3"' (no internal quotes to double)
    const data = [{ name: '=1;2;3', age: 0 }];
    SPEC.exportToCsv(data, 'test.csv');
    const csv = lastBlobText();
    expect(csv).toContain('"\'=1;2;3"');
  });

  it('values containing a double quote get the quote escaped (doubled) and the cell wrapped in quotes', () => {
    const data = [{ name: 'say "hi"', age: 0 }];
    SPEC.exportToCsv(data, 'test.csv');
    const csv = lastBlobText();
    // "say ""hi"""
    expect(csv).toContain('"say ""hi""');
  });

  it('values containing a newline get quoted', () => {
    const data = [{ name: 'line1\nline2', age: 0 }];
    SPEC.exportToCsv(data, 'test.csv');
    const csv = lastBlobText();
    // The newline is preserved inside the quotes (so the CSV row count stays
    // 1 — the quoted newline does NOT split the row).
    expect(csv).toContain('"line1\nline2"');
  });

  it('the CSV starts with a BOM (\\ufeff) — Excel needs this to detect UTF-8', () => {
    const data = [{ name: 'x', age: 0 }];
    SPEC.exportToCsv(data, 'test.csv');
    const csv = lastBlobText();
    expect(csv.startsWith('\ufeff')).toBe(true);
  });

  it('the CSV uses CRLF (\\r\\n) line endings — required for Excel compatibility', () => {
    const data = [{ a: 1 }, { a: 2 }];
    SPEC.exportToCsv(data, 'test.csv');
    const csv = lastBlobText();
    expect(csv).toContain('\r\n');
    // The first line ending should be CRLF, not just LF.
    expect(csv.indexOf('\r\n')).toBeGreaterThan(0);
    expect(csv.indexOf('\r\n')).toBeLessThan(csv.indexOf('\n') + 1);
  });

  it('the delimiter is ; (semicolon) — es-ES Excel default (after stripping the BOM)', () => {
    const data = [{ a: 1, b: 2 }];
    SPEC.exportToCsv(data, 'test.csv');
    const csv = lastBlobText();
    // Strip the leading BOM (\ufeff) when comparing the first line — the
    // BOM is a separate concern (tested elsewhere) and would otherwise mask
    // the delimiter check.
    const firstLine = csv.replace(/^\ufeff/, '').split('\r\n')[0];
    expect(firstLine).toBe('a;b');
  });

  it('null values render as empty string (no formula prefix, no quoting)', () => {
    const data = [{ name: null, age: 0 }];
    SPEC.exportToCsv(data, 'test.csv');
    const csv = lastBlobText();
    expect(csv).toContain(';0'); // name column empty, age column 0
    expect(csv).not.toContain("'null");
    expect(csv).not.toContain('"null"');
  });

  it('Date values are formatted via formatFecha (dd/MM/yyyy) and NOT treated as formula injection', () => {
    const data = [{ name: 'x', fecha: new Date(Date.UTC(2026, 7, 25)) }];
    SPEC.exportToCsv(data, 'test.csv');
    const csv = lastBlobText();
    expect(csv).toContain('25/08/2026');
  });

  it('empty data array → empty Blob (no crash)', () => {
    SPEC.exportToCsv([], 'empty.csv');
    const blob = capturedBlobs[capturedBlobs.length - 1];
    expect(blob.parts).toEqual(['']);
  });

  it('escaped injection attempts on real-world column names (COMMAND-style payload)', () => {
    // Simulates a malicious input where an attacker controls the column value.
    // Note: the first row's `=HYPERLINK("http://evil.com","click")` contains
    // `"` chars → those are doubled to `""` and the cell is wrapped in `"..."`.
    // The final cell value is `"'=HYPERLINK(""http://evil.com"",""click"")"`.
    // The second row's `=2+5+cmd|"/c calc"!A1` also contains `"` → doubled.
    const data = [
      { PERSONA: 'John Doe', 'COMANDO': '=HYPERLINK("http://evil.com","click")' },
      { PERSONA: '=2+5+cmd|"/c calc"!A1', 'COMANDO': 'normal' }
    ];
    SPEC.exportToCsv(data, 'test.csv');
    const csv = lastBlobText();
    // Both dangerous values must be neutralized with a `'` prefix. The `"`
    // doubling is a separate CSV-escaping concern, but the `'` prefix is the
    // security boundary we're checking here.
    expect(csv).toContain("'=HYPERLINK");
    expect(csv).toContain("'=2+5+cmd");
    // And the `'` must come BEFORE the `=` — i.e. the `=` is no longer the
    // first non-quote char of the cell.
    const firstPayload = csv.match(/"?'=HYPERLINK/);
    expect(firstPayload).not.toBeNull();
    // Normal values are untouched.
    expect(csv).toContain('John Doe');
    expect(csv).toContain(';normal');
  });
});
