/* Tests v6.2 — Pareto y concentración (paretoAnalytics.js).
 * §24: curva, % acumulado, comprobación REAL de la regla 80/20 (solo se
 * afirma si los datos la cumplen). */
import { describe, it, expect } from 'vitest';

const AN = globalThis.SPEC_AN;

describe('paretoAnalytics — curva de Pareto (§24)', () => {
  it('ordena desc, acumula y calcula nPara80', () => {
    const p = AN.pareto.computePareto([
      { nombre: 'A', valor: 50 }, { nombre: 'B', valor: 30 }, { nombre: 'C', valor: 15 }, { nombre: 'D', valor: 5 }
    ]);
    expect(p.total).toBe(100);
    expect(p.items.map(i => i.nombre)).toEqual(['A', 'B', 'C', 'D']);
    expect(p.items[0].pctIndividual).toBe(50);
    expect(p.items[1].pctAcumulado).toBe(80);
    expect(p.nPara80).toBe(2); // A+B llegan al 80%
    expect(p.pctElementos80).toBe(50); // 2 de 4
    expect(p.cumple8020).toBe(false); // 50% > 20% → NO se cumple
  });

  it('AFIRMA 80/20 solo cuando de verdad se cumple', () => {
    const items = [];
    // 1 tarea con 80 errores + 19 tareas con 1 error → 1/20 = 5% cubre 80%
    items.push({ nombre: 'GRANDE', valor: 80 });
    for (let i = 0; i < 19; i++) items.push({ nombre: 'P' + i, valor: 1 });
    const p = AN.pareto.computePareto(items);
    expect(p.total).toBe(99);
    expect(p.nPara80).toBe(1);
    expect(p.cumple8020).toBe(true);
  });

  it('con valores 0 o lista vacía no produce NaN', () => {
    const p = AN.pareto.computePareto([{ nombre: 'X', valor: 0 }, { nombre: 'Y', valor: 0 }]);
    expect(p.items).toEqual([]);
    expect(p.total).toBe(0);
    expect(p.nPara80).toBeNull();
    expect(p.cumple8020).toBe(false);
    const p2 = AN.pareto.computePareto([]);
    expect(p2.items).toEqual([]);
  });

  it('valorFn personalizado (por horas afectadas) y empates deterministas', () => {
    const p = AN.pareto.computePareto([
      { nombre: 'A', horas: 10 }, { nombre: 'B', horas: 10 }, { nombre: 'C', horas: 0 }
    ], i => i.horas);
    expect(p.items.length).toBe(2);
    expect(p.items[0].pctIndividual).toBe(50);
    expect(p.items[0].nombre <= p.items[1].nombre).toBe(true); // empate → orden alfabético estable
  });

  it('paretoTareas/Personas/Actividades envuelven con la métrica correcta', () => {
    const tareas = [{ taskWms: 'T1', errores: 8, horasAfectadas: 2 }, { taskWms: 'T2', errores: 2, horasAfectadas: 20 }];
    const pt = AN.pareto.computeParetoTareas(tareas);
    expect(pt.porErrores.items[0].taskWms).toBe('T1');
    expect(pt.porHoras.items[0].taskWms).toBe('T2');
    const pp = AN.pareto.computeParetoPersonas([{ persona: 'P1', errores: 3 }, { persona: 'P2', errores: 1 }]);
    expect(pp.total).toBe(4);
    const pa = AN.pareto.computeParetoActividades([{ actividad: 'PICKING MANUAL', errores: 5 }]);
    expect(pa.total).toBe(5);
  });
});
