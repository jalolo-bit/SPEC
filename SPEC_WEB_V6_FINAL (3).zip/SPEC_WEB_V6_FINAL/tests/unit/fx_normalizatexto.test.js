// Unit tests for SPEC.fx_NormalizaTexto  (M-06 / R-13)
//
// Covers the contract documented in Section1.m líneas 17-25:
//   - Text.Clean (strip 0x00-0x1F, 0x7F)
//   - Text.Trim
//   - return null on empty
//   - Text.Upper
//   - split on \s+ and collapse to single space
//
// The function is the entry point for almost every text column processed by
// the pipeline. A regression here silently breaks every normalization done
// downstream (fx_NormalizaLogin, Mapeo, etc.) — that's why it has dedicated
// tests instead of being exercised only indirectly through analizarYConciliar.

import { describe, it, expect } from 'vitest';

const SPEC = globalThis.SPEC;

describe('fx_NormalizaTexto (Section1.m líneas 17-25)', () => {
  it('null input → null', () => {
    expect(SPEC.fx_NormalizaTexto(null)).toBeNull();
  });

  it('undefined input → null', () => {
    expect(SPEC.fx_NormalizaTexto(undefined)).toBeNull();
  });

  it('empty string → null', () => {
    expect(SPEC.fx_NormalizaTexto('')).toBeNull();
  });

  it('whitespace-only string → null', () => {
    expect(SPEC.fx_NormalizaTexto('     ')).toBeNull();
    expect(SPEC.fx_NormalizaTexto('\t\t')).toBeNull();
    expect(SPEC.fx_NormalizaTexto('\n\n')).toBeNull();
  });

  it('plain text → trimmed + uppercased', () => {
    expect(SPEC.fx_NormalizaTexto('hola')).toBe('HOLA');
    expect(SPEC.fx_NormalizaTexto('hello world')).toBe('HELLO WORLD');
  });

  it('leading/trailing spaces → trimmed', () => {
    expect(SPEC.fx_NormalizaTexto('  hola  ')).toBe('HOLA');
    expect(SPEC.fx_NormalizaTexto(' \thola\t ')).toBe('HOLA');
  });

  it('internal multiple spaces → collapsed to single space', () => {
    expect(SPEC.fx_NormalizaTexto('hola     mundo')).toBe('HOLA MUNDO');
    expect(SPEC.fx_NormalizaTexto('a    b    c')).toBe('A B C');
  });

  it('text with tabs/newlines → control chars stripped (Text.Clean), then split-join collapses any remaining whitespace', () => {
    // \t = 0x09 and \n = 0x0A are both control chars → removed by Text.Clean
    // *before* split(/\s+/) runs. So 'hola\tmundo' becomes 'holamundo' (no
    // whitespace left to split on). This matches M's Text.Clean semantics:
    // it strips the char, it does NOT replace it with a space.
    expect(SPEC.fx_NormalizaTexto('hola\tmundo')).toBe('HOLAMUNDO');
    expect(SPEC.fx_NormalizaTexto('hola\nmundo')).toBe('HOLAMUNDO');
    // If a regular space coexists with a control char, the space survives
    // Text.Clean and gets normalized by split-join.
    expect(SPEC.fx_NormalizaTexto('hola \tmundo')).toBe('HOLA MUNDO');
  });

  it('text with NBSP (\\u00A0) → collapsed to single space', () => {
    // \u00A0 is NOT a control char (0x00-0x1F / 0x7F) so Text.Clean keeps it.
    // It IS whitespace per /\s+/, so split-join collapses it to a single space.
    expect(SPEC.fx_NormalizaTexto('hola\u00A0mundo')).toBe('HOLA MUNDO');
    expect(SPEC.fx_NormalizaTexto('hola\u00A0\u00A0mundo')).toBe('HOLA MUNDO');
  });

  it('mixed case → UPPER', () => {
    expect(SPEC.fx_NormalizaTexto('HoLa')).toBe('HOLA');
    expect(SPEC.fx_NormalizaTexto('AbCdEf')).toBe('ABCDEF');
  });

  it('text with accents → preserved (no NFD stripping)', () => {
    // The function does not strip accents — Text.Upper in M doesn't either.
    expect(SPEC.fx_NormalizaTexto('cañón')).toBe('CAÑÓN');
    expect(SPEC.fx_NormalizaTexto('MÚSICA')).toBe('MÚSICA');
  });

  it('numbers passed as text → preserved as string', () => {
    expect(SPEC.fx_NormalizaTexto('1234')).toBe('1234');
    expect(SPEC.fx_NormalizaTexto('12.34')).toBe('12.34');
  });

  it('numbers passed as Number → coerced to string', () => {
    expect(SPEC.fx_NormalizaTexto(1234)).toBe('1234');
    expect(SPEC.fx_NormalizaTexto(0)).toBe('0');
  });

  it('boolean input → TRUE/FALSE string', () => {
    expect(SPEC.fx_NormalizaTexto(true)).toBe('TRUE');
    expect(SPEC.fx_NormalizaTexto(false)).toBe('FALSE');
  });

  it('special chars (< > " \' &) → preserved as text (escaping is UI\'s job)', () => {
    // This is intentional: fx_NormalizaTexto is a *normalizer*, not an escaper.
    // UI must call escapeHtml() when inserting into innerHTML. CSV export must
    // call escapeCsv() when writing to disk. The normalizer must not mangle
    // legitimate content (e.g. "<>" in a sub-activity name).
    expect(SPEC.fx_NormalizaTexto('a & b')).toBe('A & B');
    expect(SPEC.fx_NormalizaTexto('a < b > c')).toBe('A < B > C');
    expect(SPEC.fx_NormalizaTexto('a "b" \'c\'')).toBe('A "B" \'C\'');
  });

  it('long string → no truncation', () => {
    const long = 'A'.repeat(10_000);
    const out = SPEC.fx_NormalizaTexto(long);
    expect(out).toBe(long);
    expect(out.length).toBe(10_000);
  });

  it('text with HTML injection attempt (<script>alert(1)</script>) → preserved as TEXT (UI escapes)', () => {
    // The normalizer upper-cases the tag — it does NOT strip or escape it.
    // UI.escapeHtml() does the actual < → &lt; replacement when this string is
    // inserted into innerHTML. This proves that fx_NormalizaTexto is NOT a
    // security boundary by itself.
    const out = SPEC.fx_NormalizaTexto('<script>alert(1)</script>');
    expect(out).toBe('<SCRIPT>ALERT(1)</SCRIPT>');
    // Sanity: the raw tag is preserved (unescaped).
    expect(out).toContain('<SCRIPT>');
    expect(out).toContain('</SCRIPT>');
  });

  it('text with formula injection attempt (=CMD(...)) → preserved as text (CSV export escapes)', () => {
    // Same principle: the normalizer must not mangle content. CSV export
    // prepends "'" to dangerous values per M-01 / R-05 / AUD-MED-007.
    const out = SPEC.fx_NormalizaTexto('=CMD("calc.exe")');
    expect(out).toBe('=CMD("CALC.EXE")');
    // The "=" prefix survives normalization — CSV export must defend.
    expect(out.startsWith('=')).toBe(true);
  });

  it('Date input → ISO date string (yyyy-MM-dd)', () => {
    const d = new Date(Date.UTC(2026, 7, 25, 10, 30, 0)); // 2026-08-25T10:30:00Z
    expect(SPEC.fx_NormalizaTexto(d)).toBe('2026-08-25');
  });

  it('whitespace + special chars combined → trimmed + collapsed + uppercased, specials preserved', () => {
    expect(SPEC.fx_NormalizaTexto('  <  img  src=x  >  ')).toBe('< IMG SRC=X >');
  });
});
