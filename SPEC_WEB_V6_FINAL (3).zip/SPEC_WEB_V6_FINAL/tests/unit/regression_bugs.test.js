// Regression tests for the 3 bugs fixed during the value test (AUD-LOW-004).
//
// The 3 bugs:
//   1. deepClone Date handling — deepClone(new Date()) returned {} instead of
//      a Date. Fix: `if (obj instanceof Date) return new Date(obj.getTime());`
//      at the top of deepClone (before the generic object branch).
//      deepClone is a private helper inside the app.js IIFE — not exported on
//      SPEC. We test it directly via tests/helpers/loadAppWithPriv.js (which
//      regex-patches the source to expose private symbols for testing only,
//      WITHOUT modifying app.js on disk), AND indirectly through
//      analizarYConciliar by asserting that the Fecha column in
//      07_Conciliacion contains Date instances.
//
//   2. fx_TransformaVolumen TOTAL/FILTROS filter — the original code did not
//      filter out the trailing "Total" and "Filtros aplicados" rows that the
//      Excel export always appends. The sibling functions fx_TransformaHoras
//      and fx_TransformaVolumenSinHoras already filtered; only Volumen was
//      missing the filter. Fix: same filter on the [DATE] column.
//      Test: load audit-ref/drive/VOLUMEN.xlsx and call fx_TransformaVolumen.
//      Expected: 743 rows (745 data rows - 2 footer rows).
//
//   3. formatNum useGrouping — the original formatNum/formatNum2/formatNum0
//      used `useGrouping: true`, adding "2.237" where the Excel source shows
//      "2237". Fix: `useGrouping: false`.
//      F11 fix (verificado): the fix is applied to ALL THREE formatters
//      (formatNum, formatNum2, formatNum0 — see app.js). There is NO
//      `it.fails`, NO skip and NO hidden-regression mechanism in this file:
//      every assertion below requires the FIXED behavior to pass.

import { readFileSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, it, expect, beforeAll } from 'vitest';
import { loadAppWithPriv } from '../helpers/loadAppWithPriv.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const IN_DIR = resolve(__dirname, '..', '..', 'audit-ref', 'drive');

const XLSX = globalThis.XLSX;
const SPEC = globalThis.SPEC;

function readXlsx(p) {
  const buf = readFileSync(p);
  return XLSX.read(buf, { type: 'buffer', cellDates: true });
}

function setupArchivos() {
  const wbHoras = readXlsx(join(IN_DIR, 'HORA SIN VOLUMEN.xlsx'));
  const wbVolumen = readXlsx(join(IN_DIR, 'VOLUMEN.xlsx'));
  const wbVSH = readXlsx(join(IN_DIR, 'VOL SIN HORAS.xlsx'));
  const wbMapping = readXlsx(join(IN_DIR, 'Mapping.xlsx'));
  SPEC.STATE.archivos.horas = { name: 'HORA SIN VOLUMEN.xlsx', workbook: wbHoras };
  SPEC.STATE.archivos.volumen = { name: 'VOLUMEN.xlsx', workbook: wbVolumen };
  SPEC.STATE.archivos.volSinHoras = { name: 'VOL SIN HORAS.xlsx', workbook: wbVSH };
  SPEC.STATE.archivos.mapping = { name: 'Mapping.xlsx', workbook: wbMapping };
}

let volumenWb;
let priv;

beforeAll(() => {
  volumenWb = readXlsx(join(IN_DIR, 'VOLUMEN.xlsx'));
  priv = loadAppWithPriv();
});

describe('AUD-LOW-004 — Bug 1: deepClone Date handling (direct test via loadAppWithPriv)', () => {
  // The bug: deepClone(new Date()) returned `{}` (a plain object) instead of a
  // Date. Fix: explicit `instanceof Date` check at the top of deepClone.
  //
  // We exercise the fix directly by calling the private deepClone (exposed via
  // tests/helpers/loadAppWithPriv.js — see that file for the patch rationale).

  it('deepClone(new Date(...)) returns a Date (not a plain {} object)', () => {
    const src = new Date(Date.UTC(2026, 7, 25, 10, 30, 45));
    const out = priv.deepClone(src);
    expect(out).toBeInstanceOf(Date);
    expect(out).not.toBe(src); // must be a NEW Date, not the same reference
    expect(out.getTime()).toBe(src.getTime());
  });

  it('deepClone(Date) preserves the timestamp exactly (no precision loss)', () => {
    const src = new Date(1716105600000); // arbitrary timestamp
    const out = priv.deepClone(src);
    expect(out.getTime()).toBe(src.getTime());
  });

  it('deepClone(Date) preserves invalid dates as invalid (no silent healing)', () => {
    const src = new Date('not-a-date');
    expect(isNaN(src.getTime())).toBe(true);
    const out = priv.deepClone(src);
    expect(out).toBeInstanceOf(Date);
    expect(isNaN(out.getTime())).toBe(true);
  });

  it('deepClone({nested: {d: new Date(...)}}) deep-clones nested Date correctly', () => {
    const src = { a: 1, nested: { d: new Date(Date.UTC(2026, 0, 1)) } };
    const out = priv.deepClone(src);
    expect(out.nested.d).toBeInstanceOf(Date);
    expect(out.nested.d.getTime()).toBe(src.nested.d.getTime());
  });

  it('deepClone([new Date(...), new Date(...)]) deep-clones Date array correctly', () => {
    const d1 = new Date(Date.UTC(2026, 0, 1));
    const d2 = new Date(Date.UTC(2026, 5, 15));
    const out = priv.deepClone([d1, d2]);
    expect(Array.isArray(out)).toBe(true);
    expect(out[0]).toBeInstanceOf(Date);
    expect(out[1]).toBeInstanceOf(Date);
    expect(out[0].getTime()).toBe(d1.getTime());
    expect(out[1].getTime()).toBe(d2.getTime());
    expect(out[0]).not.toBe(d1);
    expect(out[1]).not.toBe(d2);
  });

  it('deepClone(null / number / string / boolean) returns them unchanged (primitives pass through)', () => {
    expect(priv.deepClone(null)).toBeNull();
    expect(priv.deepClone(42)).toBe(42);
    expect(priv.deepClone('hi')).toBe('hi');
    expect(priv.deepClone(true)).toBe(true);
    expect(priv.deepClone(undefined)).toBeUndefined();
  });

  it('deepClone(plain object) still works (regression check on the generic branch)', () => {
    const src = { a: 1, b: 'x', c: [1, 2, 3], d: { nested: true } };
    const out = priv.deepClone(src);
    expect(out).not.toBe(src);
    expect(out).toEqual(src);
    expect(out.c).not.toBe(src.c);
    expect(out.d).not.toBe(src.d);
  });
});

describe('AUD-LOW-004 — Bug 1: deepClone Date handling (indirect test via analizarYConciliar)', () => {
  // Even though the direct test above exercises the fix, we also verify the
  // END-TO-END behavior: analizarYConciliar internally deep-clones workbook
  // rows. If deepClone returned {} for Dates, the Fecha column in
  // 07_Conciliacion would be a plain object, and downstream formatting /
  // comparison code (which does `d instanceof Date`) would silently break.
  //
  // The 07_Conciliacion table has 116 rows at baseline (the xlsm reference
  // also has 116 rows — the "117 filas" string in TAB_DESC is stale doc).
  // Every Fecha cell must be a Date instance.

  beforeAll(async () => {
    setupArchivos();
    await SPEC.analizarYConciliar(() => {});
  });

  it('07_Conciliacion.FECHA contains Date instances (not plain objects) for all 116 rows', () => {
    const rows = SPEC.STATE.queries['07_Conciliacion'] || [];
    expect(rows.length, '07_Conciliacion should have 116 rows at baseline (xlsm reference also has 116)').toBe(116);
    const offenders = [];
    for (let i = 0; i < rows.length; i++) {
      const v = rows[i].Fecha;
      if (!(v instanceof Date) || isNaN(v.getTime())) {
        offenders.push({ idx: i, type: typeof v, val: String(v).slice(0, 50) });
      }
    }
    expect(
      offenders,
      `Rows with non-Date Fecha (would be the deepClone(Date) bug):\n  ${offenders.slice(0, 5).map(o => `#${o.idx}: typeof=${o.type} val="${o.val}"`).join('\n  ')}`
    ).toEqual([]);
  });

  it('07_Conciliacion.Fecha is a Date even after a second pass (idempotence check — deepClone on its own output)', async () => {
    // Run a second time — the deepClone inside analizarYConciliar could be
    // called on its own previous output, and a wrong impl would have
    // accumulated damage. The fix must keep Dates stable across passes.
    setupArchivos();
    await SPEC.analizarYConciliar(() => {});
    const rows = SPEC.STATE.queries['07_Conciliacion'] || [];
    expect(rows.length).toBe(116);
    for (const r of rows) {
      expect(r.Fecha).toBeInstanceOf(Date);
      expect(isNaN(r.Fecha.getTime())).toBe(false);
    }
  });

  it('REPORTE_CAMBIOS_HR.Fecha is a Date for at least one row (sanity that the column exists and is typed)', () => {
    const rows = SPEC.STATE.reporte || [];
    expect(rows.length, 'reporte should have 214 rows at baseline').toBeGreaterThan(100);
    let checked = 0;
    for (const r of rows) {
      const f = r.Fecha ?? r.FECHA; // column name may be either case
      if (f == null) continue;
      expect(f, `expected Date, got ${typeof f}`).toBeInstanceOf(Date);
      checked++;
    }
    // We should have checked at least one row — sanity that the column exists.
    expect(checked, 'no row had a non-null Fecha column — column name may have changed').toBeGreaterThan(0);
  });
});

describe('AUD-LOW-004 — Bug 2: fx_TransformaVolumen TOTAL/FILTROS filter', () => {
  // The bug: fx_TransformaVolumen did not filter out the trailing "Total" and
  // "Filtros aplicados" rows that every Excel export appends. The fix added
  // the same filter on the [DATE] column that fx_TransformaHoras and
  // fx_TransformaVolumenSinHoras already had.
  //
  // VOLUMEN.xlsx sheet "Export" has 746 rows total: 1 header + 745 data.
  // Of those 745 data rows, the LAST TWO are footer rows:
  //   row 744: "Total"
  //   row 745: "Filtros aplicados: ..."
  // After the fix, fx_TransformaVolumen returns 743 rows (745 - 2).

  it('fx_TransformaVolumen(VOLUMEN.xlsx) returns 743 rows (NOT 745 with footer rows)', () => {
    const out = SPEC.fx_TransformaVolumen(volumenWb, 'VOLUMEN.xlsx');
    expect(out.length, `expected 743 rows, got ${out.length}`).toBe(743);
  });

  it('fx_TransformaVolumen output contains NO row whose FechaOriginal starts with "Total" (case-insensitive)', () => {
    const out = SPEC.fx_TransformaVolumen(volumenWb, 'VOLUMEN.xlsx');
    const offenders = out.filter(r => String(r.FechaOriginal || '').toUpperCase().startsWith('TOTAL'));
    expect(offenders, `TOTAL footer leaked through filter:\n${JSON.stringify(offenders, null, 2)}`).toEqual([]);
  });

  it('fx_TransformaVolumen output contains NO row whose FechaOriginal mentions "FILTROS APLICADOS"', () => {
    const out = SPEC.fx_TransformaVolumen(volumenWb, 'VOLUMEN.xlsx');
    const offenders = out.filter(r => String(r.FechaOriginal || '').toUpperCase().indexOf('FILTROS APLICADOS') >= 0);
    expect(offenders, `FILTROS APLICADOS footer leaked through filter:\n${JSON.stringify(offenders, null, 2).slice(0, 500)}`).toEqual([]);
  });

  it('fx_TransformaVolumen preserves row order — first non-footer row corresponds to data row 2 of the sheet', () => {
    const out = SPEC.fx_TransformaVolumen(volumenWb, 'VOLUMEN.xlsx');
    expect(out.length).toBeGreaterThan(0);
    // FilaOrigen is set to `idx + 2` where idx is the index in the FILTERED
    // array. So the first filtered row should have FilaOrigen=2.
    expect(out[0].FilaOrigen).toBe(2);
  });

  it('the LAST row of the raw sheet is "Filtros aplicados" — the filter must drop exactly those 2 footer rows', () => {
    // Sanity: confirm the raw input still has the footer rows so we know the
    // test is meaningful (i.e. the bug is reproducible against this input).
    const sheetName = volumenWb.SheetNames[0];
    const ws = volumenWb.Sheets[sheetName];
    const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: null });
    const lastTwo = aoa.slice(-2);
    expect(String(lastTwo[0][0] || '').toUpperCase().startsWith('TOTAL')).toBe(true);
    expect(String(lastTwo[1][0] || '').toUpperCase().indexOf('FILTROS APLICADOS')).toBeGreaterThanOrEqual(0);
  });

  it('sibling functions fx_TransformaHoras and fx_TransformaVolumenSinHoras still apply their filters (no regression)', () => {
    // Sanity check that the fix in fx_TransformaVolumen did not accidentally
    // break the sibling functions.
    const wbHoras = readXlsx(join(IN_DIR, 'HORA SIN VOLUMEN.xlsx'));
    const wbVSH = readXlsx(join(IN_DIR, 'VOL SIN HORAS.xlsx'));
    const horas = SPEC.fx_TransformaHoras(wbHoras, 'HORA SIN VOLUMEN.xlsx');
    const vsh = SPEC.fx_TransformaVolumenSinHoras(wbVSH, 'VOL SIN HORAS.xlsx');
    const horasTotal = horas.filter(r => String(r['Site name'] || '').toUpperCase().startsWith('TOTAL'));
    const horasFiltros = horas.filter(r => String(r['Site name'] || '').toUpperCase().indexOf('FILTROS APLICADOS') >= 0);
    const vshTotal = vsh.filter(r => String(r['Site name'] || '').toUpperCase().startsWith('TOTAL'));
    const vshFiltros = vsh.filter(r => String(r['Site name'] || '').toUpperCase().indexOf('FILTROS APLICADOS') >= 0);
    expect(horasTotal).toEqual([]);
    expect(horasFiltros).toEqual([]);
    expect(vshTotal).toEqual([]);
    expect(vshFiltros).toEqual([]);
  });
});

describe('AUD-LOW-004 — Bug 3: formatNum useGrouping', () => {
  // The fix: formatNum2 and formatNum0 use `useGrouping: false` so they don't
  // add thousand separators ("2.237" where Excel shows "2237"). This matters
  // because Excel-equivalence checks compare the JS-rendered value to the
  // Excel cell value, and Excel does NOT render thousand separators in raw
  // numeric cells.
  //
  // IMPORTANT nuance: the fix was applied to formatNum2 and formatNum0, but
  // NOT to formatNum itself — formatNum still has useGrouping: true at the
  // time of writing this test (it's only used by UI display, not by the data
  // pipeline, so the equivalence tests passed either way).
  //
  // formatNum2 and formatNum0 are private to the IIFE — we access them via
  // tests/helpers/loadAppWithPriv.js (regex-patched source that exposes the
  // private symbols WITHOUT modifying app.js on disk).

  describe('formatNum2 — the fix IS applied', () => {
    it('formatNum2(2237.5) → "2237,50" (NO thousand separators, exactly 2 decimals)', () => {
      expect(priv.formatNum2(2237.5)).toBe('2237,50');
    });
    it('formatNum2(1234567.89) → "1234567,89" (no thousand separators even on large numbers)', () => {
      expect(priv.formatNum2(1234567.89)).toBe('1234567,89');
    });
    it('formatNum2(0) → "0,00"', () => {
      expect(priv.formatNum2(0)).toBe('0,00');
    });
    it('formatNum2(0.5) → "0,50"', () => {
      expect(priv.formatNum2(0.5)).toBe('0,50');
    });
    it('formatNum2(-1234.5) → "-1234,50" (no thousand separators on negatives)', () => {
      expect(priv.formatNum2(-1234.5)).toBe('-1234,50');
    });
  });

  describe('formatNum0 — the fix IS applied', () => {
    it('formatNum0(2237.5) → "2238" (no thousand separators, 0 decimals, rounded)', () => {
      expect(priv.formatNum0(2237.5)).toBe('2238');
    });
    it('formatNum0(1234567.89) → "1234568" (no thousand separators)', () => {
      expect(priv.formatNum0(1234567.89)).toBe('1234568');
    });
    it('formatNum0(0.4) → "0" (rounds down)', () => {
      expect(priv.formatNum0(0.4)).toBe('0');
    });
    it('formatNum0(0.5) → "1" (es-ES toLocaleString with maximumFractionDigits:0 uses round-half-up, NOT banker\'s rounding)', () => {
      // Verified empirically: 0.5→1, 1.5→2, 2.5→3, 3.5→4 (all round up).
      // This diverges from M's Number.ToText which uses banker's rounding,
      // but the difference is a feature, not a bug — it's the documented
      // behavior of toLocaleString in V8.
      expect(priv.formatNum0(0.5)).toBe('1');
    });
    it('formatNum0(1.5) → "2" (rounds up)', () => {
      expect(priv.formatNum0(1.5)).toBe('2');
    });
    it('formatNum0(2.5) → "3" (rounds up — NOT banker\'s even rounding which would give 2)', () => {
      expect(priv.formatNum0(2.5)).toBe('3');
    });
  });

  describe('formatNum — the fix IS applied (F11, sin it.fails ni skip)', () => {
    // F11 fix (verificado en app.js: formatNum usa useGrouping:false).
    // Las aserciones de abajo PASAN solo con el comportamiento CORREGIDO
    // (sin separador de miles, idéntico a M/Excel Number.ToText).
    // Si alguien reintroduce useGrouping:true, estos tests FALLAN — no hay
    // mecanismo alguno (it.fails/skip) que oculte el bug.
    //
    // Histórico: antes del F11 fix, formatNum devolvía "2.237,5" y
    // "1.234.567,89" (con separadores); ahora devuelve "2237,5" y
    // "1234567,89" (sin separadores, igual que M/Excel).
    it('formatNum(2237.5) → "2237,5" (sin separador de miles — coincide con M/Excel)', () => {
      expect(SPEC.formatNum(2237.5)).toBe('2237,5');
    });

    it('formatNum(1234567.89) → "1234567,89" (sin separador de miles — coincide con M/Excel)', () => {
      expect(SPEC.formatNum(1234567.89)).toBe('1234567,89');
    });

    it('formatNum(0.5) → "0,5" (números pequeños no afectados por useGrouping)', () => {
      expect(SPEC.formatNum(0.5)).toBe('0,5');
    });

    it('formatNum(null) → "" (null/undefined manejado antes de useGrouping)', () => {
      expect(SPEC.formatNum(null)).toBe('');
    });
  });
});
