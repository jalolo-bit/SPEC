/* Tests v6.2 — analítica por tarea (taskAnalytics.js).
 * §10/§11/§20/§21/§35: ranking TASK_WMS, imputación SOLO a la tarea
 * afectada, espacios de nombre separados, tendencia, detalle. */
import { describe, it, expect } from 'vitest';
import { mkRecord, SEC, incSec } from '../helpers/analyticsFixtures.js';

const AN = globalThis.SPEC_AN;
const N = AN.normalizarRecords;

describe('taskAnalytics — ranking TASK_WMS (§10)', () => {
  it('cuenta oportunidades, personas, días, uds y horas por tarea', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', tareas: [{ taskWms: 'PICKING A', uds: 100 }, { taskWms: 'UBICACION B', uds: 50, actividad: 'UBICACION MANUAL' }] }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-25', tareas: [{ taskWms: 'PICKING A', uds: 200 }] }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-26', tareas: [{ taskWms: 'PICKING A', uds: 150 }] })
    ]);
    const st = AN.task.computeTaskStats(recs, AN.DEFAULT_CONFIG);
    const picking = st.find(t => t.taskWms === 'PICKING A');
    const ubi = st.find(t => t.taskWms === 'UBICACION B');
    expect(picking.oportunidades).toBe(3); // 3 persona-día
    expect(picking.personasN).toBe(2);
    expect(picking.diasN).toBe(2);
    expect(picking.uds).toBe(450);
    expect(ubi.actividad).toBe('UBICACION MANUAL');
  });

  it('§11 un error se imputa SOLO a la tarea realmente afectada', () => {
    // Persona con 2 tareas el mismo día; el error viene del volumen de BERSHKA
    const recs = N([
      mkRecord({
        login: 'A', fechaOperativaISO: '2026-08-25',
        tareas: [
          { taskWms: 'PICKING SIN PAPEL - PULL & BEAR', uds: 100, horasAsignadas: 4 },
          { taskWms: 'REPARTO A TIENDA AGV - BERSHKA', uds: 300, actividad: 'OTRA', productividad: null, horasAsignadas: 0 }
        ],
        incidencias: [incSec(SEC.cambio, { wmsTask: 'REPARTO A TIENDA AGV - BERSHKA', horasAfectadas: 3 })]
      }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-25', tareas: [{ taskWms: 'PICKING SIN PAPEL - PULL & BEAR', uds: 50 }] })
    ]);
    const st = AN.task.computeTaskStats(recs, AN.DEFAULT_CONFIG);
    const bers = st.find(t => t.taskWms === 'REPARTO A TIENDA AGV - BERSHKA');
    const pull = st.find(t => t.taskWms === 'PICKING SIN PAPEL - PULL & BEAR');
    expect(bers.errores).toBe(1);
    expect(bers.horasAfectadas).toBe(3);
    // La otra tarea del MISMO día NO recibe el error (§11):
    expect(pull.errores).toBe(0);
    expect(pull.horasAfectadas).toBe(0);
  });

  it('dedup de horas por ID REGISTRO (una propuesta múltiple no multiplica)', () => {
    const recs = N([
      mkRecord({
        login: 'A', fechaOperativaISO: '2026-08-25', idRegBase: 77,
        tareas: [{ taskWms: 'PICKING A', uds: 100 }],
        incidencias: [
          incSec(SEC.cambio, { wmsTask: 'PICKING A', horasAfectadas: 4 }),
          incSec(SEC.cambio, { wmsTask: 'PICKING A', horasAfectadas: 4 }) // mismo id registro
        ]
      })
    ]);
    const st = AN.task.computeTaskStats(recs, AN.DEFAULT_CONFIG);
    expect(st[0].errores).toBe(2);           // 2 propuestas
    expect(st[0].horasAfectadas).toBe(4);    // pero las horas cuentan 1 vez
  });

  it('tasa = errores / oportunidades con muestra pequeña configurable', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', tareas: [{ taskWms: 'T1', uds: 10 }], incidencias: [incSec(SEC.cambio, { wmsTask: 'T1' })] }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-26', tareas: [{ taskWms: 'T1', uds: 10 }] })
    ]);
    const st = AN.task.computeTaskStats(recs, AN.DEFAULT_CONFIG);
    expect(st[0].oportunidades).toBe(2);
    expect(st[0].errores).toBe(1);
    expect(st[0].pctError).toBe(50);
    expect(st[0].muestraPequena).toBe(true); // 2 < 3
  });

  it('incidencias SIN wmsTask no se imputan a ninguna tarea (no inventa)', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', tareas: [{ taskWms: 'T1', uds: 10 }], incidencias: [incSec(SEC.sinVol, { wmsTask: '', horasAfectadas: 8 })] })
    ]);
    const st = AN.task.computeTaskStats(recs, AN.DEFAULT_CONFIG);
    expect(st[0].errores).toBe(0); // sección 4 sin tarea: fuera del ranking de tareas
    expect(st[0].horasAfectadas).toBe(0);
  });
});

describe('taskAnalytics — tareas fichadas / HR Task (espacio fichaje)', () => {
  it('cuenta fichajes, cambios propuestos y correctas por HR Task', () => {
    const recs = N([
      mkRecord({
        login: 'A', fechaOperativaISO: '2026-08-25', hrTask: '20001 A',
        registros: [{ idRegistroHoras: '1', hora: '08:00', turno: 'MAÑANA', horas: 8, hrTask: '20001 A' }],
        incidencias: [incSec(SEC.cambio, { tareaOriginal: '20001 A', propuesta: '20002 B', horasAfectadas: 2 })]
      }),
      mkRecord({
        login: 'B', fechaOperativaISO: '2026-08-25', hrTask: '20001 A',
        registros: [{ idRegistroHoras: '2', hora: '08:00', turno: 'MAÑANA', horas: 8, hrTask: '20001 A' }],
        incidencias: [incSec(SEC.correcta, { tareaOriginal: '20001 A', propuesta: '20001 A' })]
      })
    ]);
    const f = AN.task.computeFichajeStats(recs, AN.DEFAULT_CONFIG);
    const x = f.find(t => t.hrTask === '20001 A');
    expect(x.fichajes).toBe(2);
    expect(x.erroresCambio).toBe(1);
    expect(x.correctas).toBe(1);
    expect(x.tasaCambio).toBe(50); // 1 / (1+1)
    expect(x.propuestaHabitual).toBe('20002 B');
  });

  it('propuestaHabitual solo cuando hay UNA propuesta única', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', incidencias: [incSec(SEC.cambio, { tareaOriginal: 'X', propuesta: 'Y' })] }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-26', incidencias: [incSec(SEC.cambio, { tareaOriginal: 'X', propuesta: 'Z' })] })
    ]);
    const f = AN.task.computeFichajeStats(recs, AN.DEFAULT_CONFIG);
    expect(f[0].propuestaHabitual).toBeNull();
    expect(f[0].topPropuestas.length).toBe(2);
  });
});

describe('taskAnalytics — tendencia de tareas (§20/§21)', () => {
  it('detecta deterioro con evidencia suficiente en ambas mitades', () => {
    const recs = [];
    for (let i = 1; i <= 4; i++) recs.push(mkRecord({ login: 'A' + i, fechaOperativaISO: '2026-08-0' + i, tareas: [{ taskWms: 'T1', uds: 10 }] }));
    for (let i = 10; i <= 13; i++) recs.push(mkRecord({ login: 'B' + i, fechaOperativaISO: '2026-08-' + i, tareas: [{ taskWms: 'T1', uds: 10 }], incidencias: [incSec(SEC.cambio, { wmsTask: 'T1' })] }));
    const t = AN.task.computeTaskTendencia(N(recs), AN.DEFAULT_CONFIG).find(x => x.taskWms === 'T1');
    expect(t.suficiente).toBe(true);
    expect(t.veredicto).toBe('EMPEORA');
    expect(t.tasaA).toBe(0);
    expect(t.tasaB).toBe(100);
  });
  it('sin evidencia suficiente → SIN EVIDENCIA (§63)', () => {
    const recs = [
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', tareas: [{ taskWms: 'T1', uds: 10 }] }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-26', tareas: [{ taskWms: 'T1', uds: 10 }], incidencias: [incSec(SEC.cambio, { wmsTask: 'T1' })] })
    ];
    const t = AN.task.computeTaskTendencia(N(recs), AN.DEFAULT_CONFIG).find(x => x.taskWms === 'T1');
    expect(t.suficiente).toBe(false);
    expect(t.veredicto).toBe('SIN EVIDENCIA');
  });
});

describe('taskAnalytics — detalle de tarea (§35)', () => {
  it('construye el perfil con personas afectadas, evolución y mappings', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', mappingHash: 'h1', tareas: [{ taskWms: 'T1', uds: 10 }], incidencias: [incSec(SEC.cambio, { wmsTask: 'T1', horasAfectadas: 2 })] }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-26', mappingHash: 'h2', tareas: [{ taskWms: 'T1', uds: 10 }] })
    ]);
    const prof = AN.task.computeTaskProfile(recs, 'T1', AN.DEFAULT_CONFIG);
    expect(prof.stats.oportunidades).toBe(2);
    expect(prof.personasAfectadas[0].login).toBe('A');
    expect(prof.evolucion.length).toBe(2);
    expect(prof.mappingsUsados.sort()).toEqual(['h1', 'h2']);
  });
  it('perfil de tarea inexistente devuelve null', () => {
    expect(AN.task.computeTaskProfile(N([mkRecord({})]), 'NOEXISTE', AN.DEFAULT_CONFIG)).toBeNull();
  });
});
