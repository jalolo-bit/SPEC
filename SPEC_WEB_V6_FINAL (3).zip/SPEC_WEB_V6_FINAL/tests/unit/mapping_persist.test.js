// Unit tests v6.1 — MEJORA 3: mapping persistente (hash, versionado, snapshots)
//
// Verifica a nivel de MOTOR (sin DOM):
//   - calcularMappingHashSHA256 determinista y sensible a cambios
//   - hash distinto del FNV legacy pero igual longitud (SHA-256 completo)
//   - restauración histórica: un record guarda SU hash y sigue interpretable
//   - el hash no depende del orden de las propiedades del objeto

import { describe, it, expect, beforeAll } from 'vitest';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const SPEC = globalThis.SPEC;
const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(__dirname, '..', '..');

// Cargar el mapping real para tests de hash realistas
function leerMappingDrive() {
  const XLSX = globalThis.XLSX;
  const path = resolve(ROOT, 'audit-ref', 'drive', 'Mapping.xlsx');
  const wb = XLSX.read(readFileSync(path), { type: 'buffer', cellDates: true });
  return SPEC.leerMapping(wb);
}

describe('v6.1 MEJORA 3 — calcularMappingHashSHA256 (versionado criptográfico)', () => {
  it('Produce un SHA-256 completo (64 hex) y determinista', async () => {
    const rows = [
      { SAP_CODE: 'ES146L', WMS_DC: 'X', CUSTOMER: 'C', DEPARTMENT: 'D', ACTIVITY: 'A', SUB_ACTIVITY: 'S', TASK_WMS: 'T1', TASK_SPEC: '2001 X' }
    ];
    const h1 = await SPEC.calcularMappingHashSHA256(rows);
    const h2 = await SPEC.calcularMappingHashSHA256(rows);
    expect(h1).toMatch(/^[a-f0-9]{64}$/);
    expect(h1).toBe(h2); // determinista
  });

  it('Cambia ante cualquier modificación del contenido', async () => {
    const rows = [
      { SAP_CODE: 'ES146L', WMS_DC: 'X', CUSTOMER: 'C', DEPARTMENT: 'D', ACTIVITY: 'A', SUB_ACTIVITY: 'S', TASK_WMS: 'T1', TASK_SPEC: '2001 X' }
    ];
    const base = await SPEC.calcularMappingHashSHA256(rows);
    // Cambio en TASK_SPEC
    const mod1 = [{ ...rows[0], TASK_SPEC: '2002 Y' }];
    expect(await SPEC.calcularMappingHashSHA256(mod1)).not.toBe(base);
    // Cambio en TASK_WMS
    const mod2 = [{ ...rows[0], TASK_WMS: 'T2' }];
    expect(await SPEC.calcularMappingHashSHA256(mod2)).not.toBe(base);
    // Fila añadida
    const mod3 = rows.concat([{ ...rows[0], TASK_WMS: 'T3' }]);
    expect(await SPEC.calcularMappingHashSHA256(mod3)).not.toBe(base);
    // Fila eliminada
    expect(await SPEC.calcularMappingHashSHA256([])).not.toBe(base);
  });

  it('No depende del orden de las propiedades del objeto', async () => {
    const a = { SAP_CODE: 'E', WMS_DC: 'W', CUSTOMER: 'C', DEPARTMENT: 'D', ACTIVITY: 'A', SUB_ACTIVITY: 'S', TASK_WMS: 'T', TASK_SPEC: 'Z' };
    const b = { TASK_SPEC: 'Z', TASK_WMS: 'T', SUB_ACTIVITY: 'S', ACTIVITY: 'A', DEPARTMENT: 'D', CUSTOMER: 'C', WMS_DC: 'W', SAP_CODE: 'E' };
    expect(await SPEC.calcularMappingHashSHA256([a])).toBe(await SPEC.calcularMappingHashSHA256([b]));
  });

  it('Solo hash de las 8 columnas estructurales (metadatos extra no afectan)', async () => {
    const rows = [{ SAP_CODE: 'E', WMS_DC: 'W', CUSTOMER: 'C', DEPARTMENT: 'D', ACTIVITY: 'A', SUB_ACTIVITY: 'S', TASK_WMS: 'T', TASK_SPEC: 'Z', PRODUCTIVE_TASK: true, extra: 'no cuenta' }];
    const clean = [{ SAP_CODE: 'E', WMS_DC: 'W', CUSTOMER: 'C', DEPARTMENT: 'D', ACTIVITY: 'A', SUB_ACTIVITY: 'S', TASK_WMS: 'T', TASK_SPEC: 'Z' }];
    expect(await SPEC.calcularMappingHashSHA256(rows)).toBe(await SPEC.calcularMappingHashSHA256(clean));
  });

  it('Hash del mapping REAL de referencia (167 filas) es estable', async () => {
    const rows = leerMappingDrive();
    expect(rows.length).toBeGreaterThan(100);
    const h = await SPEC.calcularMappingHashSHA256(rows);
    expect(h).toMatch(/^[a-f0-9]{64}$/);
    const h2 = await SPEC.calcularMappingHashSHA256(leerMappingDrive());
    expect(h).toBe(h2);
  });
});

describe('v6.1 MEJORA 3 — FNV legacy coexiste con SHA-256 (compatibilidad)', () => {
  it('calcularMappingHash (FNV) sigue determinista para la cadena de auditoría', () => {
    const rows = leerMappingDrive();
    const a = SPEC.calcularMappingHash(rows);
    const b = SPEC.calcularMappingHash(rows);
    expect(a).toBe(b);
    expect(a).toMatch(/^[a-f0-9]{8}$/); // FNV-1a 32-bit
    const mod = rows.map(r => ({ ...r }));
    mod[0].TASK_SPEC = (mod[0].TASK_SPEC || '') + 'X';
    expect(SPEC.calcularMappingHash(mod)).not.toBe(a);
  });
});

describe('v6.1 MEJORA 3 — restauración histórica con snapshot del mapping', () => {
  // El requisito: "Un registro generado con mappingHash = ABC123 debe seguir
  // siendo interpretable con ese mapping aunque semanas después se importe otro"
  it('El record guarda SU mappingHash aunque el estado global cambie después', async () => {
    const H = [
      { 'Fecha': SPEC.fx_Fecha(46259), 'FechaOriginal': 46259, 'LoginCanonico': 'OTO0499', 'Name': 'A', 'HorasSinVolumen': 8, 'HR Task': 'T', 'IdRegistroHoras': 1 }
    ];
    const VM = [
      { 'Fecha': SPEC.fx_Fecha(46259), 'LoginCanonico': 'OTO0499', 'IdNumericoNormalizado': '499', 'WMS_TASK': 'Picking sin papel - Oysho', 'VolumenPositivo': 200, 'TasksSPEC': 'S', 'EstadoMapeoFinal': 'UNICO', 'WMS_DCs': '', 'ArchivoOrigen': '', 'FilaOrigen': 2, 'SAP_CODE': '', 'CUSTOMER': '' }
    ];
    const g = SPEC.q17_PersonaDiaAnalitica(H, VM, [], { productividades: SPEC.PARAMS.ProductividadesReferencia });
    // Se procesó con el mapping v1
    const recV1 = SPEC.generarPersonDailyRecords(g, [], { mappingHash: 'AAAA1111', mappingVersion: 1 })[0];
    expect(recV1.mappingHash).toBe('AAAA1111');
    expect(recV1.mappingVersion).toBe(1);
    // Semanas después se importa otro mapping (v2) y se reprocesa el MISMO día
    const recV2 = SPEC.generarPersonDailyRecords(g, [], { mappingHash: 'BBBB2222', mappingVersion: 2 })[0];
    // El registro histórico original NO cambia: sigue siendo interpretable con AAAA1111
    expect(recV1.mappingHash).toBe('AAAA1111');
    expect(recV1.mappingVersion).toBe(1);
    // El nuevo procesado referencia el nuevo mapping
    expect(recV2.mappingHash).toBe('BBBB2222');
    // Misma clave de identidad → la UI hace upsert versionado (trazabilidad)
    expect(recV1.key).toBe(recV2.key);
  });

  it('Los records también conservan las productividades usadas (snapshot)', () => {
    const g = [{ key: 'k', login: 'L', persona: 'P', fechaOperativa: SPEC.fx_Fecha(46259), fechaOperativaISO: '2026-09-26', semana: '2026-W39', mes: '2026-09', turno: 'SIN HORA', turnos: ['SIN HORA'], horasFichadas: 1, horasAnalizables: 1, udsTotales: 0, udsSinHoras: 0, horasEquivalentes: 0, horasAsignadas: 0, desviacion: 1, nActividades: 0, actividades: [], modoVolumen: null, registros: [] }];
    const prods = { 'PICKING AGV': 111 };
    const rec = SPEC.generarPersonDailyRecords(g, [], { mappingHash: 'X', productividades: prods })[0];
    expect(rec.productividades).toEqual(prods);
    // Cambiar las preferencias globales después NO reescribe el histórico
    const otras = { 'PICKING AGV': 999 };
    expect(rec.productividades).toEqual(prods);
    expect(otras['PICKING AGV']).toBe(999); // sanity
  });
});
