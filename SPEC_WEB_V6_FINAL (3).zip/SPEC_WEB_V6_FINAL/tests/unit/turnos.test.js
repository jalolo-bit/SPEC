// Unit tests v6.1 — MEJORA 1: Filtro de turnos + FECHA_OPERATIVA_TURNO
//
// Casos obligatorios del usuario:
//   05:59 → noche · 06:00 → mañana · 13:59 → mañana · 14:00 → tarde
//   21:59 → tarde · 22:00 → noche · 23:59 → noche · 00:00 → noche
// Además: cobertura completa 0-1439 (exactamente una clasificación por minuto,
// sin huecos ni solapamientos) y regla de fecha operativa nocturna:
//   25/08 23:00 → 25/08 · 26/08 02:00 → 25/08 · 26/08 06:00 → 26/08

import { describe, it, expect } from 'vitest';

const SPEC = globalThis.SPEC;

describe('v6.1 MEJORA 1 — fx_Turno (límites exactos)', () => {
  it('05:59 → NOCHE', () => {
    expect(SPEC.fx_Turno(5 * 60 + 59)).toBe('NOCHE');
  });
  it('06:00 → MAÑANA', () => {
    expect(SPEC.fx_Turno(6 * 60)).toBe('MAÑANA');
  });
  it('13:59 → MAÑANA', () => {
    expect(SPEC.fx_Turno(13 * 60 + 59)).toBe('MAÑANA');
  });
  it('14:00 → TARDE', () => {
    expect(SPEC.fx_Turno(14 * 60)).toBe('TARDE');
  });
  it('21:59 → TARDE', () => {
    expect(SPEC.fx_Turno(21 * 60 + 59)).toBe('TARDE');
  });
  it('22:00 → NOCHE', () => {
    expect(SPEC.fx_Turno(22 * 60)).toBe('NOCHE');
  });
  it('23:59 → NOCHE', () => {
    expect(SPEC.fx_Turno(23 * 60 + 59)).toBe('NOCHE');
  });
  it('00:00 → NOCHE', () => {
    expect(SPEC.fx_Turno(0)).toBe('NOCHE');
  });

  it('acepta Date con componente horaria (UTC)', () => {
    expect(SPEC.fx_Turno(new Date(Date.UTC(2026, 7, 25, 6, 30)))).toBe('MAÑANA');
    expect(SPEC.fx_Turno(new Date(Date.UTC(2026, 7, 25, 22, 0)))).toBe('NOCHE');
    expect(SPEC.fx_Turno(new Date(Date.UTC(2026, 7, 25, 14, 0)))).toBe('TARDE');
  });

  it('lanza error con valores inválidos', () => {
    expect(() => SPEC.fx_Turno(-1)).toThrow();
    expect(() => SPEC.fx_Turno(1440)).toThrow();
    expect(() => SPEC.fx_Turno('mañana')).toThrow();
    expect(() => SPEC.fx_Turno(null)).toThrow();
    expect(() => SPEC.fx_Turno(new Date('no-es-fecha'))).toThrow();
  });

  it('cobertura completa: exactamente una clasificación por cada minuto del día', () => {
    const counts = { MAÑANA: 0, TARDE: 0, NOCHE: 0 };
    for (let m = 0; m < 1440; m++) {
      const t = SPEC.fx_Turno(m);
      expect(['MAÑANA', 'TARDE', 'NOCHE']).toContain(t);
      counts[t]++;
    }
    // MAÑANA 06:00-13:59 = 8h = 480 min; TARDE 14:00-21:59 = 480; NOCHE 22:00-05:59 = 480
    expect(counts.MAÑANA).toBe(480);
    expect(counts.TARDE).toBe(480);
    expect(counts.NOCHE).toBe(480);
    expect(counts.MAÑANA + counts.TARDE + counts.NOCHE).toBe(1440);
  });
});

describe('v6.1 MEJORA 1 — fx_FechaOperativaTurno (regla nocturna)', () => {
  const d = (y, m, dd) => new Date(Date.UTC(y, m - 1, dd));
  const iso = (x) => x.toISOString().slice(0, 10);

  it('25/08 23:00 → fecha operativa 25/08 (hora >= 22:00 → fecha actual)', () => {
    expect(iso(SPEC.fx_FechaOperativaTurno(d(2026, 8, 25), 23 * 60))).toBe('2026-08-25');
  });
  it('26/08 02:00 → fecha operativa 25/08 (hora < 06:00 → fecha anterior)', () => {
    expect(iso(SPEC.fx_FechaOperativaTurno(d(2026, 8, 26), 2 * 60))).toBe('2026-08-25');
  });
  it('26/08 05:59 → fecha operativa 25/08 (último minuto de la noche)', () => {
    expect(iso(SPEC.fx_FechaOperativaTurno(d(2026, 8, 26), 5 * 60 + 59))).toBe('2026-08-25');
  });
  it('26/08 06:00 → fecha operativa 26/08 (turno MAÑANA)', () => {
    expect(iso(SPEC.fx_FechaOperativaTurno(d(2026, 8, 26), 6 * 60))).toBe('2026-08-26');
  });
  it('26/08 14:00 → fecha operativa 26/08 (turno TARDE)', () => {
    expect(iso(SPEC.fx_FechaOperativaTurno(d(2026, 8, 26), 14 * 60))).toBe('2026-08-26');
  });
  it('26/08 21:59 → fecha operativa 26/08 (fin de TARDE)', () => {
    expect(iso(SPEC.fx_FechaOperativaTurno(d(2026, 8, 26), 21 * 60 + 59))).toBe('2026-08-26');
  });
  it('26/08 22:00 → fecha operativa 26/08 (NOCHE empieza, fecha actual)', () => {
    expect(iso(SPEC.fx_FechaOperativaTurno(d(2026, 8, 26), 22 * 60))).toBe('2026-08-26');
  });
  it('01/03 00:15 → fecha operativa 28/02 (cruza fin de mes)', () => {
    expect(iso(SPEC.fx_FechaOperativaTurno(d(2026, 3, 1), 15))).toBe('2026-02-28');
  });
  it('01/01 03:00 → fecha operativa 31/12 del año anterior (cruza año)', () => {
    expect(iso(SPEC.fx_FechaOperativaTurno(d(2027, 1, 1), 3 * 60))).toBe('2026-12-31');
  });
  it('hora null → fecha sin cambio (datos day-level)', () => {
    expect(iso(SPEC.fx_FechaOperativaTurno(d(2026, 8, 26), null))).toBe('2026-08-26');
  });
  it('acepta Date como hora', () => {
    const fecha = d(2026, 8, 26);
    const horaDate = new Date(Date.UTC(2026, 8, 26, 2, 15));
    expect(iso(SPEC.fx_FechaOperativaTurno(fecha, horaDate))).toBe('2026-08-25');
  });
});

describe('v6.1 MEJORA 1 — extraerHoraFichaje (convención de datos)', () => {
  it('Date a medianoche exacta → null (fecha day-level, sin hora)', () => {
    expect(SPEC.extraerHoraFichaje(new Date(Date.UTC(2026, 7, 25, 0, 0, 0, 0)))).toBeNull();
  });
  it('Date con hora → minutos del día', () => {
    expect(SPEC.extraerHoraFichaje(new Date(Date.UTC(2026, 7, 25, 23, 30)))).toBe(23 * 60 + 30);
    expect(SPEC.extraerHoraFichaje(new Date(Date.UTC(2026, 7, 25, 6, 0)))).toBe(360);
  });
  it('serial Excel entero → null (day-level)', () => {
    expect(SPEC.extraerHoraFichaje(46259)).toBeNull();
  });
  it('serial Excel con fracción → minutos del día', () => {
    // 46259.5 = mediodía → 720 min
    expect(SPEC.extraerHoraFichaje(46259.5)).toBe(720);
    // 46259 + 23.5h → 1410 min (23:30)
    expect(SPEC.extraerHoraFichaje(46259 + 23.5 / 24)).toBe(23 * 60 + 30);
    // 46259 + 2.25h → 135 min (02:15)
    expect(SPEC.extraerHoraFichaje(46259 + 2.25 / 24)).toBe(2 * 60 + 15);
  });
  it('null / string / inválido → null', () => {
    expect(SPEC.extraerHoraFichaje(null)).toBeNull();
    expect(SPEC.extraerHoraFichaje('25/08/2026')).toBeNull();
    expect(SPEC.extraerHoraFichaje(new Date('x'))).toBeNull();
  });
});
