/* Tests v6.2 — núcleo de la capa analítica (analyticsCore.js).
 * Configuración, divisiones seguras, media móvil, clasificación de
 * incidencias, normalización, filtros, KPIs y comparación de periodos. */
import { describe, it, expect, beforeEach } from 'vitest';
import { mkRecord, SEC, incSec } from '../helpers/analyticsFixtures.js';

const AN = globalThis.SPEC_AN;
const N = AN.normalizarRecords;

describe('analyticsCore — configuración estadística', () => {
  it('expone defaults completos y documentados (§38)', () => {
    const c = AN.DEFAULT_CONFIG;
    for (const k of ['minDiasComparar', 'minObservaciones', 'umbralCambioPP', 'rachaDias',
      'recurrenciaHabitual', 'recurrenciaRecurrente', 'ventanaMediaMovil', 'ventanaRollingLarga',
      'repeticionesConfusion', 'umbralTurnoPP', 'otraUdsMinimas', 'impactoHorasAltas',
      'semaforoBueno', 'semaforoNormal', 'semaforoAtencion', 'semaforoMinDias',
      'pesoFrecuencia', 'pesoTasa', 'pesoHoras', 'pesoRecurrencia', 'pesoTendencia',
      'pesoPersonas', 'prioridadAlta', 'prioridadMedia']) {
      expect(c[k], 'falta el umbral ' + k).toBeTypeOf('number');
      expect(isFinite(c[k])).toBe(true);
    }
  });

  it('loadConfig devuelve defaults sin almacenamiento', () => {
    const c = AN.loadConfig(null);
    expect(c.minDiasComparar).toBe(AN.DEFAULT_CONFIG.minDiasComparar);
  });

  it('loadConfig fusiona valores persistidos válidos e ignora basura', () => {
    const st = new Map();
    const storage = { getItem: k => (st.has(k) ? st.get(k) : null), setItem: (k, v) => st.set(k, v), removeItem: k => st.delete(k) };
    st.set(AN.LS_KEY, JSON.stringify({ minDiasComparar: 7, rachaDias: 'basura', inventado: 99 }));
    const c = AN.loadConfig(storage);
    expect(c.minDiasComparar).toBe(7);
    expect(c.rachaDias).toBe(AN.DEFAULT_CONFIG.rachaDias); // basura ignorada
    expect(c.inventado).toBeUndefined();
  });

  it('loadConfig sobrevive a JSON corrupto (defaults, sin lanzar)', () => {
    const st = new Map([['x', '']]);
    const storage = { getItem: () => '{{{', setItem: () => {}, removeItem: () => {} };
    expect(AN.loadConfig(storage).minDiasComparar).toBe(AN.DEFAULT_CONFIG.minDiasComparar);
    expect(st.size).toBe(1);
  });

  it('saveConfig + resetConfig persisten y restauran', () => {
    const st = new Map();
    const storage = { getItem: k => (st.has(k) ? st.get(k) : null), setItem: (k, v) => st.set(k, v), removeItem: k => st.delete(k) };
    const c = Object.assign({}, AN.DEFAULT_CONFIG, { umbralCambioPP: 12 });
    expect(AN.saveConfig(c, storage)).toBe(true);
    expect(AN.loadConfig(storage).umbralCambioPP).toBe(12);
    const r = AN.resetConfig(storage);
    expect(r.umbralCambioPP).toBe(AN.DEFAULT_CONFIG.umbralCambioPP);
    expect(AN.loadConfig(storage).umbralCambioPP).toBe(AN.DEFAULT_CONFIG.umbralCambioPP);
  });
});

describe('analyticsCore — divisiones seguras (§58: nunca NaN/Infinity)', () => {
  it('safeDiv con denominador 0 devuelve 0', () => {
    expect(AN.safeDiv(10, 0)).toBe(0);
    expect(AN.safeDiv(0, 0)).toBe(0);
  });
  it('safeDiv con no-números devuelve 0', () => {
    expect(AN.safeDiv(undefined, 2)).toBe(0);
    expect(AN.safeDiv('x', 'y')).toBe(0);
    expect(AN.safeDiv(NaN, 5)).toBe(0);
  });
  it('safeDiv calcula correctamente', () => {
    expect(AN.safeDiv(10, 4)).toBe(2.5);
    expect(AN.safeDiv(1, 3)).toBeCloseTo(0.3333333, 6);
  });
  it('pct acota a [0,100] para partes de un total', () => {
    expect(AN.pct(50, 200)).toBe(25);
    expect(AN.pct(300, 200)).toBe(100); // acotado (definición de parte de un todo)
    expect(AN.pct(-5, 200)).toBe(0);
    expect(AN.pct(5, 0)).toBe(0);
  });
});

describe('analyticsCore — media móvil (§14: sin ventana completa no se calcula)', () => {
  it('devuelve nulls cuando no hay ventana completa', () => {
    const r = AN.mediaMovil([1, 2], 7);
    expect(r).toEqual([null, null]);
  });
  it('calcula la media solo desde el punto con ventana completa', () => {
    const r = AN.mediaMovil([1, 2, 3, 4, 5, 6, 7, 8], 3);
    expect(r[0]).toBeNull(); expect(r[1]).toBeNull();
    expect(r[2]).toBe(2); expect(r[3]).toBe(3); expect(r[7]).toBe(7);
  });
  it('es determinista y estable con series constantes', () => {
    const r = AN.mediaMovil([5, 5, 5, 5, 5], 5);
    expect(r[4]).toBe(5);
  });
  it('ventana 1 replica la serie', () => {
    expect(AN.mediaMovil([3, 7, 9], 1)).toEqual([3, 7, 9]);
  });
});

describe('analyticsCore — clasificación de incidencias (§50)', () => {
  it('clasifica cada sección con su tipo y causa', () => {
    const casos = [
      [SEC.cambio, 'ERROR DE FICHAJE', 'OPERATIVO'],
      [SEC.varias, 'AMBIGÜEDAD MAPPING', 'DATOS'],
      [SEC.correcta, 'REVISIÓN (CORRECTA)', 'CONTROL'],
      [SEC.sinVol, 'SIN VOLUMEN', 'OPERATIVO'],
      [SEC.sinMap, 'SIN MAPPING', 'DATOS'],
      [SEC.multi, 'MÚLTIPLES HR TASK', 'REVISIÓN'],
      [SEC.ambiguoId, 'AMBIGÜEDAD IDNUM', 'REVISIÓN']
    ];
    for (const [seccion, tipo, causa] of casos) {
      const c = AN.clasificarIncidencia({ seccion });
      expect(c.tipoError, seccion).toBe(tipo);
      expect(c.categoria, seccion).toBe(causa);
    }
  });
  it('esError excluye la sección 3 (control)', () => {
    expect(AN.clasificarIncidencia({ seccion: SEC.correcta }).esError).toBe(false);
    expect(AN.clasificarIncidencia({ seccion: SEC.cambio }).esError).toBe(true);
    expect(AN.clasificarIncidencia({ seccion: '' }).esError).toBe(false);
  });
  it('error de asignación = sección 1 o decisión aceptada (definición v6.1)', () => {
    expect(AN.clasificarIncidencia({ seccion: SEC.cambio }).esErrorAsignacion).toBe(true);
    expect(AN.clasificarIncidencia({ seccion: SEC.correcta, decision: 'aceptada' }).esErrorAsignacion).toBe(true);
    expect(AN.clasificarIncidencia({ seccion: SEC.correcta }).esErrorAsignacion).toBe(false);
  });
});

describe('analyticsCore — normalización de registros', () => {
  it('normaliza un record completo (v6.2 con wmsTask/cliente/versiones)', () => {
    const rec = mkRecord({
      incidencias: [incSec(SEC.cambio, { wmsTask: 'REPARTO A TIENDA AGV - BERSHKA', cliente: 'BERSHKA', horasAfectadas: 2 })]
    });
    const n = AN.normalizarRecords([rec])[0];
    expect(n.login).toBe('OTO1');
    expect(n.tareas[0].taskWms).toContain('PICKING');
    expect(n.tareas[0].cliente).toBe('PULL&BEAR');
    expect(n.incidencias[0].wmsTask).toContain('BERSHKA');
    expect(n.incidencias[0].esErrorFichaje).toBe(true);
    expect(n.incidencias[0].categoria).toBe('OPERATIVO');
    expect(n.conError).toBe(true);
    expect(n.datasetFingerprint).toBe(rec.dataFingerprint);
  });
  it('sobrevive a records legacy sin campos v6.2 (normaliza con vacíos)', () => {
    const legacy = {
      key: 'L1|2026-08-25', login: 'L1', persona: 'LEGACY', fechaOperativaISO: '2026-08-25',
      turno: 'SIN HORA', horasAnalizables: 8, actividades: [{ actividad: 'PICKING MANUAL', uds: 50, tareasWms: ['TAREA VIEJA A', 'TAREA VIEJA B'], horasAsignadas: 8 }],
      incidencias: [{ id: 'x@1', seccion: '5. WMS TASK SIN MAPPING', horasAfectadas: 3 }], horasConIncidencia: 3
    };
    const n = AN.normalizarRecords([legacy])[0];
    expect(n.tareas.length).toBe(2); // una fila por tareasWms legacy
    expect(n.tareas[0].taskWms).toBe('TAREA VIEJA A');
    expect(n.incidencias[0].tipoError).toBe('SIN MAPPING');
  });
  it('descarta records sin login o fecha', () => {
    expect(AN.normalizarRecords([{ login: 'x' }, { fechaOperativaISO: '2026-08-25' }, mkRecord({})]).length).toBe(1);
  });
  it('ordena por fecha y login (determinista)', () => {
    const rs = AN.normalizarRecords([mkRecord({ login: 'B', fechaOperativaISO: '2026-08-26' }), mkRecord({ login: 'A', fechaOperativaISO: '2026-08-27' }), mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25' })]);
    expect(rs.map(r => r.login + r.fechaISO)).toEqual(['A2026-08-25', 'B2026-08-26', 'A2026-08-27']);
  });
});

describe('analyticsCore — filtros globales (§41/§42)', () => {
  const recs = AN.normalizarRecords([
    mkRecord({ login: 'P1', persona: 'ANA GARCIA', fechaOperativaISO: '2026-08-25', turno: 'MAÑANA', tareas: [{ taskWms: 'PICKING A', cliente: 'ZARA' }] }),
    mkRecord({ login: 'P2', persona: 'LUIS LOPEZ', fechaOperativaISO: '2026-08-26', turno: 'NOCHE', tareas: [{ taskWms: 'UBICACION B', cliente: 'BERSHKA' }] }),
    mkRecord({ login: 'P3', persona: 'EVA RUIZ', fechaOperativaISO: '2026-09-01', turno: 'SIN HORA', tareas: [{ taskWms: 'PICKING C', cliente: 'ZARA', actividad: 'OTRA' }] })
  ]);
  it('filtra por rango de fechas', () => {
    expect(AN.filtrarRecords(recs, { fechaDesde: '2026-08-26' }).map(r => r.login)).toEqual(['P2', 'P3']);
    expect(AN.filtrarRecords(recs, { fechaHasta: '2026-08-25' }).map(r => r.login)).toEqual(['P1']);
  });
  it('filtra por semana y mes ISO', () => {
    expect(AN.filtrarRecords(recs, { mes: '2026-08' }).length).toBe(2);
    expect(AN.filtrarRecords(recs, { mes: '2026-09' }).length).toBe(1);
  });
  it('filtra por persona (subcadena, case-insensitive)', () => {
    expect(AN.filtrarRecords(recs, { persona: 'ana' }).map(r => r.login)).toEqual(['P1']);
    expect(AN.filtrarRecords(recs, { persona: 'p2' }).map(r => r.login)).toEqual(['P2']);
  });
  it('filtra por turno exacto (SIN HORA no se reparte)', () => {
    expect(AN.filtrarRecords(recs, { turno: 'SIN HORA' }).map(r => r.login)).toEqual(['P3']);
    expect(AN.filtrarRecords(recs, { turno: 'NOCHE' }).map(r => r.login)).toEqual(['P2']);
  });
  it('filtra por actividad y por TASK_WMS (subcadena)', () => {
    expect(AN.filtrarRecords(recs, { actividad: 'OTRA' }).map(r => r.login)).toEqual(['P3']);
    expect(AN.filtrarRecords(recs, { taskWms: 'ubicacion' }).map(r => r.login)).toEqual(['P2']);
  });
  it('filtra por cliente y mapping', () => {
    expect(AN.filtrarRecords(recs, { cliente: 'zara' }).length).toBe(2);
    expect(AN.filtrarRecords(recs, { mappingHash: 'aaaa1111' }).length).toBe(3);
    expect(AN.filtrarRecords(recs, { mappingHash: 'otro' }).length).toBe(0);
  });
  it('filtros combinados se intersecan', () => {
    expect(AN.filtrarRecords(recs, { mes: '2026-08', turno: 'NOCHE' }).length).toBe(1);
    expect(AN.filtrarRecords(recs, { mes: '2026-08', turno: 'MAÑANA' }).length).toBe(1);
    expect(AN.filtrarRecords(recs, { mes: '2026-08', turno: 'SIN HORA' }).length).toBe(0);
  });
  it('dimensionesDisponibles lista valores reales presentes', () => {
    const d = AN.dimensionesDisponibles(recs);
    expect(d.clientes.sort()).toEqual(['BERSHKA', 'ZARA'].sort());
    expect(d.turnos).toContain('SIN HORA');
    expect(d.actividades).toContain('OTRA');
  });
});

describe('analyticsCore — KPIs base (§46)', () => {
  it('calcula personas, días, incidencias, tasas y horas con denominadores', () => {
    const recs = AN.normalizarRecords([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', horasAnalizables: 8, incidencias: [incSec(SEC.cambio, { horasAfectadas: 2 })] }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-26', horasAnalizables: 8 }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-25', horasAnalizables: 4 })
    ]);
    const k = AN.kpisBase(recs);
    expect(k.personas).toBe(2);
    expect(k.dias).toBe(2);
    expect(k.personaDia).toBe(3);
    expect(k.incidencias).toBe(1);
    expect(k.horasAnalizables).toBe(20);
    expect(k.horasAfectadas).toBe(2);
    expect(k.pctHorasAfectadas).toBe(10);
    expect(k.pctPersonaDiaConError).toBeCloseTo(33.33, 1);
    expect(k.erroresAsignacion).toBe(1);
    expect(k.pctErroresAsignacion).toBe(100);
  });
  it('con cero registros todo vale 0 sin NaN', () => {
    const k = AN.kpisBase([]);
    for (const key of Object.keys(k)) expect(k[key], key).not.toBeNaN();
    expect(k.pctHorasAfectadas).toBe(0);
  });
});

describe('analyticsCore — comparación de periodos (§4/§17/§18)', () => {
  it('compara mitades con deltas absolutos, relativos y pp', () => {
    const recs = AN.normalizarRecords([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-01' }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-02', incidencias: [incSec(SEC.cambio, { horasAfectadas: 1 })] }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-03' }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-04' }),
      mkRecord({ login: 'C', fechaOperativaISO: '2026-08-05', incidencias: [incSec(SEC.cambio, { horasAfectadas: 3 })] }),
      mkRecord({ login: 'C', fechaOperativaISO: '2026-08-06', incidencias: [incSec(SEC.cambio, { horasAfectadas: 2 })] })
    ]);
    const comp = AN.compararPeriodos(...(function () { const p = AN.partirPorMitades(recs); return [p.A, p.B]; })());
    // Mitades: A = 01/02/03 (3 registros, 1 con error), B = 04/05/06 (2 con error)
    expect(comp.A.personaDia).toBe(3);
    expect(comp.B.personaDia).toBe(3);
    expect(comp.cambios.incidencias).toBe(1); // 1 → 2
    expect(comp.cambios.pctPersonaDiaConError.deltaPP).toBeCloseTo(66.67 - 33.33, 1);
    expect(comp.cambios.horasAfectadas).toBe(4);
  });
  it('% relativo nulo cuando el periodo base es 0 (no se inventa)', () => {
    const c = AN.compararPeriodos(N([]), N([mkRecord({ incidencias: [incSec(SEC.cambio)] })]));
    expect(c.cambios.incidenciasPct).toBeNull();
    expect(c.cambios.incidencias).toBe(1);
  });
  it('etiqueta MEJORA/EMPEORA/SIN CAMBIO según umbral pp (§18)', () => {
    const mk = (nA, nB, fechaBase) => {
      const a = [], b = [];
      for (let i = 0; i < nA; i++) a.push(mkRecord({ login: 'A' + i, fechaOperativaISO: '2026-08-0' + (i + 1) }));
      for (let i = 0; i < nB; i++) b.push(mkRecord({ login: 'B' + i, fechaOperativaISO: '2026-08-2' + (i + 1), incidencias: [incSec(SEC.cambio)] }));
      return AN.compararPeriodos(N(a), N(b));
    };
    expect(AN.etiquetaComparacion(mk(2, 2), AN.DEFAULT_CONFIG)).toBe('EMPEORA'); // 0% → 100%
    expect(AN.etiquetaComparacion(mk(0, 0), AN.DEFAULT_CONFIG)).toBe('SIN CAMBIO');
    expect(AN.etiquetaComparacion(null, AN.DEFAULT_CONFIG)).toBe('SIN DATOS');
  });
  it('partirPorMitades es determinista y balanceado', () => {
    const recs = AN.normalizarRecords(Array.from({ length: 5 }, (_, i) => mkRecord({ login: 'X', fechaOperativaISO: '2026-08-0' + (i + 1) })));
    const p1 = AN.partirPorMitades(recs), p2 = AN.partirPorMitades(recs);
    expect(p1.A.length).toBe(3); expect(p1.B.length).toBe(2);
    expect(p1.A.map(r => r.fechaISO)).toEqual(p2.A.map(r => r.fechaISO));
  });
});
