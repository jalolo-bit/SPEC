/* Tests v6.2 — tendencias y evolución (trendAnalytics.js).
 * §14/§15/§16/§17/§26/§47: series diarias con media móvil (solo con ventana
 * completa), rolling 7/28 con días contiguos, buckets semana/mes con Δ,
 * comparación y matriz frecuencia×impacto. */
import { describe, it, expect } from 'vitest';
import { mkRecord, SEC, incSec } from '../helpers/analyticsFixtures.js';

const AN = globalThis.SPEC_AN;
const N = AN.normalizarRecords;

function dias(n, opts) {
  const o = opts || {};
  return Array.from({ length: n }, (_, i) => {
    const fecha = '2026-08-' + String(i + 1).padStart(2, '0');
    return mkRecord(Object.assign({ login: 'A', fechaOperativaISO: fecha }, o, {
      incidencias: typeof o.incidencias === 'function' ? o.incidencias(i) : (o.incidencias || [])
    }));
  });
}

describe('trendAnalytics — serie diaria (§14)', () => {
  it('agrega por fecha operativa con todas las métricas', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', horasAnalizables: 8, incidencias: [incSec(SEC.cambio, { horasAfectadas: 2 })] }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-25', horasAnalizables: 4 }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-26', horasAnalizables: 8 })
    ]);
    const d = AN.trend.computeDailySeries(recs, AN.DEFAULT_CONFIG);
    expect(d.serie.length).toBe(2);
    const d1 = d.serie[0];
    expect(d1.registros).toBe(2);
    expect(d1.personas).toBe(2);
    expect(d1.conError).toBe(1);
    expect(d1.pctPersonaDiaError).toBe(50);
    expect(d1.horasAnalizables).toBe(12);
    expect(d1.pctHorasAfectadas).toBeCloseTo(16.67, 1);
    expect(d1.erroresAsignacion).toBe(1);
  });

  it('media móvil SOLO desde el 7º punto (sin inventar antes) — §14', () => {
    const d = AN.trend.computeDailySeries(N(dias(9)), AN.DEFAULT_CONFIG);
    for (let i = 0; i < 6; i++) expect(d.serie[i].mediaMovilTasa).toBeNull();
    expect(d.serie[6].mediaMovilTasa).toBeTypeOf('number');
    expect(d.serie[7].mediaMovilTasa).toBeTypeOf('number');
    expect(d.serie[8].mediaMovilTasa).toBeTypeOf('number');
  });

  it('la media móvil refleja cambios reales de tasa', () => {
    const recs = dias(14, {
      incidencias: (i) => (i < 7 ? [] : [incSec(SEC.cambio)])
    });
    const d = AN.trend.computeDailySeries(N(recs), AN.DEFAULT_CONFIG);
    expect(d.serie[6].mediaMovilTasa).toBe(0); // ventana 1-7 sin errores
    expect(d.serie[13].mediaMovilTasa).toBeCloseTo(100, 5); // ventana 8-14 todos con error
  });

  it('rolling 7/28 sobre días contiguos del calendario (§47)', () => {
    const d = AN.trend.computeDailySeries(N(dias(10)), AN.DEFAULT_CONFIG);
    // días sin datos cuentan como 0: el rolling 7 del día 10 = registros de días 4-10
    const ultimo = d.serie[9];
    expect(ultimo.rolling7).toBeDefined();
    expect(ultimo.rolling7.registros).toBe(7);
    expect(ultimo.rolling7.incidencias).toBe(0);
    expect(ultimo.rolling28).toBeUndefined(); // no hay 28 días
    expect(d.rolling.ultimo7.registros).toBe(7);
    expect(d.rolling.ultimo28).toBeNull();
  });

  it('rolling 7 con errores en los últimos 3 días', () => {
    const recs = dias(10, { incidencias: (i) => (i >= 7 ? [incSec(SEC.cambio)] : []) });
    const d = AN.trend.computeDailySeries(N(recs), AN.DEFAULT_CONFIG);
    expect(d.rolling.ultimo7.incidencias).toBe(3);
    expect(d.rolling.ultimo7.registros).toBe(7);
    expect(d.rolling.ultimo7.tasa).toBeCloseTo(42.86, 1);
  });
});

describe('trendAnalytics — buckets semana/mes (§15/§16)', () => {
  it('agrupa por semana ISO con Δ frente a la anterior', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-03' }), // W32
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-04' }), // W32
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-11', incidencias: [incSec(SEC.cambio)] }) // W33
    ]);
    const s = AN.trend.computeBucketSeries(recs, 'semana', AN.DEFAULT_CONFIG);
    expect(s.length).toBe(2);
    expect(s[0].clave).toBe('2026-W32');
    expect(s[0].registros).toBe(2);
    expect(s[1].clave).toBe('2026-W33');
    expect(s[1].deltaIncidencias).toBe(1);
    expect(s[1].deltaPP).toBeCloseTo(100, 1);
    expect(s[0].deltaIncidencias).toBeNull();
  });

  it('agrupa por mes YYYY-MM', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25' }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-09-01' })
    ]);
    const s = AN.trend.computeBucketSeries(recs, 'mes', AN.DEFAULT_CONFIG);
    expect(s.map(x => x.clave)).toEqual(['2026-08', '2026-09']);
  });
});

describe('trendAnalytics — matriz frecuencia × impacto (§26)', () => {
  it('asigna cuadrantes por mediana del conjunto', () => {
    const fi = AN.trend.computeFrecuenciaImpacto([
      { nombre: 'A', tipo: 'TAREA', errores: 10, horasAfectadas: 20 },
      { nombre: 'B', tipo: 'TAREA', errores: 1, horasAfectadas: 1 },
      { nombre: 'C', tipo: 'TAREA', errores: 5, horasAfectadas: 10 },
      { nombre: 'D', tipo: 'TAREA', errores: 2, horasAfectadas: 30 }
    ]);
    expect(fi.puntos.length).toBe(4);
    const a = fi.puntos.find(p => p.nombre === 'A');
    const d = fi.puntos.find(p => p.nombre === 'D');
    const b = fi.puntos.find(p => p.nombre === 'B');
    expect(a.cuadrante).toBe('ALTO×ALTO');
    expect(b.cuadrante).toBe('BAJO×BAJO');
    expect(d.cuadrante).toBe('BAJO×ALTO'); // pocos errores pero horas altas
    expect(fi.medianaErrores).toBeTypeOf('number');
    expect(fi.medianaHoras).toBeTypeOf('number');
  });
  it('sin puntos → vacío y sin NaN', () => {
    const fi = AN.trend.computeFrecuenciaImpacto([{ nombre: 'X', errores: 0, horasAfectadas: 0 }]);
    expect(fi.puntos).toEqual([]);
    expect(fi.medianaErrores).toBe(0);
  });
});
