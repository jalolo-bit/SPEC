// Unit tests v6.1.1 — FILTRO REAL DE TURNOS sobre la función que filtra
// la tabla/lista de Revisar incidencias (SPEC.filtrarRegistrosPorTurno),
// usada también por Patrones, Persona/Día e históricos.
//
// Casos obligatorios del usuario (§4): crear registros sintéticos con horas
//   06:30, 13:59, 14:00, 21:59, 22:00, 02:00, 05:59 (+ uno SIN HORA)
// y verificar:
//   MAÑANA  → solo 06:30, 13:59
//   TARDE   → solo 14:00, 21:59
//   NOCHE   → solo 22:00, 02:00, 05:59
//   SIN HORA → solo registros sin hora
// Además: TODOS no filtra; MIXTO aparece en el turno que trabajó; un
// registro SIN HORA nunca aparece al filtrar un turno concreto.

import { describe, it, expect, beforeAll } from 'vitest';

const SPEC = globalThis.SPEC;

/* Registros sintéticos: cada uno con su hora de fichaje (minutos del día).
 * El turno se deriva con la MISMA fx_Turno centralizada que usa la app. */
function registroConHora(minutosDelDia, extra) {
  const hora = minutosDelDia;
  return Object.assign({
    hora,
    turno: SPEC.fx_Turno(hora),
    turnos: [SPEC.fx_Turno(hora)]
  }, extra || {});
}

function registroSinHora(extra) {
  return Object.assign({ hora: null, turno: 'SIN HORA', turnos: ['SIN HORA'] }, extra || {});
}

const fmt = h => h == null ? 'SIN HORA'
  : String(Math.floor(h / 60)).padStart(2, '0') + ':' + String(h % 60).padStart(2, '0');

/* La batería exacta pedida: 06:30, 13:59, 14:00, 21:59, 22:00, 02:00, 05:59. */
const HORAS = [6 * 60 + 30, 13 * 60 + 59, 14 * 60, 21 * 60 + 59, 22 * 60, 2 * 60, 5 * 60 + 59];

describe('v6.1.1 — FILTRO REAL de turnos (SPEC.filtrarRegistrosPorTurno)', () => {
  let registros;
  beforeAll(() => {
    registros = HORAS.map(h => registroConHora(h));
    registros.push(registroSinHora()); // 8 registros en total
  });

  it('MAÑANA solo devuelve 06:30 y 13:59', () => {
    const out = SPEC.filtrarRegistrosPorTurno(registros, 'MAÑANA');
    expect(out.map(r => fmt(r.hora))).toEqual(['06:30', '13:59']);
  });

  it('TARDE solo devuelve 14:00 y 21:59', () => {
    const out = SPEC.filtrarRegistrosPorTurno(registros, 'TARDE');
    expect(out.map(r => fmt(r.hora))).toEqual(['14:00', '21:59']);
  });

  it('NOCHE solo devuelve 22:00, 02:00 y 05:59 (incluye madrugada)', () => {
    const out = SPEC.filtrarRegistrosPorTurno(registros, 'NOCHE');
    expect(out.map(r => fmt(r.hora))).toEqual(['22:00', '02:00', '05:59']);
  });

  it('SIN HORA solo devuelve los registros sin hora de fichaje', () => {
    const out = SPEC.filtrarRegistrosPorTurno(registros, 'SIN HORA');
    expect(out.length).toBe(1);
    expect(out[0].turno).toBe('SIN HORA');
    expect(out[0].hora).toBeNull();
  });

  it('cadena vacía (Todos) devuelve todos los registros sin filtrar', () => {
    const out = SPEC.filtrarRegistrosPorTurno(registros, '');
    expect(out.length).toBe(registros.length);
    expect(SPEC.filtrarRegistrosPorTurno(registros, null).length).toBe(registros.length);
    expect(SPEC.filtrarRegistrosPorTurno(registros, undefined).length).toBe(registros.length);
  });

  it('un registro SIN HORA nunca aparece al filtrar MAÑANA/TARDE/NOCHE', () => {
    for (const t of ['MAÑANA', 'TARDE', 'NOCHE']) {
      const out = SPEC.filtrarRegistrosPorTurno(registros, t);
      expect(out.some(r => r.turno === 'SIN HORA' || r.hora == null)).toBe(false);
    }
  });

  it('persona/día MIXTO aparece en cada turno que trabajó (semántica de lista de Revisar)', () => {
    // Día con TARDE (15:00) + NOCHE (05:00 del día siguiente, fecha operativa igual)
    const mixto = { turno: 'MIXTO', turnos: ['TARDE', 'NOCHE'], hora: null };
    const puros = [
      registroConHora(6 * 60),           // MAÑANA
      registroConHora(14 * 60),          // TARDE
      registroConHora(23 * 60)           // NOCHE
    ];
    const lista = [mixto, ...puros];
    const manana = SPEC.filtrarRegistrosPorTurno(lista, 'MAÑANA');
    expect(manana.length).toBe(1);
    const tarde = SPEC.filtrarRegistrosPorTurno(lista, 'TARDE');
    expect(tarde.map(r => r.turno)).toContain('MIXTO');
    expect(tarde.map(r => r.turno)).toContain('TARDE');
    const noche = SPEC.filtrarRegistrosPorTurno(lista, 'NOCHE');
    expect(noche.map(r => r.turno)).toContain('MIXTO');
    expect(noche.map(r => r.turno)).toContain('NOCHE');
    expect(noche.some(r => r.turno === 'MAÑANA' || r.turno === 'TARDE')).toBe(false);
  });

  it('no muta el array de entrada y tolera entrada no-array', () => {
    const copia = registros.slice();
    SPEC.filtrarRegistrosPorTurno(registros, 'NOCHE');
    expect(registros.length).toBe(copia.length);
    expect(() => SPEC.filtrarRegistrosPorTurno(null, 'NOCHE')).not.toThrow();
    expect(SPEC.filtrarRegistrosPorTurno(null, 'NOCHE')).toEqual([]);
    expect(SPEC.filtrarRegistrosPorTurno(undefined, '')).toEqual([]);
  });

  it('FECHA OPERATIVA NOCTURNA: reglas obligatorias del usuario (§3)', () => {
    const d = (y, m, dd) => new Date(Date.UTC(y, m - 1, dd));
    // 25/08 23:30 → NOCHE → 25/08
    expect(SPEC.formatFechaISO(SPEC.fx_FechaOperativaTurno(d(2026, 8, 25), 23 * 60 + 30))).toBe('2026-08-25');
    // 26/08 02:15 → NOCHE → 25/08 (cruza medianoche)
    expect(SPEC.formatFechaISO(SPEC.fx_FechaOperativaTurno(d(2026, 8, 26), 2 * 60 + 15))).toBe('2026-08-25');
    // 26/08 05:59 → NOCHE → 25/08
    expect(SPEC.formatFechaISO(SPEC.fx_FechaOperativaTurno(d(2026, 8, 26), 5 * 60 + 59))).toBe('2026-08-25');
    // 26/08 06:00 → MAÑANA → 26/08
    expect(SPEC.formatFechaISO(SPEC.fx_FechaOperativaTurno(d(2026, 8, 26), 6 * 60))).toBe('2026-08-26');
    // 25/08 22:00 → NOCHE → 25/08 (22:00–23:59 mantiene la fecha actual)
    expect(SPEC.formatFechaISO(SPEC.fx_FechaOperativaTurno(d(2026, 8, 25), 22 * 60))).toBe('2026-08-25');
  });

  it('sábado-exacto: los registros day-level (hora null) mantienen la fecha sin desplazar', () => {
    const d = (y, m, dd) => new Date(Date.UTC(y, m - 1, dd));
    expect(SPEC.formatFechaISO(SPEC.fx_FechaOperativaTurno(d(2026, 8, 26), null))).toBe('2026-08-26');
    expect(SPEC.extraerHoraFichaje(46260)).toBeNull();        // serial entero
    expect(SPEC.extraerHoraFichaje(new Date(Date.UTC(2026, 7, 26)))).toBeNull(); // medianoche exacta
    expect(SPEC.extraerHoraFichaje(46260 + 14.5 / 24)).toBe(14 * 60 + 30);       // 14:30 real
  });
});
