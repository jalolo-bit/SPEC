// XSS tests for ui.js escape routes (M-02 / R-04)
//
// ui.js exposes `escapeHtml` and `escapeAttr` on `window` (per the
// AUD-CRIT-002 / AUD-HIGH-001 fix at line 1073 of ui.js). The escape
// functions are the security boundary for every piece of dynamic content
// inserted into innerHTML. If they regress, an attacker-controlled string
// (e.g. a USER_NAME field from VOLUMEN.xlsx with `<script>` payload) could
// break out of its containing element and execute arbitrary JS.
//
// ui.js is an IIFE that wraps most of the code; the post-IIFE code (after
// line 1100) references the closure-private `escapeHtml` as a bare global.
// We load the file with `new Function()` (mirroring tests/setup.js's app.js
// loader) and the IIFE's `Object.assign(window, {escapeHtml, ...})` exposes
// the function on `globalThis.window`.

import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { describe, it, expect, beforeAll } from 'vitest';
import XLSX from 'xlsx';

const __dirname = dirname(fileURLToPath(import.meta.url));
const projectRoot = resolve(__dirname, '..', '..');

// Stubs — mirrors tests/setup.js but adds the few globals ui.js touches that
// app.js's setup does not (location, indexedDB, matchMedia).
function ensureUiStubs() {
  if (typeof globalThis.window === 'undefined') globalThis.window = globalThis;
  if (typeof globalThis.document === 'undefined' || !globalThis.document.addEventListener) {
    const listeners = {};
    const el = () => ({
      tagName: '',
      style: {},
      classList: { add() {}, remove() {}, toggle() {}, contains() { return false; } },
      appendChild() {}, removeChild() {},
      setAttribute() {}, getAttribute() { return null; },
      addEventListener() {}, removeEventListener() {},
      click() {},
      dataset: {},
      innerHTML: '',
      textContent: '',
      value: '',
      querySelectorAll: () => [],
      querySelector: () => null,
      options: [],
      scrollIntoView() {},
      style: {}
    });
    globalThis.document = {
      createElement: el,
      createElementNS: el,
      getElementById: () => null,
      querySelector: () => null,
      querySelectorAll: () => [],
      addEventListener: (ev, fn) => { listeners[ev] = listeners[ev] || []; listeners[ev].push(fn); },
      removeEventListener: () => {},
      body: el(),
      documentElement: el(),
      head: el()
    };
  }
  if (typeof globalThis.navigator === 'undefined') {
    globalThis.navigator = { language: 'es', userAgent: 'node' };
  }
  if (typeof globalThis.localStorage === 'undefined') {
    const store = new Map();
    globalThis.localStorage = {
      getItem: (k) => (store.has(k) ? store.get(k) : null),
      setItem: (k, v) => store.set(k, String(v)),
      removeItem: (k) => store.delete(k),
      clear: () => store.clear()
    };
  }
  if (typeof globalThis.location === 'undefined') {
    globalThis.location = { href: 'http://localhost/', search: '', hash: '', pathname: '/' };
  }
  if (typeof globalThis.indexedDB === 'undefined') {
    globalThis.indexedDB = { open: () => ({ onsuccess: null, onerror: null, onupgradeneeded: null, result: null }) };
  }
  if (typeof globalThis.matchMedia === 'undefined') {
    globalThis.matchMedia = () => ({
      matches: false,
      addEventListener() {},
      removeEventListener() {},
      addListener() {},
      removeListener() {}
    });
  }
  if (typeof globalThis.Blob === 'undefined') {
    globalThis.Blob = class Blob { constructor(parts, opts) { this.parts = parts; this.opts = opts; } };
  }
  if (typeof globalThis.URL === 'undefined') {
    globalThis.URL = { createObjectURL: () => 'blob:fake', revokeObjectURL: () => {} };
  }
  if (typeof globalThis.XLSX === 'undefined') {
    globalThis.XLSX = XLSX;
  }
}

let escapeHtml, escapeAttr;

beforeAll(() => {
  ensureUiStubs();
  // Load app.js first — ui.js references SPEC throughout.
  const appSrc = readFileSync(resolve(projectRoot, 'app.js'), 'utf8');
  // eslint-disable-next-line no-new-func
  const appLoader = new Function('window', 'globalThis', 'document', 'navigator', 'localStorage', 'XLSX', appSrc);
  appLoader(globalThis.window, globalThis, globalThis.document, globalThis.navigator, globalThis.localStorage, globalThis.XLSX);
  // Load ui.js — the IIFE will assign window.escapeHtml etc. via Object.assign.
  const uiSrc = readFileSync(resolve(projectRoot, 'ui.js'), 'utf8');
  // eslint-disable-next-line no-new-func
  const uiLoader = new Function('window', 'globalThis', 'document', 'navigator', 'localStorage', 'XLSX', uiSrc);
  uiLoader(globalThis.window, globalThis, globalThis.document, globalThis.navigator, globalThis.localStorage, globalThis.XLSX);

  escapeHtml = globalThis.window.escapeHtml;
  escapeAttr = globalThis.window.escapeAttr;
  if (typeof escapeHtml !== 'function') {
    throw new Error('escapeHtml was not exposed on window after loading ui.js — the AUD-CRIT-002 fix may have regressed');
  }
});

describe('escapeHtml (ui.js line 1039) — security boundary for innerHTML', () => {
  describe('happy path', () => {
    it('plain text is returned unchanged', () => {
      expect(escapeHtml('hola mundo')).toBe('hola mundo');
    });
    it('empty string → empty string', () => {
      expect(escapeHtml('')).toBe('');
    });
  });

  describe('null / undefined / non-string inputs (defensive)', () => {
    it('null → empty string (not "null" — important for rendering undefined fields)', () => {
      expect(escapeHtml(null)).toBe('');
    });
    it('undefined → empty string', () => {
      expect(escapeHtml(undefined)).toBe('');
    });
    it('number 123 → "123" (stringified, NOT escaped)', () => {
      expect(escapeHtml(123)).toBe('123');
    });
    it('number 0 → "0" (NOT empty string — preserves falsy numbers)', () => {
      expect(escapeHtml(0)).toBe('0');
    });
    it('boolean true → "true"', () => {
      expect(escapeHtml(true)).toBe('true');
    });
  });

  describe('HTML injection payloads — the security-critical cases', () => {
    it('<script>alert(1)</script> → &lt;script&gt;alert(1)&lt;/script&gt;', () => {
      const payload = '<script>alert(1)</script>';
      const out = escapeHtml(payload);
      expect(out).toBe('&lt;script&gt;alert(1)&lt;/script&gt;');
      // Sanity: no raw `<` or `>` survive in the output.
      expect(out).not.toContain('<');
      expect(out).not.toContain('>');
    });

    it('<img src=x onerror=alert(1)> → all of <, >, " escaped', () => {
      const payload = '<img src=x onerror=alert(1)>';
      const out = escapeHtml(payload);
      expect(out).not.toContain('<');
      expect(out).not.toContain('>');
      // The onerror attribute value is just text now — no way for the browser
      // to parse it as an event handler.
      expect(out).toContain('onerror=alert(1)');
      expect(out).toContain('&lt;img src=x onerror=alert(1)&gt;');
    });

    it('<svg/onload=alert(1)> → <, > escaped (defeats SVG-based XSS payloads)', () => {
      const payload = '<svg/onload=alert(1)>';
      const out = escapeHtml(payload);
      expect(out).not.toContain('<');
      expect(out).not.toContain('>');
      expect(out).toContain('&lt;svg/onload=alert(1)&gt;');
    });

    it('<a href="javascript:alert(1)"> → quotes escaped too (defeats attribute breakout)', () => {
      const payload = '<a href="javascript:alert(1)">click</a>';
      const out = escapeHtml(payload);
      expect(out).not.toContain('"');
      expect(out).toContain('&lt;a href=&quot;javascript:alert(1)&quot;&gt;');
      expect(out).toContain('click');
      expect(out).toContain('&lt;/a&gt;');
    });

    it('Single-quote attribute breakout is escaped (apostrophe → &#39;)', () => {
      // This matters for attributes delimited by single quotes:
      //   <a href='USER_INPUT'>...</a>
      // If USER_INPUT contains `'>` it can break out and inject an onerror.
      // escapeHtml escapes `'` to `&#39;` which breaks the attack.
      const payload = "' onmouseover='alert(1)";
      const out = escapeHtml(payload);
      expect(out).not.toContain("'");
      expect(out).toContain('&#39;');
    });

    it('Ampersand-first input — `&` is escaped to `&amp;` BEFORE other chars', () => {
      // Order matters: `&` must be escaped first, otherwise `&lt;` (already
      // escaped) would become `&amp;lt;` (double-escaped). The implementation
      // does .replace(/&/g, '&amp;').replace(/</g, '&lt;')... in order.
      expect(escapeHtml('a < b & c > d')).toBe('a &lt; b &amp; c &gt; d');
      // Pre-escaped entities must NOT be double-escaped.
      expect(escapeHtml('&lt;script&gt;')).toBe('&amp;lt;script&amp;gt;');
    });
  });

  describe('combined / chained payloads', () => {
    it('polyglot payload with all 5 dangerous chars is fully escaped', () => {
      const payload = '<>"\'&';
      const out = escapeHtml(payload);
      expect(out).toBe('&lt;&gt;&quot;&#39;&amp;');
      // Note: the order of escaping means `&` is escaped first (→ &amp;),
      // so `&` ends up last in the output even though it was last in the input.
      // Verifying: NO raw dangerous chars survive.
      expect(out).not.toContain('<');
      expect(out).not.toContain('>');
      expect(out).not.toContain('"');
      expect(out).not.toContain("'");
      // Note: `&` survives (inside `&amp;` etc) — that's the escape output.
    });

    it('a benign-looking string with special chars is preserved', () => {
      expect(escapeHtml('Tom & Jerry')).toBe('Tom &amp; Jerry');
      expect(escapeHtml('a < b > c')).toBe('a &lt; b &gt; c');
      expect(escapeHtml('"quoted"')).toBe('&quot;quoted&quot;');
    });
  });

  describe('long input (DoS / stack-overflow safety)', () => {
    it('long input does not throw or truncate', () => {
      const long = 'a'.repeat(10_000);
      const out = escapeHtml(long);
      expect(out.length).toBe(10_000);
      expect(out).toBe(long);
    });

    it('long input with many special chars is escaped without stack overflow', () => {
      const long = '<img src=x onerror=alert(1)>'.repeat(1000);
      const out = escapeHtml(long);
      // No raw `<` or `>` survive.
      expect(out).not.toContain('<');
      expect(out).not.toContain('>');
      expect(out.length).toBeGreaterThan(long.length); // escapes added chars
    });
  });
});

describe('escapeAttr (ui.js line 1048) — escapeHtml + double-quote hardening', () => {
  it('escapeAttr is exposed on window', () => {
    expect(typeof escapeAttr).toBe('function');
  });

  it('escapeAttr("javascript:alert(1)") → "javascript:alert(1)" — protocol NOT stripped (escapeHtml only escapes HTML chars, the protocol is the caller\'s problem)', () => {
    // This documents an important limitation: escapeAttr is NOT a URL
    // sanitizer. If you put user input into href=, you must ALSO validate
    // the protocol. escapeAttr only ensures the attribute value cannot
    // break out of the attribute.
    expect(escapeAttr('javascript:alert(1)')).toBe('javascript:alert(1)');
  });

  it('escapeAttr("x" onmouseover="alert(1)") — the breakout payload is escaped', () => {
    // The `"` chars are escaped to `&quot;` — no way to close the attribute
    // and inject a new one.
    const payload = 'x" onmouseover="alert(1)';
    const out = escapeAttr(payload);
    expect(out).not.toContain('"');
  });

  it('escapeAttr passes through plain strings unchanged', () => {
    expect(escapeAttr('hello world')).toBe('hello world');
    expect(escapeAttr('OTO0499')).toBe('OTO0499');
  });
});

describe('AUD-CRIT-001/002 fix verification — the escape routes are reachable from window', () => {
  // AUD-CRIT-001: index.html must load app.js. (We can't test index.html from
  // vitest directly — the Playwright E2E test does that.)
  // AUD-CRIT-002: ui.js must expose escapeHtml to window (the v3.0+ block
  // references it as a bare global). We verify the exposure here.

  it('window.escapeHtml is a function (the AUD-CRIT-002 fix exposes IIFE privates)', () => {
    expect(typeof globalThis.window.escapeHtml).toBe('function');
  });

  it('window.escapeAttr is a function', () => {
    expect(typeof globalThis.window.escapeAttr).toBe('function');
  });

  it('window.UI is defined (the main UI controller object — exposed by the AUD-CRIT-002 fix)', () => {
    expect(globalThis.window.UI).toBeDefined();
    expect(typeof globalThis.window.UI).toBe('object');
  });
});
