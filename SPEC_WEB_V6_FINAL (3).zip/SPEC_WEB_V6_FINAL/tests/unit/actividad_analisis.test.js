// Unit tests v6.1 — MEJORA 4: clasificación centralizada ACTIVIDAD_ANALISIS
//
// Verifica las reglas del usuario:
//   PICKING AGV:   "Reparto por cuadrante AGV", "Reparto por supercuadrante AGV"
//   PICKING MANUAL: "Picking ecommerce a matrícula", "Picking por cuadrante
//                   guiado", "Picking sin papel"
//   UBICACIÓN:      Tipo movimiento que empieza por "Ubicación" (AGV/manual)
//   AUDITORÍA:      AGV/manual según contenga "AGV"
//   OTRA:           todo lo demás — NO se inventa productividad
// + taskOverrides (reasignación explícita del usuario)

import { describe, it, expect } from 'vitest';

const SPEC = globalThis.SPEC;

describe('v6.1 MEJORA 4 — fx_ActividadAnalisis (clasificación centralizada)', () => {
  it('PICKING AGV — reglas explícitas del usuario', () => {
    expect(SPEC.fx_ActividadAnalisis('Reparto por cuadrante AGV - Bershka')).toBe('PICKING AGV');
    expect(SPEC.fx_ActividadAnalisis('Reparto por supercuadrante AGV - Oysho')).toBe('PICKING AGV');
    expect(SPEC.fx_ActividadAnalisis('REPARTO POR CUADRANTE AGV - PULL & BEAR')).toBe('PICKING AGV');
    expect(SPEC.fx_ActividadAnalisis('REPARTO POR SUPERCUADRANTE AGV - BERSHKA')).toBe('PICKING AGV');
  });
  it('PICKING MANUAL — reglas explícitas del usuario', () => {
    expect(SPEC.fx_ActividadAnalisis('Picking ecommerce a matrícula - Bershka')).toBe('PICKING MANUAL');
    expect(SPEC.fx_ActividadAnalisis('Picking por cuadrante guiado - Oysho')).toBe('PICKING MANUAL');
    expect(SPEC.fx_ActividadAnalisis('Picking sin papel - Pull & Bear')).toBe('PICKING MANUAL');
    expect(SPEC.fx_ActividadAnalisis('PICKING ECOMMERCE A MATRICULA - BERSHKA')).toBe('PICKING MANUAL');
  });
  it('UBICACIÓN — Tipo movimiento que comienza por "Ubicación"', () => {
    expect(SPEC.fx_ActividadAnalisis('Ubicación directa AGV - Bershka')).toBe('UBICACION AGV');
    expect(SPEC.fx_ActividadAnalisis('UBICACIÓN DE SKU DUCHANDO AUTOMATIZADA - OYSHO')).toBe('UBICACION AGV');
    expect(SPEC.fx_ActividadAnalisis('Ubicación multireferencia AGV - Bershka')).toBe('UBICACION AGV');
    expect(SPEC.fx_ActividadAnalisis('Ubicación con cantidad - Oysho')).toBe('UBICACION MANUAL');
    expect(SPEC.fx_ActividadAnalisis('UBICACIÓN DE CONTENEDOR COMPLETO - BERSHKA')).toBe('UBICACION MANUAL');
    expect(SPEC.fx_ActividadAnalisis('Ubicación bulto con recomendación - Bershka')).toBe('UBICACION MANUAL');
    expect(SPEC.fx_ActividadAnalisis('UBICACIÓN POR SOBRANTE - OYSHO')).toBe('UBICACION MANUAL');
  });
  it('AUDITORÍA — AGV/manual según contenga "AGV"', () => {
    expect(SPEC.fx_ActividadAnalisis('Auditoría AGV - Bershka')).toBe('AUDITORIA AGV');
    expect(SPEC.fx_ActividadAnalisis('Auditoría AGV - Oysho')).toBe('AUDITORIA AGV');
    expect(SPEC.fx_ActividadAnalisis('Auditoría con cantidad - Bershka')).toBe('AUDITORIA MANUAL');
    expect(SPEC.fx_ActividadAnalisis('Auditoría escaneando - Oysho')).toBe('AUDITORIA MANUAL');
    expect(SPEC.fx_ActividadAnalisis('Auditoría RFID - Pull & Bear')).toBe('AUDITORIA MANUAL');
  });
  it('PICKING LIBRE — misma TASK_SPEC que las picking manuales (decisión documentada)', () => {
    expect(SPEC.fx_ActividadAnalisis('PICKING LIBRE - BERSHKA')).toBe('PICKING MANUAL');
  });
  it('Tareas ambiguas del mapping → clasificación conservadora (ver MAPPING_AMBIGUITIES.md)', () => {
    // REPARTO A TIENDA AGV: 2 TASK_SPEC posibles (20157 | 20159) y NO está en
    // las reglas explícitas del usuario → OTRA (no se inventa asignación)
    expect(SPEC.fx_ActividadAnalisis('REPARTO A TIENDA AGV - BERSHKA')).toBe('OTRA');
    expect(SPEC.fx_ActividadAnalisis('REPARTO A TIENDA AGV - OYSHO')).toBe('OTRA');
    // 'Ubicación de SKU duchando' (sin marca): SÍ encaja en la regla genérica
    // "empieza por Ubicación" (manual: sin AGV/AUTOMATIZADA). Su ambigüedad
    // de TASK_SPEC (20089 | 20081) la marca el propio motor en el reporte
    // (sección 5), no la clasificación física de la actividad.
    expect(SPEC.fx_ActividadAnalisis('Ubicación de SKU duchando')).toBe('UBICACION MANUAL');
  });
  it('Otras tareas no clasificables → OTRA', () => {
    expect(SPEC.fx_ActividadAnalisis('Mover SKU - Bershka')).toBe('OTRA');
    expect(SPEC.fx_ActividadAnalisis('Mover contenido - Oysho')).toBe('OTRA');
    expect(SPEC.fx_ActividadAnalisis('Move content')).toBe('OTRA');
    expect(SPEC.fx_ActividadAnalisis('TRASPASOS AGV - PULL & BEAR')).toBe('OTRA');
    expect(SPEC.fx_ActividadAnalisis('Picking por tienda guiado - Bershka')).toBe('OTRA');
    expect(SPEC.fx_ActividadAnalisis('PICKING DE DEVOLUCIÓN DE LOCALIZACIÓN - OYSHO')).toBe('OTRA');
    expect(SPEC.fx_ActividadAnalisis('DEVOLUCIÓN ONLINE')).toBe('OTRA');
    expect(SPEC.fx_ActividadAnalisis('Cambio de campaña - Bershka')).toBe('OTRA');
    expect(SPEC.fx_ActividadAnalisis('PRODUCTIVITYPACKERS - BK')).toBe('OTRA');
    expect(SPEC.fx_ActividadAnalisis('Conteo - Bershka')).toBe('OTRA');
    expect(SPEC.fx_ActividadAnalisis('Informe empaquetado')).toBe('OTRA');
    expect(SPEC.fx_ActividadAnalisis('LIBIAO')).toBe('OTRA');
  });
  it('Vacío / null → OTRA', () => {
    expect(SPEC.fx_ActividadAnalisis('')).toBe('OTRA');
    expect(SPEC.fx_ActividadAnalisis(null)).toBe('OTRA');
    expect(SPEC.fx_ActividadAnalisis(undefined)).toBe('OTRA');
    expect(SPEC.fx_ActividadAnalisis('    ')).toBe('OTRA');
  });
  it('Robustez: saltos de línea, espacios dobles, mayúsculas y acentos', () => {
    expect(SPEC.fx_ActividadAnalisis('REASIGNACIÓN\r\n  - OYSHO')).toBe('OTRA');
    expect(SPEC.fx_ActividadAnalisis('Reparto  por  cuadrante  AGV - Bershka')).toBe('PICKING AGV');
    expect(SPEC.fx_ActividadAnalisis('picking sin papel - oysho')).toBe('PICKING MANUAL');
    expect(SPEC.fx_ActividadAnalisis('UBICACIÓN SKU CON CANTIDAD  - OYSHO')).toBe('UBICACION MANUAL');
    expect(SPEC.fx_ActividadAnalisis('ubicación directa agv - bershka')).toBe('UBICACION AGV');
  });
  it('taskOverrides — el usuario reasigna explícitamente una tarea', () => {
    const ov = { 'REPARTO A TIENDA AGV - BERSHKA': { actividad: 'PICKING AGV', productividad: 150 } };
    expect(SPEC.fx_ActividadAnalisis('REPARTO A TIENDA AGV - BERSHKA', ov)).toBe('PICKING AGV');
    // Sin override → OTRA
    expect(SPEC.fx_ActividadAnalisis('REPARTO A TIENDA AGV - OYSHO', ov)).toBe('OTRA');
    // Override con actividad inválida se ignora
    const ovBad = { 'Mover SKU - Bershka': { actividad: 'ACTIVIDAD INEXISTENTE' } };
    expect(SPEC.fx_ActividadAnalisis('Mover SKU - Bershka', ovBad)).toBe('OTRA');
  });
  it('ACTIVIDADES_ANALISIS — valores del campo único', () => {
    expect(SPEC.ACTIVIDADES_ANALISIS).toEqual([
      'AUDITORIA AGV', 'AUDITORIA MANUAL', 'UBICACION AGV', 'UBICACION MANUAL',
      'PICKING AGV', 'PICKING MANUAL', 'OTRA'
    ]);
  });
});

describe('v6.1 MEJORA 4 — resolverProductividad (prioridad y OTRA)', () => {
  it('Valores por defecto del usuario (netas, uds/h)', () => {
    expect(SPEC.PARAMS.ProductividadesReferencia).toEqual({
      'AUDITORIA AGV': 35,
      'AUDITORIA MANUAL': 23,
      'UBICACION MANUAL': 260,
      'UBICACION AGV': 240,
      'PICKING MANUAL': 100,
      'PICKING AGV': 150
    });
  });
  it('OTRA nunca recibe productividad', () => {
    expect(SPEC.resolverProductividad('OTRA', null, {})).toBeNull();
    expect(SPEC.resolverProductividad('OTRA', 'X', { productividades: { OTRA: 999 } })).toBeNull();
  });
  it('Override por tarea tiene prioridad sobre el valor por actividad', () => {
    const o = {
      productividades: { 'PICKING AGV': 150 },
      taskOverrides: { 'PICKING AGV - ESPECIAL': { actividad: 'PICKING AGV', productividad: 200 } }
    };
    expect(SPEC.resolverProductividad('PICKING AGV', null, o)).toBe(150);
    expect(SPEC.resolverProductividad('PICKING AGV', 'PICKING AGV - ESPECIAL', o)).toBe(200);
  });
  it('Productividades personalizadas del usuario se respetan (contrato del motor: mapa completo)', () => {
    // El motor recibe un mapa COMPLETO de productividades; la UI lo construye
    // mezclando los defaults con las preferencias del usuario (cargarProductividades).
    const custom = Object.assign({}, SPEC.PARAMS.ProductividadesReferencia, { 'UBICACION MANUAL': 300 });
    const o = { productividades: custom };
    expect(SPEC.resolverProductividad('UBICACION MANUAL', null, o)).toBe(300);
    expect(SPEC.resolverProductividad('PICKING MANUAL', null, o)).toBe(100);
    // Sin opciones → defaults del motor
    expect(SPEC.resolverProductividad('PICKING MANUAL', null, {})).toBe(100);
    expect(SPEC.resolverProductividad('PICKING MANUAL', null, undefined)).toBe(100);
  });
  it('Valores inválidos (0, negativos, no numéricos) → null', () => {
    const o = { productividades: { 'PICKING MANUAL': 0 } };
    expect(SPEC.resolverProductividad('PICKING MANUAL', null, o)).toBeNull();
    const o2 = { productividades: { 'PICKING MANUAL': -5 } };
    expect(SPEC.resolverProductividad('PICKING MANUAL', null, o2)).toBeNull();
  });
});
