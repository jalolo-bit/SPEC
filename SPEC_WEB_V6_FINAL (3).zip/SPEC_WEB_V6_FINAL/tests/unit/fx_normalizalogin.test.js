// Unit tests for SPEC.fx_NormalizaLogin  (M-06 / R-13)
//
// Covers the contract documented in Section1.m líneas 27-43 and the
// R-12 BigInt fix for IdNumericoNormalizado on >15-digit literals.
//
// The function returns an object with these keys:
//   LoginOriginal          — the raw input (preserved)
//   LoginOriginalLimpio    — fx_NormalizaTexto(input) (null if input was empty/null)
//   LoginCanonico          — letras + digitos when both exist; else limpio; else null
//   IdNumerico             — alias of IdNumericoLiteral (raw digit string, leading zeros preserved)
//   IdNumericoLiteral      — same as IdNumerico (raw digit run, leading zeros preserved)
//   IdNumericoNormalizado  — Number() of digits if <=15 chars; BigInt() if >15;
//                            leading zeros stripped in either case; null when no digits
//   Prefijo                — letras only; null when no letters

import { describe, it, expect } from 'vitest';

const SPEC = globalThis.SPEC;

describe('fx_NormalizaLogin (Section1.m líneas 27-43)', () => {
  describe('canonical cases', () => {
    it('"OTO0499" → prefijo OTO, id literal "0499", id normalizado "499"', () => {
      const r = SPEC.fx_NormalizaLogin('OTO0499');
      expect(r.LoginCanonico).toBe('OTO0499');
      expect(r.IdNumericoLiteral).toBe('0499');
      expect(r.IdNumericoNormalizado).toBe('499');
      expect(r.Prefijo).toBe('OTO');
      expect(r.IdNumerico).toBe('0499'); // alias of IdNumericoLiteral
      expect(r.LoginOriginal).toBe('OTO0499');
      expect(r.LoginOriginalLimpio).toBe('OTO0499');
    });

    it('"0499" (digits only) → canonico "0499", prefijo null', () => {
      const r = SPEC.fx_NormalizaLogin('0499');
      expect(r.LoginCanonico).toBe('0499');
      expect(r.IdNumericoLiteral).toBe('0499');
      expect(r.IdNumericoNormalizado).toBe('499');
      expect(r.Prefijo).toBeNull();
    });

    it('"oto-0499" (lower + dash) → same as "OTO0499" (dash is a separator)', () => {
      const r = SPEC.fx_NormalizaLogin('oto-0499');
      expect(r.LoginCanonico).toBe('OTO0499');
      expect(r.IdNumericoLiteral).toBe('0499');
      expect(r.IdNumericoNormalizado).toBe('499');
      expect(r.Prefijo).toBe('OTO');
    });

    it('"OTO" (letters only) → canonico "OTO", id numerico null', () => {
      const r = SPEC.fx_NormalizaLogin('OTO');
      expect(r.LoginCanonico).toBe('OTO');
      expect(r.IdNumericoLiteral).toBeNull();
      expect(r.IdNumericoNormalizado).toBeNull();
      expect(r.Prefijo).toBe('OTO');
    });

    it('"" (empty) → all null (canonical)', () => {
      const r = SPEC.fx_NormalizaLogin('');
      expect(r.LoginCanonico).toBeNull();
      expect(r.IdNumericoLiteral).toBeNull();
      expect(r.IdNumericoNormalizado).toBeNull();
      expect(r.Prefijo).toBeNull();
      // LoginOriginal is preserved as the empty string per `String(v)`.
      expect(r.LoginOriginal).toBe('');
      expect(r.LoginOriginalLimpio).toBeNull();
    });

    it('null/undefined → all null canonical', () => {
      for (const v of [null, undefined]) {
        const r = SPEC.fx_NormalizaLogin(v);
        expect(r.LoginCanonico).toBeNull();
        expect(r.IdNumericoLiteral).toBeNull();
        expect(r.IdNumericoNormalizado).toBeNull();
        expect(r.Prefijo).toBeNull();
        // LoginOriginal tracks the input.
        expect(r.LoginOriginal).toBeNull();
      }
    });
  });

  describe('EU prefix case', () => {
    it('"EU1020" → prefijo "EU", id numerico "1020" (no leading zeros → literal == normalizado)', () => {
      const r = SPEC.fx_NormalizaLogin('EU1020');
      expect(r.LoginCanonico).toBe('EU1020');
      expect(r.Prefijo).toBe('EU');
      expect(r.IdNumerico).toBe('1020');
      expect(r.IdNumericoLiteral).toBe('1020');
      // No leading zeros, so normalizado is identical to literal.
      expect(r.IdNumericoNormalizado).toBe('1020');
    });
  });

  describe('leading zeros handling', () => {
    it('"OTO00499" → IdNumericoLiteral preserves "00499", IdNumericoNormalizado drops to "499"', () => {
      const r = SPEC.fx_NormalizaLogin('OTO00499');
      expect(r.IdNumericoLiteral).toBe('00499');
      expect(r.IdNumericoNormalizado).toBe('499');
      expect(r.LoginCanonico).toBe('OTO00499');
      expect(r.Prefijo).toBe('OTO');
    });
  });

  describe('R-12 BigInt precision — large numerics (>15 digits)', () => {
    it('"0123456789012345678" (19 digits, > UmbralBigIntDigitos=15) → IdNumericoNormalizado uses BigInt and does NOT lose precision', () => {
      const r = SPEC.fx_NormalizaLogin('0123456789012345678');
      // The literal preserves all digits, including the leading zero.
      expect(r.IdNumericoLiteral).toBe('0123456789012345678');
      // The normalized form drops the leading zero but must keep all 18 remaining
      // digits intact. A naive Number() would convert this to a float64 and lose
      // precision on the last few digits (e.g. ...0123... → ...0124...).
      expect(r.IdNumericoNormalizado).toBe('123456789012345678');
      // Critical regression check: the last digit must still be '8', not '9' or
      // some other digit affected by float64 rounding.
      expect(r.IdNumericoNormalizado.endsWith('8')).toBe(true);
      expect(r.IdNumericoNormalizado.length).toBe(18);
      // Prefijo is null because there are no letters.
      expect(r.Prefijo).toBeNull();
    });

    it('16-digit literal just above threshold → BigInt, no precision loss', () => {
      const r = SPEC.fx_NormalizaLogin('9999999999999999'); // 16 digits
      expect(r.IdNumericoLiteral).toBe('9999999999999999');
      // Number() of this 16-digit literal gives 10000000000000000 (rounds up!).
      // BigInt gives exact 9999999999999999. The fix must use BigInt.
      expect(r.IdNumericoNormalizado).toBe('9999999999999999');
    });

    it('15-digit literal at threshold → still uses Number() (exact for integers <= 2^53)', () => {
      const r = SPEC.fx_NormalizaLogin('123456789012345'); // 15 digits
      expect(r.IdNumericoLiteral).toBe('123456789012345');
      expect(r.IdNumericoNormalizado).toBe('123456789012345');
    });
  });

  describe('separators (Text.Remove of [space, -, ., _, /, \\])', () => {
    it('"OTO.0499" → same as "OTO0499" (dot removed)', () => {
      const r = SPEC.fx_NormalizaLogin('OTO.0499');
      expect(r.LoginCanonico).toBe('OTO0499');
      expect(r.IdNumericoLiteral).toBe('0499');
      expect(r.IdNumericoNormalizado).toBe('499');
      expect(r.Prefijo).toBe('OTO');
    });

    it('"oto 0499" (space separator) → same as "OTO0499"', () => {
      const r = SPEC.fx_NormalizaLogin('oto 0499');
      expect(r.LoginCanonico).toBe('OTO0499');
      expect(r.Prefijo).toBe('OTO');
      expect(r.IdNumericoLiteral).toBe('0499');
      expect(r.IdNumericoNormalizado).toBe('499');
    });

    it('"OTO_0499" (underscore) → same as "OTO0499"', () => {
      const r = SPEC.fx_NormalizaLogin('OTO_0499');
      expect(r.LoginCanonico).toBe('OTO0499');
    });

    it('"OTO/0499" (slash) → same as "OTO0499"', () => {
      const r = SPEC.fx_NormalizaLogin('OTO/0499');
      expect(r.LoginCanonico).toBe('OTO0499');
    });

    it('"OTO\\\\0499" (backslash) → same as "OTO0499"', () => {
      const r = SPEC.fx_NormalizaLogin('OTO\\0499');
      expect(r.LoginCanonico).toBe('OTO0499');
    });
  });

  describe('weird characters (non-separator, non-letter, non-digit)', () => {
    it('"OTO*0499" → asterisk is removed by fx_NormalizaTexto only if it is whitespace (it isn\'t); sinSeparadores still extracts letters + digits', () => {
      const r = SPEC.fx_NormalizaLogin('OTO*0499');
      // The asterisk is NOT a separator per the Text.Remove list, so it stays
      // in `limpio` and `sinSeparadores`. But letras/digitos extraction picks
      // only [A-Z] and [0-9] respectively, so the * is dropped from those
      // extracted runs. Canonico uses `letras + idNumerico` only when both
      // exist — so the * is also dropped from canonico.
      expect(r.LoginCanonico).toBe('OTO0499');
      expect(r.Prefijo).toBe('OTO');
      expect(r.IdNumericoLiteral).toBe('0499');
      expect(r.IdNumericoNormalizado).toBe('499');
      // LoginOriginalLimpio preserves the asterisk.
      expect(r.LoginOriginalLimpio).toBe('OTO*0499');
    });
  });
});
