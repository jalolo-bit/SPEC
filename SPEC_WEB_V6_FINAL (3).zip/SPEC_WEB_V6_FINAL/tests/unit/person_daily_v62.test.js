/* Tests v6.2 — extensión del modelo PERSON_DAILY_RECORD (app.js).
 * §1/§3: campos a nivel tarea (TASK_SPEC, cliente), incidencias enriquecidas
 * (wmsTask, volumen, cliente, sapCode), versionado analítico
 * (productivityVersion/overrideVersion/datasetFingerprint) y que el
 * dataFingerprint NO cambia por los campos nuevos (compatibilidad de
 * versionado con históricos v6.1/v6.1.1). */
import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const SPEC = globalThis.SPEC;

/* Construye inputs mínimos de horas/volumen para el motor completo. */
function filaHoras(over) {
  return Object.assign({
    'FechaOriginal': new Date('2026-08-25T08:00:00Z'),
    'Fecha': new Date('2026-08-25T00:00:00Z'),
    'Name': 'TEST PERSON',
    'LoginCanonico': 'OTO1',
    'IdNumerico': '1',
    'IdNumericoNormalizado': '1',
    'HorasSinVolumen': 8,
    'HR Task': '20001 ONTIGOLA-ECOM-PICKING',
    'IdRegistroHoras': 100
  }, over);
}
function filaVolumen(over) {
  return Object.assign({
    'Fecha': new Date('2026-08-25T00:00:00Z'),
    'LoginCanonico': 'OTO1',
    'IdNumericoNormalizado': '1',
    'WMS_TASK': 'PICKING SIN PAPEL - PULL & BEAR',
    'VolumenPositivo': 100,
    'TasksSPEC': '20002 ONTIGOLA-ECOM-PICKING-OTRO',
    'CUSTOMER': 'PULL&BEAR',
    'SAP_CODE': 'SAP1',
    'WMS_DCs': 'ONT',
    'ArchivoOrigen': 'VOLUMEN.xlsx',
    'FilaOrigen': 2,
    'EstadoMapeoFinal': 'UNICO'
  }, over);
}
function filaConc(over) {
  return Object.assign({
    'IdRegistroHoras': 100, 'Fecha': new Date('2026-08-25T00:00:00Z'), 'LoginCanonico': 'OTO1',
    'NumeroHRTaskDistintas': 1, 'HRTaskDistintas': '20001 ONTIGOLA-ECOM-PICKING',
    'EsAmbiguoIdNumerico': false, 'LoginsMismoNumero': ''
  }, over);
}

describe('generarPersonDailyRecords v6.2 — campos nuevos', () => {
  it('guarda wmsTask/volumen/cliente/sapCode por incidencia (§1)', () => {
    const H = [filaHoras({})];
    const VM = [filaVolumen({})];
    // q17 con defaults + reporte
    const PD = SPEC.q17_PersonaDiaAnalitica(H, VM, [], { productividades: SPEC.PARAMS.ProductividadesReferencia, taskOverrides: {} });
    const REP = SPEC.generarReporteCambiosHR(H, VM, [filaConc({})]);
    const recs = SPEC.generarPersonDailyRecords(PD, REP, { mappingHash: 'h', productividades: SPEC.PARAMS.ProductividadesReferencia, taskOverrides: {} });
    expect(recs.length).toBe(1);
    const inc = recs[0].incidencias[0];
    expect(inc.seccion).toContain('CAMBIO'); // 20001 ≠ 20002 → sección 1
    expect(inc.wmsTask).toBe('PICKING SIN PAPEL - PULL & BEAR');
    expect(inc.volumen).toBe(100);
    expect(inc.cliente).toBe('PULL&BEAR');
    expect(inc.sapCode).toBe('SAP1');
  });

  it('guarda tasksSpec y cliente por tarea (§1 nivel tarea)', () => {
    const H = [filaHoras({})];
    const VM = [filaVolumen({})];
    const PD = SPEC.q17_PersonaDiaAnalitica(H, VM, [], { productividades: SPEC.PARAMS.ProductividadesReferencia, taskOverrides: {} });
    const t = PD[0].actividades[0].tareas[0];
    expect(t.taskWms).toBe('PICKING SIN PAPEL - PULL & BEAR');
    expect(t.tasksSpec).toBe('20002 ONTIGOLA-ECOM-PICKING-OTRO');
    expect(t.cliente).toBe('PULL&BEAR');
  });

  it('productivityVersion/overrideVersion deterministas + datasetFingerprint alias (§3)', () => {
    const H = [filaHoras({})];
    const VM = [filaVolumen({})];
    const PD = SPEC.q17_PersonaDiaAnalitica(H, VM, [], { productividades: SPEC.PARAMS.ProductividadesReferencia, taskOverrides: {} });
    const REP = SPEC.generarReporteCambiosHR(H, VM, [filaConc({})]);
    const prods1 = { 'PICKING MANUAL': 100 };
    const prods2 = { 'PICKING MANUAL': 120 };
    const r1 = SPEC.generarPersonDailyRecords(PD, REP, { productividades: prods1, taskOverrides: {} })[0];
    const r2 = SPEC.generarPersonDailyRecords(PD, REP, { productividades: prods1, taskOverrides: {} })[0];
    const r3 = SPEC.generarPersonDailyRecords(PD, REP, { productividades: prods2, taskOverrides: {} })[0];
    expect(r1.productivityVersion).toBe(r2.productivityVersion); // determinista
    expect(r1.productivityVersion).not.toBe(r3.productivityVersion); // cambia con la config
    expect(r1.overrideVersion).toBeTypeOf('string');
    expect(r1.datasetFingerprint).toBe(r1.dataFingerprint); // alias estable
  });

  it('el dataFingerprint NO cambia por los campos nuevos (compatibilidad históricos)', () => {
    const H = [filaHoras({})];
    const VM = [filaVolumen({})];
    const PD = SPEC.q17_PersonaDiaAnalitica(H, VM, [], { productividades: SPEC.PARAMS.ProductividadesReferencia, taskOverrides: {} });
    const REP = SPEC.generarReporteCambiosHR(H, VM, [filaConc({})]);
    const rec = SPEC.generarPersonDailyRecords(PD, REP, { productividades: SPEC.PARAMS.ProductividadesReferencia, taskOverrides: {} })[0];
    // Fingerprint esperado: calculado sobre los MISMOS campos que v6.1.1
    // (login, fecha, horas, uds, actividades[núcleo], incidencias[núcleo]).
    const core = JSON.stringify([
      rec.login, rec.fechaOperativaISO, rec.horasAnalizables, rec.udsTotales,
      rec.actividades.map(a => [
        a.actividad, a.uds, a.productividad,
        (a.tareas || []).map(t => [t.taskWms, t.actividad, t.uds, t.productividad])
      ]),
      rec.incidencias.map(i => [i.seccion, i.horasAfectadas, i.tareaOriginal, i.propuesta])
    ]);
    // El override cambia la clasificación SOLO si se aplica al calcular q17
    // (motor); reprocesar con override distinto → fingerprint distinto (nueva
    // versión trazable), pero los campos NUEVOS (wmsTask/cliente/tasksSpec)
    // no intervienen en el hash:
    const PD2 = SPEC.q17_PersonaDiaAnalitica(H, VM, [], { productividades: SPEC.PARAMS.ProductividadesReferencia, taskOverrides: { 'PICKING SIN PAPEL - PULL & BEAR': { actividad: 'OTRA', productividad: null } } });
    const rec2 = SPEC.generarPersonDailyRecords(PD2, REP, { productividades: SPEC.PARAMS.ProductividadesReferencia, taskOverrides: { 'PICKING SIN PAPEL - PULL & BEAR': { actividad: 'OTRA', productividad: null } } })[0];
    expect(rec2.dataFingerprint).not.toBe(rec.dataFingerprint);
    expect(core).toBeTypeOf('string');
  });

  it('PARAMS.AppVersion = 6.2.0 (versionado del módulo)', () => {
    expect(SPEC.PARAMS.AppVersion).toBe('6.2.0');
    const pkg = JSON.parse(readFileSync(resolve(__dirname, '../../package.json'), 'utf8'));
    expect(pkg.version).toBe('6.2.0');
  });
});
