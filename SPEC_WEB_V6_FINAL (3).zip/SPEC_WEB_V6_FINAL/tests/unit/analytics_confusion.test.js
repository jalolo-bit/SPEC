/* Tests v6.2 — matriz de confusiones y recurrencia (confusionAnalytics.js).
 * §12/§13/§22/§23: fichada→correcta, mapa de calor, errores recurrentes,
 * persistencia aislado/recurrente/habitual con umbrales configurables. */
import { describe, it, expect } from 'vitest';
import { mkRecord, SEC, incSec } from '../helpers/analyticsFixtures.js';

const AN = globalThis.SPEC_AN;
const N = AN.normalizarRecords;

describe('confusionAnalytics — matriz fichada → correcta (§12)', () => {
  it('agrupa pares origen→destino con casos, personas, días y horas', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', incidencias: [incSec(SEC.cambio, { tareaOriginal: '20001 PICK A', propuesta: '20002 PICK B', horasAfectadas: 2, wmsTask: 'WMS 1' })] }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-25', incidencias: [incSec(SEC.cambio, { tareaOriginal: '20001 PICK A', propuesta: '20002 PICK B', horasAfectadas: 1, wmsTask: 'WMS 1' })] }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-26', incidencias: [incSec(SEC.cambio, { tareaOriginal: '20003 UBI C', propuesta: '20004 UBI D', horasAfectadas: 5, wmsTask: 'WMS 2' })] })
    ]);
    const m = AN.confusion.computeConfusionMatrix(recs);
    expect(m.length).toBe(2);
    expect(m[0].origen).toBe('20001 PICK A');
    expect(m[0].destino).toBe('20002 PICK B');
    expect(m[0].casos).toBe(2);
    expect(m[0].personas).toBe(2);
    expect(m[0].dias).toBe(1);
    expect(m[0].horas).toBe(3);
    expect(m[0].wmsTasks).toEqual(['WMS 1']);
  });

  it('ignora secciones que no son error de fichaje (3, 4, 5...)', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', incidencias: [incSec(SEC.correcta, { tareaOriginal: 'X', propuesta: 'Y' }), incSec(SEC.sinVol, { tareaOriginal: 'X' })] })
    ]);
    expect(AN.confusion.computeConfusionMatrix(recs)).toEqual([]);
  });

  it('sección 2 (varias TASKSPEC) NO entra en la matriz: la correcta no está determinada', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', incidencias: [incSec(SEC.varias, { tareaOriginal: 'X', propuesta: 'P1 | P2', horasAfectadas: 2 })] })
    ]);
    const m = AN.confusion.computeConfusionMatrix(recs);
    expect(m).toEqual([]); // solo la sección 1 (cambio propuesto) entra en la matriz
  });

  it('propuestas múltiples " | " en sección 1 generan una celda por destino', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', incidencias: [incSec(SEC.cambio, { tareaOriginal: 'X', propuesta: 'P1 | P2', horasAfectadas: 2 })] })
    ]);
    const m = AN.confusion.computeConfusionMatrix(recs);
    expect(m.length).toBe(2);
    expect(m.map(c => c.destino).sort()).toEqual(['P1', 'P2']);
  });

  it('dedup de horas por registro+destino (§12: cada registro una vez)', () => {
    const recs = N([
      mkRecord({
        login: 'A', fechaOperativaISO: '2026-08-25', idRegBase: 55,
        incidencias: [
          incSec(SEC.cambio, { tareaOriginal: 'X', propuesta: 'Y', horasAfectadas: 2 }),
          incSec(SEC.cambio, { tareaOriginal: 'X', propuesta: 'Y', horasAfectadas: 2 })
        ]
      })
    ]);
    const m = AN.confusion.computeConfusionMatrix(recs);
    expect(m[0].casos).toBe(2);
    expect(m[0].horas).toBe(2); // mismo id registro → 1 vez
  });
});

describe('confusionAnalytics — heatmap (§13)', () => {
  it('construye la tabla cruzada con máximo correcto', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', incidencias: [incSec(SEC.cambio, { tareaOriginal: 'O1', propuesta: 'D1' })] }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-25', incidencias: [incSec(SEC.cambio, { tareaOriginal: 'O1', propuesta: 'D1' })] }),
      mkRecord({ login: 'C', fechaOperativaISO: '2026-08-26', incidencias: [incSec(SEC.cambio, { tareaOriginal: 'O2', propuesta: 'D2' })] })
    ]);
    const hm = AN.confusion.computeConfusionHeatmap(AN.confusion.computeConfusionMatrix(recs));
    expect(hm.origenes).toContain('O1');
    expect(hm.destinos).toContain('D1');
    expect(hm.max).toBe(2);
    const i = hm.origenes.indexOf('O1'), j = hm.destinos.indexOf('D1');
    expect(hm.grid[i][j]).toBe(2);
  });
  it('matriz vacía produce heatmap vacío sin errores', () => {
    const hm = AN.confusion.computeConfusionHeatmap([]);
    expect(hm.origenes).toEqual([]);
    expect(hm.grid).toEqual([]);
    expect(hm.max).toBe(0);
  });
});

describe('confusionAnalytics — errores recurrentes (§22)', () => {
  it('agrupa por persona + pareja con días, casos, horas y turnos', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', incidencias: [incSec(SEC.cambio, { tareaOriginal: 'X', propuesta: 'Y', horasAfectadas: 2 }), incSec(SEC.cambio, { tareaOriginal: 'X', propuesta: 'Y', horasAfectadas: 1 })] }),
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-26', incidencias: [incSec(SEC.cambio, { tareaOriginal: 'X', propuesta: 'Y', horasAfectadas: 3 })] }),
      mkRecord({ login: 'B', fechaOperativaISO: '2026-08-26', incidencias: [incSec(SEC.cambio, { tareaOriginal: 'X', propuesta: 'Y', horasAfectadas: 4 })] })
    ]);
    const r = AN.confusion.computeRecurrencias(recs, AN.DEFAULT_CONFIG);
    const a = r.find(x => x.login === 'A');
    expect(a.casos).toBe(3);
    expect(a.dias).toBe(2);
    expect(a.horas).toBe(6);
    expect(a.turnos).toEqual(['MAÑANA']);
    const b = r.find(x => x.login === 'B');
    expect(b.dias).toBe(1);
  });

  it('§23 persistencia: AISLADO / RECURRENTE / HABITUAL con umbrales por defecto (1 / 2-4 / 5+)', () => {
    const mk = (dias, login) => Array.from({ length: dias }, (_, i) =>
      mkRecord({ login, fechaOperativaISO: '2026-08-' + String(i + 1).padStart(2, '0'), incidencias: [incSec(SEC.cambio, { tareaOriginal: 'X', propuesta: 'Y' })] }));
    const r1 = AN.confusion.computeRecurrencias(N(mk(1, 'L1')), AN.DEFAULT_CONFIG)[0];
    const r2 = AN.confusion.computeRecurrencias(N(mk(3, 'L2')), AN.DEFAULT_CONFIG)[0];
    const r3 = AN.confusion.computeRecurrencias(N(mk(5, 'L3')), AN.DEFAULT_CONFIG)[0];
    expect(r1.persistencia).toBe('AISLADO');
    expect(r2.persistencia).toBe('RECURRENTE');
    expect(r3.persistencia).toBe('HABITUAL');
  });

  it('los umbrales de persistencia son configurables (§23)', () => {
    const mk = (dias) => Array.from({ length: dias }, (_, i) =>
      mkRecord({ login: 'L', fechaOperativaISO: '2026-08-' + String(i + 1).padStart(2, '0'), incidencias: [incSec(SEC.cambio, { tareaOriginal: 'X', propuesta: 'Y' })] }));
    const cfg = Object.assign({}, AN.DEFAULT_CONFIG, { recurrenciaRecurrente: 2 });
    expect(AN.confusion.computeRecurrencias(N(mk(3)), cfg)[0].persistencia).toBe('HABITUAL');
  });
});
