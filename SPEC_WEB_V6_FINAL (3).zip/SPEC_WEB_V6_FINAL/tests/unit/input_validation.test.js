// FASE 11 (auditoría de certificación) — Tests de validación de entrada (R-06).
//
// Cubre los casos exigidos por la auditoría:
//   1. Archivo vacío (0 bytes)
//   2. Archivo corrupto (bytes basura que no son ZIP/OLE2)
//   3. Archivo con columnas incorrectas / estructura incorrecta
//   4. Archivo demasiado grande (> TamanoMaximoArchivoMB)
//   5. Datos malformados (hoja EXPORT con solo cabecera / sin hoja EXPORT)
//   6. Extensión no permitida
//   7. Tamaño menor a 4 bytes (firma mínima)
//
// La fuente de verdad es app.js: validarArchivoEntrada + validarWorkbook +
// leerArchivoExcel (que combina ambos caminos).

import { readFileSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, it, expect } from 'vitest';

const __dirname = dirname(fileURLToPath(import.meta.url));
const IN_DIR = resolve(__dirname, '..', '..', 'audit-ref', 'drive');
const XLSX = globalThis.XLSX;
const SPEC = globalThis.SPEC;

// Stub tipo File (Node no tiene File con name/size/type en este contexto
// de test — construimos un objeto duck-typed).
function fakeFile(name, size, type = '') {
  return { name, size, type };
}

function readRealWb(p) {
  const buf = readFileSync(p);
  return XLSX.read(buf, { type: 'buffer', cellDates: true });
}

describe('FASE 11 — validarArchivoEntrada (pre-lectura)', () => {
  it('rechaza archivo no proporcionado', () => {
    const r = SPEC.validarArchivoEntrada(null, 'horas');
    expect(r.ok).toBe(false);
    expect(r.error).toContain('no proporcionado');
  });

  it('rechaza archivo vacío (0 bytes)', () => {
    const r = SPEC.validarArchivoEntrada(fakeFile('vacio.xlsx', 0), 'horas');
    expect(r.ok).toBe(false);
    expect(r.error).toContain('vacío');
  });

  it('rechaza extensión no permitida (.csv)', () => {
    const r = SPEC.validarArchivoEntrada(fakeFile('datos.csv', 1000), 'horas');
    expect(r.ok).toBe(false);
    expect(r.error).toContain('Extensión no permitida');
  });

  it('rechaza extensión no permitida (.exe)', () => {
    const r = SPEC.validarArchivoEntrada(fakeFile('malware.exe', 1000), 'horas');
    expect(r.ok).toBe(false);
    expect(r.error).toContain('Extensión no permitida');
  });

  it('rechaza archivo demasiado grande (> 50 MB configurado)', () => {
    const r = SPEC.validarArchivoEntrada(fakeFile('grande.xlsx', 51 * 1024 * 1024), 'horas');
    expect(r.ok).toBe(false);
    expect(r.error).toContain('demasiado grande');
  });

  it('acepta archivo real dentro de límites (VOLUMEN.xlsx de referencia)', () => {
    const buf = readFileSync(join(IN_DIR, 'VOLUMEN.xlsx'));
    const r = SPEC.validarArchivoEntrada(fakeFile('VOLUMEN.xlsx', buf.length), 'volumen');
    expect(r.ok).toBe(true);
    expect(r.error).toBe(null);
  });

  it('advertencia (no rechazo) con MIME inesperado', () => {
    const r = SPEC.validarArchivoEntrada(fakeFile('raro.xlsx', 5000, 'text/html'), 'horas');
    expect(r.ok).toBe(true);
    expect(r.warnings.some(w => w.includes('MIME'))).toBe(true);
  });
});

describe('FASE 11 — Archivos malformados: cadena de defensa real', () => {
  // NOTA TÉCNICA (comportamiento medido de SheetJS 0.18.5): XLSX.read() NO
  // lanza ante bytes basura — interpreta el input como texto plano y crea una
  // "Sheet1" vacía. Por eso la defensa real contra archivos corruptos ES LA
  // PROPIA APP (defensa en profundidad):
  //   1. validarArchivoEntrada (extensión/tamaño/vacío)
  //   2. worker: check explícito buffer < 4 bytes
  //   3. validarWorkbook (estructura EXPORT + datos)
  //   4. fx_Transforma* (columnas obligatorias — lanza "Faltan columnas")
  // Estos tests verifican cada capa CON EVIDENCIA EJECUTADA.

  function loadSpec() {
    return globalThis.SPEC;
  }

  it('bytes basura: SheetJS los acepta como Sheet1 vacía (lenidad documentada)', () => {
    const garbage = Buffer.from('ESTO NO ES UN EXCEL - BASURA PURA '.repeat(10));
    const wb = XLSX.read(garbage, { type: 'buffer', cellDates: true });
    expect(wb.SheetNames).toEqual(['Sheet1']); // lenidad de SheetJS — no throw
  });

  it('bytes basura: validarWorkbook los RECHAZA (capa 3 de la app)', () => {
    const SPEC = loadSpec();
    const garbage = Buffer.from('ESTO NO ES UN EXCEL - BASURA PURA '.repeat(10));
    const wb = XLSX.read(garbage, { type: 'buffer', cellDates: true });
    const r = SPEC.validarWorkbook(wb, 'horas', 'basura.xlsx');
    expect(r.ok).toBe(false);
    expect(r.error).toContain('no contiene datos');
  });

  it('bytes basura: fx_TransformaHoras LANZA "Faltan columnas" (capa 4)', () => {
    const SPEC = loadSpec();
    const garbage = Buffer.from('ESTO NO ES UN EXCEL - BASURA PURA '.repeat(10));
    const wb = XLSX.read(garbage, { type: 'buffer', cellDates: true });
    expect(() => SPEC.fx_TransformaHoras(wb)).toThrow(/Faltan columnas/);
  });

  it('buffer vacío: validarWorkbook lo RECHAZA', () => {
    const SPEC = loadSpec();
    const wb = XLSX.read(Buffer.alloc(0), { type: 'buffer' });
    const r = SPEC.validarWorkbook(wb, 'horas', 'vacio.xlsx');
    expect(r.ok).toBe(false);
    expect(r.error).toContain('no contiene datos');
  });

  it('buffer de 2 bytes: no es ZIP/OLE2 válido — la app lo trata como sin datos', () => {
    const wb = XLSX.read(Buffer.from([0x50, 0x4b]), { type: 'buffer' });
    const SPEC = loadSpec();
    const r = SPEC.validarWorkbook(wb, 'horas', 'min.xlsx');
    expect(r.ok).toBe(false);
  });
});

describe('FASE 11 — validarWorkbook (estructura)', () => {
  it('rechaza workbook null', () => {
    const r = SPEC.validarWorkbook(null, 'horas', 'nulo.xlsx');
    expect(r.ok).toBe(false);
    expect(r.error).toContain('hojas visibles');
  });

  it('rechaza workbook sin hojas', () => {
    const r = SPEC.validarWorkbook({ SheetNames: [], Sheets: {} }, 'horas', 'sinhojas.xlsx');
    expect(r.ok).toBe(false);
    expect(r.error).toContain('hojas visibles');
  });

  it('rechaza hoja EXPORT vacía (sin cabecera)', () => {
    const ws = XLSX.utils.aoa_to_sheet([]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'EXPORT');
    const r = SPEC.validarWorkbook(wb, 'horas', 'vacio.xlsx');
    expect(r.ok).toBe(false);
    expect(r.error).toContain('vacía');
  });

  it('rechaza hoja EXPORT con SOLO cabecera (sin datos)', () => {
    const ws = XLSX.utils.aoa_to_sheet([['ID REGISTRO', 'PERSONA', 'FECHA']]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'EXPORT');
    const r = SPEC.validarWorkbook(wb, 'horas', 'soloheader.xlsx');
    expect(r.ok).toBe(false);
    expect(r.error).toContain('no contiene datos');
  });

  it('acepta un workbook mínimo con cabecera + datos', () => {
    const ws = XLSX.utils.aoa_to_sheet([
      ['ID REGISTRO', 'PERSONA', 'FECHA'],
      ['R1', 'P1', '2026-08-25'],
      ['R2', 'P2', '2026-08-25']
    ]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'EXPORT');
    const r = SPEC.validarWorkbook(wb, 'horas', 'minimo.xlsx');
    expect(r.ok).toBe(true);
  });

  it('advertencia (no rechazo) con >100 columnas (estructura sospechosa)', () => {
    const wideHeader = Array.from({ length: 120 }, (_, i) => 'COL_' + i);
    const row = Array.from({ length: 120 }, () => 'x');
    const ws = XLSX.utils.aoa_to_sheet([wideHeader, row]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'EXPORT');
    const r = SPEC.validarWorkbook(wb, 'horas', 'ancho.xlsx');
    expect(r.ok).toBe(true);
    expect(r.warnings.some(w => w.includes('columnas alto'))).toBe(true);
  });

  it('workbook real de referencia pasa la validación (VOLUMEN.xlsx)', () => {
    const wb = readRealWb(join(IN_DIR, 'VOLUMEN.xlsx'));
    const r = SPEC.validarWorkbook(wb, 'volumen', 'VOLUMEN.xlsx');
    expect(r.ok).toBe(true);
  });

  it('workbook real de mapping pasa la validación (Mapping.xlsx)', () => {
    const wb = readRealWb(join(IN_DIR, 'Mapping.xlsx'));
    const r = SPEC.validarWorkbook(wb, 'mapping', 'Mapping.xlsx');
    expect(r.ok).toBe(true);
  });

  it('workbook sin hoja EXPORT usa fallback a primera hoja (comportamiento documentado)', () => {
    const ws = XLSX.utils.aoa_to_sheet([
      ['A', 'B'],
      ['1', '2'],
      ['3', '4']
    ]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'OTRA HOJA');
    // encontrarHojaExport cae a la primera hoja — validarWorkbook lo documenta
    const r = SPEC.validarWorkbook(wb, 'horas', 'otra.xlsx');
    expect(r.ok).toBe(true);
    expect(r.sheetName).toBe('OTRA HOJA');
  });
});

describe('FASE 11 — fx_Transforma* ante columnas incorrectas', () => {
  it('fx_TransformaHoras con workbook sin columnas esperadas LANZA "Faltan columnas"', () => {
    // Hoja con columnas completamente distintas a las esperadas — la capa 4
    // de la app rechaza con error explícito (verificado por ejecución).
    const ws = XLSX.utils.aoa_to_sheet([
      ['NOMBRE', 'APELLIDO', 'EDAD'],
      ['Ana', 'García', 30],
      ['Luis', 'López', 40]
    ]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'EXPORT');
    expect(() => SPEC.fx_TransformaHoras(wb)).toThrow(/Faltan columnas/);
  });

  it('fx_TransformaHoras con workbook real produce las 116 filas esperadas', () => {
    const wb = readRealWb(join(IN_DIR, 'HORA SIN VOLUMEN.xlsx'));
    const rows = SPEC.fx_TransformaHoras(wb);
    expect(rows.length).toBe(116);
  });

  it('fx_TransformaVolumen con workbook real produce las 743 filas esperadas (sin footers)', () => {
    const wb = readRealWb(join(IN_DIR, 'VOLUMEN.xlsx'));
    const rows = SPEC.fx_TransformaVolumen(wb);
    expect(rows.length).toBe(743);
  });
});
