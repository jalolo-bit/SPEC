// Unit tests v6.1.1 — PRODUCTIVIDAD POR TASK_WMS (overrides + reparto por tarea)
//
// Casos obligatorios del usuario (§16):
//   Caso 1: tarea normal PICKING AGV → 150 uds/h (DEFAULT)
//   Caso 2: override PICKING AGV - ESPECIAL → PICKING AGV → 200 uds/h
//   Caso 3: OTRA (REPARTO A TIENDA AGV - BERSHKA) → OTRA inicialmente;
//           tras override → PICKING AGV → 150 uds/h → ENTRA en el reparto
//   Caso 4: dos tareas de la MISMA actividad con productividades distintas
//           (100 vs 200) → NO se mezclan
// Además (§12): prioridad override tarea > productividad actividad > default;
// (§13): conservación SUM(H_ASIGNADAS_TAREA) = HORAS_ANALIZABLES < 1e-9;
// (§14): los históricos guardan el detalle por tarea (TASK_WMS, actividad,
// productividad, HE, peso, H asignadas) y el snapshot de taskOverrides.

import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const SPEC = globalThis.SPEC;
const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(__dirname, '..', '..');
const TOL = 1e-9;

let __idReg = 0;
function hRow({ fecha, login, name, horas }) {
  __idReg++;
  return {
    'Site name': 'ONTIGOLA INDITEX',
    'Department': '2-ITX-OUTBOUND',
    'Activity': '2.2',
    'Subactivity': '2.2.1',
    'FechaOriginal': fecha,
    'HR Task': '20051 ONTIGOLA-ECOM-PICKING',
    'WMSLoginOriginal': login,
    'Name': name,
    'HorasSinVolumen': horas,
    'ArchivoOrigen': 'test.xlsx',
    'FilaOrigen': 2,
    'Fecha': SPEC.fx_Fecha(fecha),
    'LoginOriginal': login,
    'LoginOriginalLimpio': login,
    'LoginCanonico': login,
    'IdNumerico': '0499',
    'IdNumericoLiteral': '0499',
    'IdNumericoNormalizado': '499',
    'PrefijoLogin': 'OTO',
    'IdRegistroHoras': __idReg
  };
}

function vmRow({ fecha, login, task, uds }) {
  return {
    'Fecha': SPEC.fx_Fecha(fecha),
    'LoginCanonico': login,
    'IdNumericoNormalizado': String(login).replace(/\D/g, ''),
    'WMS_TASK': task,
    'SAP_CODE': 'ES146L',
    'CUSTOMER': 'INDITEX ECOM',
    'VolumenPositivo': uds,
    'TasksSPEC': '20051 ONTIGOLA-ECOM-PICKING',
    'EstadoMapeoFinal': 'UNICO',
    'WMS_DCs': 'ONTIGOLA',
    'ArchivoOrigen': 'v.xlsx',
    'FilaOrigen': 2
  };
}

const PRODS = () => Object.assign({}, SPEC.PARAMS.ProductividadesReferencia);
const DIA = 46260; // 2026-08-26

describe('v6.1.1 — resolverClasificacionTarea (prioridad override > actividad > default)', () => {
  it('CASO 1 — tarea normal: Reparto por cuadrante AGV → PICKING AGV 150 uds/h DEFAULT', () => {
    const cls = SPEC.resolverClasificacionTarea('Reparto por cuadrante AGV - Bershka', { productividades: PRODS(), taskOverrides: {} });
    expect(cls.actividad).toBe('PICKING AGV');
    expect(cls.productividad).toBe(150);
    expect(cls.fuente).toBe('DEFAULT');
  });

  it('CASO 2 — override: PICKING AGV - ESPECIAL → PICKING AGV 200 uds/h OVERRIDE TASK_WMS', () => {
    const ov = { 'PICKING AGV - ESPECIAL': { actividad: 'PICKING AGV', productividad: 200 } };
    const cls = SPEC.resolverClasificacionTarea('PICKING AGV - ESPECIAL', { productividades: PRODS(), taskOverrides: ov });
    expect(cls.actividad).toBe('PICKING AGV');
    expect(cls.productividad).toBe(200);
    expect(cls.fuente).toBe('OVERRIDE TASK_WMS');
  });

  it('CASO 3 (a) — REPARTO A TIENDA AGV - BERSHKA es OTRA inicialmente (sin productividad inventada)', () => {
    const cls = SPEC.resolverClasificacionTarea('REPARTO A TIENDA AGV - BERSHKA', { productividades: PRODS(), taskOverrides: {} });
    expect(cls.actividad).toBe('OTRA');
    expect(cls.productividad).toBeNull();
    expect(cls.fuente).toBe('OTRA');
  });

  it('CASO 3 (b) — tras override → PICKING AGV 150 uds/h: fuente OVERRIDE TASK_WMS', () => {
    const ov = { 'REPARTO A TIENDA AGV - BERSHKA': { actividad: 'PICKING AGV', productividad: 150 } };
    const cls = SPEC.resolverClasificacionTarea('REPARTO A TIENDA AGV - BERSHKA', { productividades: PRODS(), taskOverrides: ov });
    expect(cls.actividad).toBe('PICKING AGV');
    expect(cls.productividad).toBe(150);
    expect(cls.fuente).toBe('OVERRIDE TASK_WMS');
  });

  it('productividad de actividad personalizada se distingue de DEFAULT (columna Fuente)', () => {
    const prods = PRODS(); prods['PICKING MANUAL'] = 130;
    const clsCustom = SPEC.resolverClasificacionTarea('Picking sin papel - Pull & Bear', { productividades: prods, productividadesDefault: SPEC.PARAMS.ProductividadesReferencia, taskOverrides: {} });
    expect(clsCustom.productividad).toBe(130);
    expect(clsCustom.fuente).toBe('PRODUCTIVIDAD ACTIVIDAD');
    const clsDefault = SPEC.resolverClasificacionTarea('Picking sin papel - Pull & Bear', { productividades: PRODS(), productividadesDefault: SPEC.PARAMS.ProductividadesReferencia, taskOverrides: {} });
    expect(clsDefault.productividad).toBe(100);
    expect(clsDefault.fuente).toBe('DEFAULT');
  });

  it('prioridad exacta: override tarea > productividad actividad > default (nunca otra tarea)', () => {
    const tarea = 'Picking sin papel - Pull & Bear';
    // override 180 vs actividad 130 vs default 100 → gana 180
    const prods = PRODS(); prods['PICKING MANUAL'] = 130;
    const ov = { 'PICKING SIN PAPEL - PULL & BEAR': { actividad: 'PICKING MANUAL', productividad: 180 } };
    const cls = SPEC.resolverClasificacionTarea(tarea, { productividades: prods, taskividadesDefault: null, productividadesDefault: SPEC.PARAMS.ProductividadesReferencia, taskOverrides: ov });
    expect(cls.productividad).toBe(180);
    // sin override pero actividad 130 → 130
    const cls2 = SPEC.resolverClasificacionTarea(tarea, { productividades: prods, productividadesDefault: SPEC.PARAMS.ProductividadesReferencia, taskOverrides: {} });
    expect(cls2.productividad).toBe(130);
    // sin override y sin personalización → 100
    const cls3 = SPEC.resolverClasificacionTarea(tarea, { productividades: PRODS(), productividadesDefault: SPEC.PARAMS.ProductividadesReferencia, taskOverrides: {} });
    expect(cls3.productividad).toBe(100);
  });

  it('override puede mandar una tarea productiva a OTRA (y viceversa)', () => {
    const ov = { 'REPARTO POR CUADRANTE AGV - BERSHKA': { actividad: 'OTRA', productividad: null } };
    const cls = SPEC.resolverClasificacionTarea('Reparto por cuadrante AGV - Bershka', { productividades: PRODS(), taskOverrides: ov });
    expect(cls.actividad).toBe('OTRA');
    expect(cls.productividad).toBeNull();
  });

  it('la normalización robusta aplica a los overrides (espacios/acentos/saltos de línea)', () => {
    const ov = { 'REPARTO A TIENDA AGV - BERSHKA': { actividad: 'PICKING AGV', productividad: 150 } };
    // El usuario escribe "reparto a tienda  agv - BERSHKA\r\n" → misma clave
    const cls = SPEC.resolverClasificacionTarea('Reparto a tienda  AGV - Bershka\r\n', { productividades: PRODS(), taskOverrides: ov });
    expect(cls.actividad).toBe('PICKING AGV');
    expect(cls.productividad).toBe(150);
  });
});

describe('v6.1.1 — repartirTiemposPorTarea (modelo por TASK_WMS, §9)', () => {
  it('CASO 4 — dos tareas de la MISMA actividad con productividades distintas NO se mezclan', () => {
    const tareas = [
      { taskWms: 'TASK A', actividad: 'PICKING MANUAL', uds: 200, productividad: 100, fuente: 'DEFAULT' },
      { taskWms: 'TASK B', actividad: 'PICKING MANUAL', uds: 400, productividad: 200, fuente: 'OVERRIDE TASK_WMS' }
    ];
    const rep = SPEC.repartirTiemposPorTarea(8, tareas);
    // HE por tarea: 200/100 = 2 · 400/200 = 2 → pesos 0.5/0.5
    expect(tareas[0].horasEquivalentes).toBeCloseTo(2, 10);
    expect(tareas[1].horasEquivalentes).toBeCloseTo(2, 10);
    expect(tareas[0].peso).toBeCloseTo(0.5, 10);
    expect(tareas[1].peso).toBeCloseTo(0.5, 10);
    expect(tareas[0].horasAsignadas).toBeCloseTo(4, 10);
    expect(tareas[1].horasAsignadas).toBeCloseTo(4, 10);
    // Conservación exacta
    expect(Math.abs(rep.sumaHorasAsignadas - 8)).toBeLessThan(TOL);
  });

  it('conservación con 1, 2 y 3 tareas y productividades variadas (< 1e-9)', () => {
    for (const n of [1, 2, 3]) {
      const tareas = [];
      for (let i = 0; i < n; i++) {
        tareas.push({ taskWms: 'T' + i, actividad: 'PICKING AGV', uds: 100 * (i + 1), productividad: 50 * (i + 1), fuente: 'DEFAULT' });
      }
      const rep = SPEC.repartirTiemposPorTarea(7.5, tareas);
      expect(Math.abs(rep.sumaHorasAsignadas - 7.5)).toBeLessThan(TOL);
      const suma = tareas.reduce((s, t) => s + t.horasAsignadas, 0);
      expect(Math.abs(suma - 7.5)).toBeLessThan(TOL);
    }
  });

  it('tareas OTRA y con 0 uds quedan fuera del reparto (asignadas 0, sin peso ficticio)', () => {
    const tareas = [
      { taskWms: 'PROD', actividad: 'PICKING AGV', uds: 300, productividad: 150, fuente: 'DEFAULT' },
      { taskWms: 'OTRA1', actividad: 'OTRA', uds: 500, productividad: null, fuente: 'OTRA' },
      { taskWms: 'CERO', actividad: 'PICKING AGV', uds: 0, productividad: 150, fuente: 'DEFAULT' }
    ];
    const rep = SPEC.repartirTiemposPorTarea(6, tareas);
    expect(tareas[0].horasAsignadas).toBeCloseTo(6, 10); // la única con HE > 0
    expect(tareas[1].horasAsignadas).toBe(0);
    expect(tareas[1].peso).toBe(0);
    expect(tareas[1].horasEquivalentes).toBeNull();
    expect(tareas[2].horasAsignadas).toBe(0);
    expect(Math.abs(rep.sumaHorasAsignadas - 6)).toBeLessThan(TOL);
  });

  it('valores extremos no rompen la conservación (1e9 uds)', () => {
    const tareas = [
      { taskWms: 'G1', actividad: 'UBICACION AGV', uds: 1e9, productividad: 240, fuente: 'DEFAULT' },
      { taskWms: 'G2', actividad: 'PICKING AGV', uds: 1, productividad: 150, fuente: 'DEFAULT' }
    ];
    const rep = SPEC.repartirTiemposPorTarea(12, tareas);
    expect(Math.abs(rep.sumaHorasAsignadas - 12)).toBeLessThan(TOL);
  });
});

describe('v6.1.1 — q17_PersonaDiaAnalitica con reparto POR TAREA (§8-10)', () => {
  it('CASO 3 (c) — OTRA → override PICKING AGV 150 → ENTRA realmente en el reparto', () => {
    const H = [hRow({ fecha: DIA, login: 'OTO9101', name: 'AMBIGUA TEST', horas: 8 })];
    const VM = [
      vmRow({ fecha: DIA, login: 'OTO9101', task: 'REPARTO A TIENDA AGV - BERSHKA', uds: 300 }),
      vmRow({ fecha: DIA, login: 'OTO9101', task: 'Ubicación con cantidad - Oysho', uds: 260 })
    ];
    // Sin override: todo lo de REPARTO A TIENDA queda OTRA → fuera del reparto
    const sinOv = SPEC.q17_PersonaDiaAnalitica(H, VM, [], { productividades: PRODS(), taskOverrides: {} });
    const otra = sinOv[0].actividades.find(a => a.actividad === 'OTRA');
    expect(otra).toBeTruthy();
    expect(otra.uds).toBe(300);
    expect(otra.horasAsignadas).toBe(0);
    const ubic = sinOv[0].actividades.find(a => a.actividad === 'UBICACION MANUAL');
    expect(ubic.horasAsignadas).toBeCloseTo(8, 10); // única productiva
    // Con override: REPARTO A TIENDA → PICKING AGV 150 → entra al reparto
    const conOv = SPEC.q17_PersonaDiaAnalitica(H, VM, [], {
      productividades: PRODS(),
      taskOverrides: { 'REPARTO A TIENDA AGV - BERSHKA': { actividad: 'PICKING AGV', productividad: 150 } }
    });
    expect(conOv[0].actividades.some(a => a.actividad === 'OTRA')).toBe(false);
    const pick = conOv[0].actividades.find(a => a.actividad === 'PICKING AGV');
    expect(pick).toBeTruthy();
    expect(pick.uds).toBe(300);
    expect(pick.horasAsignadas).toBeGreaterThan(0);
    // HE: 300/150 = 2 h · 260/260 = 1 h → pesos 2/3 y 1/3 sobre 8 h
    expect(pick.horasEquivalentes).toBeCloseTo(2, 10);
    expect(pick.horasAsignadas).toBeCloseTo(8 * (2 / 3), 10);
    const sum = conOv[0].actividades.reduce((s, a) => s + a.horasAsignadas, 0);
    expect(Math.abs(sum - 8)).toBeLessThan(TOL);
  });

  it('CASO 4 (q17) — dos tareas de la misma actividad no comparten productividad', () => {
    const H = [hRow({ fecha: DIA, login: 'OTO9102', name: 'DOS TAREAS TEST', horas: 8 })];
    const VM = [
      vmRow({ fecha: DIA, login: 'OTO9102', task: 'Picking sin papel - Pull & Bear', uds: 200 }),        // 100 uds/h default
      vmRow({ fecha: DIA, login: 'OTO9102', task: 'Picking ecommerce a matrícula - Zara', uds: 400 })     // override 200
    ];
    const out = SPEC.q17_PersonaDiaAnalitica(H, VM, [], {
      productividades: PRODS(),
      taskOverrides: { 'PICKING ECOMMERCE A MATRICULA - ZARA': { actividad: 'PICKING MANUAL', productividad: 200 } }
    });
    const g = out[0];
    expect(g.actividades.length).toBe(1); // una sola actividad PICKING MANUAL
    const act = g.actividades[0];
    expect(act.uds).toBe(600);
    expect(act.productividad).toBeNull(); // varias productividades → null (se muestra "varias")
    expect(act.tareas.length).toBe(2);      // detalle por tarea
    const tA = act.tareas.find(t => t.taskWms.indexOf('sin papel') >= 0);
    const tB = act.tareas.find(t => t.taskWms.indexOf('matrícula') >= 0);
    expect(tA.productividad).toBe(100);
    expect(tA.fuente).toBe('DEFAULT');
    expect(tB.productividad).toBe(200);
    expect(tB.fuente).toBe('OVERRIDE TASK_WMS');
    // HE: 200/100 = 2 · 400/200 = 2 → 4 h + 4 h
    expect(tA.horasEquivalentes).toBeCloseTo(2, 10);
    expect(tB.horasEquivalentes).toBeCloseTo(2, 10);
    expect(tA.horasAsignadas).toBeCloseTo(4, 10);
    expect(tB.horasAsignadas).toBeCloseTo(4, 10);
    // La suma de tareas = la suma de la actividad = tiempo analizable
    expect(Math.abs(act.horasAsignadas - 8)).toBeLessThan(TOL);
    expect(Math.abs(g.sumaHorasAsignadas - 8)).toBeLessThan(TOL);
  });

  it('la vista por actividad suma exactamente sus tareas (§10)', () => {
    const H = [hRow({ fecha: DIA, login: 'OTO9103', name: 'AGREGACION TEST', horas: 6 })];
    const VM = [
      vmRow({ fecha: DIA, login: 'OTO9103', task: 'Reparto por cuadrante AGV - Bershka', uds: 300 }),        // PICKING AGV 150 → 2 h
      vmRow({ fecha: DIA, login: 'OTO9103', task: 'Reparto por supercuadrante AGV - Zara', uds: 450 })      // override PICKING AGV 300 → 1.5 h
    ];
    const out = SPEC.q17_PersonaDiaAnalitica(H, VM, [], {
      productividades: PRODS(),
      taskOverrides: { 'REPARTO POR SUPERCUADRANTE AGV - ZARA': { actividad: 'PICKING AGV', productividad: 300 } }
    });
    const act = out[0].actividades[0];
    expect(act.actividad).toBe('PICKING AGV');
    expect(act.uds).toBe(750);
    expect(act.tareas.length).toBe(2);
    expect(act.horasEquivalentes).toBeCloseTo(3.5, 10);
    expect(Math.abs(act.horasAsignadas - 6)).toBeLessThan(TOL);
    expect(act.tareas[0].horasAsignadas + act.tareas[1].horasAsignadas).toBeCloseTo(act.horasAsignadas, 10);
  });
});

describe('v6.1.1 — históricos: detalle por tarea + snapshot de overrides (§14)', () => {
  it('generarPersonDailyRecords guarda TASK_WMS/productividad/HE/peso/asignadas y taskOverrides', () => {
    const H = [hRow({ fecha: DIA, login: 'OTO9104', name: 'HISTORICO TEST', horas: 8 })];
    const VM = [
      vmRow({ fecha: DIA, login: 'OTO9104', task: 'Picking sin papel - Pull & Bear', uds: 200 }),
      vmRow({ fecha: DIA, login: 'OTO9104', task: 'Picking ecommerce a matrícula - Zara', uds: 400 })
    ];
    const ov = { 'PICKING ECOMMERCE A MATRICULA - ZARA': { actividad: 'PICKING MANUAL', productividad: 200 } };
    const PD = SPEC.q17_PersonaDiaAnalitica(H, VM, [], { productividades: PRODS(), taskOverrides: ov });
    const recs = SPEC.generarPersonDailyRecords(PD, [], {
      mappingHash: 'sha256:test', mappingVersion: 2,
      productividades: PRODS(), taskOverrides: ov,
      appVersion: '6.1.1-test', sessionId: 's1', timestamp: '2026-10-02T00:00:00Z'
    });
    expect(recs.length).toBe(1);
    const r = recs[0];
    expect(r.taskOverrides).toEqual(ov);
    expect(r.productividades['PICKING MANUAL']).toBe(100);
    expect(r.appVersion).toBe('6.1.1-test');
    const act = r.actividades[0];
    expect(act.tareas.length).toBe(2);
    for (const t of act.tareas) {
      expect(typeof t.taskWms).toBe('string');
      expect(t.horasEquivalentes).toBeCloseTo(2, 10);
      expect(t.peso).toBeCloseTo(0.5, 10);
      expect(t.horasAsignadas).toBeCloseTo(4, 10);
    }
    // Conservación a nivel de record
    expect(Math.abs(act.horasAsignadas - r.horasAnalizables)).toBeLessThan(TOL);
  });

  it('cambiar un override cambia el fingerprint → nueva versión al reprocesar', () => {
    const H = [hRow({ fecha: DIA, login: 'OTO9105', name: 'VERSION TEST', horas: 8 })];
    const VM = [vmRow({ fecha: DIA, login: 'OTO9105', task: 'Picking sin papel - Pull & Bear', uds: 400 })];
    const mk = (ov) => {
      const PD = SPEC.q17_PersonaDiaAnalitica(H, VM, [], { productividades: PRODS(), taskOverrides: ov });
      return SPEC.generarPersonDailyRecords(PD, [], { mappingHash: 'h', productividades: PRODS(), taskOverrides: ov })[0];
    };
    const r1 = mk({});
    const r2 = mk({ 'PICKING SIN PAPEL - PULL & BEAR': { actividad: 'PICKING MANUAL', productividad: 200 } });
    expect(r1.dataFingerprint).not.toBe(r2.dataFingerprint);
    expect(r2.actividades[0].tareas[0].productividad).toBe(200);
    // Mismos datos → mismo fingerprint (idempotente)
    const r1b = mk({});
    expect(r1b.dataFingerprint).toBe(r1.dataFingerprint);
  });
});
