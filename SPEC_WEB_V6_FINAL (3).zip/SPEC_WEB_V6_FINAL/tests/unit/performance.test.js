// Performance tests with synthetic large datasets (T-08).
//
// We generate VOLUMEN-like workbooks with 1k, 10k, and 50k rows and run
// them through SPEC.analizarYConciliar. The test asserts each size completes
// within a loose upper bound (documented per-size) and that the pipeline
// does not throw or produce obviously broken output (e.g. row count zero).
//
// Bounds (chosen loose enough to pass on a CI runner while still catching
// accidental quadratic blowups):
//   1k rows   : < 1s
//   10k rows  : < 5s
//   50k rows  : < 30s
//
// The synthetic data is intentionally simple (random logins + dates + the
// minimum column set required by fx_Transforma*). It does NOT need to be
// equivalent to the Excel source — it just needs to be processable.

import { describe, it, expect, beforeAll } from 'vitest';

const SPEC = globalThis.SPEC;
const XLSX = globalThis.XLSX;

// ---- Synthetic data generators -------------------------------------------

const SITES = ['MADRID', 'BARCELONA', 'VALENCIA', 'SEVILLA', 'BILBAO'];
const DEPTS = ['CD', 'TIENDA', 'ECOM'];
const ACTIVITIES = ['PICKING', 'PACKING', 'DEVO', 'UBICACION'];
const SUBS = ['A', 'B', 'C'];
const TASKS = ['T1', 'T2', 'T3', 'T4', 'T5'];
const CUSTOMERS = ['INDITEX', 'ZARA', 'BERSHKA', 'MANGO'];
const SAP_CODES = ['ES146L', 'ES280L', 'ES410L'];
const DC = ['DC1', 'DC2'];
const PREFIXES = ['OTO', 'EU', 'PSC', 'XRG'];

function randInt(max) { return Math.floor(Math.random() * max); }
function pick(arr) { return arr[randInt(arr.length)]; }

function makeLogin(i) {
  // e.g. "OTO0499" — 3-letter prefix + 4-digit number
  return PREFIXES[i % PREFIXES.length] + String(1000 + (i % 9000)).padStart(4, '0');
}

function makeDateSerial(i) {
  // Excel serial date: pick a date in 2026 (>=46200 = 2026-06-15)
  // Vary the date to spread rows across the month.
  return 46200 + (i % 30);
}

function makeVolumenRows(n) {
  const rows = [];
  for (let i = 0; i < n; i++) {
    rows.push({
      DATE: makeDateSerial(i),
      SAP_CODE: pick(SAP_CODES),
      CUSTOMER: pick(CUSTOMERS),
      WMS_TASK: pick(TASKS) + ' ' + pick(ACTIVITIES),
      WMS_LOGIN: makeLogin(i),
      USER_NAME: 'USER_' + (i % 100),
      WMS_UOM: randInt(1000)
    });
  }
  return rows;
}

function makeHorasRows(n) {
  const rows = [];
  for (let i = 0; i < n; i++) {
    rows.push({
      'Site name': pick(SITES),
      'Department': pick(DEPTS),
      'Activity': pick(ACTIVITIES),
      'Subactivity': pick(SUBS),
      'Date': makeDateSerial(i),
      'HR Task': pick(TASKS),
      'WMS Login': makeLogin(i),
      'Name': 'USER_' + (i % 100),
      'Hours without volume': 0.5 + Math.random()
    });
  }
  return rows;
}

function makeVSHRows(n) {
  const rows = [];
  for (let i = 0; i < n; i++) {
    rows.push({
      'Site name': pick(SITES),
      'Department': pick(DEPTS),
      'Activity': pick(ACTIVITIES),
      'Subactivity': pick(SUBS),
      'Date': makeDateSerial(i),
      'HR Task': pick(TASKS),
      'WMS Login': makeLogin(i),
      'Name': 'USER_' + (i % 100),
      'Volume Without Hours': randInt(500)
    });
  }
  return rows;
}

function makeMappingRows(n) {
  const rows = [];
  for (let i = 0; i < n; i++) {
    rows.push({
      SAP_CODE: pick(SAP_CODES),
      WMS_DC: pick(DC),
      CUSTOMER: pick(CUSTOMERS),
      DEPARTMENT: pick(DEPTS),
      ACTIVITY: pick(ACTIVITIES),
      SUB_ACTIVITY: pick(SUBS),
      TASK_WMS: pick(TASKS) + ' ' + pick(ACTIVITIES),
      TASK_SPEC: 'SPEC_' + (i % 20)
    });
  }
  // Ensure at least one mapping row matches a WMS_TASK from the synthetic
  // volume data, otherwise the pipeline produces an empty 12_MapeoActividadSPEC
  // (which is fine for perf timing but reduces the value of the run).
  rows.push({
    SAP_CODE: 'ES146L', WMS_DC: 'DC1', CUSTOMER: 'INDITEX',
    DEPARTMENT: 'CD', ACTIVITY: 'PICKING', SUB_ACTIVITY: 'A',
    TASK_WMS: 'T1 PICKING', TASK_SPEC: 'SPEC_PICKING'
  });
  return rows;
}

function buildWorkbook(rows, sheetName) {
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheetName);
  return wb;
}

function setupSynthetic(n) {
  const horasWb   = buildWorkbook(makeHorasRows(n),   'Export');
  const volumenWb = buildWorkbook(makeVolumenRows(n),  'Export');
  const vshWb     = buildWorkbook(makeVSHRows(n),      'Export');
  const mappingWb = buildWorkbook(makeMappingRows(50), 'Mapping');
  SPEC.STATE.archivos.horas      = { name: 'H.xlsx',  workbook: horasWb };
  SPEC.STATE.archivos.volumen    = { name: 'V.xlsx',  workbook: volumenWb };
  SPEC.STATE.archivos.volSinHoras = { name: 'VSH.xlsx', workbook: vshWb };
  SPEC.STATE.archivos.mapping    = { name: 'M.xlsx',  workbook: mappingWb };
}

// ---- Time + run helpers --------------------------------------------------

async function runPipeline(n) {
  setupSynthetic(n);
  const t0 = performance.now();
  await SPEC.analizarYConciliar(() => {});
  const t1 = performance.now();
  return {
    ms: Math.round(t1 - t0),
    reporteLength: SPEC.STATE.reporte.length,
    queryKeys: Object.keys(SPEC.STATE.queries).length
  };
}

// ---- Tests ---------------------------------------------------------------

describe('Performance tests — synthetic large datasets (T-08)', () => {
  // Warmup once before timing the actual tests — the first run of
  // analizarYConciliar after setup.js loads app.js pays one-time V8 warmup
  // costs (function compilation, hidden-class transitions) that would
  // otherwise skew the 1k timing.
  let warmupMs;

  beforeAll(async () => {
    const r = await runPipeline(500);
    warmupMs = r.ms;
    // Sanity: warmup should produce *some* output, not zero rows.
    expect(r.queryKeys, 'warmup should populate at least 10 query tables').toBeGreaterThanOrEqual(10);
  }, 60_000);

  describe('1k rows', () => {
    it('completes in < 1s', async () => {
      const r = await runPipeline(1_000);
      expect(r.ms, `1k rows took ${r.ms}ms (warmup was ${warmupMs}ms)`).toBeLessThan(1_000);
      expect(r.queryKeys, 'expected at least 10 query tables').toBeGreaterThanOrEqual(10);
      expect(r.reporteLength, 'expected at least 1 reporte row').toBeGreaterThan(0);
    }, 30_000);
  });

  describe('10k rows', () => {
    it('completes in < 5s', async () => {
      const r = await runPipeline(10_000);
      expect(r.ms, `10k rows took ${r.ms}ms`).toBeLessThan(5_000);
      expect(r.reporteLength, 'expected at least 1 reporte row').toBeGreaterThan(0);
    }, 60_000);
  });

  describe('50k rows', () => {
    it('completes in < 30s', async () => {
      const r = await runPipeline(50_000);
      expect(r.ms, `50k rows took ${r.ms}ms`).toBeLessThan(30_000);
      expect(r.reporteLength, 'expected at least 1 reporte row').toBeGreaterThan(0);
    }, 120_000);
  });

  describe('scaling sanity check', () => {
    // A simple check that 10k is not dramatically slower than expected (no
    // accidental quadratic blowup). 10k should be roughly 5-15x slower than
    // 1k — if it's 100x slower, there's a scaling bug.
    it('10k takes less than 50x the time of 1k (no quadratic blowup)', async () => {
      const r1k = await runPipeline(1_000);
      const r10k = await runPipeline(10_000);
      const ratio = r10k.ms / Math.max(r1k.ms, 1);
      // 10x data → expected ~10x time (linear) up to ~20x for O(n log n).
      // 50x is the "definitely quadratic" threshold.
      expect(ratio, `10k took ${r10k.ms}ms vs 1k ${r1k.ms}ms (ratio ${ratio.toFixed(1)}x)`).toBeLessThan(50);
    }, 120_000);
  });
});
