/* Tests v6.2 — alertas e índice de prioridad (alertAnalytics.js).
 * §5/§6/§37/§62: reglas deterministas A1-A11, índice transparente con
 * desglose y TOP 5 prioridades. */
import { describe, it, expect } from 'vitest';
import { mkRecord, SEC, incSec } from '../helpers/analyticsFixtures.js';

const AN = globalThis.SPEC_AN;
const N = AN.normalizarRecords;
const D = AN.DEFAULT_CONFIG;

describe('alertAnalytics — reglas deterministas (§37)', () => {
  it('A1: tarea con tasa creciente > umbral pp', () => {
    const recs = [];
    for (let i = 1; i <= 4; i++) recs.push(mkRecord({ login: 'A' + i, fechaOperativaISO: '2026-08-0' + i, tareas: [{ taskWms: 'T1', uds: 10 }] }));
    for (let i = 10; i <= 13; i++) recs.push(mkRecord({ login: 'B' + i, fechaOperativaISO: '2026-08-' + i, tareas: [{ taskWms: 'T1', uds: 10 }], incidencias: [incSec(SEC.cambio, { wmsTask: 'T1' })] }));
    const alerts = AN.alerts.computeAlerts(N(recs), D);
    const a1 = alerts.find(a => a.codigo === 'A1_TASA_CRECIENTE');
    expect(a1).toBeDefined();
    expect(a1.datos.taskWms).toBe('T1');
    expect(a1.detalle).toContain('pp');
  });

  it('A2: persona con racha de días consecutivos con error', () => {
    const recs = N(Array.from({ length: 4 }, (_, i) =>
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-' + String(i + 1).padStart(2, '0'), incidencias: [incSec(SEC.cambio)] })));
    const alerts = AN.alerts.computeAlerts(recs, D);
    const a2 = alerts.find(a => a.codigo === 'A2_RACHA_PERSONA');
    expect(a2).toBeDefined();
    expect(a2.datos.racha).toBe(4);
  });

  it('A3: concentración con comprobación real de 80/20', () => {
    const recs = [];
    // 1 tarea concentra casi todos los errores → 80/20 se cumple
    for (let i = 0; i < 6; i++) {
      recs.push(mkRecord({
        login: 'A' + i, fechaOperativaISO: '2026-08-' + String(i + 1).padStart(2, '0'),
        tareas: [{ taskWms: 'TOP', uds: 10 }, { taskWms: 'MIN' + i, uds: 5 }],
        incidencias: [incSec(SEC.cambio, { wmsTask: 'TOP' })]
      }));
    }
    const alerts = AN.alerts.computeAlerts(N(recs), D);
    const a3 = alerts.find(a => a.codigo === 'A3_CONCENTRACION');
    expect(a3).toBeDefined();
    expect(a3.detalle).toContain('80%');
  });

  it('A4: turno con tasa de error significativamente superior', () => {
    const recs = [];
    for (let i = 0; i < 6; i++) recs.push(mkRecord({ login: 'N' + i, fechaOperativaISO: '2026-08-' + String(i + 1).padStart(2, '0'), turno: 'NOCHE', turnos: ['NOCHE'], incidencias: [incSec(SEC.cambio)] }));
    for (let i = 0; i < 6; i++) recs.push(mkRecord({ login: 'M' + i, fechaOperativaISO: '2026-08-' + String(i + 10).padStart(2, '0'), turno: 'MAÑANA', turnos: ['MAÑANA'] }));
    const alerts = AN.alerts.computeAlerts(N(recs), D);
    const a4 = alerts.find(a => a.codigo === 'A4_TURNO_PEOR');
    expect(a4).toBeDefined();
    expect(a4.datos.turno).toBe('NOCHE');
  });

  it('A5: tarea OTRA con volumen relevante (necesidad de mapping)', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', tareas: [{ taskWms: 'REPARTO A TIENDA AGV - BERSHKA', actividad: 'OTRA', uds: 500, productividad: null, horasAsignadas: 0 }] })
    ]);
    const alerts = AN.alerts.computeAlerts(recs, D);
    const a5 = alerts.find(a => a.codigo === 'A5_OTRA_VOLUMEN');
    expect(a5).toBeDefined();
    expect(a5.detalle).toContain('500 uds');
  });

  it('A6: la misma confusión A→B repetida N veces', () => {
    const recs = N(Array.from({ length: 4 }, (_, i) =>
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-' + String(i + 1).padStart(2, '0'), incidencias: [incSec(SEC.cambio, { tareaOriginal: 'X', propuesta: 'Y' })] })));
    const alerts = AN.alerts.computeAlerts(recs, D);
    const a6 = alerts.find(a => a.codigo === 'A6_CONFUSION_REPETIDA');
    expect(a6).toBeDefined();
    expect(a6.titulo).toContain('X → Y');
  });

  it('A7: persona con alta recurrencia (días distintos con error)', () => {
    const recs = N(Array.from({ length: 5 }, (_, i) =>
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-' + String(i + 1).padStart(2, '0'), incidencias: [incSec(SEC.cambio)] })));
    const alerts = AN.alerts.computeAlerts(recs, D);
    expect(alerts.find(a => a.codigo === 'A7_PERSONA_RECURRENTE')).toBeDefined();
  });

  it('A8: pocos errores pero gran impacto en horas', () => {
    const recs = N([
      mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25', tareas: [{ taskWms: 'CARA', uds: 10 }], incidencias: [incSec(SEC.cambio, { wmsTask: 'CARA', horasAfectadas: 8 })] })
    ]);
    const alerts = AN.alerts.computeAlerts(recs, Object.assign({}, D, { minObservaciones: 5 }));
    expect(alerts.find(a => a.codigo === 'A8_IMPACTO_ALTO')).toBeDefined();
  });

  it('A9/A10: empeora y mejora con evidencia suficiente', () => {
    const empeora = [];
    for (let i = 1; i <= 3; i++) empeora.push(mkRecord({ login: 'A', fechaOperativaISO: '2026-08-0' + i }));
    for (let i = 10; i <= 12; i++) empeora.push(mkRecord({ login: 'A', fechaOperativaISO: '2026-08-' + i, incidencias: [incSec(SEC.cambio)] }));
    const alerts = AN.alerts.computeAlerts(N(empeora), D);
    expect(alerts.find(a => a.codigo === 'A9_PERSONA_EMPEORA')).toBeDefined();

    const mejora = [];
    for (let i = 1; i <= 3; i++) mejora.push(mkRecord({ login: 'B', fechaOperativaISO: '2026-08-0' + i, incidencias: [incSec(SEC.cambio)] }));
    for (let i = 10; i <= 12; i++) mejora.push(mkRecord({ login: 'B', fechaOperativaISO: '2026-08-' + i }));
    const alerts2 = AN.alerts.computeAlerts(N(mejora), D);
    expect(alerts2.find(a => a.codigo === 'A10_PERSONA_MEJORA')).toBeDefined();
  });

  it('A11: % elevado de registros SIN HORA (calidad del dato, no operativo)', () => {
    const recs = [];
    for (let i = 0; i < 10; i++) recs.push(mkRecord({ login: 'A' + i, fechaOperativaISO: '2026-08-' + String(i + 1).padStart(2, '0'), turno: 'SIN HORA', turnos: ['SIN HORA'], hora: null }));
    const alerts = AN.alerts.computeAlerts(N(recs), D);
    const a11 = alerts.find(a => a.codigo === 'A11_SIN_HORA');
    expect(a11).toBeDefined();
    expect(a11.severidad).toBe('INFO');
  });

  it('sin errores no dispara alertas de persona/tarea', () => {
    const recs = N([mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25' }), mkRecord({ login: 'B', fechaOperativaISO: '2026-08-25' })]);
    const alerts = AN.alerts.computeAlerts(recs, D);
    expect(alerts.filter(a => a.codigo.startsWith('A2') || a.codigo.startsWith('A7'))).toEqual([]);
  });

  it('histórico vacío → sin alertas y sin excepciones', () => {
    expect(AN.alerts.computeAlerts([], D)).toEqual([]);
  });
});

describe('alertAnalytics — índice de prioridad (§6: transparente)', () => {
  it('score 0-100 con desglose completo de componentes', () => {
    const res = AN.alerts.computePrioridades([
      { nombre: 'T1', tipo: 'TAREA', frecuencia: 10, tasa: 50, horas: 20, recurrencia: 5, deltaPP: 10, personas: 3 },
      { nombre: 'T2', tipo: 'TAREA', frecuencia: 1, tasa: 5, horas: 1, recurrencia: 1, deltaPP: 0, personas: 1 }
    ], D);
    expect(res[0].nombre).toBe('T1');
    expect(res[0].score).toBe(100); // máximo en todos los componentes
    expect(res[0].nivel).toBe('ALTA');
    expect(res[0].desglose.frecuencia.valor).toBe(10);
    expect(res[0].desglose.frecuencia.peso).toBe(D.pesoFrecuencia);
    expect(res[0].desglose.horas.contrib).toBe(D.pesoHoras);
    expect(res[1].score).toBeLessThan(res[0].score);
    // el desglose suma: los contribs del máximo == suma de pesos
    const d = res[0].desglose;
    const suma = d.frecuencia.contrib + d.tasa.contrib + d.horas.contrib + d.recurrencia.contrib + d.tendencia.contrib + d.personas.contrib;
    expect(suma).toBe(D.pesoFrecuencia + D.pesoTasa + D.pesoHoras + D.pesoRecurrencia + D.pesoTendencia + D.pesoPersonas);
  });

  it('nivel según umbrales configurables y sin candidatos → vacío', () => {
    expect(AN.alerts.computePrioridades([], D)).toEqual([]);
    const r = AN.alerts.computePrioridades([{ nombre: 'X', frecuencia: 1, tasa: 1, horas: 1, recurrencia: 1, deltaPP: 0, personas: 1 }], D);
    // único candidato → máximo relativo en 5 componentes; la tendencia con
    // deltaPP 0 no puntúa (no hay empeoramiento que ponderar): 85/100.
    expect(r[0].score).toBe(D.pesoFrecuencia + D.pesoTasa + D.pesoHoras + D.pesoRecurrencia + D.pesoPersonas);
    expect(r[0].nivel).toBe('ALTA');
  });

  it('la tendencia empeorando sube el score (contribución > 0)', () => {
    const base = (deltaPP) => [
      { nombre: 'A', frecuencia: 5, tasa: 50, horas: 5, recurrencia: 2, deltaPP: deltaPP, personas: 2 },
      { nombre: 'B', frecuencia: 1, tasa: 10, horas: 1, recurrencia: 1, deltaPP: 0, personas: 1 }
    ];
    const sin = AN.alerts.computePrioridades(base(null), D)[0];
    const con = AN.alerts.computePrioridades(base(20), D)[0];
    expect(con.score).toBeGreaterThan(sin.score);
    expect(con.desglose.tendencia.valor).toBe(20);
    expect(sin.desglose.tendencia.valor).toBeNull();
  });
});

describe('alertAnalytics — TOP 5 prioridades (§62)', () => {
  it('devuelve como máximo 5 elementos con qué/por qué/impacto/tendencia', () => {
    const recs = [];
    const tareas = ['T1', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'T8'];
    for (let i = 0; i < 10; i++) {
      recs.push(mkRecord({
        login: 'A' + i, fechaOperativaISO: '2026-08-' + String(i + 1).padStart(2, '0'),
        tareas: tareas.map((t, j) => ({ taskWms: t, uds: 10 * (8 - j) })),
        incidencias: [incSec(SEC.cambio, { wmsTask: 'T1', horasAfectadas: 2 }), incSec(SEC.cambio, { wmsTask: 'T2', horasAfectadas: 1 })]
      }));
    }
    const top = AN.alerts.computeTopPrioridades(N(recs), D, 5);
    expect(top.length).toBeLessThanOrEqual(5);
    expect(top.length).toBeGreaterThan(0);
    expect(top[0].nombre).toBe('T1'); // mayor frecuencia
    for (const p of top) {
      expect(p.desglose).toBeDefined();
      expect(p.flecha).toBeDefined();
      expect(['ALTA', 'MEDIA', 'BAJA']).toContain(p.nivel);
    }
  });

  it('sin errores ni horas → sin prioridades', () => {
    const recs = N([mkRecord({ login: 'A', fechaOperativaISO: '2026-08-25' })]);
    expect(AN.alerts.computeTopPrioridades(recs, D, 5)).toEqual([]);
  });
});
