// Test helper — load app.js with private symbols exposed.
//
// app.js is an IIFE that does NOT export formatNum2 / formatNum0 /
// formatNumExact / deepClone on SPEC. To unit-test them directly, we load
// the SAME source with a single regex patch: just before `global.SPEC = {`,
// we insert `global.__testPriv = { formatNum, formatNum2, formatNum0,
// formatNumExact, deepClone, stripTime, fechaToLong };`. The patch is
// test-only — we never modify the app.js file on disk. The exposed object
// lives on `globalThis.__testPriv` for the duration of the test process.
//
// If a future refactor exports these on SPEC, this helper can be deleted and
// the tests can switch to `SPEC.formatNum2` directly. The presence of the
// helper is a documentation smell that points at the missing exports.

import { readFileSync } from 'node:fs';
import XLSX from 'xlsx';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const projectRoot = resolve(__dirname, '..', '..');

// Stubs (mirrors tests/setup.js but isolated to this helper so it can be
// called from any test file that needs the private symbols).
function ensureStubs() {
  if (typeof globalThis.window === 'undefined') globalThis.window = globalThis;
  if (typeof globalThis.document === 'undefined') {
    globalThis.document = {
      createElement: () => ({ style: {}, appendChild() {}, setAttribute() {}, addEventListener() {} }),
      getElementById: () => null,
      querySelector: () => null,
      querySelectorAll: () => [],
      addEventListener() {},
      body: { appendChild() {}, classList: { add() {}, remove() {}, toggle() {} } }
    };
  }
  if (typeof globalThis.navigator === 'undefined') {
    globalThis.navigator = { language: 'en', userAgent: 'node' };
  }
  if (typeof globalThis.localStorage === 'undefined') {
    const store = new Map();
    globalThis.localStorage = {
      getItem: (k) => (store.has(k) ? store.get(k) : null),
      setItem: (k, v) => store.set(k, String(v)),
      removeItem: (k) => store.delete(k),
      clear: () => store.clear()
    };
  }
  if (typeof globalThis.XLSX === 'undefined') {
    globalThis.XLSX = XLSX;
  }
}

let loaded = false;

export function loadAppWithPriv() {
  if (loaded) return globalThis.__testPriv;
  ensureStubs();
  const src = readFileSync(resolve(projectRoot, 'app.js'), 'utf8');
  // Single regex patch: insert `global.__testPriv = {...};` just before
  // `global.SPEC = {`. The patch is anchored on the exact assignment at the
  // bottom of the IIFE; if that anchor ever changes, this helper will throw
  // and force an update.
  const patched = src.replace(
    /global\.SPEC = \{/,
    'global.__testPriv = { formatNum, formatNum2, formatNum0, formatNumExact, deepClone, stripTime, fechaToLong };\nglobal.SPEC = {'
  );
  if (patched === src) {
    throw new Error('[loadAppWithPriv] anchor "global.SPEC = {" not found in app.js — the helper needs an update');
  }
  // eslint-disable-next-line no-new-func
  const loader = new Function(
    'window', 'globalThis', 'document', 'navigator', 'localStorage', 'XLSX',
    patched
  );
  loader(
    globalThis.window,
    globalThis,
    globalThis.document,
    globalThis.navigator,
    globalThis.localStorage,
    globalThis.XLSX
  );
  if (!globalThis.__testPriv) {
    throw new Error('[loadAppWithPriv] __testPriv was not exposed — patch did not run inside the IIFE');
  }
  loaded = true;
  return globalThis.__testPriv;
}
