/* Fixtures sintéticos para los tests de la capa analítica v6.2.
 * Generan PERSON_DAILY_RECORD crudos (como vendrían de IndexedDB) con la
 * misma estructura que generarPersonDailyRecords (app.js). */

function isoWeekOf(fechaISO) {
  const d = new Date(fechaISO + 'T00:00:00Z');
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = Date.UTC(d.getUTCFullYear(), 0, 1);
  const week = Math.ceil(((d.getTime() - yearStart) / 86400000 + 1) / 7);
  return d.getUTCFullYear() + '-W' + String(week).padStart(2, '0');
}

/* Record crudo mínimamente completo. */
function mkRecord(over) {
  const o = over || {};
  const fechaISO = o.fechaOperativaISO || '2026-08-25';
  const turno = o.turno || 'MAÑANA';
  const login = o.login || 'OTO1';
  const tareas = (o.tareas === undefined ? [{}] : o.tareas).map(t => Object.assign({
    taskWms: 'PICKING SIN PAPEL - PULL & BEAR', actividad: 'PICKING MANUAL',
    uds: 100, productividad: 100, fuente: 'DEFAULT',
    horasEquivalentes: 1, peso: 1, horasAsignadas: 8, tasksSpec: '20051 PICKING', cliente: 'PULL&BEAR'
  }, t));
  const actividades = [];
  const porAct = new Map();
  for (const t of tareas) {
    if (!porAct.has(t.actividad)) porAct.set(t.actividad, []);
    porAct.get(t.actividad).push(t);
  }
  porAct.forEach((ts, act) => {
    actividades.push({
      actividad: act,
      uds: ts.reduce((s, t) => s + t.uds, 0),
      tareasWms: ts.map(t => t.taskWms),
      tareas: ts,
      productividad: ts.length === 1 ? ts[0].productividad : null,
      horasEquivalentes: ts.reduce((s, t) => s + t.horasEquivalentes, 0),
      peso: ts.reduce((s, t) => s + t.peso, 0),
      horasAsignadas: ts.reduce((s, t) => s + t.horasAsignadas, 0),
      productividadImplicita: null
    });
  });
  const incidencias = (o.incidencias || []).map((i, ix) => Object.assign({
    id: (o.login || 'OTO1') + '|' + fechaISO + '@' + ix,
    seccion: '3. HR TASK CORRECTA',
    horasAfectadas: 0,
    requiereCambio: 'NO',
    tareaOriginal: '20051 ONTIGOLA-ECOM-PICKING',
    propuesta: '20051 ONTIGOLA-ECOM-PICKING',
    wmsTask: 'PICKING SIN PAPEL - PULL & BEAR',
    volumen: 100,
    tipoCoincidencia: 'LOGIN EXACTO',
    cliente: 'PULL&BEAR',
    sapCode: 'SAP1',
    decision: null
  }, i));
  let horasConIncidencia = 0;
  const porId = new Map();
  for (const i of incidencias) {
    const idReg = String(i.id).split('@')[0];
    porId.set(idReg, Math.max(porId.get(idReg) || 0, i.horasAfectadas || 0));
  }
  for (const h of porId.values()) horasConIncidencia += h;
  return {
    key: login + '|' + fechaISO,
    login,
    persona: o.persona || ('PERSONA ' + login),
    fechaOperativa: new Date(fechaISO + 'T00:00:00Z'),
    fechaOperativaISO: fechaISO,
    semana: isoWeekOf(fechaISO),
    mes: fechaISO.slice(0, 7),
    turno,
    turnos: o.turnos || [turno],
    horasFichadas: o.horasFichadas != null ? o.horasFichadas : 8,
    horasAnalizables: o.horasAnalizables != null ? o.horasAnalizables : 8,
    registros: o.registros || [{
      idRegistroHoras: (o.idRegBase || 100) + '',
      hora: o.hora != null ? o.hora : '08:00',
      turno, horas: o.horasAnalizables != null ? o.horasAnalizables : 8,
      hrTask: o.hrTask || '20051 ONTIGOLA-ECOM-PICKING'
    }],
    udsTotales: o.udsTotales != null ? o.udsTotales : tareas.reduce((s, t) => s + t.uds, 0),
    udsSinHoras: o.udsSinHoras || 0,
    horasEquivalentes: o.horasEquivalentes != null ? o.horasEquivalentes : tareas.reduce((s, t) => s + t.horasEquivalentes, 0),
    horasAsignadas: o.horasAsignadas != null ? o.horasAsignadas : 8,
    desviacion: o.desviacion != null ? o.desviacion : 0,
    nActividades: actividades.length,
    actividades,
    modoVolumen: o.modoVolumen !== undefined ? o.modoVolumen : 'LOGIN EXACTO',
    incidencias,
    nIncidencias: incidencias.length,
    horasConIncidencia,
    decision: o.decision || (incidencias.length === 0 ? 'SIN INCIDENCIAS' : 'PENDIENTE'),
    mappingHash: o.mappingHash || 'aaaa1111',
    mappingVersion: o.mappingVersion != null ? o.mappingVersion : null,
    productividades: o.productividades || null,
    taskOverrides: o.taskOverrides || null,
    productivityVersion: o.productivityVersion || null,
    overrideVersion: o.overrideVersion || null,
    appVersion: o.appVersion || '6.2.0',
    sessionId: 'sess-test',
    version: o.version || 1,
    dataFingerprint: o.dataFingerprint || 'fp-' + login + '-' + fechaISO,
    datasetFingerprint: o.dataFingerprint || 'fp-' + login + '-' + fechaISO,
    createdAt: '2026-08-25T20:00:00.000Z',
    updatedAt: '2026-08-25T20:00:00.000Z',
    previousVersions: o.previousVersions || []
  };
}

/* Atajos de secciones del REPORTE. */
const SEC = {
  cambio: '1. CAMBIO HR TASK PROPUESTO',
  varias: '2. VARIAS TASKSPEC CON VOLUMEN',
  correcta: '3. HR TASK CORRECTA',
  sinVol: '4. SIN VOLUMEN',
  sinMap: '5. WMS TASK SIN MAPPING',
  multi: '6. REVISION MANUAL - MULTIPLES HR TASK',
  ambiguoId: '7. REVISION MANUAL - AMBIGUEDAD ID NUMERICO'
};

function incSec(seccion, over) {
  return Object.assign({ seccion }, over || {});
}

globalThis.mkRecord = mkRecord;
globalThis.SEC = SEC;
globalThis.incSec = incSec;
module.exports = { mkRecord, SEC, incSec, isoWeekOf };
