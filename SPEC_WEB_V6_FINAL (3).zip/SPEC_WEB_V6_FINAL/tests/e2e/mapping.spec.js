// FASE 10 (auditoría de certificación) — Mapping E2E completo.
//
// Requisitos del auditor, todos verificados en el navegador real:
//   1. Visualización (tabla con las filas del Mapping.xlsx cargado)
//   2. Búsqueda (mapping-search filtra por texto)
//   3. Filtro (selects de Customer y Actividad)
//   4. Creación (modal + nuevo mapping)
//   5. Edición (modal sobre fila existente)
//   6. Eliminación (con confirm)
//   7. Duplicados (detección y resaltado)
//   8. Ambigüedades (detección y resaltado)
//   9. Audit log (cada operación CRUD deja entrada mapping_create/update/delete
//      con hash chain SHA-256 íntegra)

import { test, expect } from '@playwright/test';
import { resolve } from 'node:path';

const DRIVE = resolve(process.cwd(), 'audit-ref', 'drive');
const FILES = {
  horas: resolve(DRIVE, 'HORA SIN VOLUMEN.xlsx'),
  volumen: resolve(DRIVE, 'VOLUMEN.xlsx'),
  volSinHoras: resolve(DRIVE, 'VOL SIN HORAS.xlsx'),
  mapping: resolve(DRIVE, 'Mapping.xlsx')
};
const INPUTS = {
  horas: '#drop-horas input[type=file]',
  volumen: '#drop-volumen input[type=file]',
  volSinHoras: '#drop-volSinHoras input[type=file]',
  mapping: '#drop-mapping input[type=file]'
};

async function setupWithMapping(page) {
  await page.goto('/');
  await page.waitForLoadState('networkidle');
  for (const k of Object.keys(INPUTS)) {
    await page.setInputFiles(INPUTS[k], FILES[k]);
  }
  await page.waitForFunction(
    () => window.SPEC?.STATE?.archivos && Object.keys(window.SPEC.STATE.archivos).length === 4,
    { timeout: 30_000 }
  );
  // Ejecutar análisis (necesario para que initMappingData tenga stats/mappingHash)
  await page.locator('.tab[data-tab="cargaanalizar"]').click();
  await page.locator('#btn-analizar').click();
  await page.waitForFunction(
    () => window.SPEC?.STATE?.reporte && window.SPEC.STATE.reporte.length > 0,
    { timeout: 60_000 }
  );
  // Ir a la pestaña Mapping
  await page.locator('.tab[data-tab="mapping"]').click();
  await page.waitForSelector('#mapping-tbody tr', { timeout: 10_000 });
}

test.describe('FASE 10 — Mapping: E2E completo', () => {
  test('visualización + búsqueda + filtros + CRUD + duplicados + ambigüedades + audit log', async ({ page }) => {
    test.setTimeout(120_000);
    const errors = [];
    page.on('pageerror', (err) => errors.push(err.message));
    page.on('dialog', (dialog) => dialog.accept()); // aceptar confirm de delete

    await setupWithMapping(page);

    // === 1. VISUALIZACIÓN ===
    const initialCount = await page.evaluate(() => window.SPEC.STATE.archivos.mapping[0].workbook ? document.querySelectorAll('#mapping-tbody tr').length : 0);
    const mappingRows = await page.evaluate(() => {
      // initMappingData vuelca UI.mappingCurrent — leer desde el DOM
      const rows = document.querySelectorAll('#mapping-tbody tr');
      return rows.length;
    });
    expect(mappingRows, 'tabla de mapping visible con filas (167 esperadas del Mapping.xlsx)').toBeGreaterThan(100);

    const statsCount = await page.locator('#mapping-count').textContent();
    expect(statsCount).toContain('167 entradas');

    // Hash del mapping visible
    const hashText = await page.locator('#mapping-hash').textContent();
    expect(hashText, 'badge de hash del mapping presente').toContain('Hash:');

    // === 2. BÚSQUEDA ===
    // Buscar por el TASK_WMS de la primera fila (selectivo: 1 coincidencia
    // exacta — el SAP_CODE ES146L aparece en todas las filas, es el código de planta)
    const firstTaskWms = await page.evaluate(() => {
      const tr = document.querySelector('#mapping-tbody tr');
      return tr ? tr.querySelectorAll('td')[6].textContent.trim() : '';
    });
    expect(firstTaskWms.length, 'primera fila tiene TASK_WMS').toBeGreaterThan(0);

    await page.fill('#mapping-search', firstTaskWms);
    await page.waitForTimeout(300); // debounce de render
    const filteredRows = await page.evaluate(() => document.querySelectorAll('#mapping-tbody tr').length);
    expect(filteredRows, `la búsqueda por "${firstTaskWms}" reduce las filas a 1`).toBe(1);
    expect(filteredRows).toBeLessThan(mappingRows);
    await page.fill('#mapping-search', '');
    await page.waitForTimeout(300);

    // Búsqueda sin resultados
    await page.fill('#mapping-search', 'NO_EXISTE_EN_MAPPING_XXXX');
    await page.waitForTimeout(300);
    const noResults = await page.locator('#mapping-tbody').textContent();
    expect(noResults, 'búsqueda sin resultados muestra estado vacío').toContain('No hay');
    await page.fill('#mapping-search', '');
    await page.waitForTimeout(300);

    // === 3. FILTRO por Customer ===
    const customerOptions = await page.evaluate(() => {
      const sel = document.getElementById('mapping-filter-customer');
      return Array.from(sel.options).map(o => o.value).filter(v => v !== '');
    });
    expect(customerOptions.length, 'select de Customers poblado').toBeGreaterThan(0);
    await page.selectOption('#mapping-filter-customer', customerOptions[0]);
    await page.waitForTimeout(300);
    const custFiltered = await page.evaluate(() => document.querySelectorAll('#mapping-tbody tr').length);
    expect(custFiltered, 'filtro por customer muestra filas (>0)').toBeGreaterThan(0);
    expect(custFiltered, 'filtro por customer reduce filas').toBeLessThan(mappingRows);
    await page.selectOption('#mapping-filter-customer', '');
    await page.waitForTimeout(300);

    // === 4. CREACIÓN ===
    const auditBefore = await page.evaluate(() => window.SPEC.STATE.auditLog.length);
    await page.click('#mapping-new');
    await page.waitForSelector('#mapping-edit-modal[style*="flex"]', { timeout: 5_000 });
    await page.fill('#mapping-edit-sap', 'SAP_TEST_999');
    await page.fill('#mapping-edit-wmsdc', 'DC_TEST');
    await page.fill('#mapping-edit-customer', 'CUSTOMER_TEST');
    await page.fill('#mapping-edit-department', 'DEP_TEST');
    await page.fill('#mapping-edit-activity', 'ACT_TEST');
    await page.fill('#mapping-edit-subactivity', 'SUB_TEST');
    await page.fill('#mapping-edit-taskwms', 'TAREA_WMS_TEST_999');
    await page.fill('#mapping-edit-taskspec', 'TAREA_SPEC_TEST_999');
    await page.click('#mapping-edit-form button[type="submit"]');
    await page.waitForTimeout(500);

    const countAfterCreate = await page.evaluate(() => document.querySelectorAll('#mapping-tbody tr').length);
    expect(countAfterCreate, 'crear mapping añade una fila').toBe(mappingRows + 1);
    const auditAfterCreate = await page.evaluate(() => window.SPEC.STATE.auditLog.length);
    expect(auditAfterCreate, 'crear deja entrada mapping_create en audit log').toBe(auditBefore + 1);
    const createAction = await page.evaluate(() => window.SPEC.STATE.auditLog[window.SPEC.STATE.auditLog.length - 1].action);
    expect(createAction).toBe('mapping_create');

    // === 5. EDICIÓN ===
    // Buscar la fila recién creada y editarla
    await page.fill('#mapping-search', 'TAREA_WMS_TEST_999');
    await page.waitForTimeout(300);
    await page.locator('.btn-mapping-edit').first().click();
    await page.waitForSelector('#mapping-edit-modal[style*="flex"]', { timeout: 5_000 });
    const wmsValue = await page.inputValue('#mapping-edit-taskwms');
    expect(wmsValue, 'el modal de edición precarga la fila correcta').toBe('TAREA_WMS_TEST_999');
    await page.fill('#mapping-edit-taskspec', 'TAREA_SPEC_EDITADA_888');
    await page.click('#mapping-edit-form button[type="submit"]');
    await page.waitForTimeout(500);

    const editedCell = await page.evaluate(() => {
      const rows = document.querySelectorAll('#mapping-tbody tr');
      return rows[0] ? rows[0].querySelectorAll('td')[7].textContent.trim() : '';
    });
    expect(editedCell, 'la edición cambia el TASK_SPEC en la tabla').toBe('TAREA_SPEC_EDITADA_888');
    const auditAfterEdit = await page.evaluate(() => window.SPEC.STATE.auditLog.length);
    expect(auditAfterEdit, 'editar deja entrada mapping_update').toBe(auditAfterCreate + 1);
    const updateAction = await page.evaluate(() => window.SPEC.STATE.auditLog[window.SPEC.STATE.auditLog.length - 1].action);
    expect(updateAction).toBe('mapping_update');

    // === 6. ELIMINACIÓN ===
    await page.fill('#mapping-search', 'TAREA_WMS_TEST_999');
    await page.waitForTimeout(300);
    const rowsBeforeDelete = await page.evaluate(() => document.querySelectorAll('#mapping-tbody tr').length);
    expect(rowsBeforeDelete, 'la fila de test existe antes de borrar').toBe(1);
    await page.locator('.btn-mapping-delete').first().click();
    await page.waitForTimeout(500);
    await page.fill('#mapping-search', '');
    await page.waitForTimeout(300);
    const countAfterDelete = await page.evaluate(() => document.querySelectorAll('#mapping-tbody tr').length);
    expect(countAfterDelete, 'eliminar mapping quita la fila').toBe(mappingRows);
    const auditAfterDelete = await page.evaluate(() => window.SPEC.STATE.auditLog.length);
    expect(auditAfterDelete, 'eliminar deja entrada mapping_delete').toBe(auditAfterEdit + 1);
    const deleteAction = await page.evaluate(() => window.SPEC.STATE.auditLog[window.SPEC.STATE.auditLog.length - 1].action);
    expect(deleteAction).toBe('mapping_delete');

    // === 7/8. DUPLICADOS y AMBIGÜEDADES ===
    // Crear un duplicado exacto de la primera fila para disparar la detección
    const firstRowData = await page.evaluate(() => {
      const tr = document.querySelector('#mapping-tbody tr');
      const tds = tr.querySelectorAll('td');
      return {
        sap: tds[0].textContent.trim(),
        customer: tds[2].textContent.trim(),
        activity: tds[4].textContent.trim(),
        taskwms: tds[6].textContent.trim(),
        taskspec: tds[7].textContent.trim()
      };
    });
    await page.click('#mapping-new');
    await page.waitForSelector('#mapping-edit-modal[style*="flex"]', { timeout: 5_000 });
    await page.fill('#mapping-edit-sap', firstRowData.sap);
    await page.fill('#mapping-edit-customer', firstRowData.customer);
    await page.fill('#mapping-edit-activity', firstRowData.activity);
    await page.fill('#mapping-edit-taskwms', firstRowData.taskwms);
    await page.fill('#mapping-edit-taskspec', 'SPEC_DUPLICADO_DISTINTO');
    await page.click('#mapping-edit-form button[type="submit"]');
    await page.waitForTimeout(500);

    const dupBadge = await page.locator('#mapping-duplicates').textContent();
    expect(parseInt(dupBadge, 10), 'badge de duplicados detecta el duplicado creado').toBeGreaterThanOrEqual(1);

    // Botón de resaltado de duplicados
    await page.click('#mapping-detect-duplicates');
    await page.waitForTimeout(300);
    const highlightedDups = await page.evaluate(() => document.querySelectorAll('#mapping-tbody tr.duplicate').length);
    expect(highlightedDups, 'las filas duplicadas quedan resaltadas (clase .duplicate)').toBeGreaterThanOrEqual(2);

    // Botón de ambigüedades
    await page.click('#mapping-detect-ambiguities');
    await page.waitForTimeout(300);
    const ambBadge = await page.locator('#mapping-ambiguities').textContent();
    expect(parseInt(ambBadge, 10), 'badge de ambigüedades >= 1').toBeGreaterThanOrEqual(1);

    // Limpiar el duplicado para restaurar el estado
    await page.fill('#mapping-search', 'SPEC_DUPLICADO_DISTINTO');
    await page.waitForTimeout(300);
    await page.locator('.btn-mapping-delete').first().click();
    await page.waitForTimeout(500);
    await page.fill('#mapping-search', '');
    await page.waitForTimeout(300);

    // === 9. AUDIT LOG: integridad de la cadena tras todo el CRUD ===
    const integrity = await page.evaluate(() => window.SPEC.verificarAuditLogChain(window.SPEC.STATE.auditLog));
    expect(integrity.ok, `hash chain del audit log íntegra tras CRUD de mapping: ${JSON.stringify(integrity)}`).toBe(true);

    const mappingEntries = await page.evaluate(() =>
      window.SPEC.STATE.auditLog.filter(e => String(e.action).startsWith('mapping_')).map(e => e.action)
    );
    expect(mappingEntries, 'el audit log registra create, update, delete de mapping').toEqual(
      expect.arrayContaining(['mapping_create', 'mapping_update', 'mapping_delete'])
    );

    expect(errors, `pageerrors durante el flujo: ${errors.join('\n')}`).toEqual([]);
  });
});
