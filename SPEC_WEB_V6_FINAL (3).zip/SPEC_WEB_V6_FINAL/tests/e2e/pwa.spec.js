// FASE 14 (auditoría de certificación) — PWA E2E.
//
// Verifica físicamente (no por documentación):
//   1. manifest.json se sirve y es válido (parseable, campos clave v6.0)
//   2. sw.js existe y el Service Worker se REGISTRA de verdad (sw-register.js)
//   3. La caché precarga los recursos core (spec-web-v6)
//   4. La app funciona OFFLINE tras la primera carga (cache-first)
//   5. Contexto seguro: http://127.0.0.1 cuenta como secure context para SW

import { test, expect } from '@playwright/test';

test.describe('FASE 14 — PWA: manifest + Service Worker + offline', () => {
  test('manifest.json se sirve y es un manifest PWA válido', async ({ request }) => {
    const resp = await request.get('/manifest.json');
    expect(resp.status(), 'manifest.json accesible').toBe(200);
    const manifest = await resp.json();
    expect(manifest.name).toContain('SPEC Web v6.2');
    expect(manifest.version).toBe('6.2.0');
    expect(manifest.start_url).toBe('./index.html');
    expect(manifest.display).toBe('standalone');
    expect(Array.isArray(manifest.icons)).toBe(true);
    expect(manifest.icons.length).toBeGreaterThanOrEqual(1);
    expect(manifest.icons[0].src).toContain('logo_idl.png');
    // El icono referenciado debe servirse
    const iconResp = await request.get('/' + manifest.icons[0].src.replace(/^\.\//, ''));
    expect(iconResp.status(), 'icono del manifest accesible').toBe(200);
  });

  test('index.html referencia el manifest y registra el Service Worker', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    // <link rel="manifest"> presente
    const manifestLink = await page.evaluate(() => {
      const l = document.querySelector('link[rel="manifest"]');
      return l ? l.getAttribute('href') : null;
    });
    expect(manifestLink).toBe('manifest.json');

    // El Service Worker queda ACTIVO (sw-register.js lo registró)
    const swState = await page.waitForFunction(
      async () => {
        if (!('serviceWorker' in navigator)) return 'unsupported';
        const reg = await navigator.serviceWorker.getRegistration();
        if (!reg) return 'no-registration';
        return reg.active ? 'active' : (reg.installing ? 'installing' : (reg.waiting ? 'waiting' : 'none'));
      },
      { timeout: 15_000 }
    );
    const state = await swState.jsonValue();
    expect(state, 'Service Worker registrado y activo').toBe('active');
  });

  test('la caché precarga los recursos core de la app', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    // Esperar a que el SW active y llene la caché
    await page.waitForFunction(
      async () => {
        if (!('caches' in window)) return false;
        const keys = await caches.keys();
        if (!keys.some(k => k.startsWith('spec-web-v'))) return false;
        // Al menos index.html + app.js cacheados
        const all = await caches.open(keys.find(k => k.startsWith('spec-web-v')));
        const hasIndex = await all.match('./index.html');
        const hasApp = await all.match('./app.js');
        return !!(hasIndex && hasApp);
      },
      { timeout: 20_000 }
    );

    const cacheInfo = await page.evaluate(async () => {
      const keys = await caches.keys();
      const name = keys.find(k => k.startsWith('spec-web-v'));
      const cache = await caches.open(name);
      const reqs = await cache.keys();
      return { name, count: reqs.length, urls: reqs.map(r => new URL(r.url).pathname) };
    });
    expect(cacheInfo.name, 'caché con el nombre spec-web-v6-1-1').toBe('spec-web-v6-2');
    expect(cacheInfo.count, 'al menos los 10 recursos core cacheados').toBeGreaterThanOrEqual(10);
    for (const core of ['/index.html', '/app.js', '/ui.js', '/worker.js', '/xlsx.full.min.js', '/styles.css', '/manifest.json']) {
      expect(cacheInfo.urls, `recurso core ${core} en caché`).toContain(core);
    }
  });

  test('la app funciona OFFLINE (contexto sin red)', async ({ browser }) => {
    const context = await browser.newContext();
    const page = await context.newPage();
    const errors = [];
    page.on('pageerror', (err) => errors.push(err.message));

    // Primera carga (online) — permite instalar el SW y la caché
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    await page.waitForFunction(
      async () => {
        if (!('serviceWorker' in navigator)) return false;
        const reg = await navigator.serviceWorker.getRegistration();
        return !!(reg && reg.active);
      },
      { timeout: 20_000 }
    );

    // Cortar la red y recargar — todo debe salir de la caché
    await context.setOffline(true);
    const resp = await page.goto('/', { waitUntil: 'domcontentloaded' });
    expect(resp, 'respuesta offline obtenida de la caché').not.toBe(null);
    expect(resp.status(), 'index.html servido desde caché (200)').toBe(200);

    const title = await page.title();
    expect(title).toContain('SPEC');

    // El DOM es funcional: cabecera con v6.0 y pestañas de navegación
    const badge = await page.textContent('.version-badge');
    expect(badge.trim()).toBe('v6.2');
    const tabs = await page.locator('.tab').count();
    expect(tabs, 'las pestañas de navegación renderizadas offline').toBeGreaterThanOrEqual(6);

    // XLSX embebido disponible (script cargado desde caché)
    const xlsxOk = await page.evaluate(() => typeof window.XLSX === 'object' && typeof window.XLSX.read === 'function');
    expect(xlsxOk, 'SheetJS cargado offline desde caché').toBe(true);

    // SPEC global definido (app.js ejecutado)
    const specOk = await page.evaluate(() => typeof window.SPEC === 'object' && typeof window.SPEC.analizarYConciliar === 'function');
    expect(specOk, 'SPEC global disponible offline').toBe(true);

    const offlineErrors = errors.filter(e => !e.includes('ServiceWorker') && !e.includes('Failed to load resource'));
    expect(offlineErrors, `pageerrors offline: ${offlineErrors.join('\n')}`).toEqual([]);

    await context.setOffline(false);
    await context.close();
  });
});
