// E2E tests v6.2 — MÓDULO DE ESTADÍSTICA AVANZADA E INTELIGENCIA OPERATIVA.
// Los 14 escenarios obligatorios (spec §59):
//   E2E 1:  Patrones con histórico vacío
//   E2E 2:  Cargar un día → histórico + KPIs
//   E2E 3:  Cargar segundo día → acumulación SIN duplicados
//   E2E 4:  Cerrar y abrir → histórico conservado
//   E2E 5:  Ranking de personas (semáforo + perfil drill-down)
//   E2E 6:  Ranking de TASK_WMS (imputación a la tarea afectada)
//   E2E 7:  Ranking de actividades (+ OTRA visible)
//   E2E 8:  Matriz de confusiones + errores recurrentes
//   E2E 9:  Gráfico de evolución (series + media móvil)
//   E2E 10: Comparación de periodos (mejoran / empeoran)
//   E2E 11: Alertas deterministas
//   E2E 12: Cambio de mapping SIN modificar el histórico anterior (versiones)
//   E2E 13: Override por TASK_WMS → nueva versión trazable
//   E2E 14: Filtros combinados

import { test, expect } from '@playwright/test';
import { resolve } from 'node:path';

const PAT = resolve(process.cwd(), 'test-data', 'patrones');
const FILES = {
  dia1Horas: resolve(PAT, 'DIA1_HORAS.xlsx'),
  dia1Vol: resolve(PAT, 'DIA1_VOLUMEN.xlsx'),
  dia1Vsh: resolve(PAT, 'DIA1_VSH.xlsx'),
  dia2Horas: resolve(PAT, 'DIA2_HORAS.xlsx'),
  dia2Vol: resolve(PAT, 'DIA2_VOLUMEN.xlsx'),
  dia2Vsh: resolve(PAT, 'DIA2_VSH.xlsx'),
  mapping: resolve(PAT, 'Mapping_patrones.xlsx'),
  mappingV2: resolve(PAT, 'Mapping_patrones_v2.xlsx')
};

async function limpiarStorage(page) {
  await page.evaluate(async () => {
    try { localStorage.clear(); } catch (e) { /* noop */ }
    for (const db of ['spec_history_db', 'spec_decisions_db']) {
      await new Promise(res => {
        const done = () => res();
        if (typeof indexedDB === 'undefined') { done(); return; }
        const req = indexedDB.deleteDatabase(db);
        req.onsuccess = req.onerror = req.onblocked = done;
      });
    }
  });
}

/* Carga los archivos indicados, pulsa ANALIZAR y espera al post-procesado. */
async function cargarYAnalizar(page, files) {
  await page.goto('/');
  await page.waitForLoadState('networkidle');
  await limpiarStorage(page);
  await page.reload();
  await page.waitForLoadState('networkidle');
  await page.setInputFiles('#drop-unified input[type=file]', files);
  await page.waitForFunction(() => {
    const a = window.SPEC?.STATE?.archivos;
    return a && ['horas', 'volumen', 'volSinHoras', 'mapping'].every(k => Array.isArray(a[k]) && a[k].length > 0);
  }, null, { timeout: 30000 });
  await page.click('#btn-analizar');
  await page.waitForFunction(() => window.SPEC?.STATE?.reporte && window.SPEC.STATE.reporte.length > 0, null, { timeout: 60000 });
  await page.waitForFunction(() => window.SPEC?.STATE?.personaDiaRecords && window.SPEC.STATE.personaDiaRecords.length > 0, null, { timeout: 30000 });
  await page.waitForTimeout(500); // persistencia encolada
}

const TODOS = [FILES.dia1Horas, FILES.dia1Vol, FILES.dia1Vsh, FILES.dia2Horas, FILES.dia2Vol, FILES.dia2Vsh, FILES.mapping];

async function irAPatrones(page) {
  await page.click('.tab[data-tab="patrones"]');
  await page.waitForSelector('#patrones-view-resumen .kpi-card', { timeout: 20000 });
  await page.waitForTimeout(400); // primer render + memo
}

test.describe.serial('v6.2 — Patrones: estadística avanzada e inteligencia operativa', () => {

  test('E2E 1: Patrones con histórico vacío muestra estado vacío', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    await limpiarStorage(page);
    await page.reload();
    await page.waitForLoadState('networkidle');
    await page.click('.tab[data-tab="patrones"]');
    await page.waitForTimeout(500);
    const resumen = await page.textContent('#patrones-view-resumen');
    expect(resumen).toContain('No hay registros diarios todavía');
    // Las 8 vistas existen y quedan en estado vacío
    for (const id of ['personas', 'tareas', 'actividades', 'errores', 'evolucion', 'pareto', 'calidad']) {
      const v = await page.textContent('#patrones-view-' + (id === 'evolucion' ? 'evolucion' : id));
      expect(v).toBeTruthy();
    }
    const vistas = await page.evaluate(() => document.querySelectorAll('.pv-tab').length);
    expect(vistas).toBe(8);
  });

  test('E2E 2: cargar un día → histórico + KPIs del resumen', async ({ page }) => {
    await cargarYAnalizar(page, [FILES.dia1Horas, FILES.dia1Vol, FILES.dia1Vsh, FILES.mapping]);
    const n = await page.evaluate(async () => (await window.cargarTodosRecords()).length);
    expect(n).toBe(14); // RECUR 4 + MEJORA 3 + EMPEORA 3 + NOCTURNA 1 + SINHORA 1 + OTRA 1 + SINMAPEO 1
    await irAPatrones(page);
    const kpis = await page.textContent('#patrones-view-resumen');
    expect(kpis).toContain('Personas analizadas');
    expect(kpis).toContain('Días analizados');
    // 4 fechas operativas en la mitad A: 25-28/08
    expect(kpis).toContain('4');
    // Evolución (bloque §4): comparación de mitades visible
    expect(kpis).toContain('Evolución');
  });

  test('E2E 3: cargar segundo día → acumulación SIN duplicados', async ({ page }) => {
    await cargarYAnalizar(page, [FILES.dia1Horas, FILES.dia1Vol, FILES.dia1Vsh, FILES.mapping]);
    // Segundo día: recargar TODO (día 1 + día 2) y volver a analizar
    await page.click('.tab[data-tab="cargaanalizar"]');
    await page.setInputFiles('#drop-unified input[type=file]', TODOS);
    await page.waitForFunction(() => {
      const a = window.SPEC?.STATE?.archivos;
      return a && a.horas.length === 2 && a.volumen.length === 2;
    }, null, { timeout: 30000 });
    await page.click('#btn-analizar');
    await page.waitForFunction(() => window.SPEC?.STATE?.personaDiaRecords && window.SPEC.STATE.personaDiaRecords.length === 21, null, { timeout: 60000 });
    await page.waitForTimeout(600);
    const records = await page.evaluate(async () => await window.cargarTodosRecords());
    expect(records.length).toBe(21); // 14 + 7 nuevos, sin duplicados
    const keys = new Set(records.map(r => r.key));
    expect(keys.size).toBe(21);
    const dias = new Set(records.map(r => r.fechaOperativaISO));
    expect(Array.from(dias).sort()).toEqual(['2026-08-25', '2026-08-26', '2026-08-27', '2026-08-28', '2026-09-01', '2026-09-02', '2026-09-03']);
  });

  test('E2E 4: cerrar y abrir la aplicación → histórico conservado', async ({ page }) => {
    await cargarYAnalizar(page, TODOS);
    await page.close();
    const page2 = await page.context().newPage();
    await page2.goto('/');
    await page2.waitForLoadState('networkidle');
    await page2.click('.tab[data-tab="patrones"]');
    await page2.waitForSelector('#patrones-view-resumen .kpi-card', { timeout: 20000 });
    await page2.waitForTimeout(600);
    const n = await page2.evaluate(async () => (await window.cargarTodosRecords()).length);
    expect(n).toBe(21); // sobrevive sin reprocesar
    const kpis = await page2.textContent('#patrones-view-resumen');
    expect(kpis).toContain('Personas analizadas');
    await page2.close();
  });

  test('E2E 5: ranking de personas con semáforo, recurrencia y perfil (drill-down)', async ({ page }) => {
    await cargarYAnalizar(page, TODOS);
    await irAPatrones(page);
    await page.click('#pv-personas');
    await page.waitForSelector('#patrones-personas-table tbody tr', { timeout: 10000 });
    const filas = await page.evaluate(() =>
      Array.from(document.querySelectorAll('#patrones-personas-table tbody tr'))
        .map(tr => Array.from(tr.cells).map(c => c.textContent.trim()))
    );
    expect(filas.length).toBe(7);
    const recur = filas.find(f => f[0].includes('RECUR RACHA TEST'));
    expect(recur, 'RECUR aparece en el ranking').toBeTruthy();
    expect(recur[1]).toBe('5');        // días
    expect(recur[2]).toBe('5');        // días con error
    expect(recur[3]).toContain('100'); // % días con error
    expect(recur[9]).toBe('5');        // recurrencia (días)
    expect(recur[10]).toBe('4');      // racha máxima
    expect(recur[12]).toContain('CRÍTICO');
    const mejora = filas.find(f => f[0].includes('MEJORA PATRONES'));
    // MEJORA: 3/6 días con error = 50% → ATENCIÓN (umbrales por defecto)
    expect(mejora[12]).toContain('ATENCIÓN');
    // Drill-down: clic en RECUR → perfil histórico
    await page.click('#patrones-personas-table tbody tr:first-child');
    await page.waitForSelector('#patrones-profile:not([hidden])', { timeout: 5000 });
    const perfil = await page.textContent('#patrones-profile');
    expect(perfil).toContain('Perfil histórico');
    expect(perfil).toContain('RECUR RACHA TEST');
    expect(perfil).toContain('Racha máxima');
    expect(perfil).toContain('Errores recurrentes');
  });

  test('E2E 6: ranking de TASK_WMS con imputación SOLO a la tarea afectada', async ({ page }) => {
    await cargarYAnalizar(page, TODOS);
    await irAPatrones(page);
    await page.click('#pv-tareas');
    await page.waitForSelector('#patrones-tareas-table tbody tr', { timeout: 10000 });
    const filas = await page.evaluate(() =>
      Array.from(document.querySelectorAll('#patrones-tareas-table tbody tr'))
        .map(tr => Array.from(tr.cells).map(c => c.textContent.trim()))
    );
    // Los nombres de tarea llegan normalizados a MAYÚSCULAS (fx_NormalizaTexto)
    const sinPapel = filas.find(f => f[0].toUpperCase().includes('PICKING SIN PAPEL'));
    expect(sinPapel, 'la tarea problemática aparece').toBeTruthy();
    expect(sinPapel[1]).toBe('PICKING MANUAL');
    expect(sinPapel[2]).toBe('12');   // oportunidades
    expect(sinPapel[3]).toBe('12');   // errores imputados
    expect(sinPapel[4]).toContain('100'); // % error
    // La tarea correcta NO recibe errores imputados del día de otra tarea (§11):
    const ecom = filas.find(f => f[0].toUpperCase().includes('PICKING ECOMMERCE'));
    expect(ecom[3]).toBe('0');
    // Tarea OTRA visible con su volumen:
    const otra = filas.find(f => f[0].toUpperCase().includes('REPARTO A TIENDA'));
    expect(otra[1]).toBe('OTRA');
    expect(otra[8]).toContain('300'); // uds
  });

  test('E2E 7: ranking de actividades con OTRA siempre visible', async ({ page }) => {
    await cargarYAnalizar(page, TODOS);
    await irAPatrones(page);
    await page.click('#pv-actividades');
    await page.waitForSelector('#patrones-actividades-table tbody tr', { timeout: 10000 });
    const html = await page.textContent('#patrones-view-actividades');
    expect(html).toContain('PICKING MANUAL'); // la nocturna imputa a la tarea afectada (picking)
    expect(html).toContain('OTRA');
    expect(html).toContain('Turnos'); // sección de turnos §27
    expect(html).toContain('SIN HORA'); // nunca repartido
    expect(html).toContain('Análisis de OTRA');
    expect(html).toContain('REPARTO A TIENDA AGV - BERSHKA'); // volumen OTRA visible (§29)
    expect(html).toContain('TAREA INVENTADA SIN MAPPING - TEST'); // tarea sin clasificar visible
  });

  test('E2E 8: matriz de confusiones + errores recurrentes con persistencia', async ({ page }) => {
    await cargarYAnalizar(page, TODOS);
    await irAPatrones(page);
    await page.click('#pv-errores');
    await page.waitForSelector('#patrones-view-errores', { timeout: 10000 });
    const html = await page.textContent('#patrones-view-errores');
    // Matriz fichada → correcta (la confusión diseñada 20051 → 20052)
    expect(html).toContain('Matriz tarea fichada');
    expect(html).toContain('20051 ONTIGOLA-ECOM-PICKING');
    expect(html).toContain('20052 ONTIGOLA-ECOM-PICKING-SIN-PAPEL');
    // Recurrentes: RECUR repite la confusión en 5 días → HABITUAL
    expect(html).toContain('Errores recurrentes');
    expect(html).toContain('RECUR RACHA TEST');
    expect(html).toContain('HABITUAL');
    // Heatmap presente (tabla SIEMPRE disponible además del mapa)
    const heat = await page.evaluate(() => document.querySelectorAll('#patrones-view-errores svg').length);
    expect(heat).toBeGreaterThanOrEqual(1);
  });

  test('E2E 9: gráfico de evolución con series y media móvil', async ({ page }) => {
    await cargarYAnalizar(page, TODOS);
    await irAPatrones(page);
    await page.click('#pv-evolucion');
    await page.waitForTimeout(300);
    const ev = await page.textContent('#patrones-view-evolucion');
    expect(ev).toContain('Evolución diaria');
    const svgs = await page.evaluate(() => document.querySelectorAll('#patrones-evolucion svg').length);
    expect(svgs).toBeGreaterThanOrEqual(3); // % error + incidencias + horas
    // Desglose diario: 7 fechas
    const html = await page.evaluate(() => document.querySelector('#patrones-evolucion').innerHTML);
    expect(html).toContain('2026-08-25');
    expect(html).toContain('2026-09-03');
    // Granularidad semanal
    await page.selectOption('#evol-granularidad', 'semana');
    await page.waitForTimeout(300);
    const htmlSem = await page.evaluate(() => document.querySelector('#patrones-evolucion').innerHTML);
    expect(htmlSem).toContain('2026-W');
  });

  test('E2E 10: comparación de periodos con mejora y empeoramiento', async ({ page }) => {
    await cargarYAnalizar(page, TODOS);
    await irAPatrones(page);
    await page.click('#pv-evolucion');
    await page.waitForSelector('#patrones-periodos', { timeout: 10000 });
    const per = await page.textContent('#patrones-periodos');
    expect(per).toContain('Comparación de periodos');
    expect(per).toContain('MEJORA PATRONES');
    expect(per).toContain('EMPEORA PATRONES');
    // El resumen refleja el Δ en pp
    const resumen = await page.textContent('#patrones-view-resumen');
    expect(resumen).toContain('pp');
  });

  test('E2E 11: alertas deterministas (racha, confusión repetida, OTRA con volumen)', async ({ page }) => {
    await cargarYAnalizar(page, TODOS);
    await irAPatrones(page);
    const focos = await page.textContent('#patrones-resumen-focos');
    expect(focos).toContain('Dónde poner el ojo');
    expect(focos).toContain('Top 5 prioridades');
    // A2: racha de RECUR
    expect(focos).toContain('RECUR RACHA TEST lleva 4 días consecutivos con errores');
    // A6: la confusión 20051 → 20052 repetida
    expect(focos).toContain('La confusión');
    expect(focos).toContain('se repite');
    // A5: tarea OTRA con volumen relevante
    expect(focos).toContain('sin clasificación productiva');
    // El TOP 5 muestra el desglose (§6: entender por qué es ALTA)
    expect(focos).toContain('Frecuencia');
    expect(focos).toContain('PRIORIDAD');
  });

  test('E2E 12: cambio de mapping SIN modificar el histórico anterior (versiones trazables)', async ({ page }) => {
    await cargarYAnalizar(page, TODOS);
    const hashV1 = await page.evaluate(() => (window.UI.mappingMeta && window.UI.mappingMeta.hash) || null);
    expect(hashV1).toBeTruthy();
    // Importar mapping v2 y aceptar el diálogo
    await page.setInputFiles('#mapping-update-input', FILES.mappingV2);
    await page.waitForSelector('#mcm-confirm', { timeout: 10000 });
    await page.click('#mcm-confirm');
    await page.waitForTimeout(500);
    // Reprocesar con el nuevo mapping (volver a la pestaña de carga primero)
    await page.click('.tab[data-tab="cargaanalizar"]');
    await page.click('#btn-analizar');
    await page.waitForFunction(() => window.SPEC?.STATE?.personaDiaRecords && window.SPEC.STATE.personaDiaRecords.length === 21, null, { timeout: 60000 });
    await page.waitForTimeout(800);
    const records = await page.evaluate(async () => await window.cargarTodosRecords());
    expect(records.length).toBe(21);
    const hashV2 = await page.evaluate(() => (window.UI.mappingMeta && window.UI.mappingMeta.hash) || null);
    expect(hashV2).not.toBe(hashV1);
    // El registro de RECUR (propuestas afectadas por el cambio de TASK_SPEC)
    // conserva el NÚCLEO anterior en previousVersions con su hash original:
    const recur25 = records.find(r => r.key === 'OTO9301|2026-08-25');
    expect(recur25.version).toBe(2);
    expect(recur25.previousVersions.length).toBe(1);
    expect(recur25.previousVersions[0].mappingHash).toBe(hashV1);
    expect(recur25.mappingHash).toBe(hashV2);
    // El registro CORRECTO no afectado por el cambio no genera versión espuria:
    const mejora0309 = records.find(r => r.key === 'OTO9302|2026-09-03');
    expect(mejora0309.version).toBe(1);
    expect(mejora0309.previousVersions.length).toBe(0);
  });

  test('E2E 13: override por TASK_WMS → el motor lo usa y el histórico versiona', async ({ page }) => {
    await cargarYAnalizar(page, TODOS);
    // Override: Reparto a tienda AGV - Bershka → PICKING AGV 150
    await page.click('.tab[data-tab="revisar"]');
    await page.evaluate(() => { document.getElementById('productividades-editor').open = true; });
    await page.fill('#task-prod-search', 'Reparto a tienda AGV - Bershka');
    await page.selectOption('#task-prod-actividad', 'PICKING AGV');
    await page.fill('#task-prod-value', '150');
    await page.click('#btn-task-prod-save');
    await page.waitForTimeout(1200);
    // El record de OTRA VOLUMEN TEST cambia de versión (fingerprint distinto):
    const records = await page.evaluate(async () => await window.cargarTodosRecords());
    const otra = records.find(r => r.key === 'OTO9306|2026-08-25');
    expect(otra.version).toBe(2);
    expect(otra.previousVersions.length).toBe(1);
    // La clasificación nueva entra en el reparto:
    const act = otra.actividades.map(a => a.actividad);
    expect(act).toContain('PICKING AGV');
    // Los demás registros no se versionan espuriamente:
    const sinCambios = records.filter(r => r.key !== 'OTO9306|2026-08-25' && r.version > 1);
    expect(sinCambios.length).toBe(0);
  });

  test('E2E 14: filtros combinados (turno + persona + actividad)', async ({ page }) => {
    await cargarYAnalizar(page, TODOS);
    await irAPatrones(page);
    // Turno NOCHE: solo NOCTURNA (op 25/08)
    await page.selectOption('#patrones-filter-turno', 'NOCHE');
    await page.waitForTimeout(400);
    let kpis = await page.textContent('#patrones-view-resumen');
    expect(kpis).toContain('1'); // 1 persona-día
    await page.selectOption('#patrones-filter-turno', '');
    // Persona RECUR → 5 registros propios
    await page.fill('#patrones-filter-persona', 'RECUR');
    await page.waitForTimeout(400);
    kpis = await page.textContent('#patrones-view-resumen');
    expect(kpis).toContain('5');
    // Combinado: persona EMPEORA + turno NOCHE → 0
    await page.fill('#patrones-filter-persona', 'EMPEORA');
    await page.selectOption('#patrones-filter-turno', 'NOCHE');
    await page.waitForTimeout(400);
    await page.click('#pv-personas');
    await page.waitForTimeout(300);
    const vacio = await page.textContent('#patrones-view-personas');
    expect(vacio).toContain('Sin registros');
    // Actividad OTRA → 1 registro (OTO9306)
    await page.selectOption('#patrones-filter-turno', '');
    await page.fill('#patrones-filter-persona', '');
    await page.selectOption('#patrones-filter-actividad', 'OTRA');
    await page.waitForTimeout(400);
    kpis = await page.textContent('#patrones-view-resumen');
    expect(kpis).toContain('1');
    await page.selectOption('#patrones-filter-actividad', '');
    await page.waitForTimeout(300);
  });
});
