// E2E tests v6.1 — MEJORAS: turnos, carga unificada, mapping persistente,
// revisión unificada persona/día, reparto de tiempos, undo real, patrones.
//
// Los 8 escenarios OBLIGATORIOS definidos por el usuario:
//   E2E 1: Cargar archivos → detectar automáticamente → Analizar → resultados
//   E2E 2: Importar mapping → cerrar → abrir → mapping recuperado
//   E2E 3: Cambiar mapping → nuevo hash → procesar → histórico con nuevo hash
//   E2E 4: Persona con 2 WMS tasks → UNA revisión
//   E2E 5: Persona con 3 WMS tasks → reparto correcto del tiempo
//   E2E 6: Aceptar incidencia → undo → estado restaurado
//   E2E 7: Procesar dos días → cerrar → abrir → Patrones conserva los dos días
//   E2E 8: Filtrar NOCHE y verificar 22:00–06:00

import { test, expect } from '@playwright/test';
import { resolve } from 'node:path';

const DRIVE = resolve(process.cwd(), 'audit-ref', 'drive');
const TURNOS = resolve(process.cwd(), 'test-data', 'turnos');
const FILES = {
  horas: resolve(DRIVE, 'HORA SIN VOLUMEN.xlsx'),
  volumen: resolve(DRIVE, 'VOLUMEN.xlsx'),
  vsh: resolve(DRIVE, 'VOL SIN HORAS.xlsx'),
  mapping: resolve(DRIVE, 'Mapping.xlsx'),
  horasTurnos: resolve(TURNOS, 'HORAS_TURNO.xlsx'),
  volumenTurnos: resolve(TURNOS, 'VOLUMEN_TURNO.xlsx'),
  vshTurnos: resolve(TURNOS, 'VOL_SIN_HORAS_TURNO.xlsx'),
  mappingV2: resolve(TURNOS, 'Mapping_v2.xlsx')
};

async function limpiarStorage(page) {
  await page.evaluate(async () => {
    try { localStorage.clear(); } catch (e) { /* noop */ }
    await new Promise(res => {
      const done = () => res();
      if (typeof indexedDB === 'undefined') { done(); return; }
      const req = indexedDB.deleteDatabase('spec_history_db');
      req.onsuccess = req.onerror = req.onblocked = done;
    });
    await new Promise(res => {
      const done = () => res();
      if (typeof indexedDB === 'undefined') { done(); return; }
      const req = indexedDB.deleteDatabase('spec_decisions_db');
      req.onsuccess = req.onerror = req.onblocked = done;
    });
  });
}

async function cargarYAnalizar(page, files) {
  await page.goto('/');
  await page.waitForLoadState('networkidle');
  await limpiarStorage(page);
  await page.reload();
  await page.waitForLoadState('networkidle');
  await page.setInputFiles('#drop-unified input[type=file]', files);
  await page.waitForFunction(() => {
    const a = window.SPEC?.STATE?.archivos;
    return a && ['horas', 'volumen', 'volSinHoras', 'mapping'].every(k => Array.isArray(a[k]) && a[k].length > 0);
  }, null, { timeout: 30000 });
  await page.click('#btn-analizar');
  await page.waitForFunction(() => window.SPEC?.STATE?.reporte && window.SPEC.STATE.reporte.length > 0, null, { timeout: 60000 });
  // Esperar al post-procesado v6.1 (recompute + persistencia + auto-nav)
  await page.waitForFunction(() => window.SPEC?.STATE?.personaDiaRecords && window.SPEC.STATE.personaDiaRecords.length > 0, null, { timeout: 30000 });
  await page.waitForTimeout(400);
}

/* Espera (sondeo desde Node) a que TODOS los registros históricos de
 * spec_history_db lleven exclusivamente el hash esperado. */
async function esperarHashEnRegistros(page, expected, timeoutMs) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeoutMs) {
    const hashes = await page.evaluate(async () => {
      return await new Promise(res => {
        const req = indexedDB.open('spec_history_db', 1);
        req.onsuccess = e => {
          try {
            const tx = e.target.result.transaction('person_daily_records', 'readonly');
            const r = tx.objectStore('person_daily_records').getAll();
            r.onsuccess = () => res(Array.from(new Set(r.result.map(x => x.mappingHash))));
            r.onerror = () => res([]);
          } catch (err) { res([]); }
        };
        req.onerror = () => res([]);
      });
    }).catch(() => []);
    if (hashes.length === 1 && hashes[0] === expected) return true;
    await page.waitForTimeout(500);
  }
  return false;
}

test.describe('v6.1 — E2E mejoras obligatorias', () => {

  test('E2E 1: cargar archivos juntos → detección automática → ANALIZAR → resultados', async ({ page }) => {
    await cargarYAnalizar(page, [FILES.horas, FILES.volumen, FILES.vsh, FILES.mapping]);
    // Detección automática: cada tipo quedó en su sitio
    const tipos = await page.evaluate(() => ({
      horas: window.SPEC.STATE.archivos.horas.length,
      volumen: window.SPEC.STATE.archivos.volumen.length,
      volSinHoras: window.SPEC.STATE.archivos.volSinHoras.length,
      mapping: window.SPEC.STATE.archivos.mapping.length
    }));
    expect(tipos).toEqual({ horas: 1, volumen: 1, volSinHoras: 1, mapping: 1 });
    // El checklist unificado muestra los 4 tipos cargados
    const checklist = await page.textContent('#unified-checklist');
    expect(checklist).toContain('✓ 1 archivo');
    // Resultados
    expect(await page.evaluate(() => window.SPEC.STATE.reporte.length)).toBeGreaterThan(0);
    expect(await page.evaluate(() => window.SPEC.STATE.queries['17_PersonaDiaAnalitica'].length)).toBeGreaterThan(0);
    // Auto-navegación a la primera pestaña útil
    expect(await page.evaluate(() => window.UI.activeTab)).toBe('revisar');
    const nCards = await page.locator('#review-list .review-item').count();
    expect(nCards).toBeGreaterThan(0);
  });

  test('E2E 2: importar mapping → cerrar → abrir → mapping recuperado', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    await limpiarStorage(page);
    await page.reload();
    await page.waitForLoadState('networkidle');
    // Primera vez: no hay mapping guardado (STATE.archivos.mapping es null/array vacío)
    expect(await page.evaluate(() => Array.isArray(window.SPEC.STATE.archivos.mapping) ? window.SPEC.STATE.archivos.mapping.length : 0)).toBe(0);
    // Importar mapping (primera vez → se guarda sin confirmación)
    await page.setInputFiles('#mapping-update-input', FILES.mapping);
    await page.waitForFunction(() => window.UI.mappingMeta && window.UI.mappingMeta.version === 1, null, { timeout: 15000 });
    const meta1 = await page.evaluate(() => ({ v: window.UI.mappingMeta.version, hash: window.UI.mappingMeta.hash, n: window.UI.mappingMeta.nRows }));
    expect(meta1.v).toBe(1);
    expect(meta1.hash).toMatch(/^[a-f0-9]{64}$/);
    expect(meta1.n).toBe(167);
    // CERRAR (nueva página = cerrar pestaña y abrir de nuevo) → mismo contexto (mismo navegador/perfil)
    await page.close();
    const page2 = await page.context().newPage();
    await page2.goto('/');
    await page2.waitForLoadState('networkidle');
    // El mapping se recupera automáticamente sin pedir al usuario
    await page2.waitForFunction(() => Array.isArray(window.SPEC?.STATE?.archivos?.mapping) && window.SPEC.STATE.archivos.mapping.length === 1, null, { timeout: 15000 });
    const meta2 = await page2.evaluate(() => ({ v: window.UI.mappingMeta.version, hash: window.UI.mappingMeta.hash, n: window.UI.mappingMeta.nRows }));
    expect(meta2.hash).toBe(meta1.hash); // mismo mapping
    expect(meta2.n).toBe(167);
    // La tarjeta "Mapping activo" muestra nombre/hash/fecha
    const card = await page2.textContent('#mapping-activo-info');
    expect(card).toContain('Mapping activo');
    expect(card).toContain('Hash:');
    await page2.close();
  });

  test('E2E 3: cambiar mapping → nuevo hash → procesar → histórico con nuevo hash', async ({ page }) => {
    await cargarYAnalizar(page, [FILES.horas, FILES.volumen, FILES.vsh, FILES.mapping]);
    const hash1 = await page.evaluate(() => window.UI.mappingMeta.hash);
    // Guardar histórico con el mapping v1
    await page.waitForFunction(async () => {
      return await new Promise(res => {
        const req = indexedDB.open('spec_history_db', 1);
        req.onsuccess = e => {
          const tx = e.target.result.transaction('person_daily_records', 'readonly');
          const r = tx.objectStore('person_daily_records').getAll();
          r.onsuccess = () => res(r.result.length > 0);
        };
      });
    }, null, { timeout: 15000 });
    const hashRecs1 = await page.evaluate(async () => {
      return await new Promise(res => {
        const req = indexedDB.open('spec_history_db', 1);
        req.onsuccess = e => {
          const tx = e.target.result.transaction('person_daily_records', 'readonly');
          const r = tx.objectStore('person_daily_records').getAll();
          r.onsuccess = () => res(Array.from(new Set(r.result.map(x => x.mappingHash))));
        };
      });
    });
    // Cambiar el mapping: aparece el diálogo de confirmación old vs new
    await page.setInputFiles('#mapping-update-input', FILES.mappingV2);
    await page.waitForSelector('#mcm-confirm', { timeout: 15000 });
    const dialogText = await page.textContent('.mapping-change-modal');
    expect(dialogText).toContain('Mapping actual');
    expect(dialogText).toContain('Nuevo mapping');
    // Confirmar el cambio
    await page.click('#mcm-confirm');
    await page.waitForFunction(() => window.UI.mappingMeta && window.UI.mappingMeta.version === 2, null, { timeout: 15000 });
    const hash2 = await page.evaluate(() => window.UI.mappingMeta.hash);
    expect(hash2).not.toBe(hash1); // NUEVO hash
    // Procesar de nuevo → el histórico se guarda con el NUEVO hash
    await page.click('.tab[data-tab="cargaanalizar"]'); // volver a la pestaña de análisis
    await page.click('#btn-analizar');
    await page.waitForFunction(() => window.SPEC?.STATE?.personaDiaRecords && window.SPEC.STATE.personaDiaRecords.length > 0
      && window.SPEC.STATE.stats.mappingHash, null, { timeout: 60000 });
    // Esperar a que TODOS los registros de IDB lleven el nuevo hash
    // (97 upserts secuenciales pueden tardar más de un WAIT fijo).
    // Bucle de sondeo desde Node: determinista y con reintentos reales.
    const hashFinal = hash2;
    const ok = await esperarHashEnRegistros(page, hashFinal, 45000);
    expect(ok, 'todos los registros históricos deben llevar el hash del mapping v2').toBe(true);
    const hashRecs2 = await page.evaluate(async () => {
      return await new Promise(res => {
        const req = indexedDB.open('spec_history_db', 1);
        req.onsuccess = e => {
          const tx = e.target.result.transaction('person_daily_records', 'readonly');
          const r = tx.objectStore('person_daily_records').getAll();
          r.onsuccess = () => res(Array.from(new Set(r.result.map(x => x.mappingHash))));
        };
      });
    });
    expect(hashRecs2[0]).toBe(hashFinal); // histórico con el NUEVO hash
  });

  test('E2E 4: persona con 2 WMS tasks → UNA revisión', async ({ page }) => {
    await cargarYAnalizar(page, [FILES.horasTurnos, FILES.volumenTurnos, FILES.vshTurnos, FILES.mapping]);
    // MIXTO UNO TEST tiene 2 tareas WMS el mismo día operativo (fecha operativa 25/08)
    const rec = await page.evaluate(() => {
      const r = window.SPEC.STATE.personaDiaRecords.find(x => x.login === 'OTO9006');
      return { key: r.key, nAct: r.actividades.length, uds: r.udsTotales, horas: r.horasAnalizables, turno: r.turno };
    });
    expect(rec.nAct).toBe(2); // 2 actividades WMS...
    // ...pero UNA SOLA revisión: solo 1 card tiene su login
    const cards = await page.evaluate((login) => {
      return Array.from(document.querySelectorAll('#review-list .review-item'))
        .filter(el => el.textContent.includes(login)).length;
    }, 'MIXTO UNO TEST');
    expect(cards).toBe(1); // ← UNA revisión, no dos
    // El detalle muestra las actividades con reparto
    await page.click('#review-list .review-item:has-text("MIXTO UNO TEST")');
    const det = await page.textContent('#incident-detail');
    expect(det).toContain('Actividades y reparto');
    expect(det).toContain('PICKING MANUAL');
    expect(det).toContain('UBICACION MANUAL');
  });

  test('E2E 5: persona con varias tareas → reparto correcto del tiempo', async ({ page }) => {
    await cargarYAnalizar(page, [FILES.horasTurnos, FILES.volumenTurnos, FILES.vshTurnos, FILES.mapping]);
    // MIXTO UNO TEST: 4 h analizables · picking manual 400 uds (4 HE) · ubicación manual 260 uds (1 HE)
    // pesos 4/5 y 1/5 → 3.2 h y 0.8 h · SUM = 4 = tiempo analizable
    const rec = await page.evaluate(() => {
      const r = window.SPEC.STATE.personaDiaRecords.find(x => x.login === 'OTO9006');
      return {
        horas: r.horasAnalizables,
        acts: r.actividades.map(a => ({ act: a.actividad, uds: a.uds, prod: a.productividad, he: a.horasEquivalentes, peso: a.peso, hasig: a.horasAsignadas })),
        suma: r.actividades.reduce((s, a) => s + a.horasAsignadas, 0),
        he: r.horasEquivalentes,
        desv: r.desviacion
      };
    });
    const pick = rec.acts.find(a => a.act === 'PICKING MANUAL');
    const ubic = rec.acts.find(a => a.act === 'UBICACION MANUAL');
    expect(pick.he).toBeCloseTo(4, 10);       // 400/100
    expect(ubic.he).toBeCloseTo(1, 10);       // 260/260
    expect(pick.peso).toBeCloseTo(0.8, 10);   // 4/5
    expect(ubic.peso).toBeCloseTo(0.2, 10);   // 1/5
    expect(pick.hasig).toBeCloseTo(3.2, 10);  // 4h × 0.8
    expect(ubic.hasig).toBeCloseTo(0.8, 10);   // 4h × 0.2
    expect(Math.abs(rec.suma - rec.horas)).toBeLessThan(1e-9); // CONSERVACIÓN EXACTA
    // La tabla visible muestra H equivalentes, PESO y H asignadas por separado
    await page.click('#review-list .review-item:has-text("MIXTO UNO TEST")');
    const det = await page.textContent('#incident-detail');
    expect(det).toContain('conservación exacta');
  });

  test('E2E 6: aceptar incidencia → undo → estado restaurado', async ({ page }) => {
    await cargarYAnalizar(page, [FILES.horas, FILES.volumen, FILES.vsh, FILES.mapping]);
    await page.click('#review-list .review-item >> nth=0');
    // ACEPTAR la primera incidencia del persona/día
    await page.click('#incident-detail button[data-action="aceptar"]:not([disabled])');
    await page.waitForFunction(() => Object.keys(window.SPEC.STATE.decisions).length === 1, null, { timeout: 10000 });
    const estado1 = await page.evaluate(() => Object.values(window.SPEC.STATE.decisions)[0].decision);
    expect(estado1).toBe('aceptada');
    // Acción consecutiva: MANTENER
    await page.click('#incident-detail button[data-action="mantener"]');
    await page.waitForFunction(() => Object.values(window.SPEC.STATE.decisions)[0].decision === 'mantenida', null, { timeout: 10000 });
    // UNDO → restaura el estado ANTERIOR (aceptada), no el inicial
    await page.click('#incident-detail button[data-action="undo"]');
    await page.waitForFunction(() => Object.values(window.SPEC.STATE.decisions)[0].decision === 'aceptada', null, { timeout: 10000 });
    const audit = await page.evaluate(() => window.SPEC.STATE.auditLog.map(e => e.action));
    expect(audit).toContain('undo');
    // Segundo UNDO → vuelve a pendiente
    await page.click('#incident-detail button[data-action="undo"]');
    await page.waitForFunction(() => Object.keys(window.SPEC.STATE.decisions).length === 0, null, { timeout: 10000 });
    // El registro de auditoría NO se borra: hay 2 decisiones + 2 undos
    const auditFinal = await page.evaluate(() => window.SPEC.STATE.auditLog.length);
    expect(auditFinal).toBe(4); // aceptada + mantenida + undo + undo
    // La persistencia incluye el undoStack (undo persistente)
    const persistido = await page.evaluate(() => {
      const raw = localStorage.getItem('spec_decisions');
      const d = JSON.parse(raw);
      return { tieneUndoStack: Array.isArray(d.undoStack), len: (d.undoStack || []).length };
    });
    expect(persistido.tieneUndoStack).toBe(true);
  });

  test('E2E 7: procesar dos días → cerrar → abrir → Patrones conserva los dos días', async ({ page }) => {
    // El fixture de turnos tiene 2 fechas operativas: 2026-08-25 y 2026-08-26
    await cargarYAnalizar(page, [FILES.horasTurnos, FILES.volumenTurnos, FILES.vshTurnos, FILES.mapping]);
    const diasAntes = await page.evaluate(() =>
      Array.from(new Set(window.SPEC.STATE.personaDiaRecords.map(r => r.fechaOperativaISO))).sort());
    expect(diasAntes).toEqual(['2026-08-25', '2026-08-26']);
    // Cerrar (nueva página en el mismo contexto) y reabrir
    await page.close();
    const page2 = await page.context().newPage();
    await page2.goto('/');
    await page2.waitForLoadState('networkidle');
    // Ir a Patrones: los registros sobreviven sin reprocesar
    await page2.click('.tab[data-tab="patrones"]');
    await page2.waitForSelector('#patrones-view-resumen .kpi-card', { timeout: 15000 });
    await page2.waitForTimeout(600);
    const kpis = await page2.textContent('#patrones-view-resumen');
    expect(kpis).toContain('Días analizados');
    const diasDespues = await page2.evaluate(async () => {
      const records = await window.cargarTodosRecords();
      return Array.from(new Set(records.map(r => r.fechaOperativaISO))).sort();
    });
    expect(diasDespues).toEqual(['2026-08-25', '2026-08-26']); // conserva los DOS días
    // El número de registros NO se duplicó
    const nRecs = await page2.evaluate(async () => (await window.cargarTodosRecords()).length);
    expect(nRecs).toBe(6);
    await page2.close();
  });

  test('E2E 8: filtrar NOCHE y verificar 22:00–06:00 (fecha operativa nocturna)', async ({ page }) => {
    await cargarYAnalizar(page, [FILES.horasTurnos, FILES.volumenTurnos, FILES.vshTurnos, FILES.mapping]);
    // Clasificación correcta de los registros con hora:
    //   NOC1 25/08 23:30 → NOCHE (op 25/08) · NOC2 26/08 02:15 → NOCHE (op 25/08,
    //   cruza medianoche) · NOC3 26/08 05:59 → NOCHE (op 25/08) ·
    //   MAN1 26/08 06:00 → MAÑANA · TAR1 26/08 14:30 → TARDE · MIX1 → MIXTO
    const recs = await page.evaluate(() => window.SPEC.STATE.personaDiaRecords.map(r => ({
      login: r.login, turno: r.turno, op: r.fechaOperativaISO
    })));
    const byLogin = Object.fromEntries(recs.map(r => [r.login, r]));
    expect(byLogin['OTO9001'].turno).toBe('NOCHE'); // 23:30
    expect(byLogin['OTO9002'].turno).toBe('NOCHE'); // 02:15
    expect(byLogin['OTO9003'].turno).toBe('NOCHE'); // 05:59
    expect(byLogin['OTO9004'].turno).toBe('MAÑANA'); // 06:00 (límite)
    expect(byLogin['OTO9005'].turno).toBe('TARDE'); // 14:30
    expect(byLogin['OTO9006'].turno).toBe('MIXTO');
    // Fecha operativa nocturna: los 00:00–05:59 pertenecen al día anterior
    expect(byLogin['OTO9001'].op).toBe('2026-08-25'); // 23:30 del 25/08
    expect(byLogin['OTO9002'].op).toBe('2026-08-25'); // 02:15 del 26/08 → 25/08
    expect(byLogin['OTO9003'].op).toBe('2026-08-25'); // 05:59 del 26/08 → 25/08
    expect(byLogin['OTO9004'].op).toBe('2026-08-26'); // 06:00 del 26/08 → 26/08
    // FILTRAR NOCHE en Revisar incidencias. Semántica del filtro: un
    // persona/día aparece si ALGUNO de sus registros es de ese turno — el
    // MIXTO (TARDE + NOCHE) también trabajó de noche → 4 visibles:
    // NOC1, NOC2, NOC3 (NOCHE pura) + MIXTO UNO TEST.
    await page.selectOption('#review-filter-turno', 'NOCHE');
    await page.waitForTimeout(400);
    const visibles = await page.evaluate(() => Array.from(document.querySelectorAll('#review-list .review-item'))
      .map(el => el.dataset.key));
    expect(visibles.length).toBe(4);
    for (const key of visibles) {
      expect(key).toContain('2026-08-25'); // todos con fecha operativa del día nocturno
    }
    // El MIXTO está incluido (tiene horas de NOCHE esa fecha operativa)
    expect(visibles.join(',')).toContain('OTO9006');
    // Los persona/día de MAÑANA/TARDE pura no aparecen
    expect(visibles.join(',')).not.toContain('OTO9004');
    expect(visibles.join(',')).not.toContain('OTO9005');
    // El filtro NOCHE también aplica en Patrones
    await page.click('.tab[data-tab="patrones"]');
    await page.selectOption('#patrones-filter-turno', 'NOCHE');
    await page.waitForTimeout(400);
    const kpi = await page.textContent('#patrones-view-resumen');
    expect(kpi).toContain('Personas analizadas');
    await page.selectOption('#patrones-filter-turno', '');
  });
});
