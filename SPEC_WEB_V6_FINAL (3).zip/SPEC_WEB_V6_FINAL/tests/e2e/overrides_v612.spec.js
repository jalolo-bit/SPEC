// E2E tests v6.1.1 — Correcciones finales: FILTRO REAL de turnos en Revisar
// y PRODUCTIVIDAD POR TASK_WMS (overrides reales desde la interfaz).
//
// Los 8 escenarios OBLIGATORIOS definidos por el usuario:
//   E2E 1: Filtro mañana real (lista de Revisar, no solo fx_Turno)
//   E2E 2: Filtro tarde real (incluye 21:59)
//   E2E 3: Filtro noche atravesando medianoche (02:00 → fecha operativa anterior)
//   E2E 4: Registro sin hora → SIN HORA + aviso «Este registro no contiene
//          hora de fichaje.» y NUNCA aparece al filtrar un turno concreto
//   E2E 5: Editar productividad de una TASK_WMS desde la UI → motor la usa
//   E2E 6: Cambiar OTRA → PICKING AGV → entra realmente en el reparto
//   E2E 7: Dos tareas de la misma actividad con productividades diferentes
//          → no se mezclan (4 h + 4 h, conservación exacta)
//   E2E 8: Cambiar override → reprocesar → histórico conserva la versión anterior

import { test, expect } from '@playwright/test';
import { resolve } from 'node:path';

const DRIVE = resolve(process.cwd(), 'audit-ref', 'drive');
const TURNOS = resolve(process.cwd(), 'test-data', 'turnos');
const FILES = {
  horas: resolve(DRIVE, 'HORA SIN VOLUMEN.xlsx'),
  volumen: resolve(DRIVE, 'VOLUMEN.xlsx'),
  vsh: resolve(DRIVE, 'VOL SIN HORAS.xlsx'),
  mapping: resolve(DRIVE, 'Mapping.xlsx'),
  horasOverride: resolve(TURNOS, 'HORAS_OVERRIDE.xlsx'),
  volumenOverride: resolve(TURNOS, 'VOLUMEN_OVERRIDE.xlsx'),
  vshTurnos: resolve(TURNOS, 'VOL_SIN_HORAS_TURNO.xlsx')
};

async function limpiarStorage(page) {
  await page.evaluate(async () => {
    try { localStorage.clear(); } catch (e) { /* noop */ }
    for (const db of ['spec_history_db', 'spec_decisions_db']) {
      await new Promise(res => {
        const done = () => res();
        if (typeof indexedDB === 'undefined') { done(); return; }
        const req = indexedDB.deleteDatabase(db);
        req.onsuccess = req.onerror = req.onblocked = done;
      });
    }
  });
}

async function cargarYAnalizar(page, files) {
  await page.goto('/');
  await page.waitForLoadState('networkidle');
  await limpiarStorage(page);
  await page.reload();
  await page.waitForLoadState('networkidle');
  await page.setInputFiles('#drop-unified input[type=file]', files);
  await page.waitForFunction(() => {
    const a = window.SPEC?.STATE?.archivos;
    return a && ['horas', 'volumen', 'volSinHoras', 'mapping'].every(k => Array.isArray(a[k]) && a[k].length > 0);
  }, null, { timeout: 30000 });
  await page.click('#btn-analizar');
  await page.waitForFunction(() => window.SPEC?.STATE?.reporte && window.SPEC.STATE.reporte.length > 0, null, { timeout: 60000 });
  await page.waitForFunction(() => window.SPEC?.STATE?.personaDiaRecords && window.SPEC.STATE.personaDiaRecords.length > 0, null, { timeout: 30000 });
  await page.waitForTimeout(400);
}

/* Claves visibles actuales de la lista de Revisar (persona/día). */
async function clavesVisibles(page) {
  return await page.evaluate(() =>
    Array.from(document.querySelectorAll('#review-list .review-item')).map(el => el.dataset.key));
}

/* Crea un override desde la INTERFAZ (sección PRODUCTIVIDAD POR TAREA). */
async function crearOverride(page, taskWms, actividad, productividad) {
  await page.click('.tab[data-tab="revisar"]');
  const editor = page.locator('#productividades-editor');
  if (await editor.getAttribute('open') == null) await page.click('#productividades-editor summary');
  await page.fill('#task-prod-search', taskWms);
  await page.selectOption('#task-prod-actividad', actividad);
  if (productividad != null) {
    await page.fill('#task-prod-value', String(productividad));
  }
  await page.click('#btn-task-prod-save');
  await page.waitForTimeout(500); // recompute + persistencia serializada
  // El override quedó guardado en localStorage
  const guardado = await page.evaluate(t => {
    const ov = JSON.parse(localStorage.getItem('spec_task_overrides') || '{}');
    return ov[window.SPEC.normalizarTareaWms(t)] || null;
  }, taskWms);
  expect(guardado, 'override persistido en localStorage').toBeTruthy();
  return guardado;
}

/* Abre el detalle de una persona/día y devuelve sus filas de tarea.
 * NOTA: el motor normaliza TASK_WMS a MAYÚSCULAS — los finds usan
 * toUpperCase() para ser robustos ante la capitalización. */
async function abrirDetalleYLeerTareas(page, login) {
  await page.click('.tab[data-tab="revisar"]');
  await page.waitForTimeout(200);
  const item = page.locator(`#review-list .review-item[data-key*="${login}"]`).first();
  await item.click();
  await page.waitForTimeout(300);
  return await page.evaluate(() => {
    const rows = Array.from(document.querySelectorAll('#incident-detail .pdd-task-row')).map(tr =>
      Array.from(tr.cells).map(td => td.textContent.trim()));
    const acts = Array.from(document.querySelectorAll('#incident-detail .pdd-act-table tbody > tr:not(.pdd-task-row)')).map(tr =>
      Array.from(tr.cells).map(td => td.textContent.trim()));
    return { rows, acts };
  });
}

const up = s => String(s || '').toUpperCase();

test.describe('v6.1.1 — E2E filtro de turnos REAL (Revisar incidencias)', () => {

  test('E2E 1: filtro MAÑANA real — solo 08:00 y 13:59', async ({ page }) => {
    await cargarYAnalizar(page, [FILES.horasOverride, FILES.volumenOverride, FILES.vshTurnos, FILES.mapping]);
    const recs = await page.evaluate(() => window.SPEC.STATE.personaDiaRecords.map(r => ({ login: r.login, turno: r.turno, op: r.fechaOperativaISO })));
    expect(recs.length).toBe(5);
    await page.selectOption('#review-filter-turno', 'MAÑANA');
    await page.waitForTimeout(400);
    const visibles = await clavesVisibles(page);
    expect(visibles.length).toBe(2);
    expect(visibles.some(k => k.indexOf('OTO9201') >= 0)).toBe(true); // 08:00
    expect(visibles.some(k => k.indexOf('OTO9202') >= 0)).toBe(true); // 13:59 (último minuto)
    expect(visibles.some(k => k.indexOf('OTO9203') >= 0)).toBe(false); // 21:59 TARDE
    expect(visibles.some(k => k.indexOf('OTO9204') >= 0)).toBe(false); // 22:00 NOCHE
    expect(visibles.some(k => k.indexOf('OTO9205') >= 0)).toBe(false); // 02:00 NOCHE
    // Sin notas SIN HORA (todos los registros tienen hora)
    expect(await page.locator('#review-list .sin-hora-note').count()).toBe(0);
    await page.selectOption('#review-filter-turno', '');
  });

  test('E2E 2: filtro TARDE real — solo 21:59', async ({ page }) => {
    await cargarYAnalizar(page, [FILES.horasOverride, FILES.volumenOverride, FILES.vshTurnos, FILES.mapping]);
    await page.selectOption('#review-filter-turno', 'TARDE');
    await page.waitForTimeout(400);
    const visibles = await clavesVisibles(page);
    expect(visibles.length).toBe(1);
    expect(visibles[0]).toContain('OTO9203'); // 21:59 (último minuto de TARDE)
    await page.selectOption('#review-filter-turno', '');
  });

  test('E2E 3: filtro NOCHE real atravesando medianoche (22:00 + 02:00 → fecha operativa 25/08)', async ({ page }) => {
    await cargarYAnalizar(page, [FILES.horasOverride, FILES.volumenOverride, FILES.vshTurnos, FILES.mapping]);
    // OTO9205 fichó el 26/08 a las 02:00 → NOCHE → fecha operativa 25/08
    const recs = await page.evaluate(() => Object.fromEntries(
      window.SPEC.STATE.personaDiaRecords.map(r => [r.login, r])));
    expect(recs['OTO9204'].turno).toBe('NOCHE');
    expect(recs['OTO9204'].fechaOperativaISO).toBe('2026-08-25'); // 22:00 del 25/08
    expect(recs['OTO9205'].turno).toBe('NOCHE');
    expect(recs['OTO9205'].fechaOperativaISO).toBe('2026-08-25'); // 02:00 del 26/08 → 25/08
    await page.selectOption('#review-filter-turno', 'NOCHE');
    await page.waitForTimeout(400);
    const visibles = await clavesVisibles(page);
    expect(visibles.length).toBe(2);
    for (const k of visibles) expect(k).toContain('2026-08-25'); // fecha operativa nocturna
    expect(visibles.some(k => k.indexOf('OTO9204') >= 0)).toBe(true);
    expect(visibles.some(k => k.indexOf('OTO9205') >= 0)).toBe(true);
    // Los de MAÑANA/TARDE no aparecen
    expect(visibles.some(k => k.indexOf('OTO9201') >= 0)).toBe(false);
    expect(visibles.some(k => k.indexOf('OTO9202') >= 0)).toBe(false);
    expect(visibles.some(k => k.indexOf('OTO9203') >= 0)).toBe(false);
    // El filtro NOCHE también funciona en Patrones (misma función centralizada)
    await page.click('.tab[data-tab="patrones"]');
    await page.waitForTimeout(600);
    await page.selectOption('#patrones-filter-turno', 'NOCHE');
    await page.waitForTimeout(400);
    const kpi = await page.textContent('#patrones-view-resumen');
    expect(kpi).toContain('Personas analizadas');
    await page.selectOption('#patrones-filter-turno', '');
  });

  test('E2E 4: registros SIN HORA (archivos day-level) → SIN HORA + aviso explícito', async ({ page }) => {
    await cargarYAnalizar(page, [FILES.horas, FILES.volumen, FILES.vsh, FILES.mapping]);
    // Todos los persona/día son SIN HORA (archivos reales sin hora de fichaje)
    const sinHora = await page.evaluate(() =>
      window.SPEC.STATE.personaDiaRecords.filter(r => r.turno === 'SIN HORA').length);
    const total = await page.evaluate(() => window.SPEC.STATE.personaDiaRecords.length);
    expect(sinHora).toBe(total);
    expect(total).toBeGreaterThan(0);
    // Al filtrar MAÑANA no aparecen falsamente: lista vacía + aviso explícito
    await page.selectOption('#review-filter-turno', 'MAÑANA');
    await page.waitForTimeout(400);
    expect(await clavesVisibles(page)).toEqual([]);
    const aviso = await page.textContent('#review-list');
    expect(aviso).toContain('no contiene hora de fichaje');
    // TARDE y NOCHE: igual (nunca se les inventa turno)
    await page.selectOption('#review-filter-turno', 'TARDE');
    await page.waitForTimeout(300);
    expect(await clavesVisibles(page)).toEqual([]);
    await page.selectOption('#review-filter-turno', 'NOCHE');
    await page.waitForTimeout(300);
    expect(await clavesVisibles(page)).toEqual([]);
    // El detalle muestra el mensaje por registro
    await page.selectOption('#review-filter-turno', 'SIN HORA');
    await page.waitForTimeout(400);
    const visibles = await clavesVisibles(page);
    expect(visibles.length).toBe(total); // el filtro SIN HORA los muestra TODOS
    await page.locator('#review-list .review-item').first().click();
    await page.waitForTimeout(300);
    const detalle = await page.textContent('#incident-detail');
    expect(detalle).toContain('Este registro no contiene hora de fichaje.');
    await page.selectOption('#review-filter-turno', '');
  });
});

test.describe('v6.1.1 — E2E PRODUCTIVIDAD POR TASK_WMS (overrides desde la UI)', () => {

  test('E2E 5: editar la productividad de una TASK_WMS → el motor la utiliza', async ({ page }) => {
    await cargarYAnalizar(page, [FILES.horasOverride, FILES.volumenOverride, FILES.vshTurnos, FILES.mapping]);
    // Estado inicial: PICKING MANUAL 600 uds @100 → 8 h para la actividad
    let d = await abrirDetalleYLeerTareas(page, 'OTO9201');
    let zara = d.rows.find(r => up(r[0]).indexOf('MATRÍCULA') >= 0);
    expect(zara).toBeTruthy();
    expect(zara[2]).toBe('100');   // productividad DEFAULT
    expect(zara[6]).toBe('DEFAULT');
    // EDITAR desde la UI: Zara → PICKING MANUAL 200
    await crearOverride(page, 'Picking ecommerce a matrícula - Zara', 'PICKING MANUAL', 200);
    d = await abrirDetalleYLeerTareas(page, 'OTO9201');
    zara = d.rows.find(r => up(r[0]).indexOf('MATRÍCULA') >= 0);
    expect(zara[2]).toBe('200');                          // productividad del override
    expect(zara[6]).toBe('OVERRIDE TASK_WMS');            // fuente
    // HE: 400/200 = 2 h · peso 2/4 · asignadas 4 h sobre 8 h analizables
    expect(zara[3]).toBe('2');      // H equiv.
    expect(zara[4]).toBe('50%');    // peso %
    expect(zara[5]).toBe('4');      // H asignadas
    // La fila de actividad muestra "varias" (100 y 200 en la misma actividad)
    const act = d.acts.find(r => r[0].indexOf('PICKING MANUAL') >= 0);
    expect(act[2]).toBe('varias');
  });

  test('E2E 6: cambiar OTRA → PICKING AGV → entra realmente en el reparto', async ({ page }) => {
    await cargarYAnalizar(page, [FILES.horasOverride, FILES.volumenOverride, FILES.vshTurnos, FILES.mapping]);
    // Inicialmente REPARTO A TIENDA AGV - BERSHKA es OTRA (sin productividad inventada)
    let d = await abrirDetalleYLeerTareas(page, 'OTO9201');
    let otra = d.acts.find(r => r[0].indexOf('OTRA') >= 0);
    expect(otra).toBeTruthy();
    expect(otra[1]).toBe('300');  // uds
    expect(otra[2]).toBe('—');    // sin productividad
    expect(otra[5]).toBe('0');    // 0 h asignadas
    // OVERRIDE desde la UI: OTRA → PICKING AGV → 150 uds/h
    await crearOverride(page, 'REPARTO A TIENDA AGV - BERSHKA', 'PICKING AGV', 150);
    d = await abrirDetalleYLeerTareas(page, 'OTO9201');
    expect(d.acts.some(r => r[0].indexOf('OTRA') >= 0)).toBe(false); // ya no es OTRA
    const pa = d.acts.find(r => r[0].indexOf('PICKING AGV') >= 0);
    expect(pa).toBeTruthy();
    expect(pa[1]).toBe('300');
    expect(pa[2]).toBe('150');
    // PICKING AGV: HE = 300/150 = 2 h; PICKING MANUAL HE = 6 h → peso 2/8 → 2 h asignadas
    expect(pa[3]).toBe('2');      // H equiv.
    expect(pa[5]).toBe('2');      // H asignadas
    const taskRow = d.rows.find(r => up(r[0]).indexOf('REPARTO A TIENDA') >= 0);
    expect(taskRow).toBeTruthy();
    expect(taskRow[6]).toBe('OVERRIDE TASK_WMS');
  });

  test('E2E 7: dos tareas de la misma actividad con productividades diferentes (100 y 200)', async ({ page }) => {
    await cargarYAnalizar(page, [FILES.horasOverride, FILES.volumenOverride, FILES.vshTurnos, FILES.mapping]);
    // Override SOLO de Zara (200); sin papel mantiene 100 → NO se mezclan
    await crearOverride(page, 'Picking ecommerce a matrícula - Zara', 'PICKING MANUAL', 200);
    const d = await abrirDetalleYLeerTareas(page, 'OTO9201');
    const sinPapel = d.rows.find(r => up(r[0]).indexOf('SIN PAPEL') >= 0);
    const zara = d.rows.find(r => up(r[0]).indexOf('MATRÍCULA') >= 0);
    expect(sinPapel[2]).toBe('100');
    expect(sinPapel[6]).toBe('DEFAULT');
    expect(zara[2]).toBe('200');
    expect(zara[6]).toBe('OVERRIDE TASK_WMS');
    // HE 200/100 = 2 h · 400/200 = 2 h → pesos 50/50 → 4 h + 4 h = 8 h exactos
    expect(sinPapel[3]).toBe('2');
    expect(zara[3]).toBe('2');
    expect(sinPapel[5]).toBe('4');
    expect(zara[5]).toBe('4');
    const sum = Number(sinPapel[5]) + Number(zara[5]);
    expect(Math.abs(sum - 8)).toBeLessThan(1e-9); // conservación < 1e-9
    // La actividad agrega sus tareas: 600 uds · 4 h HE · 8 h asignadas · "varias"
    const act = d.acts.find(r => r[0].indexOf('PICKING MANUAL') >= 0);
    expect(act[1]).toBe('600');
    expect(act[2]).toBe('varias');
    expect(act[3]).toBe('4');
    expect(act[5]).toBe('8');
  });

  test('E2E 8: cambiar override → reprocesar → histórico conserva la versión anterior', async ({ page }) => {
    await cargarYAnalizar(page, [FILES.horasOverride, FILES.volumenOverride, FILES.vshTurnos, FILES.mapping]);
    // v1: sin overrides → PICKING MANUAL 600@100 (6 h HE) · OTRA 300 fuera
    await crearOverride(page, 'Picking ecommerce a matrícula - Zara', 'PICKING MANUAL', 200);
    // El override recalcula y persiste una NUEVA VERSIÓN del histórico (fingerprint distinto)
    await page.click('.tab[data-tab="cargaanalizar"]');
    await page.click('#btn-analizar'); // reprocesado explícito
    await page.waitForFunction(() => window.SPEC?.STATE?.personaDiaRecords && window.SPEC.STATE.personaDiaRecords.length > 0, null, { timeout: 60000 });
    await page.waitForTimeout(1200); // persistencia serializada
    // Leer el registro histórico directamente de IndexedDB
    const rec = await page.evaluate(() => new Promise(res => {
      const req = indexedDB.open('spec_history_db', 1);
      req.onsuccess = e => {
        try {
          const tx = e.target.result.transaction('person_daily_records', 'readonly');
          const r = tx.objectStore('person_daily_records').getAll();
          r.onsuccess = () => res(r.result.find(x => x.key && x.key.indexOf('OTO9201') >= 0) || null);
          r.onerror = () => res(null);
        } catch (err) { res(null); }
      };
      req.onerror = () => res(null);
    }));
    expect(rec, 'registro histórico de OTO9201 en IndexedDB').toBeTruthy();
    expect(rec.version).toBeGreaterThanOrEqual(2);
    expect(Array.isArray(rec.previousVersions)).toBe(true);
    expect(rec.previousVersions.length).toBeGreaterThanOrEqual(1);
    // La versión actual usa el override (Zara 200, fuente OVERRIDE TASK_WMS)
    const actAhora = rec.actividades.find(a => a.actividad === 'PICKING MANUAL');
    const zaraAhora = actAhora.tareas.find(t => up(t.taskWms).indexOf('MATRÍCULA') >= 0);
    expect(zaraAhora.productividad).toBe(200);
    expect(zaraAhora.fuente).toBe('OVERRIDE TASK_WMS');
    expect(rec.taskOverrides).toBeTruthy();
    // La versión ANTERIOR conserva el estado SIN override (histórico inmutable)
    const prev = rec.previousVersions[rec.previousVersions.length - 1];
    const actPrev = prev.actividades.find(a => a.actividad === 'PICKING MANUAL');
    const zaraPrev = actPrev.tareas.find(t => up(t.taskWms).indexOf('MATRÍCULA') >= 0);
    expect(zaraPrev.productividad).toBe(100);          // productividad original DEFAULT
    expect(zaraPrev.fuente).toBe('DEFAULT');
    expect(prev.productividades['PICKING MANUAL']).toBe(100); // snapshot de productividades
  });
});
