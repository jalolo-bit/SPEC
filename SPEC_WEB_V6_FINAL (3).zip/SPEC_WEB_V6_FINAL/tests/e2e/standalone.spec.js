// P9-cierre (auditoría de certificación) — Standalone SPEC_AUTONOMO_v6.html E2E.
//
// El standalone que venía en el RC original era un motor ANTIGUO renombrado
// (sin M-01, sin SHA-256, sin R-06). Se reconstruyó desde el código v6.0 real
// con scripts/06_build_autonomo.py (que ahora VERIFICA los probes de seguridad
// antes de emitir el archivo). Este test demuestra en navegador que:
//   1. El standalone carga y ejecuta el motor v6.0 (AppVersion correcta).
//   2. Contiene las mejoras de seguridad embebidas (probes de runtime).
//   3. Procesa los 4 archivos de referencia y produce las 214 propuestas
//      (equivalencia funcional con el build modular).
//   4. El análisis funciona (main-thread: en un solo archivo no existe
//      worker.js — el fallback documentado ante incompatibilidad REAL).
//   5. Sin PWA (manifest/sw eliminados del standalone — exclusivo del modular).

import { test, expect } from '@playwright/test';
import { resolve } from 'node:path';

const DRIVE = resolve(process.cwd(), 'audit-ref', 'drive');
const FILES = {
  horas: resolve(DRIVE, 'HORA SIN VOLUMEN.xlsx'),
  volumen: resolve(DRIVE, 'VOLUMEN.xlsx'),
  volSinHoras: resolve(DRIVE, 'VOL SIN HORAS.xlsx'),
  mapping: resolve(DRIVE, 'Mapping.xlsx')
};
const INPUTS = {
  horas: '#drop-horas input[type=file]',
  volumen: '#drop-volumen input[type=file]',
  volSinHoras: '#drop-volSinHoras input[type=file]',
  mapping: '#drop-mapping input[type=file]'
};

test.describe('P9 — Standalone SPEC_AUTONOMO_v6.html', () => {
  test('carga, motor v6.0 con mejoras embebidas, análisis completo', async ({ page }) => {
    test.setTimeout(120_000);
    const errors = [];
    page.on('pageerror', (err) => errors.push(err.message));

    await page.goto('/SPEC_AUTONOMO_v6.html');
    await page.waitForLoadState('networkidle');

    // 1. Motor v6.0 presente y con las mejoras de seguridad embebidas
    const engine = await page.evaluate(() => ({
      version: window.SPEC?.PARAMS?.AppVersion,
      hasCalcEntryHash: typeof window.SPEC?.calcularEntryHash === 'function',
      hasVerifyChain: typeof window.SPEC?.verificarAuditLogChain === 'function',
      hasValidarArchivo: typeof window.SPEC?.validarArchivoEntrada === 'function',
      hasIdbBackup: typeof window.SPEC?.idbBackupDecisions === 'function' ||
                   typeof window.idbBackupDecisions === 'function',
      formatNum: window.SPEC?.formatNum?.(2237.5)
    }));
    expect(engine.version, 'AppVersion del standalone').toBe('6.2.0');
    expect(engine.hasCalcEntryHash, 'audit log SHA-256 (calcularEntryHash) embebido').toBe(true);
    expect(engine.hasVerifyChain, 'verificarAuditLogChain embebido').toBe(true);
    expect(engine.hasValidarArchivo, 'validarArchivoEntrada (R-06) embebido').toBe(true);
    expect(engine.formatNum, 'F11 fix en standalone: sin separador de miles').toBe('2237,5');

    // 2. Sin PWA en standalone (manifest/sw eliminados del build)
    const manifestLink = await page.evaluate(() =>
      document.querySelector('link[rel="manifest"]')?.getAttribute('href') || null
    );
    expect(manifestLink, 'standalone sin link manifest (PWA es exclusiva del modular)').toBe(null);

    // 3. Cargar los 4 archivos y analizar
    for (const k of Object.keys(INPUTS)) {
      await page.setInputFiles(INPUTS[k], FILES[k]);
    }
    await page.waitForFunction(
      () => window.SPEC?.STATE?.archivos && Object.keys(window.SPEC.STATE.archivos).length === 4,
      { timeout: 30_000 }
    );

    await page.locator('.tab[data-tab="cargaanalizar"]').click();
    await page.locator('#btn-analizar').click();
    await page.waitForFunction(
      () => window.SPEC?.STATE?.reporte && window.SPEC.STATE.reporte.length > 0,
      { timeout: 90_000 }
    );

    // 4. Equivalencia funcional con el build modular
    const repLength = await page.evaluate(() => window.SPEC.STATE.reporte.length);
    expect(repLength, '214 propuestas (idéntico al modular)').toBe(214);

    const tables = await page.evaluate(() => Object.keys(window.SPEC.STATE.queries).length);
    expect(tables, '14 tablas de queries generadas (13 de v6.0 + 17_PersonaDiaAnalitica v6.1)').toBe(14);

    // 5. Una decisión queda registrada en el audit log con SHA-256
    await page.locator('.tab[data-tab="revisar"]').click();
    await page.waitForSelector('.review-item', { timeout: 10_000 });
    await page.locator('.review-item[data-seccion^="1"]').first().click();
    await page.waitForSelector('[data-action="aceptar"]:not([disabled])', { timeout: 5_000 });
    await page.locator('[data-action="aceptar"]').first().click();
    await page.waitForFunction(
      () => window.SPEC?.STATE?.auditLog?.length >= 1,
      { timeout: 5_000 }
    );

    const entry = await page.evaluate(() => {
      const e = window.SPEC.STATE.auditLog[0];
      return { hash: e.entryHash, prev: e.prevHash, version: e.appVersion };
    });
    expect(entry.hash, 'entryHash SHA-256 (64 hex)').toMatch(/^[a-f0-9]{64}$/);
    expect(entry.prev, 'primera entrada = génesis (prevHash null)').toBe(null);
    expect(entry.version).toBe('6.2.0');

    // Filtrar pageerrors esperables: el worker.js no existe en standalone
    // (fallback main-thread documentado ante error REAL del Worker)
    const realErrors = errors.filter(e =>
      !e.includes('worker') && !e.includes('Worker') &&
      !e.includes('Failed to load resource') && !e.includes('ServiceWorker')
    );
    expect(realErrors, `pageerrors inesperados en standalone: ${realErrors.join('\n')}`).toEqual([]);
  });
});
