// Playwright E2E smoke tests for SPEC Web v6.0 (T-06 / AUD-CRIT-001/002 detection)
//
// These tests load the live http-server (started automatically by
// playwright.config.js's `webServer` option) and exercise the critical
// user flow end-to-end. The tests verify SPEC.STATE via page.evaluate()
// to avoid coupling to specific DOM visibility (e.g., a button inside a
// hidden panel).
//
// Tests:
//   1. Initial load with no console errors (AUD-CRIT-001 — app.js loaded)
//   2. Upload 4 reference files — STATE.archivos has 4 keys
//   3. Run analysis — STATE.reporte has 214 proposals
//   4. Navigate to Resultados — 13 tables listed
//   5. Navigate to Revisar — review-list has incidents
//   6. Take a decision — STATE.auditLog has 1 entry
//   7. Undo last — STATE.auditLog has 2 entries
//   8. Toggle dark mode — body.dark class added

import { test, expect } from '@playwright/test';
import { resolve } from 'node:path';

const DRIVE = resolve(process.cwd(), 'audit-ref', 'drive');
const FILES = {
  horas:    resolve(DRIVE, 'HORA SIN VOLUMEN.xlsx'),
  volumen:  resolve(DRIVE, 'VOLUMEN.xlsx'),
  vsh:      resolve(DRIVE, 'VOL SIN HORAS.xlsx'),
  mapping:  resolve(DRIVE, 'Mapping.xlsx')
};

const INPUTS = {
  horas:    '#drop-horas input[type=file]',
  volumen:  '#drop-volumen input[type=file]',
  vsh:      '#drop-volSinHoras input[type=file]',
  mapping:  '#drop-mapping input[type=file]'
};

// CSP "frame-ancestors via meta" warning was emitted in older versions.
// After FASE-2-fix it was removed. We allow this specific message just in case.
const ALLOWED_CONSOLE_PATTERNS = [
  // 'frame-ancestors' was removed from CSP meta in FASE-2-fix; if it reappears,
  // we want to know — but it's not a critical error.
];

async function expectNoRealErrors(page, errors) {
  const realErrors = errors.filter(e => !ALLOWED_CONSOLE_PATTERNS.some(p => e.includes(p)));
  expect(realErrors, `unexpected console errors:\n  ${realErrors.join('\n  ')}`).toEqual([]);
}

async function upload4Files(page) {
  await page.goto('/');
  await page.waitForLoadState('networkidle');
  await page.setInputFiles(INPUTS.horas, FILES.horas);
  await page.setInputFiles(INPUTS.volumen, FILES.volumen);
  await page.setInputFiles(INPUTS.vsh, FILES.vsh);
  await page.setInputFiles(INPUTS.mapping, FILES.mapping);
  // Wait for SPEC.STATE.archivos to have 4 keys with at least 1 file each.
  // (Instead of waiting for the visible button — it lives in a hidden panel.)
  await page.waitForFunction(
    () => {
      const a = window.SPEC?.STATE?.archivos;
      if (!a) return false;
      const keys = Object.keys(a);
      if (keys.length !== 4) return false;
      return keys.every(k => {
        const v = a[k];
        return Array.isArray(v) ? v.length > 0 : (v != null);
      });
    },
    { timeout: 30_000 }
  );
}

test.describe('SPEC Web v6.0 — Smoke E2E', () => {
  test('1. Carga inicial: app carga sin errores de consola', async ({ page }) => {
    const errors = [];
    page.on('console', (msg) => {
      if (msg.type() === 'error') errors.push(msg.text());
    });
    page.on('pageerror', (err) => errors.push(err.message));

    await page.goto('/');

    // AUD-CRIT-001 fix: app.js must be loaded → window.SPEC is defined.
    const specDefined = await page.evaluate(() => typeof window.SPEC !== 'undefined');
    expect(specDefined, 'window.SPEC is undefined — AUD-CRIT-001 regression (app.js not loaded)').toBe(true);

    // AUD-CRIT-002 fix: escapeHtml must be exposed on window.
    const escapeHtmlDefined = await page.evaluate(() => typeof window.escapeHtml === 'function');
    expect(escapeHtmlDefined, 'window.escapeHtml is not a function — AUD-CRIT-002 regression').toBe(true);

    await expectNoRealErrors(page, errors);
  });

  test('2. Cargar 4 archivos: STATE.archivos tiene 4 keys', async ({ page }) => {
    const errors = [];
    page.on('pageerror', (err) => errors.push(err.message));

    await upload4Files(page);

    const archivosCount = await page.evaluate(() => Object.keys(window.SPEC.STATE.archivos).length);
    expect(archivosCount, 'SPEC.STATE.archivos should have 4 keys after upload').toBe(4);

    expect(errors, `pageerror during upload:\n  ${errors.join('\n  ')}`).toEqual([]);
  });

  test('3. Ejecutar análisis: 214 propuestas generadas', async ({ page }) => {
    const errors = [];
    page.on('pageerror', (err) => errors.push(err.message));

    await upload4Files(page);

    // Click the "Proceso" tab so the button becomes visible.
    await page.locator('.tab[data-tab="cargaanalizar"]').click();
    await page.locator('#btn-analizar').click();

    // Wait for the analysis to complete (REPORTE has 214 proposals).
    await page.waitForFunction(
      () => window.SPEC?.STATE?.reporte && window.SPEC.STATE.reporte.length > 0,
      { timeout: 60_000 }
    );
    const reporteLength = await page.evaluate(() => window.SPEC.STATE.reporte.length);
    expect(reporteLength, 'expected 214 proposals in REPORTE_CAMBIOS_HR').toBe(214);

    expect(errors, `pageerror during analysis:\n  ${errors.join('\n  ')}`).toEqual([]);
  });

  test('4. Pestaña Resultados: 13 tablas listadas', async ({ page }) => {
    await upload4Files(page);
    await page.locator('.tab[data-tab="cargaanalizar"]').click();
    await page.locator('#btn-analizar').click();
    await page.waitForFunction(
      () => window.SPEC?.STATE?.reporte && window.SPEC.STATE.reporte.length > 0,
      { timeout: 60_000 }
    );

    // Navigate to Resultados
    await page.locator('.tab[data-tab="resultados"]').click();
    const tableCount = await page.locator('#table-list li').count();
    expect(tableCount, 'expected 13 tables in Resultados (excl. REPORTE)').toBe(13);
  });

  test('5. Pestaña Revisar incidencias: lista no vacía', async ({ page }) => {
    await upload4Files(page);
    await page.locator('.tab[data-tab="cargaanalizar"]').click();
    await page.locator('#btn-analizar').click();
    await page.waitForFunction(
      () => window.SPEC?.STATE?.reporte && window.SPEC.STATE.reporte.length > 0,
      { timeout: 60_000 }
    );

    // Navigate to Revisar
    await page.locator('.tab[data-tab="revisar"]').click();
    // Wait for review list to populate
    await page.waitForSelector('.review-item', { timeout: 10_000 });
    const reviewCount = await page.locator('.review-item').count();
    expect(reviewCount, 'expected at least 1 incident in review list').toBeGreaterThan(0);
  });

  test('6. Tomar decisión (aceptar): audit log registra entrada', async ({ page }) => {
    const errors = [];
    page.on('pageerror', (err) => errors.push(err.message));

    await upload4Files(page);
    await page.locator('.tab[data-tab="cargaanalizar"]').click();
    await page.locator('#btn-analizar').click();
    await page.waitForFunction(
      () => window.SPEC?.STATE?.reporte && window.SPEC.STATE.reporte.length > 0,
      { timeout: 60_000 }
    );

    // Navigate to Revisar, click first incident WITH PROPOSAL (section "1" = CAMBIO)
    await page.locator('.tab[data-tab="revisar"]').click();
    await page.waitForSelector('.review-item', { timeout: 10_000 });
    // Section 1 = "1. CAMBIO HR TASK PROPUESTO" — these have a propuesta and the aceptar button is enabled
    await page.locator('.review-item[data-seccion^="1"]').first().click();
    // Wait for the detail panel to render the action button
    await page.waitForSelector('[data-action="aceptar"]:not([disabled])', { timeout: 5_000 });
    await page.locator('[data-action="aceptar"]').first().click();
    // Wait for async registrarDecision + hash chain to complete
    await page.waitForFunction(
      () => window.SPEC?.STATE?.auditLog?.length >= 1,
      { timeout: 5_000 }
    );

    const auditLogLength = await page.evaluate(() => window.SPEC.STATE.auditLog.length);
    expect(auditLogLength, 'audit log should have ≥1 entry after accept').toBeGreaterThanOrEqual(1);

    const decisionsCount = await page.evaluate(() => Object.keys(window.SPEC.STATE.decisions).length);
    expect(decisionsCount, 'decisions map should have ≥1 entry').toBeGreaterThanOrEqual(1);

    expect(errors, `pageerror during decision:\n  ${errors.join('\n  ')}`).toEqual([]);
  });

  test('7. Deshacer última acción (audit log crece a 2 entradas)', async ({ page }) => {
    const errors = [];
    page.on('pageerror', (err) => errors.push(err.message));

    await upload4Files(page);
    await page.locator('.tab[data-tab="cargaanalizar"]').click();
    await page.locator('#btn-analizar').click();
    await page.waitForFunction(
      () => window.SPEC?.STATE?.reporte && window.SPEC.STATE.reporte.length > 0,
      { timeout: 60_000 }
    );

    await page.locator('.tab[data-tab="revisar"]').click();
    await page.waitForSelector('.review-item', { timeout: 10_000 });
    await page.locator('.review-item[data-seccion^="1"]').first().click();
    await page.waitForSelector('[data-action="aceptar"]:not([disabled])', { timeout: 5_000 });
    await page.locator('[data-action="aceptar"]').first().click();
    await page.waitForFunction(
      () => window.SPEC?.STATE?.auditLog?.length >= 1,
      { timeout: 5_000 }
    );

    // Now click undo on the same incident
    await page.locator('[data-action="undo"]').click();
    await page.waitForFunction(
      () => window.SPEC?.STATE?.auditLog?.length >= 2,
      { timeout: 5_000 }
    );

    const auditLogLength = await page.evaluate(() => window.SPEC.STATE.auditLog.length);
    expect(auditLogLength, 'audit log should have ≥2 entries (accept + undo)').toBeGreaterThanOrEqual(2);

    expect(errors, `pageerror during undo:\n  ${errors.join('\n  ')}`).toEqual([]);
  });

  test('8. Dark mode toggle: body.dark class + localStorage', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    // Theme cycle: 'auto' (default) → 'light' (1st click) → 'dark' (2nd click).
    // To get to 'dark', we need 2 clicks.
    await page.locator('#theme-toggle').click(); // auto → light
    await page.locator('#theme-toggle').click(); // light → dark
    // Wait for body.dark class
    await page.waitForSelector('body.dark', { timeout: 5_000 });

    const hasDarkClass = await page.evaluate(() => document.body.classList.contains('dark'));
    expect(hasDarkClass, 'body should have dark class after 2 toggle clicks').toBe(true);

    const storedTheme = await page.evaluate(() => localStorage.getItem('spec_theme'));
    expect(storedTheme, 'localStorage.spec_theme should be set').toBe('dark');
  });
});
