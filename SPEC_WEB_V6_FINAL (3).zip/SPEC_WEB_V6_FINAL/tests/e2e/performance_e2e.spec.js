// FASE 17 (auditoría de certificación) — Performance E2E con tag @perf.
//
// npm run test:perf ejecuta `playwright test --grep @perf`. Antes de esta
// suite NO existía ningún test etiquetado @perf y el comando terminaba con
// "No tests found" (error). Estos tests miden rendimiento REAL en navegador:
//
//   1. Tiempo de análisis end-to-end con los 4 archivos de referencia
//      (Web Worker activo, sin fallback main-thread)
//   2. Tiempo de render de la pestaña Resultados con la tabla grande
//      (02_VolumenDetalle, 743 filas con virtual scrolling)
//   3. Ausencia de degradación cuadrática: 1 archivo vs análisis repetido
//
// Los umbrales son generosos (CI varía) pero capturan regresiones graves.

import { test, expect } from '@playwright/test';
import { resolve } from 'node:path';

const DRIVE = resolve(process.cwd(), 'audit-ref', 'drive');
const FILES = {
  horas: resolve(DRIVE, 'HORA SIN VOLUMEN.xlsx'),
  volumen: resolve(DRIVE, 'VOLUMEN.xlsx'),
  volSinHoras: resolve(DRIVE, 'VOL SIN HORAS.xlsx'),
  mapping: resolve(DRIVE, 'Mapping.xlsx')
};
const INPUTS = {
  horas: '#drop-horas input[type=file]',
  volumen: '#drop-volumen input[type=file]',
  volSinHoras: '#drop-volSinHoras input[type=file]',
  mapping: '#drop-mapping input[type=file]'
};

test.describe('FASE 17 — Performance E2E @perf', () => {
  test.setTimeout(120_000);

  test('análisis completo de 4 archivos completa en < 30s @perf', async ({ page }) => {
    test.setTimeout(90_000);
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    for (const k of Object.keys(INPUTS)) {
      await page.setInputFiles(INPUTS[k], FILES[k]);
    }
    await page.waitForFunction(
      () => window.SPEC?.STATE?.archivos && Object.keys(window.SPEC.STATE.archivos).length === 4,
      { timeout: 30_000 }
    );

    const t0 = Date.now();
    await page.locator('.tab[data-tab="cargaanalizar"]').click();
    await page.locator('#btn-analizar').click();
    await page.waitForFunction(
      () => window.SPEC?.STATE?.reporte && window.SPEC.STATE.reporte.length > 0,
      { timeout: 60_000 }
    );
    const elapsed = Date.now() - t0;

    const repLen = await page.evaluate(() => window.SPEC.STATE.reporte.length);
    expect(repLen, '214 propuestas generadas').toBe(214);

    // Umbral holgado: el análisis local con Worker debe tardar mucho menos de 30s
    expect(elapsed, `análisis tardó ${elapsed}ms`).toBeLessThan(30_000);

    // El worker internamente reporta su propio tiempo
    const statsMs = await page.evaluate(() => window.SPEC.STATE.stats?.totalMs || null);
    if (statsMs != null) {
      expect(statsMs, `totalMs interno = ${statsMs}`).toBeLessThan(30_000);
    }
  });

  test('render de tabla grande (743 filas, virtual scroll) en < 5s @perf', async ({ page }) => {
    test.setTimeout(90_000);
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    for (const k of Object.keys(INPUTS)) {
      await page.setInputFiles(INPUTS[k], FILES[k]);
    }
    await page.waitForFunction(
      () => window.SPEC?.STATE?.archivos && Object.keys(window.SPEC.STATE.archivos).length === 4,
      { timeout: 30_000 }
    );
    await page.locator('.tab[data-tab="cargaanalizar"]').click();
    await page.locator('#btn-analizar').click();
    await page.waitForFunction(
      () => window.SPEC?.STATE?.reporte && window.SPEC.STATE.reporte.length > 0,
      { timeout: 60_000 }
    );

    // Ir a Resultados y abrir la tabla más grande (02_VolumenDetalle, 743 filas)
    const t0 = Date.now();
    await page.locator('.tab[data-tab="resultados"]').click();
    await page.waitForSelector('#table-list li', { timeout: 10_000 });
    // La lista muestra las 13 tablas; click en 02_VolumenDetalle
    await page.locator('#table-list li', { hasText: '02_VolumenDetalle' }).first().click();
    await page.waitForFunction(
      () => {
        const tb = document.querySelector('#viewer-table tbody');
        return tb && tb.children.length > 0;
      },
      { timeout: 30_000 }
    );
    const elapsed = Date.now() - t0;
    expect(elapsed, `render de 02_VolumenDetalle tardó ${elapsed}ms`).toBeLessThan(5_000);

    // Con virtual scrolling (VIEWER_THRESHOLD=200), el DOM no debe tener 743 filas de datos
    const domRows = await page.evaluate(() => {
      const tb = document.querySelector('#viewer-table tbody');
      return tb ? tb.children.length : -1;
    });
    expect(domRows, 'virtual scrolling limita las filas en DOM (< 743 + padding)').toBeLessThan(300);

    const totalRows = await page.evaluate(() => window.SPEC.STATE.queries['02_VolumenDetalle'].length);
    expect(totalRows).toBe(743);
  });

  test('segundo análisis del mismo dataset no degrada (sin fuga cuadrática) @perf', async ({ page }) => {
    test.setTimeout(120_000);
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    for (const k of Object.keys(INPUTS)) {
      await page.setInputFiles(INPUTS[k], FILES[k]);
    }
    await page.waitForFunction(
      () => window.SPEC?.STATE?.archivos && Object.keys(window.SPEC.STATE.archivos).length === 4,
      { timeout: 30_000 }
    );

    await page.locator('.tab[data-tab="cargaanalizar"]').click();

    const runAnalysis = async () => {
      const t = Date.now();
      await page.locator('#btn-analizar').click();
      await page.waitForFunction(
        () => window.SPEC?.STATE?.reporte && window.SPEC.STATE.reporte.length > 0,
        { timeout: 60_000 }
      );
      return Date.now() - t;
    };

    const first = await runAnalysis();
    const second = await runAnalysis();

    // La segunda ejecución no debe ser drásticamente más lenta (ratio < 3x
    // absorbe jitter de CI sin permitir degradación cuadrática grave)
    expect(second, `segunda pasada ${second}ms vs primera ${first}ms`).toBeLessThan(first * 3 + 5000);
  });
});
