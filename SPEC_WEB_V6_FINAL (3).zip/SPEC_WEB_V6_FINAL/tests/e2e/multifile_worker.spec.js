// F14 + FASE 3 (auditoría de certificación) — Multi-archivo + Web Worker.
//
// Test 1 (original F14): 2 archivos de HORAS + Worker, sin fallback main-thread.
// Test 2 (FASE 3): 2 archivos de CADA tipo (2 horas + 2 volumen + 2 vol-sin-horas
//                  + 1 mapping) procesados íntegramente en el Worker, sin
//                  fallback a main-thread.
//
// La regla del auditor: el fallback a main-thread SOLO es aceptable ante error
// real del Worker — nunca simplemente porque haya varios archivos. Estos tests
// capturan warnings/errores de consola para demostrar que no ocurre.
//
// Nota: usamos archivos con NOMBRES distintos pero mismo contenido, porque
// Playwright deduplica por ruta en setInputFiles con array.

import { test, expect } from '@playwright/test';
import { resolve } from 'node:path';
import { copyFileSync, existsSync, mkdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const DRIVE = resolve(process.cwd(), 'audit-ref', 'drive');
const HORAS_FILE = resolve(DRIVE, 'HORA SIN VOLUMEN.xlsx');
const VOLUMEN_FILE = resolve(DRIVE, 'VOLUMEN.xlsx');
const VSH_FILE = resolve(DRIVE, 'VOL SIN HORAS.xlsx');
const MAPPING_FILE = resolve(DRIVE, 'Mapping.xlsx');

// Directorio de duplicados con nombres distintos
const DUP_DIR = join(tmpdir(), 'spec-multifile-e2e');
const HORAS_DUP = join(DUP_DIR, 'HORA_DUP.xlsx');
const VOLUMEN_DUP = join(DUP_DIR, 'VOLUMEN_DUP.xlsx');
const VSH_DUP = join(DUP_DIR, 'VOL_SIN_HORAS_DUP.xlsx');

test.beforeAll(() => {
  mkdirSync(DUP_DIR, { recursive: true });
  for (const [src, dst] of [
    [HORAS_FILE, HORAS_DUP],
    [VOLUMEN_FILE, VOLUMEN_DUP],
    [VSH_FILE, VSH_DUP]
  ]) {
    if (!existsSync(dst) || process.env.SPEC_E2E_REFRESH_DUPS) {
      copyFileSync(src, dst);
    }
  }
});

test.afterAll(() => {
  // Limpieza no destructiva: dejamos los duplicados (se regeneran en el
  // beforeAll si cambian los originales). rmSync opcional:
  try { rmSync(DUP_DIR, { recursive: true, force: true }); } catch { /* noop */ }
});

// Helper: captura de consola para detectar fallbacks/errores
function attachConsoleCapture(page) {
  const capture = { errors: [], warnings: [] };
  page.on('console', (msg) => {
    const text = msg.text();
    if (msg.type() === 'error') capture.errors.push(text);
    if (msg.type() === 'warning') capture.warnings.push(text);
  });
  page.on('pageerror', (err) => capture.errors.push('PAGEERROR: ' + err.message));
  return capture;
}

function fallbackWarningsOf(capture) {
  return capture.warnings.filter(w =>
    w.includes('fallback') || w.includes('cayendo a main-thread') || w.includes('Multi-archivo')
  );
}

function realErrorsOf(capture) {
  return capture.errors.filter(e =>
    !e.includes('frame-ancestors') && !e.includes('ServiceWorker')
  );
}

test.describe('F14 — Multi-archivo + Web Worker', () => {
  test('2 archivos del mismo tipo (horas) + Worker: NO hay fallback main-thread', async ({ page }) => {
    const capture = attachConsoleCapture(page);

    await page.goto('/');
    await page.waitForLoadState('networkidle');

    await page.setInputFiles('#drop-horas input[type=file]', [HORAS_FILE, HORAS_DUP]);
    await page.setInputFiles('#drop-volumen input[type=file]', VOLUMEN_FILE);
    await page.setInputFiles('#drop-volSinHoras input[type=file]', VSH_FILE);
    await page.setInputFiles('#drop-mapping input[type=file]', MAPPING_FILE);

    await page.waitForFunction(
      () => {
        const a = window.SPEC?.STATE?.archivos;
        if (!a) return false;
        const len = (x) => (Array.isArray(x) ? x.length : 0);
        return Object.keys(a).length === 4 &&
               len(a.horas) === 2 &&
               len(a.volumen) === 1 &&
               len(a.volSinHoras) === 1 &&
               len(a.mapping) === 1;
      },
      { timeout: 30_000 }
    );

    await page.locator('.tab[data-tab="cargaanalizar"]').click();
    await page.locator('#btn-analizar').click();

    await page.waitForFunction(
      () => window.SPEC?.STATE?.reporte && window.SPEC.STATE.reporte.length > 0,
      { timeout: 60_000 }
    );

    const repLength = await page.evaluate(() => window.SPEC.STATE.reporte.length);
    expect(repLength, 'reporte debe tener >214 (duplicado por multi-file de horas)').toBeGreaterThan(214);

    expect(fallbackWarningsOf(capture), 'NO debe haber warnings de fallback').toEqual([]);
    expect(realErrorsOf(capture), 'sin errores de consola reales').toEqual([]);
  });

  test('FASE 3 — 2 archivos de CADA tipo procesados en el Worker sin fallback', async ({ page }) => {
    const capture = attachConsoleCapture(page);

    await page.goto('/');
    await page.waitForLoadState('networkidle');

    // 2 horas + 2 volumen + 2 vol-sin-horas + 1 mapping (7 archivos)
    await page.setInputFiles('#drop-horas input[type=file]', [HORAS_FILE, HORAS_DUP]);
    await page.setInputFiles('#drop-volumen input[type=file]', [VOLUMEN_FILE, VOLUMEN_DUP]);
    await page.setInputFiles('#drop-volSinHoras input[type=file]', [VSH_FILE, VSH_DUP]);
    await page.setInputFiles('#drop-mapping input[type=file]', MAPPING_FILE);

    // El estado debe reflejar 2 entradas en horas, volumen y volSinHoras
    await page.waitForFunction(
      () => {
        const a = window.SPEC?.STATE?.archivos;
        if (!a) return false;
        const len = (x) => (Array.isArray(x) ? x.length : 0);
        return Object.keys(a).length === 4 &&
               len(a.horas) === 2 &&
               len(a.volumen) === 2 &&
               len(a.volSinHoras) === 2 &&
               len(a.mapping) === 1;
      },
      { timeout: 30_000 }
    );

    await page.locator('.tab[data-tab="cargaanalizar"]').click();
    await page.locator('#btn-analizar').click();

    await page.waitForFunction(
      () => window.SPEC?.STATE?.reporte && window.SPEC.STATE.reporte.length > 0,
      { timeout: 90_000 }
    );

    // Con horas duplicadas el reporte supera las 214 propuestas base
    const repLength = await page.evaluate(() => window.SPEC.STATE.reporte.length);
    expect(repLength, 'reporte > 214 con horas duplicadas').toBeGreaterThan(214);

    // 02_VolumenDetalle con 2 archivos de volumen: 743 × 2 = 1486 filas
    const volDetalle = await page.evaluate(() => window.SPEC.STATE.queries['02_VolumenDetalle']?.length || 0);
    expect(volDetalle, '02_VolumenDetalle debe duplicarse a 1486 filas').toBe(1486);

    // 09_VolumenSinHorasDetalle con 2 archivos VSH: 245 × 2 = 490 filas
    const vshDetalle = await page.evaluate(() => window.SPEC.STATE.queries['09_VolumenSinHorasDetalle']?.length || 0);
    expect(vshDetalle, '09_VolumenSinHorasDetalle debe duplicarse a 490 filas').toBe(490);

    // Crítico: NI UN fallback a main-thread por multi-archivo
    expect(fallbackWarningsOf(capture), `NO debe haber warnings de fallback: ${fallbackWarningsOf(capture).join('\n')}`).toEqual([]);
    expect(realErrorsOf(capture), `console errors: ${realErrorsOf(capture).join('\n')}`).toEqual([]);
  });
});
