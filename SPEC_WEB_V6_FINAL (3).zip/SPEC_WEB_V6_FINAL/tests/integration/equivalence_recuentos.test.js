// Adapted from scripts/05_test_equivalencia.js for the Vitest integration suite.
//
// Differences from the original legacy script:
//   - Uses relative paths (../../app.js via tests/setup.js; drive files
//     at ../../audit-ref/drive/...).
//   - Reads XLSX from globalThis.XLSX (loaded by tests/setup.js from the
//     bundled xlsx.full.min.js — same version the app ships).
//   - Wraps the comparison logic in describe/it blocks with expect() assertions.
//   - Keeps the original row-counting logic intact so a baseline pass/fail
//     can be established before the main agent fixes the ui.js bugs.
//
// Coverage: 14 tables in the xlsm + REPORTE_CAMBIOS_HR.
// Baseline expectation: tests pass against the live xlsm (the JS port
// already produced 14/14 OK and 0 cell mismatches per PRUEBAS_EQUIVALENCIA.md).
//
// These integration tests do NOT touch ui.js (which has AUD-CRIT-002). They
// only exercise app.js + xlsx.full.min.js, so they should pass at baseline.

import { readFileSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, it, expect, beforeAll } from 'vitest';

const __dirname = dirname(fileURLToPath(import.meta.url));
const IN_DIR = resolve(__dirname, '..', '..', 'audit-ref', 'drive');
const SPEC_XLSM = join(IN_DIR, 'SPEC V0.47.3.xlsm');

// XLSX and SPEC come from tests/setup.js (loaded via vitest setupFiles).
const XLSX = globalThis.XLSX;
const SPEC = globalThis.SPEC;

function readXlsx(p) {
  const buf = readFileSync(p);
  return XLSX.read(buf, { type: 'buffer', cellDates: true });
}

function setupArchivos() {
  const wbHoras = readXlsx(join(IN_DIR, 'HORA SIN VOLUMEN.xlsx'));
  const wbVolumen = readXlsx(join(IN_DIR, 'VOLUMEN.xlsx'));
  const wbVSH = readXlsx(join(IN_DIR, 'VOL SIN HORAS.xlsx'));
  const wbMapping = readXlsx(join(IN_DIR, 'Mapping.xlsx'));
  SPEC.STATE.archivos.horas = { name: 'HORA SIN VOLUMEN.xlsx', workbook: wbHoras };
  SPEC.STATE.archivos.volumen = { name: 'VOLUMEN.xlsx', workbook: wbVolumen };
  SPEC.STATE.archivos.volSinHoras = { name: 'VOL SIN HORAS.xlsx', workbook: wbVSH };
  SPEC.STATE.archivos.mapping = { name: 'Mapping.xlsx', workbook: wbMapping };
}

function readSpecSheets() {
  const wb = readXlsx(SPEC_XLSM);
  const result = {};
  for (const sn of wb.SheetNames) {
    const ws = wb.Sheets[sn];
    const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: null });
    if (aoa.length === 0) {
      result[sn] = { rows: 0, cols: 0, headers: [], firstRow: [] };
      continue;
    }
    const headers = aoa[0];
    const dataRows = aoa.slice(1).filter((r) => r.some((c) => c != null && String(c).trim() !== ''));
    result[sn] = {
      rows: dataRows.length,
      cols: headers.length,
      headers: headers.filter((h) => h != null).map((h) => String(h)),
      firstRow: dataRows[0] ? dataRows[0].slice(0, Math.min(10, headers.length)) : []
    };
  }
  return result;
}

let specSheets;
let jsCounts;

beforeAll(async () => {
  setupArchivos();
  await SPEC.analizarYConciliar(() => {});
  specSheets = readSpecSheets();
  jsCounts = {};
  for (const name of Object.keys(SPEC.STATE.queries)) {
    jsCounts[name] = SPEC.STATE.queries[name].length;
  }
  jsCounts.REPORTE_CAMBIOS_HR = SPEC.STATE.reporte.length;
});

describe('T-01 Equivalencia de recuentos vs SPEC V0.47.3.xlsm', () => {
  // Snapshot the list of tables present at baseline. This catches any
  // future regression where a query silently stops being populated.
  it('produces a non-empty result set for every query table', () => {
    const empties = Object.entries(jsCounts)
      .filter(([_, n]) => n === 0)
      .map(([k]) => k);
    expect(empties, `queries with zero rows: ${empties.join(', ')}`).toEqual([]);
  });

  // Excel truncates sheet names to 31 chars. For each JS table, look up
  // the matching xlsm sheet and require diff <= 2 (matches original
  // script's tolerance for WARN; FAIL = diff > 2).
  it('row count for every table matches the xlsm sheet within +/-2 rows', () => {
    const failures = [];
    const warn = [];
    for (const name of Object.keys(jsCounts)) {
      const lookupName = name.length > 31 ? name.slice(0, 31) : name;
      const exp = specSheets[lookupName] != null
        ? specSheets[lookupName].rows
        : (specSheets[name] != null ? specSheets[name].rows : undefined);
      const act = jsCounts[name];
      if (exp == null) continue; // sheet not in xlsm — skip (matches legacy script's SKIP)
      const diff = act - exp;
      if (diff === 0) continue;
      if (Math.abs(diff) <= 2) warn.push(`${name}: excel=${exp} js=${act} diff=${diff}`);
      else failures.push(`${name}: excel=${exp} js=${act} diff=${diff}`);
    }
    expect(failures, `row-count mismatches >2: ${failures.join(' | ')}`).toEqual([]);
    if (warn.length > 0) {
      // Tolerable warnings — surface them but don't fail.
      // eslint-disable-next-line no-console
      console.warn('[WARN] row-count diffs within tolerance:\n  ' + warn.join('\n  '));
    }
  });

  it('column structure of 07_Conciliacion matches', () => {
    const spec = specSheets['07_Conciliacion'];
    const js = SPEC.STATE.queries['07_Conciliacion'];
    if (!spec || !js || js.length === 0) return; // skip if table is empty
    const specSet = new Set(spec.headers.map((h) => h.toUpperCase().trim()));
    const jsH = Object.keys(js[0]);
    const missingInJs = spec.headers.filter((h) => !jsH.some((h2) => h2.toUpperCase().trim() === h.toUpperCase().trim()));
    const extraInJs = jsH.filter((h) => !specSet.has(h.toUpperCase().trim()));
    expect(missingInJs, `missing columns in JS: ${missingInJs.join(', ')}`).toEqual([]);
    expect(extraInJs, `extra columns in JS: ${extraInJs.join(', ')}`).toEqual([]);
  });

  it('column structure of REPORTE_CAMBIOS_HR matches', () => {
    const spec = specSheets['REPORTE_CAMBIOS_HR'];
    const js = SPEC.STATE.reporte;
    if (!spec || !js || js.length === 0) return;
    const specSet = new Set(spec.headers.map((h) => h.toUpperCase().trim()));
    const jsH = Object.keys(js[0]);
    const missingInJs = spec.headers.filter((h) => !jsH.some((h2) => h2.toUpperCase().trim() === h.toUpperCase().trim()));
    const extraInJs = jsH.filter((h) => !specSet.has(h.toUpperCase().trim()));
    expect(missingInJs).toEqual([]);
    expect(extraInJs).toEqual([]);
  });

  it('column structure of 16_ControlMapeoSPEC matches', () => {
    const spec = specSheets['16_ControlMapeoSPEC'];
    const js = SPEC.STATE.queries['16_ControlMapeoSPEC'];
    if (!spec || !js || js.length === 0) return;
    const specSet = new Set(spec.headers.map((h) => h.toUpperCase().trim()));
    const jsH = Object.keys(js[0]);
    const missingInJs = spec.headers.filter((h) => !jsH.some((h2) => h2.toUpperCase().trim() === h.toUpperCase().trim()));
    const extraInJs = jsH.filter((h) => !specSet.has(h.toUpperCase().trim()));
    expect(missingInJs).toEqual([]);
    expect(extraInJs).toEqual([]);
  });

  it('08_Validaciones produces a non-empty results set', () => {
    const val = SPEC.STATE.queries['08_Validaciones'];
    expect(val).toBeDefined();
    expect(val.length).toBeGreaterThan(0);
  });

  it('16_ControlMapeoSPEC produces a non-empty results set', () => {
    const ctrl = SPEC.STATE.queries['16_ControlMapeoSPEC'];
    expect(ctrl).toBeDefined();
    expect(ctrl.length).toBeGreaterThan(0);
  });
});
