// Adapted from scripts/07_test_equivalencia_valores.js for the Vitest integration suite.
//
// Differences from the original legacy script:
//   - Uses relative paths (../../app.js via tests/setup.js; drive files
//     at ../../audit-ref/drive/...).
//   - Reads XLSX from globalThis.XLSX (loaded by tests/setup.js).
//   - Wraps the comparison logic in describe/it blocks with expect() assertions.
//   - Keeps the cell-by-cell comparison logic intact so a baseline pass/fail
//     can be established before the main agent fixes the ui.js bugs.
//
// Coverage: 14 tables, cell-by-cell comparison after sorting by canonical key.
// Baseline expectation (per PRUEBAS_EQUIVALENCIA.md): 0 mismatches across
// 74,672 cells.
//
// These integration tests do NOT touch ui.js (which has AUD-CRIT-002). They
// only exercise app.js + xlsx.full.min.js, so they should pass at baseline.

import { readFileSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, it, expect, beforeAll } from 'vitest';

const __dirname = dirname(fileURLToPath(import.meta.url));
const IN_DIR = resolve(__dirname, '..', '..', 'audit-ref', 'drive');
const SPEC_XLSM = join(IN_DIR, 'SPEC V0.47.3.xlsm');

// XLSX and SPEC come from tests/setup.js (loaded via vitest setupFiles).
const XLSX = globalThis.XLSX;
const SPEC = globalThis.SPEC;

function readXlsx(p) {
  const buf = readFileSync(p);
  return XLSX.read(buf, { type: 'buffer', cellDates: true });
}

function setupArchivos() {
  const wbHoras = readXlsx(join(IN_DIR, 'HORA SIN VOLUMEN.xlsx'));
  const wbVolumen = readXlsx(join(IN_DIR, 'VOLUMEN.xlsx'));
  const wbVSH = readXlsx(join(IN_DIR, 'VOL SIN HORAS.xlsx'));
  const wbMapping = readXlsx(join(IN_DIR, 'Mapping.xlsx'));
  SPEC.STATE.archivos.horas = { name: 'HORA SIN VOLUMEN.xlsx', workbook: wbHoras };
  SPEC.STATE.archivos.volumen = { name: 'VOLUMEN.xlsx', workbook: wbVolumen };
  SPEC.STATE.archivos.volSinHoras = { name: 'VOL SIN HORAS.xlsx', workbook: wbVSH };
  SPEC.STATE.archivos.mapping = { name: 'Mapping.xlsx', workbook: wbMapping };
}

function readSheetAsRows(p, sheetName) {
  const wb = readXlsx(p);
  const ws = wb.Sheets[sheetName];
  if (!ws) return null;
  const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: null });
  if (aoa.length === 0) return null;
  const headers = aoa[0].map((h) => (h == null ? '' : String(h)));
  const rows = [];
  for (let i = 1; i < aoa.length; i++) {
    const r = aoa[i];
    if (!r.some((c) => c != null && String(c).trim() !== '')) continue;
    const obj = {};
    for (let j = 0; j < headers.length; j++) {
      obj[headers[j]] = r[j] != null ? r[j] : null;
    }
    rows.push(obj);
  }
  return { headers, rows };
}

/* Normaliza un valor para comparación (copied verbatim from legacy script). */
function normVal(v) {
  if (v == null) return '';
  if (v instanceof Date) {
    const y = v.getUTCFullYear();
    const m = String(v.getUTCMonth() + 1).padStart(2, '0');
    const d = String(v.getUTCDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
  if (typeof v === 'number') {
    if (!isFinite(v)) return 'NaN';
    return v.toLocaleString('en-US', { maximumFractionDigits: 12, useGrouping: false });
  }
  if (typeof v === 'boolean') return v ? 'TRUE' : 'FALSE';
  return String(v).trim();
}

function compareTable(name, expected, actual) {
  const issues = [];
  const expH = expected.headers.filter((h) => h);
  const actH = Object.keys(actual[0] || {});
  const missingInJs = [];
  for (const h of expH) {
    if (!actH.some((h2) => h2.toUpperCase().trim() === h.toUpperCase().trim())) {
      missingInJs.push(h);
    }
  }
  if (missingInJs.length > 0) {
    issues.push(`Faltan columnas en JS: ${missingInJs.join(', ')}`);
  }
  if (expected.rows.length !== actual.length) {
    issues.push(`Recuento de filas: Excel=${expected.rows.length} JS=${actual.length}`);
  }
  const commonCols = expH.filter((h) => actH.some((h2) => h2.toUpperCase().trim() === h.toUpperCase().trim()));
  const sortKey = (row) =>
    commonCols
      .map((c) => {
        const jsCol = actH.find((h2) => h2.toUpperCase().trim() === c.toUpperCase().trim());
        const v = jsCol ? (row[c] != null ? row[c] : row[jsCol]) : row[c];
        return normVal(v);
      })
      .join('||');
  const expSorted = [...expected.rows]
    .map((r) => ({ row: r, key: sortKey(r) }))
    .sort((a, b) => (a.key < b.key ? -1 : a.key > b.key ? 1 : 0));
  const actSorted = [...actual]
    .map((r) => ({ row: r, key: sortKey(r) }))
    .sort((a, b) => (a.key < b.key ? -1 : a.key > b.key ? 1 : 0));
  let mismatches = 0;
  const mismatchesByCol = {};
  for (const c of commonCols) mismatchesByCol[c] = 0;
  const sampleMismatches = [];
  const maxRows = Math.min(expSorted.length, actSorted.length);
  for (let i = 0; i < maxRows; i++) {
    const e = expSorted[i].row;
    const a = actSorted[i].row;
    for (const c of commonCols) {
      const jsCol = actH.find((h2) => h2.toUpperCase().trim() === c.toUpperCase().trim());
      const expV = normVal(e[c]);
      const actV = normVal(a[jsCol]);
      if (expV !== actV) {
        mismatches++;
        mismatchesByCol[c]++;
        if (sampleMismatches.length < 5) {
          sampleMismatches.push({ sortIdx: i + 1, col: c, exp: expV, act: actV });
        }
      }
    }
  }
  const totalCells = maxRows * commonCols.length;
  return {
    name,
    expectedRows: expected.rows.length,
    actualRows: actual.length,
    expectedCols: expH.length,
    actualCols: actH.length,
    commonCols: commonCols.length,
    totalCellsCompared: totalCells,
    mismatches,
    mismatchRate: totalCells > 0 ? Number((mismatches / totalCells * 100).toFixed(2)) : 0,
    mismatchesByCol,
    sampleMismatches,
    issues
  };
}

const TABLES_TO_COMPARE = [
  { js: '01_HorasSinVolumen', excel: '01_HorasSinVolumen' },
  { js: '02_VolumenDetalle', excel: '02_VolumenDetalle' },
  { js: '09_VolumenSinHorasDetalle', excel: '09_VolumenSinHorasDetalle' },
  { js: '12_MapeoActividadSPEC', excel: '12_MapeoActividadSPEC' },
  { js: '13_VolumenMapeadoSPEC', excel: '13_VolumenMapeadoSPEC' },
  { js: '03_VolumenPersonaDia', excel: '03_VolumenPersonaDia' },
  { js: '05_VolumenIdNumericoDia', excel: '05_VolumenIdNumericoDia' },
  { js: '10_VolumenSinHorasPersonaDia', excel: '10_VolumenSinHorasPersonaDia' },
  { js: '14_VolumenPersonaDiaActividadSPEC', excel: '14_VolumenPersonaDiaActividadSP' },
  { js: '15_VolumenSinHorasPersonaDiaActividadSPEC', excel: '15_VolumenSinHorasPersonaDiaAct' },
  { js: '16_ControlMapeoSPEC', excel: '16_ControlMapeoSPEC' },
  { js: '07_Conciliacion', excel: '07_Conciliacion' },
  { js: '08_Validaciones', excel: '08_Validaciones' },
  { js: 'REPORTE_CAMBIOS_HR', excel: 'REPORTE_CAMBIOS_HR', isReporte: true }
];

let specSheets = {};

beforeAll(async () => {
  setupArchivos();
  await SPEC.analizarYConciliar(() => {});

  // Read every sheet from the xlsm so cell-level compareTable() works.
  const wb = readXlsx(SPEC_XLSM);
  for (const sn of wb.SheetNames) {
    const ws = wb.Sheets[sn];
    if (!ws) continue;
    const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: null });
    if (aoa.length === 0) {
      specSheets[sn] = { headers: [], rows: [] };
      continue;
    }
    const headers = aoa[0].map((h) => (h == null ? '' : String(h)));
    const rows = [];
    for (let i = 1; i < aoa.length; i++) {
      const r = aoa[i];
      if (!r.some((c) => c != null && String(c).trim() !== '')) continue;
      const obj = {};
      for (let j = 0; j < headers.length; j++) obj[headers[j]] = r[j];
      rows.push(obj);
    }
    specSheets[sn] = { headers, rows };
  }
});

describe('T-02 Equivalencia de valores celda a celda vs SPEC V0.47.3.xlsm', () => {
  // P7-cierre — Equivalencia ESTRICTA: 0 mismatches absolutos + 0 structural issues
  // por cada tabla. NO se tolera mismatchRate < 1%. La definición de PASS es:
  //   r.mismatches === 0  AND  r.issues.length === 0  AND  r.expectedRows === r.actualRows
  for (const t of TABLES_TO_COMPARE) {
    it(`table ${t.js} matches cell values with xlsm sheet ${t.excel}`, () => {
      const expected = specSheets[t.excel];
      const actual = t.isReporte ? SPEC.STATE.reporte : SPEC.STATE.queries[t.js];
      if (!expected || !actual || actual.length === 0) {
        // Table not in xlsm — skip with a documented reason.
        // eslint-disable-next-line no-console
        console.warn(`[SKIP] ${t.js}: table empty or not in xlsm`);
        return;
      }
      const r = compareTable(t.js, expected, actual);
      // P7-cierre — Fallo estructural absoluto
      expect(r.issues, `structural issues for ${t.js}: ${r.issues.join(' | ')}`).toEqual([]);
      // P7-cierre — Filas deben coincidir exactamente
      expect(r.expectedRows, `row count mismatch for ${t.js}: expected ${r.expectedRows}, got ${r.actualRows}`).toBe(r.actualRows);
      // P7-cierre — 0 mismatches absolutos (NO mismatchRate < 1%)
      expect(r.mismatches, `mismatches for ${t.js}: ${r.mismatches} (must be 0)\n` +
        r.sampleMismatches
          .map((m) => `  col "${m.col}": excel="${m.exp}" vs js="${m.act}"`)
          .join('\n')
      ).toBe(0);
    });
  }
});
