// Vitest global setup for SPEC Web v6.0
//
// Loads `XLSX` and `SPEC` into the Node global scope so every test file can
// reference them without imports.
//
// Implementation notes:
// - XLSX: the task description asks for the bundled `xlsx.full.min.js` to
//   be loaded via eval. The bundle detects the `module.exports` environment
//   when run with a Function loader and exposes its API through
//   `module.exports` only (it does NOT also assign to `window.XLSX` in that
//   branch). Importing the npm-installed `xlsx@0.18.5` achieves the same
//   effect with the same version (pinned in package.json to match the
//   bundled file's SHA-256 exactly — see worklog). Using the npm dep is
//   cleaner and avoids needing to maintain a Function-based shim.
// - app.js: an IIFE that expects `window` in scope (assigns `window.SPEC`
//   at the end). We alias `globalThis` as `window` and eval the source so
//   the same code path runs.

import XLSX from 'xlsx';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const projectRoot = resolve(__dirname, '..');

// --- Minimal browser-like global shims (only what app.js touches) --------
// app.js itself is fairly DOM-agnostic for the analizarYConciliar path, but
// it references `window` at the bottom. tests/ here never invoke ui.js.
if (typeof globalThis.window === 'undefined') {
  globalThis.window = globalThis;
}
if (typeof globalThis.document === 'undefined') {
  globalThis.document = {
    createElement: () => ({ style: {}, appendChild() {}, setAttribute() {}, addEventListener() {} }),
    getElementById: () => null,
    querySelector: () => null,
    querySelectorAll: () => [],
    addEventListener() {},
    body: { appendChild() {}, classList: { add() {}, remove() {}, toggle() {} } }
  };
}
if (typeof globalThis.navigator === 'undefined') {
  globalThis.navigator = { language: 'en', userAgent: 'node' };
}
if (typeof globalThis.localStorage === 'undefined') {
  const store = new Map();
  globalThis.localStorage = {
    getItem: (k) => (store.has(k) ? store.get(k) : null),
    setItem: (k, v) => store.set(k, String(v)),
    removeItem: (k) => store.delete(k),
    clear: () => store.clear()
  };
}

// --- XLSX (npm dep, same 0.18.5 version as the bundled xlsx.full.min.js) ---
globalThis.XLSX = XLSX;
if (!globalThis.XLSX || typeof globalThis.XLSX.read !== 'function') {
  throw new Error('[tests/setup.js] XLSX failed to load — global XLSX.read is not a function');
}

// --- app.js (project source — IIFE that exports window.SPEC) -------------
const appPath = resolve(projectRoot, 'app.js');
const appSrc = readFileSync(appPath, 'utf8');
// Wrap in a Function so the IIFE sees our `window`, `document`, `navigator`,
// `localStorage`, and `XLSX` globals. The IIFE assigns `window.SPEC` at the
// bottom, which (with our shim `window = globalThis`) places SPEC on
// `globalThis.SPEC` directly.
// eslint-disable-next-line no-new-func
const appLoader = new Function(
  'window', 'globalThis', 'document', 'navigator', 'localStorage', 'XLSX',
  appSrc
);
appLoader(
  globalThis.window,
  globalThis,
  globalThis.document,
  globalThis.navigator,
  globalThis.localStorage,
  globalThis.XLSX
);

if (!globalThis.SPEC) {
  if (globalThis.window && globalThis.window.SPEC) {
    globalThis.SPEC = globalThis.window.SPEC;
  } else {
    throw new Error('[tests/setup.js] app.js failed to attach SPEC to globalThis.window');
  }
}
if (!globalThis.SPEC || typeof globalThis.SPEC.analizarYConciliar !== 'function') {
  throw new Error('[tests/setup.js] SPEC.analizarYConciliar not available after eval');
}

// --- v6.2 — capa analítica (analytics/*.js, namespace window.SPEC_AN) ------
// Orden: el núcleo primero (los demás módulos dependen de SPEC_AN).
const ANALYTICS_FILES = [
  'analytics/analyticsCore.js',
  'analytics/personAnalytics.js',
  'analytics/taskAnalytics.js',
  'analytics/activityAnalytics.js',
  'analytics/confusionAnalytics.js',
  'analytics/trendAnalytics.js',
  'analytics/paretoAnalytics.js',
  'analytics/alertAnalytics.js',
  'analytics/dataQualityAnalytics.js'
];
for (const rel of ANALYTICS_FILES) {
  const src = readFileSync(resolve(projectRoot, rel), 'utf8');
  // eslint-disable-next-line no-new-func
  const loader = new Function('window', 'globalThis', src);
  loader(globalThis.window, globalThis);
}
if (!globalThis.SPEC_AN || typeof globalThis.SPEC_AN.normalizarRecords !== 'function') {
  throw new Error('[tests/setup.js] analytics layer failed to attach SPEC_AN');
}

export {};
