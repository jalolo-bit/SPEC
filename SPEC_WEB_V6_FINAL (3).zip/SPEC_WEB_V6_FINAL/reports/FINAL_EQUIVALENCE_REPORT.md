# FINAL_EQUIVALENCE_REPORT — SPEC Web v6.0 vs Excel V0.47.3

**Fecha:** 2026-10-02 (re-verificado en la auditoría de certificación P9)
**Fuente:** Ejecución real de `npm run test:integration` (21 tests Vitest) + `node scripts/07_test_equivalencia_valores.cjs` + recuento independiente `scripts/_cell_count.cjs` — todos ejecutados desde el proyecto con rutas relativas (portables).

## Setup

- **Excel referencia:** `audit-ref/drive/SPEC V0.47.3.xlsm` (522.658 bytes, SHA-256 `0fd524a929cca614ffc4461aa2727892629629eb6e3c70e83f4e3c85d1b3c7d1` — verificado contra el original de Drive en P9)
- **Inputs:** 4 archivos en `audit-ref/drive/` (HORA SIN VOLUMEN, VOLUMEN, VOL SIN HORAS, Mapping — SHA-256 verificados contra Drive en P9)
- **App JS:** `app.js` del proyecto cargado vía `new Function()` en Node, con `XLSX` global inyectado
- **Engine:** `SPEC.analizarYConciliar()` (sin Web Worker en tests Node)
- **Test framework:** Vitest 2.1.9

## Resultado: 14/14 tablas equivalentes

> Nota P9: `EQUIVALENCE_MACHINE_RESULT.json` es DETERMINISTA (sin timestamp interno) — re-ejecutar la equivalencia no invalida el MANIFEST_SHA256.txt del paquete.

Salida real de `npm run test:integration`:

```
✓ tests/integration/equivalence_valores.test.js (14 tests) 2.1s
   ✓ T-02 Equivalencia de valores celda a celda vs SPEC V0.47.3.xlsm > table 02_VolumenDetalle matches cell values with xlsm sheet 02_VolumenDetalle (376ms)
   ✓ T-02 Equivalencia de valores celda a celda vs SPEC V0.47.3.xlsm > table 13_VolumenMapeadoSPEC matches cell values with xlsm sheet 13_VolumenMapeadoSPEC (533ms)
✓ tests/integration/equivalence_recuentos.test.js (7 tests) 0.4s

Test Files  2 passed (2)
Tests       21 passed (21)
```

## Recuentos por tabla (JS)

| # | Tabla | Filas JS | Filas Excel | Cols | Celdas | Diff |
|---|-------|---------:|------------:|-----:|-------:|-----:|
| 1 | 01_HorasSinVolumen | 116 | 116 | 25 | 2.900 | 0 |
| 2 | 02_VolumenDetalle | 743 | 743 | 24 | 17.832 | 0 |
| 3 | 03_VolumenPersonaDia | 212 | 212 | 13 | 2.756 | 0 |
| 4 | 05_VolumenIdNumericoDia | 196 | 196 | 7 | 1.372 | 0 |
| 5 | 07_Conciliacion | 116 | 116 | 65 | 7.540 | 0 |
| 6 | 08_Validaciones | 18 | 18 | 5 | 90 | 0 |
| 7 | 09_VolumenSinHorasDetalle | 245 | 245 | 23 | 5.635 | 0 |
| 8 | 10_VolumenSinHorasPersonaDia | 83 | 83 | 8 | 664 | 0 |
| 9 | 12_MapeoActividadSPEC | 134 | 134 | 14 | 1.876 | 0 |
| 10 | 13_VolumenMapeadoSPEC | 743 | 743 | 36 | 26.748 | 0 |
| 11 | 14_VolumenPersonaDiaActividadSPEC | 310 | 310 | 8 | 2.480 | 0 |
| 12 | 15_VolumenSinHorasPersonaDiaActividadSPEC | 92 | 92 | 5 | 460 | 0 |
| 13 | 16_ControlMapeoSPEC | 13 | 13 | 3 | 39 | 0 |
| 14 | REPORTE_CAMBIOS_HR | 214 | 214 | 20 | 4.280 | 0 |
| **TOTAL** | | **3.355** | **3.355** | — | **74.672** | **0** |

## Resolución del misterio 74.172 vs 74.672

**La cifra correcta es 74.672 celdas.**

### Origen del "74.172"

La cifra "74.172" aparece en documentación HEREDADA de SPEC Web v.5 (que NO he modificado porque son documentos históricos de auditoría):
- `PRUEBAS_EQUIVALENCIA.md` (línea con "74,172 celdas comparadas, 0 diferencias")
- `INFORME_AUDITORIA.md` (mención)
- Otros docs del paquete de auditoría original

### Causa

Transposición de dígitos: el autor original del doc escribió "74.172" cuando el cálculo real (verificado ahora) es "74.672". El dígito "6" se transpuso con "1" en la posición decimal (74.672 → 74.172). Es el hallazgo **AUD-MED-001** ya documentado por la auditoría independiente.

### Verificación forense real (ejecutada ahora)

Script `scripts/_cell_count.cjs` (preservado en el ZIP final):
```
Celdas por tabla (JS rows × cols):
  01_HorasSinVolumen                                2900
  02_VolumenDetalle                                 17832
  03_VolumenPersonaDia                              2756
  05_VolumenIdNumericoDia                           1372
  07_Conciliacion                                   7540
  08_Validaciones                                   90
  09_VolumenSinHorasDetalle                         5635
  10_VolumenSinHorasPersonaDia                      664
  12_MapeoActividadSPEC                             1876
  13_VolumenMapeadoSPEC                             26748
  14_VolumenPersonaDiaActividadSPEC                 2480
  15_VolumenSinHorasPersonaDiaActividadSPEC         460
  16_ControlMapeoSPEC                               39
  REPORTE_CAMBIOS_HR                                4280

TOTAL CELLS (JS rows × cols): 74672
```

Suma manual de la columna "Celdas": `2900+17832+2756+1372+7540+90+5635+664+1876+26748+2480+460+39+4280 = 74.672` ✓

### Decisión

**No se ha cambiado ninguna cifra para hacerla coincidir con un informe anterior.** Los documentos v6.0 (`PLAN_IMPLEMENTACION_COMPLETO.md`, `FINAL_VALIDATION_REPORT.md`, `REGISTRO_RIESGOS_FINAL.md`, `MEJORAS_IMPLEMENTADAS.md`, este reporte) usan consistentemente **74.672**. Los documentos v5 heredados (`PRUEBAS_EQUIVALENCIA.md`, `INFORME_AUDITORIA.md`) preservan el typo "74.172" porque son archivos históricos de auditoría (no se maquillan).

## Otras equivalencias verificadas

| Métrica | JS | Excel | Match |
|---------|----|-------|-------|
| 13/13 KPIs de `16_ControlMapeoSPEC` | ✓ | ✓ | 100% |
| 18/18 KPIs de `08_Validaciones` | ✓ | ✓ | 100% |
| 7/7 secciones de `REPORTE_CAMBIOS_HR` | ✓ | ✓ | 100% |
| Sección 1: CAMBIO HR TASK PROPUESTO | 30 filas | 30 | ✓ |
| Sección 2: VARIAS TASKSPEC CON VOLUMEN | 15 | 15 | ✓ |
| Sección 3: HR TASK CORRECTA | 38 | 38 | ✓ |
| Sección 4: SIN VOLUMEN | 51 | 51 | ✓ |
| Sección 5: WMS TASK SIN MAPPING | 3 | 3 | ✓ |
| Sección 6: REVISION MANUAL - MULTIPLES HR TASK | 73 | 73 | ✓ |
| Sección 7: REVISION MANUAL - AMBIGUEDAD ID NUMERICO | 4 | 4 | ✓ |
| **TOTAL** | **214** | **214** | **100%** |

## Limitación explícita

- **Excel con macros en vivo no ejecutado**: este entorno Linux no tiene Microsoft Excel ni VBA ni Power Query. La equivalencia se demuestra contra los resultados PRE-CALCULADOS en las 14 hojas del xlsm (que se asumen correctos). El hash SHA-256 del xlsm se verifica contra el registrado por el dev original y por la auditoría independiente: `0fd524a929cca614ffc4461aa2727892629629eb6e3c70e83f4e3c85d1b3c7d1`.
- **Multi-periodo**: los 4 archivos de input solo contienen datos de una única fecha (25/08/2026, semana W35). La equivalencia solo está demostrada para 1 día.

## Conclusión

**14/14 tablas equivalentes, 0 diferencias en 74.672 celdas.** El motor JS reproduce fielmente el comportamiento del Excel V0.47.3 para el dataset de referencia. Tras TODAS las modificaciones de v6.0 (security, audit log, IndexedDB, Web Worker, virtual scrolling, multi-file, Mapping tab, auto-advance, filtros, accesibilidad), la equivalencia **se preserva**.
