# HISTORICAL_ANALYTICS_MODEL — PERSON_DAILY_RECORD y versionado analítico

**Versión:** 6.2.0 · **Fecha:** 2026-10-06

## 1. Unidad histórica y identidad

El histórico analítico se construye sobre **PERSON_DAILY_RECORD** (v6.1, MEJORA 6), con clave estable:

```
key = LOGIN + '|' + FECHA_OPERATIVA_ISO
```

Cada registro se persiste en IndexedDB (`spec_history_db`, store `person_daily_records`) mediante **upsert**:

| Situación al reprocesar | Comportamiento |
|---|---|
| No existe | Se inserta (versión 1) |
| Mismo `dataFingerprint` | Se refrescan decisiones/sesión; versión, `createdAt` y `previousVersions` intactos |
| `dataFingerprint` distinto | **Nueva versión** (version+1); el núcleo anterior pasa a `previousVersions` (cap 10) |

**No duplicar nunca**: cargar el mismo día dos veces con las mismas entradas no crea registros adicionales (§2/§3).

## 2. Campos del registro (v6.2)

Herencia v6.1/6.1.1 (resumen): `login, persona, fechaOperativa(ISO), semana, mes, turno, turnos[], horasFichadas, horasAnalizables, registros[] (idRegistroHoras/hora/turno/horas/hrTask), udsTotales, udsSinHoras, horasEquivalentes, horasAsignadas, desviacion, nActividades, actividades[], modoVolumen, incidencias[], nIncidencias, horasConIncidencia, decision, mappingHash, mappingVersion, productividades, taskOverrides, appVersion, sessionId, version, dataFingerprint, createdAt, updatedAt, previousVersions[]`.

**Nuevos v6.2** (aditivos, no alteran el fingerprint):

- Nivel tarea (`actividades[].tareas[]`): `tasksSpec` (TASK_SPEC del mapping), `cliente` (CUSTOMER del volumen).
- Nivel incidencia: `wmsTask` (WMS TASK CON VOLUMEN → imputación §11), `volumen`, `tipoCoincidencia`, `cliente`, `sapCode`.
- Nivel registro: `productivityVersion` (FNV-1a de `productividades`), `overrideVersion` (FNV-1a de `taskOverrides`), `datasetFingerprint` (alias estable de `dataFingerprint`).

## 3. dataFingerprint (compatibilidad y trazabilidad)

El fingerprint v6.1.1 se calcula sobre: `login, fechaOperativaISO, horasAnalizables, udsTotales, actividades[actividad/uds/productividad + tareas[taskWms/actividad/uds/productividad]], incidencias[seccion/horasAfectadas/tareaOriginal/propuesta]`.

- Los campos NUEVOS (tasksSpec, cliente, wmsTask, volumen, sapCode, versiones) **no** participan → los históricos v6.1/v6.1.1 no se versionan espuriamente al abrir con v6.2.
- Cambiar mapping/productividad/override **solo** genera nueva versión si cambia el NÚCLEO (clasificación/uds/incidencias): la propuesta cambia con el mapping → nuevo fingerprint → nueva versión trazable.

## 4. Vínculo de configuración

Cada registro queda vinculado (§3):

```
mappingHash (SHA-256 del mapping versionado, MEJORA 3)
productivityVersion (hash de las productividades usadas)
overrideVersion (hash de los overrides por tarea usados)
datasetFingerprint (núcleo de datos)
```

Reprocesar con otra configuración **nunca reescribe el histórico anterior**: crea una versión nueva con el núcleo previo en `previousVersions` (que conserva su `mappingHash`, `productividades`, `actividades` e `incidencias`). La vista CALIDAD DE DATOS lista los mappings distintos usados en el tiempo (§31): los periodos no se mezclan porque cada registro conserva su hash.

## 5. Flujo diario incremental (§55)

```
Hoy      → Importar Excel → ANALIZAR → PERSON_DAILY_RECORD (upsert)
                                          → persistir IndexedDB (serializado)
Mañana   → Importar nuevo día → ANALIZAR → añadir (sin duplicar)
                                          → Patrones re-memoiza (firma cambia)
Cerrar/abrir navegador → cargarTodosRecords() reconstruye el histórico sin reimportar
```

`cargarTodosRecords()` fusiona lo persistido con la sesión en memoria; `patronesStampRecords()` invalida la memo tras cada persistencia. La pestaña Patrones recalcula la snapshot completa cuando cambian filtros, configuración o el propio histórico.

## 6. Extensión de compatibilidad en la capa analítica

`normalizarRecords()` es **defensiva**: si un registro viene de una versión anterior (sin `tareas[]`, sin `wmsTask`, sin versiones), la capa analítica:
- reconstruye filas por tarea desde `tareasWms` (con pérdida documentada de granularidad),
- trata los campos ausentes como vacíos/0 (nunca rompe),
- clasifica las incidencias por sección en tiempo de análisis.

Esto permite que un histórico acumulado desde v6.1 sea analizable por v6.2 sin migración.
