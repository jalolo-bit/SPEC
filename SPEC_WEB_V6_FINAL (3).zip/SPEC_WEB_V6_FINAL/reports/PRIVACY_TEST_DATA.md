# Privacy & Test Data — SPEC Web v6.0

**Fecha:** 2026-10-01
**Marco normativo:** RGPD (UE) 2016/679, LOPDGDD 3/2018 (España)

## 1. Separación de datos

| Tipo | Ubicación | Contenido | Confidencialidad |
|------|-----------|-----------|------------------|
| **Producción** | `audit-ref/drive/` | 5 archivos Excel reales con datos de trabajadores reales de ID Logistics Ontigola (site ES146L, semana W35, 25/08/2026) | **CONFIDENCIAL** — tratar como datos personales per GDPR/LOPD |
| **Sintético** | `test-data/synthetic/` | 4 archivos Excel generados por script Python con datos ficticios | **PÚBLICO** — apto para CI/CD, repos públicos, screenshots |

## 2. Datos de producción

Los archivos en `audit-ref/drive/` contienen:

- **Nombres completos reales** de trabajadores (ej. "SANCHEZ FERNANDEZ ANDREA")
- **WMS logins reales** (ej. "OTO0499", "EU20080")
- **Fechas y horas sin volumen productivo** por persona (rendimiento individual inferible)
- **Volúmenes WMS** por login/día
- **Mapeo TASK_WMS → TASK_SPEC** (no contiene datos personales)

Estos archivos se tratan como:
- Datos personales según RGPD Art. 4(1)
- Categoría especial: datos laborales (no son categoría especial del Art. 9, pero sí sensibles por afectar a la relación laboral — Art. 88)
- Base legal: interés legítimo del responsable (ID Logistics España) para control de calidad de fichajes
- Conservación: según política interna de HR (no conocida, fuera del alcance)

### Acciones obligatorias

1. **No subir archivos de producción a repositorios públicos** (GitHub, etc.)
2. **No usar nombres reales en screenshots** de E2E tests en CI público
3. **No usar archivos de producción para datasets de performance** (se generan sintéticos)
4. **Restringir acceso al Google Drive** original a personal autorizado de ID Logistics
5. **Anonimizar antes de compartir evidencias** de auditoría con terceros

## 3. Datos sintéticos

Generados por `scripts/08_generate_synthetic_data.py` con `random.seed(42)` (determinista).

| Archivo | Tamaño | Filas | Casos cubiertos |
|---------|--------|-------|-----------------|
| `HORA_SIN_VOLUMEN_synth.xlsx` | 6.0 KB | ~20 | 7 secciones del REPORTE_CAMBIOS_HR |
| `VOLUMEN_synth.xlsx` | 5.8 KB | ~30 | 8 filas sin login (caso límite), mix positivo/negativo |
| `VOL_SIN_HORAS_synth.xlsx` | 5.9 KB | 15 | VSH por persona/día |
| `Mapping_synth.xlsx` | 5.4 KB | 7 | Mapeo UNICO + AMBIGUO (PUTAWAY mapeado a 2 TaskSpec) |

### Casos límite cubiertos por los datos sintéticos

| Login | Sección esperada | Descripción |
|-------|------------------|-------------|
| `OTO1020` | 1 (CAMBIO) | Login exacto, volume positivo en otra TASK_SPEC |
| `OTO1050` | 3 (CORRECTA) | HR Task fichada = TaskSpec del mapping |
| `OTO0499` | 1 (CAMBIO) | Login con leading zeros |
| `EU20080` | 1 (CAMBIO) | Otro login con cambio |
| `EU20052` | 3 (CORRECTA) | Otro correcto |
| `OTO` | 6 (MULTIPLES HR TASK) | Sin IdNum, 2 HR Task distintas |
| `EU1020` | 6 (MULTIPLES HR TASK) | Mismo IdNum que OTO1020 → ambigüedad |
| `""` (vacío) | 4 (SIN VOLUMEN) | Sin login → sin volumen |
| `OTO0001` | 7 (AMBIGUEDAD ID NUM) | Mismo IdNum que OTO1 |
| `OTO1` | 7 (AMBIGUEDAD ID NUM) | Otro con mismo IdNum |
| `OTO3000` | 2 (VARIAS TASKSPEC) | Mapping ambiguo (2 TaskSpec) |
| `OTO3001` | 5 (WMS SIN MAPPING) | TASK_WMS sin mapping |
| `OTO4000` | 1 (CAMBIO) | Otro cambio |
| `OTO5000` | 3 (CORRECTA) | Otro correcto |
| `OTO6000` | 4 (SIN VOLUMEN) | Sin volume en VOLUMEN.xlsx |

### Nombres sintéticos utilizados

20 nombres ficticios con apellidos comunes españoles pero no correspondientes a trabajadores reales de ID Logistics:
`GARCIA PEREZ ANA`, `MARTINEZ LOPEZ BRUNO`, `SANCHEZ RUIZ CARLA`, ... (lista completa en el script).

## 4. Uso recomendado

| Tipo de test | Datos a usar |
|--------------|-------------|
| Equivalencia (14/14 tablas, 74.672 celdas) | **Producción** (`audit-ref/drive/`) — requiere datos pre-calculados en SPEC V0.47.3.xlsm |
| Unit tests (fx_*, calcularMaterialidad) | Sin datos — tests puros |
| E2E tests en CI público | **Sintético** (cuando se añadan tests E2E con datos) |
| Performance tests (10k/50k rows) | Generados in-memory por el test (no archivos) |
| Accessibility tests | Sin datos de negocio |
| Regression tests post-fix | **Producción** (para verificar equivalencia) |
| Screenshots en documentación pública | **Sintético** |

## 5. Acciones futuras

1. **Corto plazo:** añadir tests E2E que usen los datos sintéticos (no los de producción) para verificar UI flow sin exponer datos reales.
2. **Medio plazo:** si se requiere compartir el repositorio públicamente, mover `audit-ref/drive/` a un submódulo git privado o a almacenamiento cifrado.
3. **Largo plazo:** si la app se despliega con backend, implementar:
   - Cifrado en reposo de los archivos de input
   - Anonimización automática al exportar logs/audit
   - Sistema de roles (admin puede ver datos reales; reviewer solo nombres anonimizados)
   - Retención automática (purga de datos > N días configurable)

## 6. Conclusión

La separación entre datos de producción y datos sintéticos queda establecida. Los datos sintéticos cubren todos los casos límite documentados en las 22 reglas de negocio y las 7 secciones del REPORTE_CAMBIOS_HR. Los datos de producción se tratan como confidenciales per GDPR/LOPD y se excluyen de cualquier artefacto público.
