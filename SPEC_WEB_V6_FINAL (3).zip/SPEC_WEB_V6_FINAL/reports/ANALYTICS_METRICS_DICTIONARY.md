# ANALYTICS_METRICS_DICTIONARY — Diccionario de métricas v6.2

**Versión:** 6.2.0 · Fecha: 2026-10-06 · Convención: todas las tasas en %; los deltas de tasas en **puntos porcentuales (pp)**.

## Calidad global (Resumen)

| Métrica | Fórmula | Nivel | Denominador | Interpretación |
|---|---|---|---|---|
| Personas analizadas | `count(distinct login)` | global | — | Cobertura de plantilla del filtro |
| Días analizados | `count(distinct fechaISO)` | global | — | Amplitud temporal |
| Persona-día | `count(records)` | global | — | Unidad del histórico |
| Incidencias | `Σ nIncidencias` | global | — | Todas las secciones 1-7 (incluye control 3) |
| % persona-día con incidencia | `personaDiaConIncidencia / personaDia` | global | persona-día | Presencia de propuestas |
| Persona-día con error | `count(r con ≥1 incidencia ≠ sec. 3)` | global | — | Excluye controles correctos |
| % persona-día con error | `conError / personaDia` | global | persona-día | KPI de calidad de fichaje |
| Horas afectadas | `Σ horasErrorDedup` (sec. ≠ 3, dedup por registro) | global | — | Impacto en horas |
| % horas afectadas | `horasErrorDedup / horasAnalizables` | global | horas analizables | Impacto relativo |
| Errores de asignación | `count(sec. 1 + aceptadas)` | global | — | Definición v6.1 |
| % errores de asignación | `erroresAsignacion / incidencias` | global | incidencias | Peso del error de fichaje |
| Δ pp % error | `tasaB − tasaA` | mitades | — | MEJORA/EMPEORA con umbral ±5 pp |
| Incidencias Δ% | `(B−A)/A` | mitades | — | Null si A=0 (no se inventa) |

## Personas (vista PERSONAS, §7/§8/§9)

| Métrica | Fórmula | Denominador |
|---|---|---|
| Días | `count(records del login)` | — |
| Días con error | `count(r con incidencia ≠ 3)` | — |
| % días con error (tasa) | `diasConError / dias` | días |
| Incidencias (frecuencia) | `Σ nIncidencias` | — |
| Inc./día | `incidencias / dias` | días |
| Horas afectadas | `Σ horasErrorDedup` | — |
| % horas afectadas | `horasErrorDedup / horasAnalizables` | horas analizables |
| Cambios de tarea | `count(sec. 1)` | — |
| Recurrencia | días distintos con error | — |
| Racha máxima | días CONSECUTIVOS con error (huecos rompen) | — |
| Tendencia | Δpp de la tasa entre mitades (flecha ↑↓→) | ≥3 días/mitad |
| Semáforo | MUY BUENO 0% · BUENO ≤10 · NORMAL ≤25 · ATENCIÓN ≤50 · CRÍTICO >50 · MUESTRA PEQUEÑA <3 días | días |

## Tareas (vista TAREAS, §10/§11)

| Métrica | Fórmula | Denominador |
|---|---|---|
| Oportunidades | persona-día con volumen de esa TASK_WMS | — |
| Errores | incidencias (≠3) con `wmsTask` = tarea (**imputación §11**) | — |
| % error | `errores / oportunidades` | oportunidades |
| Horas afectadas | horas de las incidencias imputadas (dedup por registro) | — |
| Personas / Días | `distinct login / fechaISO` de apariciones | — |
| MUESTRA PEQUEÑA | `oportunidades < minObservaciones (3)` | — |
| Tendencia | Δpp tasa entre mitades | ≥3 obs/mitad |

Espacio **tarea fichada (HR Task)** (vista ERRORES): `fichajes` = nº de registros de horas con esa HR Task · `tasaCambio = cambios / (cambios + correctas)` (resueltas contra mapping) · `propuestaHabitual` = destino único cuando existe.

## Actividades (§28) y turnos (§27)

- Actividad: mismas métricas que tareas, agregadas por `ACTIVIDAD_ANALISIS`; errores imputados vía la actividad de la tarea afectada (nunca copiados al día entero).
- Turno: `pctError = conError / registros` por turno; NOCHE usa FECHA_OPERATIVA_TURNO; SIN HORA permanece propio (sin reparto artificial); tendencia por turno con ≥3 registros/mitad.

## Confusiones y recurrencia (§12/§22/§23)

| Métrica | Fórmula |
|---|---|
| Casos | nº de propuestas sección 1 con ese par fichada→correcta |
| Horas (dedup) | por registro+destino, una vez |
| Recurrencia persona+pareja | días distintos con esa confusión |
| Persistencia | AISLADO 1 d · RECURRENTE 2-4 d · HABITUAL ≥5 d (configurable) |

## Evolución (§14-§16/§47)

- Serie diaria: `registros, personas, conError, incidencias, erroresAsignacion, horasAnalizables, horasAfectadas(pct)`; `pctPersonaDiaError = conError/registros`; `pctHorasAfectadas = horasErrorDedup/horasAnalizables`.
- `MM7`: media móvil de ventana 7 **solo desde el 7º punto** (nada antes).
- `rolling7/28`: suma de la ventana sobre días contiguos del calendario (sin datos = 0).
- Buckets semana ISO / mes con `ΔIncidencias` y `Δpp` frente al bucket anterior.

## Pareto y prioridad (§24/§26/§6)

- Curva: orden desc por valor; `pctIndividual`, `pctAcumulado`; `nPara80` = nº de elementos para 80% acumulado; `cumple8020 = (pctElementos80 ≤ 20)` — **comprobación real**.
- Frecuencia×Impacto: cuadrantes por **mediana** del conjunto (documentado; alto/alto = actuar primero).
- Prioridad: ver ADVANCED_ANALYTICS_SPEC §5 (pesos 20/20/20/15/15/10; ALTA ≥60, MEDIA ≥35).

## Calidad de datos y mapping (§29-§31/§49/§50)

| Métrica | Fórmula | Denominador |
|---|---|---|
| % SIN HORA | `registrosSinHora / registros` | registros |
| Registros con OTRA / UDS OTRA | conteo / `Σ uds` tareas OTRA | — |
| Casos SIN MAPPING | `count(sec. 5)` | — |
| Datos incompletos | `count(sec. 4) + count(sec. 6/7)` | — |
| Causas operativo/datos/revisión/control | conteos por categoría | total incidencias |
| Cambios de mapping | `distinct(mappingHash) − 1` | — |
| Versiones por reprocesado | `Σ previousVersions.length` (trazabilidad, NO duplicados) | — |

## Umbrales (defaults editables en ⚙ Configuración estadística)

`minDiasComparar 3` · `minObservaciones 3` · `umbralCambioPP 5` · `rachaDias 3` · `recurrenciaHabitual 5` · `recurrenciaRecurrente 4` · `ventanaMediaMovil 7` · `ventanaRollingLarga 28` · `repeticionesConfusion 3` · `umbralTurnoPP 10` · `otraUdsMinimas 100` · `impactoHorasAltas 4` · `semaforoBueno 10` · `semaforoNormal 25` · `semaforoAtencion 50` · `semaforoMinDias 3` · pesos prioridad `20/20/20/15/15/10` · `prioridadAlta 60` · `prioridadMedia 35`.

**Nota**: estos defaults son valores razonables documentados, no decisiones de negocio cerradas (§70). Ajustarlos desde la UI si el negocio define otros objetivos (p. ej., objetivo de tasa futura, arquitectura ya preparada).
