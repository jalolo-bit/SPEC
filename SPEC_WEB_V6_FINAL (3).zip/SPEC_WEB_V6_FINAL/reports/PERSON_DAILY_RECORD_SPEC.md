# PERSON_DAILY_RECORD_SPEC — Modelo de datos histórico diario

**Versión:** v6.1 · **Fecha:** 2026-10-02 · **Implementación:** `app.js → generarPersonDailyRecords()` · **Persistencia:** IndexedDB `spec_history_db` → store `person_daily_records` (gestión en `ui.js`)

---

## 1. Entidad

**PERSON_DAILY_RECORD** — una fila por cada **persona + fecha operativa** analizada. Es la unidad histórica de las pestañas *Revisar incidencias* (vista) y *Patrones* (análisis temporal).

## 2. Clave de identidad (sin duplicados)

```
key = login_canonico + '|' + fecha_operativa_ISO       // p.ej. "OTO0499|2026-08-25"
```

- `fecha_operativa` respeta la regla del turno NOCHE: registros entre 00:00–05:59 pertenecen a la fecha operativa **anterior** (22:00–06:00 cruza medianoche).
- Reprocesar los mismos archivos **no duplica** históricos: el upsert en IndexedDB es por `key`.
- Si los datos cambian, se crea una **nueva versión** del registro conservando trazabilidad (`version` + `previousVersions`, ver §6).

## 3. Campos

| Campo | Tipo | Descripción |
|---|---|---|
| `key` | string | Clave estable `login\|fechaOperativaISO` |
| `login` | string | Login canónico (normalizado) |
| `persona` | string | Nombre |
| `fechaOperativa` | Date | Fecha operativa (con regla nocturna) |
| `fechaOperativaISO` | string | `YYYY-MM-DD` |
| `semana` | string | Semana ISO 8601 `YYYY-Www` (validada contra `isocalendar` de Python) |
| `mes` | string | `YYYY-MM` |
| `turno` | string | `MAÑANA` \| `TARDE` \| `NOCHE` \| `MIXTO` (varios turnos ese día) \| `SIN HORA` (archivos day-level) |
| `turnos` | string[] | Turnos individuales presentes ese día |
| `horasFichadas` | number | Σ horas registradas del persona/día |
| `horasAnalizables` | number | Igual a `horasFichadas` (tiempo bajo revisión = base del reparto) |
| `udsTotales` | number | Σ uds de todas sus actividades (volumen WMS) |
| `udsSinHoras` | number | Volumen sin horas asociadas (informativo, del archivo VOL SIN HORAS) |
| `horasEquivalentes` | number | Σ horas productivas equivalentes estimadas (uds/productividad) — solo actividades clasificables |
| `horasAsignadas` | number | Σ horas asignadas por el reparto (= `horasAnalizables` cuando hay clasificables) |
| `desviacion` | number | `horasAnalizables − horasEquivalentes` |
| `nActividades` | number | Nº de ACTIVIDAD_ANALISIS distintas |
| `actividades` | array | Ver §4 |
| `modoVolumen` | string | `LOGIN EXACTO` \| `MISMO NUMERO, DISTINTO PREFIJO` \| null |
| `incidencias` | array | Ver §5 |
| `nIncidencias` | number | Nº de propuestas del reporte vinculadas |
| `horasConIncidencia` | number | Σ horas de registros con incidencia (**deduplicada**: cada registro de horas cuenta una vez aunque genere varias propuestas) |
| `decision` | string | Estado agregado: `PENDIENTE` \| `EN REVISIÓN` \| `COMPLETADA` \| `SIN INCIDENCIAS` |
| `mappingHash` | string | **SHA-256 del mapping usado** (identidad de la versión persistente del mapping) |
| `mappingVersion` | number | Versión del mapping persistido |
| `productividades` | object | Snapshot de las productividades usadas |
| `appVersion` | string | Versión de la app (6.1.0) |
| `sessionId` | string | Sesión de procesado |
| `version` | number | Versión del registro (1, 2, …) |
| `dataFingerprint` | string | Hash FNV-1a del núcleo de datos (detección de cambios al reprocesar) |
| `createdAt` / `updatedAt` | ISO | Ciclo de vida |
| `previousVersions` | array | Versiones anteriores compactadas (máx. 10) |

## 4. `actividades[]` (el reparto)

| Campo | Descripción |
|---|---|
| `actividad` | `AUDITORIA AGV` \| `AUDITORIA MANUAL` \| `UBICACION AGV` \| `UBICACION MANUAL` \| `PICKING AGV` \| `PICKING MANUAL` \| `OTRA` |
| `uds` | Unidades totales de esa actividad en el persona/día |
| `tareasWms[]` | Tareas WMS concretas que la componen (trazabilidad al detalle) |
| `productividad` | Referencia aplicada (uds/h) — `null` para OTRA |
| `horasEquivalentes` | `uds / productividad` — `null` para OTRA |
| `peso` | `he / Σ he` — `null` si no hubo reparto |
| `horasAsignadas` | `horasAnalizables × peso` |
| `productividadImplicita` | `uds / horasAsignadas` (mostrada como *implícita*, no real medida) |

El modelo matemático completo está en `reports/TIME_ALLOCATION_MODEL.md`.

## 5. `incidencias[]`

Cada elemento vincula una propuesta del `REPORTE_CAMBIOS_HR` al persona/día (por `ID REGISTRO`):

`{ id, seccion, horasAfectadas, requiereCambio, tareaOriginal, propuesta, decision }`

- `id` = `ID_REGISTRO@FILA_ORIGEN` (identidad de la propuesta en la sesión).
- `decision` se sincroniza desde `SPEC.STATE.decisions` en cada acción/undo.

## 6. Versionado y trazabilidad

Al reprocesar un persona/día cuya `key` ya existe en IndexedDB:

1. **Mismo `dataFingerprint`** (mismos datos) → upsert idempotente: se refrescan decisiones/sesión, `version` no cambia.
2. **Fingerprint distinto** (cambiaron datos, mapping o productividades) → `version += 1`; el núcleo anterior se compacta en `previousVersions[]` (cap 10) con su propio `mappingHash` y `productividades`.

**Inmutabilidad de históricos:** un registro guardado con `mappingHash = ABC123` sigue siendo interpretable con ese mapping aunque se importen otros mappings después; los registros **no se recalculan retroactivamente** al cambiar mapping o productividades — solo un reprocesado explícito genera nueva versión.

## 7. Persistencia (IndexedDB)

- Base de datos: `spec_history_db` (v1), stores `mappings` (versiones de mapping) y `person_daily_records` (keyPath `key`, índices `login`, `fechaOperativaISO`, `semana`, `mes`).
- Escrituras **serializadas** (cola `encolarPersistenciaRecords`) para que dos análisis consecutivos nunca intercalen sus upserts.
- La fusión de lectura (`cargarTodosRecords`) combina IDB + registros de la sesión en memoria.
- Separación de responsabilidades: `spec_decisions_db` (v5) sigue almacenando decisiones/audit log; `spec_history_db` es exclusivo del histórico diario.

## 8. Supervivencia

Los registros sobreviven a: cierre de pestaña, cierre del navegador, nueva sesión y nuevas cargas de archivos (verificado en E2E 7: procesar dos días → cerrar → abrir → Patrones conserva los dos días, sin duplicados).

## 9. Trazabilidad completa

Cada registro permite reconstruir la cadena:

```
Persona → Día (operativo) → Actividades → Tareas WMS → Unidades →
Productividad de referencia → Horas equivalentes → Horas asignadas →
Incidencia → Decisión → Mapping utilizado (hash + versión)
```

Todas las métricas de Patrones son **transparentes** y reconstruibles desde los registros (fórmulas documentadas junto a cada vista).

## 10. Tests

- Unitarios: `tests/unit/persona_dia.test.js` (estructura completa, clave estable, fingerprints, dedupe de horas, semanas ISO) y `tests/unit/mapping_persist.test.js` (snapshot de hash/productividades).
- E2E: `tests/e2e/mejoras_v6.spec.js` (E2E 4, 5, 7 y vinculación de decisiones).
