# TIME_ALLOCATION_MODEL — Modelo matemático del reparto de tiempos

**Versión:** v6.1.1 · **Fecha:** 2026-10-02 · **Implementación:** `app.js → repartirTiemposPorTarea()` (v6.1.1, reparto POR TAREA) y `resolverClasificacionTarea()` (prioridad de resolución). Testeadas en `tests/unit/reparto_tiempos.test.js` y `tests/unit/overrides_task.test.js`.

---

## 0. Cambio v6.1.1 — cálculo POR TASK_WMS (no por actividad)

En v6.1 el volumen se agregaba por `ACTIVIDAD_ANALISIS` ANTES de resolver la
productividad, de modo que dos tareas de la misma actividad con
productividades distintas (p. ej. TASK A = 100 uds/h y TASK B = 200 uds/h)
compartían una única productividad. **Esto era incorrecto con overrides por
tarea** y se ha corregido:

```
AHORA (v6.1.1):  el cálculo se realiza para cada
                  PERSONA + FECHA_OPERATIVA + TASK_WMS

  UDS_TAREA                 = Σ VolumenPositivo de esa TASK_WMS
  PRODUCTIVIDAD_TAREA       = prioridad (ver §4bis)
  HORAS_EQUIVALENTES_TAREA  = UDS_TAREA / PRODUCTIVIDAD_TAREA
  PESO_TAREA                = HORAS_EQUIVALENTES_TAREA / Σ_HORAS_EQUIVALENTES_PERSONA_DÍA
  HORAS_ASIGNADAS_TAREA     = HORAS_ANALIZABLES × PESO_TAREA
```

La interfaz sigue mostrando una **vista resumida por ACTIVIDAD_ANALISIS**
sumando sus tareas (la fila de actividad muestra «varias» cuando sus tareas
tienen productividades distintas), y el detalle por tarea se despliega como
sub-filas: `TASK_WMS | UDS | Productividad | H eq. | Peso | H asignadas | Fuente`.

## 1. Objetivo

Cuando una persona ha realizado varias tareas WMS durante su día, el tiempo registrado de la persona se **reparte entre las tareas utilizando las horas productivas equivalentes como ponderación**. La unidad de análisis es **PERSONA + FECHA_OPERATIVA** (no PERSONA + TASK_WMS).

## 2. Dos variables DISTINTAS (nunca intercambiables)

### 2.1 HORAS EQUIVALENTES ESTIMADAS

```
HORAS_EQUIVALENTES(actividad) = UDS(actividad) / PRODUCTIVIDAD_MEDIA(actividad)
```

Es una **estimación productiva**: "8 h equivalentes" significa *8 horas productivas equivalentes estimadas según la productividad media*, **NO** tiempo real trabajado.

### 2.2 HORAS ASIGNADAS

```
TIEMPO_ASIGNADO(actividad) = TIEMPO_ANALIZABLE(persona/día) × PESO(actividad)
```

Es la parte del tiempo real registrado (horas sin volumen bajo revisión) que se atribuye a esa actividad.

## 3. Producto: TIEMPO_ANALIZABLE

El `TIEMPO_ANALIZABLE_PERSONA_DIA` es la suma de las horas de todos los registros de esa persona en esa fecha operativa (`Σ HorasSinVolumen`), es decir, **el tiempo que está bajo revisión** en esa persona/día. Se trata del tiempo que se reparte, y su cantidad es exactamente la que se conserva (ver §6).

## 4. Cadena de cálculo completa

```
Para cada actividad a de la persona/día:
  1. uds_a            = Σ VolumenPositivo de las filas WMS clasificadas como a
  2. prod_a           = productividad de referencia (editor de productividades,
                        override por tarea, o valor por defecto)
  3. he_a              = uds_a / prod_a                     [solo actividades ≠ OTRA]
  4. total_he          = Σ he_a                             [solo actividades ≠ OTRA]
  5. peso_a            = he_a / total_he                     (si total_he > 0)
  6. h_asignadas_a     = TIEMPO_ANALIZABLE × peso_a
  7. prod_implicita_a  = uds_a / h_asignadas_a               (si h_asignadas_a > 0)
```

**Actividades OTRA:** no reciben productividad inventada; `he = null`, `peso = null/0`, `h_asignadas = 0`. Quedan fuera del reparto salvo regla de negocio explícita (override del usuario).

**Caso total_he = 0** (todas las actividades clasificables con 0 unidades, o solo OTRA): no se reparte nada; todas las `h_asignadas = 0`; el tiempo analizable queda sin asignar (no desaparece: el registro lo conserva en `horasAnalizables`).

## 4bis. Prioridad de resolución POR TASK_WMS (v6.1.1)

`resolverClasificacionTarea(taskWms, opciones)` resuelve cada tarea con esta
prioridad EXACTA (nunca se usa la productividad de OTRO TASK_WMS):

```
1. OVERRIDE específico de la TASK_WMS     → fuente «OVERRIDE TASK_WMS»
   (sección PRODUCTIVIDAD POR TAREA, localStorage['spec_task_overrides'])
2. Productividad de su ACTIVIDAD_ANALISIS → fuente «PRODUCTIVIDAD ACTIVIDAD»
   si fue personalizada, o «DEFAULT» si coincide con el valor por defecto
3. Default PARAMS.ProductividadesReferencia
```

Una tarea inicialmente clasificada **OTRA** puede reasignarse por override a
cualquier actividad productiva (se exige productividad > 0) — y una tarea
productiva puede mandarse a OTRA. La columna **Fuente** de la tabla de
overrides muestra el origen efectivo de cada valor.

## 5. Productividades de referencia (netas, uds/h)

Valores por defecto (editables en la UI y persistidos en `localStorage['spec_productividades']`):

| Actividad | Productividad |
|---|---:|
| AUDITORÍA AGV | 35 uds/h |
| AUDITORÍA MANUAL | 23 uds/h |
| UBICACIÓN MANUAL | 260 uds/h |
| UBICACIÓN AGV | 240 uds/h |
| PICKING MANUAL | 100 uds/h |
| PICKING AGV | 150 uds/h |

Orden de resolución por tarea: **override por tarea → productividades del usuario → valores por defecto**. Cambiar las productividades recalcula el reparto de la sesión en curso; los históricos ya guardados conservan sus valores (snapshot por registro).

## 6. Conservación exacta

**Invariante:** `Σ h_asignadas = TIEMPO_ANALIZABLE` con tolerancia numérica mínima (< 1e-9; el error flotante observado en los datos reales es ~8.9e-16).

- El cálculo mantiene **precisión interna completa**; el redondeo es **solo de presentación** (`formatNum`).
- No aparece ni desaparece tiempo por redondeos: la suma se verifica en la UI ("Σ horas asignadas = X h · tiempo analizable = Y h ✓ conservación exacta") y en tests unitarios para 1, 2, 3, muchas actividades, unidades muy grandes (1e9) y mezclas con OTRA.

## 7. Ejemplo (caso del usuario)

Persona con **8 horas registradas**:

| Actividad | UDS | Productividad | H. equivalentes | Peso | H. asignadas |
|---|---:|---:|---:|---:|---:|
| Picking AGV | 900 | 150 uds/h | 6,0000 h | 6/8,1667 = 0,7347 | 8 × 0,7347 = **5,8776 h** |
| Ubicación AGV | 520 | 240 uds/h | 2,1667 h | 0,2653 | 8 × 0,2653 = **2,1224 h** |
| **Σ** | | | 8,1667 h | 1,0000 | **8,0000 h = tiempo analizable** ✓ |

La **productividad implícita** (uds / h_asignadas) se muestra claramente etiquetada como *productividad implícita*, no como productividad real medida.

## 8. Desviación

```
DESVIACIÓN(persona/día) = TIEMPO_ANALIZABLE − Σ HORAS_EQUIVALENTES
```

Interpretación: diferencia entre el tiempo registrado y el tiempo productivo equivalente estimado. Positiva ⇒ la persona registró más horas de las estimables con su volumen (según las medias de referencia). Es un indicador de análisis, no una medida exacta.

## 9. Implementación y verificación

- Función pura: `repartirTiempos(tiempoAnalizable, actividades)` en `app.js` (motor, ejecutable en el Worker).
- Query: `q17_PersonaDiaAnalitica(H, VM, VSH, opciones)` — construye los grupos persona/día, agrega el volumen por `ACTIVIDAD_ANALISIS` (clasificación centralizada) y aplica el reparto.
- La UI recalcula `q17` con las preferencias del usuario tras cada análisis (el Worker calcula con los valores por defecto).
- Tests: `tests/unit/reparto_tiempos.test.js` (12 casos, incluidos los obligatorios del usuario), `tests/unit/persona_dia.test.js` (integración de la query) y E2E 5 (reparto correcto en la app real).

## 10. Limitaciones documentadas

1. Las productividades son **medias de referencia netas**, no tiempos exactos por persona/turno.
2. Las tareas OTRA no reciben productividad; su volumen se muestra pero no pondera el reparto.
3. El reparto se hace a nivel de ACTIVIDAD_ANALISIS (agregando las tareas WMS de la misma actividad); el detalle por tarea WMS se conserva en `actividades[].tareasWms`.
4. `horasSinHoras` (volumen sin horas) no participa del reparto (no hay horas que repartir); se informa como campo descriptivo.
