# MAPPING_AMBIGUITIES — Análisis de ambigüedades del Mapping.xlsx

**Fecha de análisis:** 2026-10-02 · **App:** SPEC Web v6.1 · **Mapping analizado:** `Mapping.xlsx` (167 filas, hoja `Mapping`)

Este informe responde a la REGLA FINAL SOBRE AMBIGÜEDADES de la iteración v6.1:
**antes de ejecutar cualquier asignación de productividad que dependa de una clasificación dudosa, la ambigüedad se identifica, se muestra y NO se inventa una clasificación.**

Las tareas ambiguas se clasifican como **OTRA** (sin productividad inventada, fuera del reparto productivo) hasta decisión explícita del usuario. La app permite cambiar la actividad y la productividad de cualquier tarea desde el editor de *Productividades de referencia* (overrides por tarea, persistidos en `localStorage['spec_task_overrides']`).

---

## 1. Ambigüedades REALES del mapping (TASK_WMS con más de un TASK_SPEC)

Análisis automático sobre las 167 filas de la hoja `Mapping` (139 TASK_WMS distintos):

| TASK_WMS | Posibles asignaciones (TASK_SPEC) | Motivo | Decisión necesaria |
|---|---|---|---|
| `Ubicación de SKU duchando` (sin marca) | `20089 ONTIGOLA-ECOM-UBIC-DEVO-ONLINE` \| `20081 ONTIGOLA-ECOM-UBIC-DEVO-TIENDA` | La misma tarea WMS aparece asociada a dos TASK_SPEC distintos según la fila del mapping | ¿A cuál de las dos devoluciones (ONLINE vs TIENDA) debe imputarse el volumen cuando el WMS reporta esta tarea? |
| `REPARTO A TIENDA AGV - BERSHKA` | `20157 ONTIGOLA-ECOM-TRASPASO` \| `20159 ONTIGOLA-ECOM-PICKING-TRASPASOS` | Doble correspondencia | ¿Traspaso o picking de traspasos? |
| `REPARTO A TIENDA AGV - OYSHO` | `20157 ONTIGOLA-ECOM-TRASPASO` \| `20159 ONTIGOLA-ECOM-PICKING-TRASPASOS` | Ídem | Ídem |
| `REPARTO A TIENDA AGV - PULL & BEAR` | `20157 ONTIGOLA-ECOM-TRASPASO` \| `20159 ONTIGOLA-ECOM-PICKING-TRASPASOS` | Ídem | Ídem |

**Tratamiento en v6.1:**
- La clasificación `ACTIVIDAD_ANALISIS` de estas tareas es **OTRA** (no encajan en las reglas explícitas del usuario: "Reparto por cuadrante AGV / supercuadrante" son las únicas de reparto→PICKING AGV). Quedan **fuera del reparto de tiempos** hasta confirmación.
- El propio motor del reporte las marca en la sección **5. WMS TASK SIN MAPPING** (`EstadoMapeoSPEC ≠ UNICO`), por lo que siempre son visibles en Revisar incidencias.
- `Ubicación de SKU duchando` sí encaja en la regla genérica de ubicación (empieza por "Ubicación", sin AGV/AUTOMATIZADA → UBICACION MANUAL); su ambigüedad afecta al TASK_SPEC del reporte, no a la actividad física.

> Nota: el ejemplo mencionado por el usuario, `Mover SKU - Bershka`, NO presenta ambigüedad de TASK_SPEC en esta versión del mapping (una única correspondencia: `20090 ONTIGOLA-ECOM-STOCK-INCIDENCIAS`). Sí se clasifica como OTRA por no pertenecer a las 6 actividades principales.

## 2. Tareas con TASK_WMS vacío

27 filas del mapping tienen `TASK_WMS` vacío (tareas de soporte, calidad, MOI, consumo, runner, automatista, etc.). Estas filas **no pueden participar en la clasificación por tarea WMS** (no hay tarea que clasificar) y se tratan como OTRA en los análisis de actividad. No requieren decisión de negocio para el reparto productivo, pero conviene revisar si alguna debería tener TASK_WMS asignado en el propio mapping.

Ejemplos: `BORDADOS`, `RECICLAJE`, `ADICIONAL TASK`, `STAFF`, `MAINTENANCE TECH`, `ADMIN`, `5S`, `CARRETILLERO`, `RUNNER`, `MOVIMIENTO-STOCK`, `MANT-AGV`, `CALIDAD-ITX`, `TRASLADO ZH`.

## 3. Calidad de datos detectada en el mapping

| Problema | Ejemplo | Impacto | Tratamiento |
|---|---|---|---|
| Saltos de línea dentro del nombre de tarea | `"REASIGNACIÓN\r\n  - OYSHO"` | La comparación por nombre exacto fallaría | `normalizarTareaWms()` colapsa `\r\n` y espacios múltiples antes de comparar |
| Espacios dobles finales | `"Ubicación SKU con cantidad  - Oysho"`, `"Ubicación de contenedor completo  - Oysho"` | Ídem | Ídem (normalización) |
| TASK_SPEC "0 Actividad no especificada" | `UDS. EXPEDIDAS2` | Sin actividad real | OTRA |

## 4. Decisiones de clasificación tomadas (documentadas, reversibles)

Reglas EXPLÍCITAS del usuario (implementadas literalmente):

| Regla | Clasificación |
|---|---|
| `Reparto por cuadrante AGV*` | PICKING AGV |
| `Reparto por supercuadrante AGV*` | PICKING AGV |
| `Picking ecommerce a matrícula*` | PICKING MANUAL |
| `Picking por cuadrante guiado*` | PICKING MANUAL |
| `Picking sin papel*` | PICKING MANUAL |
| Tipo movimiento que empieza por `Ubicación` | UBICACIÓN (AGV si contiene `AGV` o `AUTOMATIZADA`; manual en caso contrario) |
| `Auditoría*` | AUDITORÍA (AGV si contiene `AGV`; manual en caso contrario) |

Decisión ADICIONAL tomada (justificada, reversible desde el editor):

| Tarea | Clasificación | Justificación |
|---|---|---|
| `PICKING LIBRE*` | PICKING MANUAL | Comparte TASK_SPEC (20051) con las tres tareas picking manual explícitas del usuario; físicamente es picking manual sin guía AGV |

Tareas deliberadamente **OTRA** (sin inventar clasificación) — pendientes de regla de negocio:

| Tarea | Motivo para NO clasificarla |
|---|---|
| `REPARTO A TIENDA AGV*` | Ambigüedad real de mapping (2 TASK_SPEC) y fuera de las reglas explícitas |
| `Picking por tienda guiado*` | Picking de transferencias entre tiendas (TASK_SPEC 20062 P.TRANSFER): distinto del picking ecommerce; productividad probablemente distinta |
| `PICKING DE DEVOLUCIÓN DE LOCALIZACIÓN*` | Picking de devoluciones (TASK_SPEC 20157 TRASPASO): semántica mixta |
| `TRASPASOS AGV*` | Traspasos, no picking |
| `Mover SKU*` / `Mover contenido*` / `Move content` | Movimientos de stock (20090 STOCK-INCIDENCIAS) |
| `Cambio de campaña*`, `Conteo*`, `Contenedor sin QA*`, `DEVOLUCIÓN*`, `Informe empaquetado`, `LIBIAO`, `PRODUCTIVITYPACKERS*`, `Picking RFID*`, `RFID`, `UDS. EXPEDIDAS*`, `REASIGNACIÓN*` | No pertenecen a las 6 actividades principales |

## 5. Cómo resolver una ambigüedad desde la aplicación (v6.1.1)

1. Abre **Revisar incidencias → ⚙ Productividades de referencia → PRODUCTIVIDAD POR TAREA** (sección nueva v6.1.1).
2. Busca la TASK_WMS ambigua (el buscador ofrece todas las tareas conocidas del mapping y del volumen cargado; también puede escribirse cualquier nombre a mano).
3. Selecciona la actividad destino (cualquiera de las 6 productivas, u OTRA) y, si la actividad es productiva, una productividad > 0. Ejemplo: `REPARTO A TIENDA AGV - BERSHKA` → `PICKING AGV` → `150 uds/h`.
4. Pulsa **Guardar override**. El motor recalcula inmediatamente el reparto del persona/día (la tarea pasa de OTRA a la actividad elegida y entra en el reparto), la tabla muestra la fila con fuente `OVERRIDE TASK_WMS` y el botón **Resetear** permite deshacer el override en cualquier momento.
5. Los históricos ya guardados **no se recalculan retroactivamente** (conservan las productividades y overrides con los que fueron creados); un reprocesado genera una nueva versión del registro (trazabilidad en `previousVersions`, con snapshot de `taskOverrides`).

Los overrides se persisten en `localStorage['spec_task_overrides']` (clave: tarea normalizada) y el motor los aplica con la prioridad exacta: **override de tarea → productividad de la actividad → default** (nunca la productividad de otra tarea). Ver `reports/TIME_ALLOCATION_MODEL.md` §4bis.

## 6. Resumen

- 4 tareas con ambigüedad real de TASK_SPEC → requieren decisión de negocio del usuario.
- 27 filas con TASK_WMS vacío → sin impacto en el reparto (OTRA).
- 3 problemas de calidad de datos → mitigados por normalización centralizada.
- 1 decisión adicional documentada (PICKING LIBRE → PICKING MANUAL).
- Ninguna clasificación dudosa se ha inventado: las ambiguas quedan como OTRA hasta confirmación.
