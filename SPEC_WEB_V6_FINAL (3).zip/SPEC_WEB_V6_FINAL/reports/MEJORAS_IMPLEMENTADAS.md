# Mejoras M-01 → M-15 — Tabla Final de Implementación

**Versión:** SPEC Web v6.0 — Post-Audit Certified Release
**Fecha:** 2026-10-02 (regenerada tras auditoría de certificación P9 — todas las evidencias provienen de la última ejecución real)

| Mejora | Estado | Archivos | Test de evidencia | Resultado | Notas P9 |
|--------|--------|----------|-------------------|-----------|----------|
| **M-01** CSV formula escape | ✅ IMPLEMENTADA | `app.js` (exportToCsv, FORMULA_PREFIXES) | `tests/unit/csv_injection.test.js` (17 tests) | 17/17 | Standalone reconstruido: la versión anterior NO contenía esta mejora; ahora sí (probe del build + E2E) |
| **M-02** innerHTML/XSS | ✅ IMPLEMENTADA | `ui.js` (escapeHtml/escapeAttr en todas las rutas dinámicas) | `tests/unit/escape_html.test.js` (24 tests) + axe-core | 24/24 + 5/5 a11y | Virtual scrolling y mapping también escapados (`_viewerRowCellsHtml`, renderMappingTable) |
| **M-03** Web Worker | ✅ IMPLEMENTADA | `worker.js` (135 líneas), `ui.js` (analizarConWorker) | `tests/e2e/multifile_worker.spec.js` (2 tests FASE 3) | 2/2 | 2 archivos de CADA tipo procesados EN EL WORKER, sin fallback. Transfer zero-copy de ArrayBuffers |
| **M-04** Auto-backup | ✅ IMPLEMENTADA | `ui.js` (idbBackupDecisions/idbRestoreDecisions) | `tests/e2e/indexeddb.spec.js` (2 tests FASE 9) | 2/2 | Ciclo completo: persistir → reload → recuperar → borrar localStorage → recuperar de IndexedDB |
| **M-05** Virtual scrolling | ✅ IMPLEMENTADA | `ui.js` (VIEWER_THRESHOLD=200, VIEWER_ROW_HEIGHT=32) | `tests/e2e/performance_e2e.spec.js` @perf | 3/3 | 743 filas renderizadas <5s con DOM <300 nodos |
| **M-06** Unit tests | ✅ IMPLEMENTADA | `tests/unit/` 12 archivos | `npm test` | 250/250 Vitest total | +2 archivos P9: audit_log_chain (22), input_validation (24) |
| **M-07** Mapping management | ✅ IMPLEMENTADA | `index.html` (pestaña), `ui.js` (~480 líneas) | `tests/e2e/mapping.spec.js` (FASE 10) | 1/1 E2E completo | **Regresión M-07/M-10 corregida en P9** (pestaña vacía con formato array multi-archivo) + estado vacío con mensaje |
| **M-08** Auto-advance | ✅ IMPLEMENTADA | `index.html` (checkbox), `ui.js` (persistencia localStorage) | E2E smoke (flujo decisiones) | OK | Label accesible |
| **M-09** Filtros | ✅ IMPLEMENTADA | `index.html` (6+ filtros), `ui.js` (UI.reviewFilter) | E2E + mapping.spec.js (filtros Customer/Activity) | OK | Turno documentado como informativo (inputs sin hora) |
| **M-10** Multiarchivo | ✅ IMPLEMENTADA | `index.html` (multiple), `ui.js` (loadFiles), `app.js` (flatMap+toArray) | `tests/e2e/multifile_worker.spec.js` FASE 3 | 2/2 | La evidencia anterior afirmaba "fallback a main-thread para multiarchivo" — CORREGIDO: multiarchivo va por Worker |
| **M-11** CSP + headers | ✅ IMPLEMENTADA | `index.html` (meta CSP/X-Content-Type-Options/Referrer-Policy) | E2E 0 console errors + standalone CSP por hashes | OK | Standalone: CSP con hashes SHA-256 por script inline (sin unsafe-inline). HSTS/X-Frame/Permissions-Policy = headers del servidor (documentado, no afirmados) |
| **M-12** IndexedDB | ✅ IMPLEMENTADA | `ui.js` (idbOpen, spec_decisions_db) | `tests/e2e/indexeddb.spec.js` FASE 9 | 2/2 | localStorage primero, IndexedDB backup/recuperación |
| **M-13** TypeScript | ❌ NO IMPLEMENTADA | — | — | — | 0 archivos .ts. Migración multi-sesión con riesgo arquitectónico (IIFE + new Function en tests). Decisión documentada |
| **M-14** CI/CD | ✅ IMPLEMENTADA | `.github/workflows/ci.yml` (9 jobs) | Parser YAML real + validator | YAML VÁLIDO | **Corregido en P9**: el workflow era no-parseable (línea npm audit con `: ` sin quote). Ahora validado + guard en validator |
| **M-15** PWA | ✅ IMPLEMENTADA | `manifest.json` + `sw.js` + `sw-register.js` | `tests/e2e/pwa.spec.js` (4 tests FASE 14) | 4/4 | Manifest válido servido, SW ACTIVO, caché core (10+ recursos), **OFFLINE completo verificado**. Nota: solo en contextos seguros (https/localhost). Standalone sin SW (documentado). |

## Resumen

| Estado | Cantidad | Mejoras |
|--------|----------|---------|
| ✅ IMPLEMENTADA | 14 | M-01, M-02, M-03, M-04, M-05, M-06, M-07, M-08, M-09, M-10, M-11, M-12, M-14, M-15 |
| ❌ NO IMPLEMENTADA | 1 | M-13 (TypeScript — decisión documentada) |

**Conclusión:** 14/15 mejoras implementadas y DEMOSTRADAS con tests ejecutados en la auditoría de certificación. M-13 no implementada (documentada). El estado anterior de este documento (M-15 "aplazada", M-13 "parcial") quedó obsoleto tras la implementación de M-15 y la reclasificación honesta de M-13.
