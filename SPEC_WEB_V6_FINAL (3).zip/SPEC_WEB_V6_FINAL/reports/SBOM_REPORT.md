# SBOM Report — SPEC Web v6.0

**Fecha:** 2026-10-01
**Formato:** CycloneDX 1.4 (JSON)
**Herramienta:** `@cyclonedx/cyclonedx-npm` 1.20.0
**Archivo:** `/home/z/my-project/sbom.json`

## Resumen

| Métrica | Valor |
|---------|-------|
| Formato | CycloneDX 1.4 |
| Serial Number | urn:uuid:2a243163-f364-4255-b29d-1fbcb1405f27 |
| Timestamp metadata | 2026-10-01T16:18:09.670Z |
| Componentes totales | ~305 (incluyendo transitive) |
| Dependencias directas (prod) | 1 (xlsx@0.18.5) |
| Dependencias directas (dev) | 9 |
| Licencia principal | Apache-2.0 (xlsx) + MIT/ISC (devDeps) |

## Dependencias directas

### Producción

| Paquete | Versión | Licencia | Notas |
|---------|---------|----------|-------|
| `xlsx` | 0.18.5 | Apache-2.0 | SheetJS — parsea .xlsx/.xlsm/.xlsb. **VULNERABLE** (ver sección siguiente). |

### Desarrollo

| Paquete | Versión | Uso |
|---------|---------|-----|
| `vitest` | 2.1.9 | Test runner |
| `@vitest/coverage-istanbul` | 2.1.9 | Cobertura |
| `@playwright/test` | 1.63.0 | E2E + a11y tests |
| `eslint` | 9.39.5 | Lint |
| `@eslint/js` | 9.39.5 | ESLint recommended config |
| `globals` | 15.15.0 | Definición de globals para ESLint |
| `axe-core` | 4.13.0 | Accessibility engine |
| `@cyclonedx/cyclonedx-npm` | 1.20.0 | Generación de SBOM |
| `http-server` | 14.1.1 | Servir la app para E2E |

## Vulnerabilidades conocidas

### xlsx 0.18.5 — 2 advisories HIGH

| Advisory | Tipo | CVSS | Fix en | Estado |
|----------|------|------|--------|--------|
| GHSA-4r6h-8v6p-xvw6 | Prototype Pollution (CWE-1321) | 7.8 | 0.19.3 | **MITIGADO** |
| GHSA-5pgg-2g8v-p4x9 | ReDoS (CWE-1333) | 7.5 | 0.20.2 | **MITIGADO** |

**Mitigación aplicada (FASE 2 / R-06):**
1. **Límite estricto de tamaño** (`PARAMS.TamanoMaximoArchivoMB = 50`) rechaza archivos > 50 MB antes de pasarlos a SheetJS.
2. **Validación estructural** (`validarArchivoEntrada` + `validarWorkbook`) comprueba extensión, MIME type, longitud mínima del buffer, presencia de hojas EXPORT/MAPPING, número razonable de columnas.
3. **Procesamiento 100% offline**: la app no hace llamadas de red (`fetch`/`XMLHttpRequest`/`WebSocket`/`Worker`/`sendBeacon` = 0, verificado por auditoría dinámica). El vector de ataque requeriría que el atacante tuviera acceso al sistema de archivos del usuario.
4. **CSP restrictiva** (`default-src 'self'`) bloquea cualquier intento de exfiltración.
5. **Sin `unsafe-eval`** en la CSP.

**Por qué no se actualiza:**
- SheetJS NO publica versiones parcheadas en el registry público de npm. La versión 0.20.2+ solo está disponible en el CDN oficial de SheetJS (cdn.sheetjs.com) que no es accesible desde este entorno.
- Actualizar el bundle local `xlsx.full.min.js` a 0.20.2 requiere descargar manualmente del CDN oficial + verificar hash + reemplazar bundle. Se documenta como acción de mantenimiento post-entrega.

**Acción recomendada post-entrega:**
```bash
# En entorno con acceso a internet:
curl -O https://cdn.sheetjs.com/xlsx-0.20.3/package/xlsx.full.min.js
sha256sum xlsx.full.min.js  # verificar integridad
# Comparar hash con el oficial publicado por SheetJS
mv xlsx.full.min.js /home/z/my-project/
npm run test  # verificar equivalencia 14/14 se mantiene
```

## Vulnerabilidades transitivas

`npm audit` reporta 16 vulnerabilidades en dependencias transitivas (xlsx, esbuild, tar, glob). Todas son del toolchain de build/dev, NO de la app en producción (que solo usa `xlsx` 0.18.5 bundleado localmente, sin npm registry).

## Paquetes innecesarios

No se identifican paquetes innecesarios. `xlsx` es la única dependencia de producción y es estrictamente necesaria para leer/escribir archivos Excel. Las 9 devDeps son todas herramientas de test/build/dev estándar.

## Próximas acciones

1. **Corto plazo (mantenimiento post-entrega):** actualizar `xlsx.full.min.js` a ≥0.20.3 desde el CDN oficial SheetJS con verificación de hash SHA-256 publicado.
2. **Medio plazo:** evaluar alternativas a SheetJS (exceljs, ooxml-schema) si SheetJS no resuelve las vulnerabilidades.
3. **Largo plazo:** si se añade backend (cambiar arquitectura), mover el parsing de archivos al servidor con una librería server-side parcheada.

## Trazabilidad

El SBOM `sbom.json` puede ser firmado digitalmente (cosign o sigstore) en CI para garantizar integridad. Es una mejora futura.
