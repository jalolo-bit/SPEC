# DELIVERY_CONCORDANCE_MATRIX — SPEC Web v6.0

**Fecha:** 2026-10-02 (regenerada tras auditoría de certificación P9)
**Versión entregada:** SPEC Web v6.0 — Post-Audit Certified Release

Cada afirmación se contrasta con la evidencia de la **última ejecución real**. Ningún número proviene de informes anteriores.

| Afirmación realizada | Evidencia real (última ejecución) | ¿Demostrada? |
|----------------------|-----------------------------------|--------------|
| **250 tests Vitest** | `npm test`: "Test Files 14 passed (14), Tests 250 passed (250)" (28.14s). Desglose por archivo en `TEST_RESULTS_FINAL.md`. | ✅ VERIFICADO |
| **26 tests Playwright** | `npx playwright test`: 26 passed (1.3m) — smoke 8 + a11y 5 + multifile 2 + indexeddb 2 + mapping 1 + pwa 4 + @perf 3 + standalone 1 | ✅ VERIFICADO |
| **Total 276 tests, 0 skip** | 250 + 26 = 276. Sin `it.fails`/`.skip`/`xit`/`todo` (grep: 0 ocurrencias). Piso estático verificado por el validator. | ✅ VERIFICADO |
| **M-01 CSV Formula Injection** | `app.js` FORMULA_PREFIXES `/^[=+\-@]/` en exportToCsv + `tests/unit/csv_injection.test.js` (17 tests). Standalone reconstruido: probe FORMULA_PREFIXES presente (verificado por build + E2E). | ✅ VERIFICADO |
| **M-02 innerHTML/XSS** | Interpolaciones dinámicas vía `escapeHtml`/`escapeAttr` (`_viewerRowCellsHtml`, renderMappingTable, etc.) + `tests/unit/escape_html.test.js` (24 tests) + axe-core sin violaciones | ✅ VERIFICADO |
| **M-03 Web Worker** | `worker.js` (135 líneas) + `new Worker('worker.js')` en ui.js + E2E FASE 3: 2 archivos de CADA tipo procesados EN EL WORKER, sin warnings de fallback, 02_VolumenDetalle=1486 y 09_VolumenSinHorasDetalle=490 | ✅ VERIFICADO |
| **M-04 Backup automático** | `idbBackupDecisions`/`idbRestoreDecisions` + E2E FASE 9: borrar localStorage y recuperar DESDE IndexedDB tras reload, con integridad del hash chain verificada | ✅ VERIFICADO |
| **M-05 Virtual scrolling** | `VIEWER_THRESHOLD=200`, `VIEWER_ROW_HEIGHT=32`, `_viewerRenderWindow` + E2E @perf: tabla de 743 filas renderizada en <5s con DOM <300 nodos | ✅ VERIFICADO |
| **M-06 Unit tests** | 12 archivos unit (225 tests) cubriendo fx_*, calcularMaterialidad, numberFrom, csv_injection, escape_html, regression_bugs, performance, smoke, audit_log_chain (P9), input_validation (P9) | ✅ VERIFICADO |
| **M-07 Pestaña Mapping CRUD** | `setupMappingTab`, `initMappingData` (corregida regresión M-07/M-10), CRUD + export/import + E2E FASE 10: visualización 167 filas, búsqueda selectiva, filtros, crear/editar/borrar, duplicados, ambigüedades, audit log íntegro | ✅ VERIFICADO (tras corregir regresión detectada en P9) |
| **M-08 Auto-advance** | `#auto-advance-toggle` + persistencia localStorage `spec_auto_advance` + navegación automática tras decisión | ✅ VERIFICADO |
| **M-09 Filtros** | 6+ filtros en Revisar (search, date-from, date-to, sección, decisión, confianza, turno, sort) + búsqueda global + viewer-search. Turno documentado como informativo (inputs sin hora). | ✅ VERIFICADO (turno documentado como limitación) |
| **M-10 Multiarchivo** | Atributo `multiple` en 4 inputs + `loadFiles` + E2E 2 archivos por CADA tipo en Worker | ✅ VERIFICADO |
| **M-11 CSP/security** | Meta CSP (sin unsafe-eval, sin frame-ancestors en meta), X-Content-Type-Options, Referrer-Policy + **standalone con CSP por hashes SHA-256** de cada script inline + E2E 0 console errors | ✅ VERIFICADO (HSTS/X-Frame-Options/Permissions-Policy son headers del servidor — documentado, NO afirmados como presentes) |
| **M-12 IndexedDB** | `spec_decisions_db` store `decisions` + E2E FASE 9 ciclo completo | ✅ VERIFICADO |
| **M-13 TypeScript** | **0 archivos `.ts`** — NO IMPLEMENTADA, decisión documentada (riesgo arquitectónico multi-sesión) | ❌ NO IMPLEMENTADO (documentado) |
| **M-14 CI/CD** | `.github/workflows/ci.yml` 9 jobs — **YAML corregido en P9** (antes no-parseable) y validado con parser YAML real; validator ahora bloquea regresiones | ✅ VERIFICADO (tras corrección P9) |
| **M-15 PWA** | `manifest.json` + `sw.js` + `sw-register.js` + E2E FASE 14: manifest válido servido, SW ACTIVO, caché spec-web-v6 con 10+ recursos core, **funcionamiento OFFLINE completo** (DOM funcional, SheetJS cargado, SPEC global disponible sin red) | ✅ VERIFICADO |
| **Equivalencia 14/14 tablas** | `node scripts/07_test_equivalencia_valores.cjs`: 14/14, mismatches=0, issues=[] + `npm run test:integration`: 21/21 (T-01+T-02) | ✅ VERIFICADO |
| **74.672 celdas comparadas** | Cálculo automático del script de equivalencia (74672) + recuento independiente `_cell_count.cjs` (74672). "74.172" es typo histórico AUD-MED-001. | ✅ VERIFICADO |
| **Audit log SHA-256** | `calcularEntryHash` (Web Crypto, sin fallback FNV — lanza si no hay crypto.subtle) + `tests/unit/audit_log_chain.test.js` (22 tests): 6 escenarios de manipulación TODOS detectados | ✅ VERIFICADO |
| **Validación de entradas** | `validarArchivoEntrada` + `validarWorkbook` + fx_Transforma* + `tests/unit/input_validation.test.js` (24 tests): vacío/corrupto/columnas/grande/malformado rechazados | ✅ VERIFICADO |
| **SBOM CycloneDX** | `sbom.json` CycloneDX 1.4, 327 componentes, xlsx@0.18.5 — correspondencia con package-lock verificada | ✅ VERIFICADO |
| **SheetJS 0.18.5 vulnerable** | GHSA-4r6h-8v6p-xvw6 + GHSA-5pgg-2g8v-p4x9. Actualización a 0.20.3 probada y REVERTIDA (rompe equivalencia 5/14 tablas). Mitigación: 50MB + validación + offline. | ⚠️ RIESGO RESIDUAL ACEPTADO (no eliminado) |
| **Accesibilidad WCAG 2.1 AA** | `npm run test:a11y`: 5/5 pasan (0 violaciones críticas), navegación por teclado y dark mode probados | ✅ VERIFICADO |
| **Rendimiento** | `npm run test:perf` (suite P9): análisis 4 archivos <30s (2.3s real), render 743 filas <5s (2.9s real), sin degradación en segunda pasada | ✅ VERIFICADO |
| **Standalone single-file** | `SPEC_AUTONOMO_v6.html` reconstruido desde v6.0 real (era motor antiguo — hallazgo P9). E2E: AppVersion correcto, mejoras embebidas, 214 propuestas, audit SHA-256, CSP por hashes | ✅ VERIFICADO (tras reconstrucción P9) |
| **R-01 a R-21 riesgos** | Ver `REGISTRO_RIESGOS_FINAL.md`: 7 ELIMINADOS, 8 MITIGADOS, 5 ACEPTADOS (4 diseño + 1 residual), 1 NO VERIFICABLE, 0 ABIERTOS | ✅ VERIFICADO |

## Resumen

| Categoría | Cantidad | Estado |
|-----------|----------|--------|
| Afirmaciones verificadas con evidencia física ejecutada | 25 | ✅ VERIFICADO |
| Afirmaciones con riesgo residual documentado | 1 (SheetJS CVEs) | ⚠️ ACEPTADO |
| Afirmaciones NO implementadas (documentadas) | 1 (M-13 TypeScript) | ❌ NO IMPLEMENTADO |

## Correcciones aplicadas por la auditoría de certificación P9

| Defecto detectado | Acción correctiva | Evidencia |
|-------------------|-------------------|-----------|
| Regresión M-07/M-10: pestaña Mapping VACÍA tras flujo multi-archivo | `initMappingData` soporta array + fusión de workbooks | E2E mapping.spec.js PASS |
| Standalone = motor antiguo renombrado (sin M-01/SHA-256/R-06/M-04/M-05) | Reconstruido con `06_build_autonomo.py` (probes obligatorios) + CSP por hashes | E2E standalone.spec.js PASS |
| CI YAML inválido (npm audit con `: ` sin quote) | Comando entrecomillado; validado con parser YAML | 9 jobs OK |
| `npm run test:perf` ejecutaba 0 tests | Suite @perf creada (3 tests) | 3/3 PASS |
| Scripts con rutas absolutas del entorno original (5 JS + 6 Python) | Convertidos a rutas relativas | Ejecutados desde instalación limpia |
| Tests de manipulación del audit log inexistentes | `audit_log_chain.test.js` (22 tests, 6 escenarios) | 22/22 PASS |
| Tests de validación de entrada inexistentes | `input_validation.test.js` (24 tests) | 24/24 PASS |
| Tests E2E de IndexedDB/Mapping/PWA inexistentes | 3 specs nuevos (7 tests) | 7/7 PASS |
| Validator con checks muertos (cifras viejas no fallaban) | Checks activados + piso estático + guards CI/@perf/M-07 | Validator falla ante contradicciones (demostrado) |
| Cifras obsoletas en docs (206/219/80/77/92) | Regeneradas desde la última ejecución real | Este documento + TEST_RESULTS_FINAL.md |
| CHANGELOG.md vacío (0 bytes) | Changelog real escrito | docs/CHANGELOG.md |
