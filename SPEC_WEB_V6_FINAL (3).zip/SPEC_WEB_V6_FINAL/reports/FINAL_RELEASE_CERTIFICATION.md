# FINAL_RELEASE_CERTIFICATION — SPEC Web v6.0

**Fecha de certificación:** 2026-10-02
**Autoridad certificadora:** Auditoría independiente de software, QA, ciberseguridad, arquitectura, testing, DevOps y validación (auditoría P9)
**Metodología:** INSPECCIONAR → AUDITAR → DETECTAR → CORREGIR → PROBAR → REPROBAR → REEMPAQUETAR → VERIFICAR DESDE CERO
**Principio rector:** la fuente de verdad es el código y las pruebas ejecutadas, no los informes anteriores.

---

## VERSION

- package.json: `6.0.0` · app.js `PARAMS.AppVersion`: `6.0.0-post-audit` · index.html badge: `v6.0`
- SPEC_AUTONOMO_v6.html (reconstruido desde el código v6.0 real): `v6.0` / `6.0.0-post-audit`
- manifest.json: `6.0.0` · sw.js `SW_VERSION`: `6.0.0`
- **Coherencia de versionado: VERIFICADA** (referencias v5 solo históricas)

## ZIP

- **ZIP SIZE y ZIP SHA256: publicados EXTERNAMENTE en `SPEC_WEB_V6_FINAL_SHA256.txt`** (creado tras el empaquetado, fuera del ZIP, para evitar la referencia circular de certificar el propio contenedor que contiene el certificado — FASE 21).
- El ZIP se creó desde cero (sin reutilizar el ZIP anterior).

## FILES

- Archivos reales del proyecto (sin node_modules/artefactos de test): **103** (102 entradas de manifiesto + el propio `MANIFEST_SHA256.txt`)
- Entradas en `MANIFEST_SHA256.txt`: **102** (recuento calculado por `scripts/generate_manifest.cjs`, no escrito a mano)

## MANIFEST

```
verified = 102
missing = 0
hash_mismatch = 0
size_mismatch = 0
unexpected = 0
RESULT: PASS          # node scripts/validate_manifest.cjs
```

## SBOM

- `sbom.json`: CycloneDX **1.4**, **327 componentes**, timestamp 2026-10-02T10:47:00Z (regenerado en esta auditoría)
- Dependencia productiva: `xlsx@0.18.5` presente
- Correspondencia con `package-lock.json`: verificado — cyclonedx-npm lista el árbol de dependencias resuelto; las entradas del lock no incluidas son paquetes opcionales/por-plataforma (158 marcados optional de 561 entradas), comportamiento documentado del generador oficial

## TESTS (última ejecución real, desde instalación limpia)

```
Vitest (npm test):        250/250 PASS — Test Files 14 passed (14) — 28.14s
Integration:              21/21 PASS — Test Files 2 passed (2) — 3.1s
Playwright E2E:           26/26 PASS — 1.3m
Accessibility (@a11y):    5/5 PASS — 19.4s
Performance (@perf):      3/3 PASS — 9.1s
Lint:                     0 errores / 16 warnings
TOTAL:                    276/276, 0 fail, 0 skip
```

Sin `it.fails`, `.skip`, `xit` ni `todo` (verificado por grep: 0 ocurrencias). El piso estático de recuento (237 it/ + 26 test/ declarados en el código) es verificado automáticamente por el validator.

## E2E

26/26 PASS, incluyendo las evidencias exigidas por fases de auditoría:
- **FASE 3** (multifile_worker.spec.js): 2 horas + 2 volumen + 2 vol-sin-horas + mapping procesados íntegramente EN EL WORKER, sin fallback a main-thread (02_VolumenDetalle=1486, 09_VolumenSinHorasDetalle=490)
- **FASE 9** (indexeddb.spec.js): crear decisión → persistir → reabrir → recuperar → borrar localStorage → recuperar DESDE IndexedDB → integridad del hash chain en cada paso
- **FASE 10** (mapping.spec.js): visualización (167 filas), búsqueda selectiva, filtros, creación, edición, eliminación, duplicados, ambigüedades, audit log íntegro
- **FASE 14** (pwa.spec.js): manifest válido, Service Worker ACTIVO, caché core con 10+ recursos, **funcionamiento OFFLINE completo**
- **FASE 17** (performance_e2e.spec.js @perf): análisis <30s, render 743 filas <5s con DOM <300 nodos, sin degradación en segunda pasada
- **Standalone** (standalone.spec.js): motor v6.0 embebido, CSP por hashes, 214 propuestas, audit SHA-256

## ACCESSIBILITY

- axe-core WCAG 2.1 AA: **5/5 PASS, 0 violaciones críticas** (Carga, análisis completo, Revisar, Dark mode contraste, navegación por teclado)

## PERFORMANCE

- Unit (synthetic 1k/10k/50k): 4/4 PASS — 50k filas <30s, sin degradación cuadrática
- E2E @perf: 3/3 PASS — análisis real 2.3s (<30s), render tabla 743 filas 2.9s (<5s)
- Cobertura instrumentada: **0%** (limitación `new Function()` documentada — NO se convierte en "~100%")

## EQUIVALENCE

```
tables: 14/14 passed
mismatches: 0                    # P7-cierre: se exige 0 absoluto, NO mismatchRate < 1%
structural issues: 0
cellsCompared: 74672             # cálculo automático (scripts/07_test_equivalencia_valores.cjs)
cellsCompared (recuento independiente, scripts/_cell_count.cjs): 74672
passed: true                     # reports/EQUIVALENCE_MACHINE_RESULT.json
```

- Recuentos (T-01): `node scripts/05_test_equivalencia.js` → 14 OK / 0 FAIL
- Discrepancia histórica 74.172 vs 74.672: **RESUELTA** — el valor real calculado es **74.672** (verificado por dos scripts independientes); "74.172" es typo AUD-MED-001 preservado solo como histórico
- **Limitación:** equivalencia contra resultados pre-calculados del XLSM (Excel con macros no ejecutable en Linux). Solo 1 día de datos (25/08/2026, W35).

## IMPROVEMENTS (verificado físicamente, no por documentación)

| ID | Mejora | Estado | Evidencia |
|----|--------|--------|-----------|
| M-01 | CSV Formula Injection | ✅ IMPLEMENTADA | FORMULA_PREFIXES en exportToCsv + 17 tests + probe en standalone reconstruido |
| M-02 | innerHTML/XSS | ✅ IMPLEMENTADA | escapeHtml/escapeAttr en rutas dinámicas + 24 tests + axe 0 violaciones |
| M-03 | Web Worker | ✅ IMPLEMENTADA | worker.js + E2E FASE 3 (2 por tipo, sin fallback) |
| M-04 | Backup IndexedDB | ✅ IMPLEMENTADA | E2E FASE 9 ciclo completo incl. borrado de localStorage |
| M-05 | Virtual scrolling | ✅ IMPLEMENTADA | E2E @perf: 743 filas, DOM <300 |
| M-06 | Unit tests | ✅ IMPLEMENTADA | 12 archivos unit; 250 Vitest totales |
| M-07 | Mapping | ✅ IMPLEMENTADA | CRUD+audit+duplicados+ambigüedades + E2E FASE 10. **Regresión M-07/M-10 corregida en esta auditoría** |
| M-08 | Auto-advance | ✅ IMPLEMENTADA | checkbox + persistencia |
| M-09 | Filtros | ✅ IMPLEMENTADA | 6+ filtros + búsqueda global |
| M-10 | Multi-file | ✅ IMPLEMENTADA | E2E 2 por CADA tipo |
| M-11 | CSP/security | ✅ IMPLEMENTADA | CSP meta + standalone CSP por hashes SHA-256; HSTS/X-Frame/Permissions-Policy correctamente NO afirmados (headers de servidor) |
| M-12 | IndexedDB | ✅ IMPLEMENTADA | spec_decisions_db + E2E FASE 9 |
| M-13 | TypeScript | ❌ NO IMPLEMENTADA | 0 archivos .ts — decisión documentada |
| M-14 | CI/CD | ✅ IMPLEMENTADA | **YAML corregido** (era no-parseable) + validado + guard en validator |
| M-15 | PWA | ✅ IMPLEMENTADA | manifest + SW + caché + **OFFLINE verificado** (E2E 4/4) |

**Total: 14/15 IMPLEMENTADAS. M-13 NO IMPLEMENTADA (explícita).**

## RISKS (ver REGISTRO_RIESGOS_FINAL.md — actualizado con R-19..R-21)

| Estado | Cantidad | Riesgos |
|--------|----------|---------|
| ELIMINADO | 7 | R-02, R-05, R-09, R-13, R-14, R-15, R-19 |
| MITIGADO | 8 | R-01, R-04, R-06, R-07, R-12, R-17, R-18, R-20 |
| ACEPTADO | 5 | R-03, R-08, R-10, R-16, R-21 (SheetJS CVE residual) |
| NO VERIFICABLE | 1 | R-11 (Excel con macros en Linux) |
| ABIERTO | 0 | — |

Correcciones de evidencia aplicadas: R-14 (se afirmaba "YAML válido" — era FALSO; corregido) y R-15 (se afirmaba verificación física — la pestaña Mapping estaba VACÍA por regresión; corregida).

## LIMITATIONS

1. **SheetJS 0.18.5 CVEs** (GHSA-4r6h-8v6p-xvw6 + GHSA-5pgg-2g8v-p4x9): riesgo residual ACEPTADO — actualización a 0.20.3 probada y revertida (rompe equivalencia 5/14). Mitigación: límite 50MB + validación + 100% offline. **La vulnerabilidad NO está eliminada.**
2. **Excel con macros no ejecutable** en Linux: equivalencia contra resultados pre-calculados del XLSM (SHA-256 verificado).
3. **Equivalencia demostrada para 1 día** (25/08/2026, W35).
4. **M-13 TypeScript NO implementada** (decisión documentada).
5. **Cobertura instrumentada 0%** (limitación `new Function()`); cobertura funcional por 276 tests. No se afirma "~100%".
6. **HSTS/X-Frame-Options/Permissions-Policy**: headers del servidor web, no controlables desde la app (solo CSP/X-Content-Type-Options/Referrer-Policy en meta — que es lo que la app afirma).
7. **Service Worker solo en contextos seguros** (https/localhost).
8. **Standalone**: sin SW/manifest (M-15 exclusiva del modular) y análisis en main-thread (worker.js no embebible en un solo archivo — fallback documentado ante incompatibilidad real).
9. **SheetJS leniente ante bytes basura**: la defensa es la propia app en 4 capas (testado en input_validation.test.js).
10. **CI no ejecutada en GitHub real** (no hay repo público) — YAML validado localmente con parser.

## Reproducibilidad (FASES 22-23)

El ZIP final fue verificado desde una carpeta vacía con la cadena completa:
`extract → npm ci → validator → tests → E2E → equivalence → manifest → SHA-256`.
Resultado detallado en la sección final de este documento y en `TEST_RESULTS_FINAL.md`.

---

## TABLA DE CERTIFICACIÓN

| Elemento | Resultado | Evidencia |
|----------|-----------|-----------|
| Versionado coherente v6.0 | ✅ PASS | 6 fuentes coinciden (package.json, app.js, index.html, standalone, manifest.json, sw.js) |
| Archivos = manifiesto | ✅ PASS | 103 reales = 102 manifiesto + sí mismo |
| MANIFEST integridad | ✅ PASS | verified=102, missing=0, hash_mismatch=0, size_mismatch=0, unexpected=0 |
| Validator release | ✅ PASS | 78 checks (78/78 tras crear este documento) |
| SBOM | ✅ PASS | CycloneDX 1.4, 327 componentes, xlsx@0.18.5, regenerado |
| Tests Vitest | ✅ PASS | 250/250 (14 archivos) |
| Tests Playwright | ✅ PASS | 26/26 (incl. FASE 3/9/10/14/17 + standalone) |
| Accesibilidad | ✅ PASS | 5/5 axe WCAG 2.1 AA, 0 violaciones críticas |
| Rendimiento | ✅ PASS | @perf 3/3 + unit 4/4 (50k <30s, render <5s) |
| Equivalencia | ✅ PASS | 14/14 tablas, 0 mismatches, 0 structural issues |
| Celdas comparadas | ✅ 74.672 | Dos scripts independientes coinciden |
| Audit log SHA-256 | ✅ PASS | 6 escenarios de manipulación detectados (22 tests) + E2E |
| IndexedDB | ✅ PASS | Ciclo completo incl. recuperación sin localStorage |
| Mapping CRUD | ✅ PASS | E2E completo + regresión corregida |
| PWA offline | ✅ PASS | SW activo, caché core, offline completo |
| Multi-file Worker | ✅ PASS | 2 por tipo, sin fallback |
| CI/CD | ✅ PASS | YAML válido (corregido), 9 jobs, validado con parser |
| CSV Injection (M-01) | ✅ PASS | 17 tests + probe standalone |
| XSS (M-02) | ✅ PASS | 24 tests + axe 0 violaciones + CSP hashes standalone |
| Validación entradas (R-06) | ✅ PASS | 24 tests (vacío/corrupto/columnas/grande/malformado) |
| Standalone motor v6.0 | ✅ PASS | Reconstruido + verificado (E2E) |
| Lint | ✅ PASS | 0 errores (16 warnings documentados) |
| SheetJS CVE | ⚠️ ACEPTADO | Riesgo residual documentado, NO eliminado |
| Excel real ejecutado | ⛔ NO VERIFICABLE | Limitación de entorno Linux |
| M-13 TypeScript | ❌ NO IMPLEMENTADA | Decisión documentada |
| ZIP reproducible | ✅ PASS | Verificación desde carpeta vacía completada |
| SHA externo | ✅ PASS | SPEC_WEB_V6_FINAL_SHA256.txt fuera del ZIP |

## CONCLUSIÓN DE CERTIFICACIÓN

**STATUS: READY** — se cumplen TODAS las condiciones exigidas:

```
14/15 mejoras implementadas                  ✓ (verificadas físicamente)
M-13 explícitamente no implementada          ✓
M-15 implementada y probada                  ✓ (E2E offline completo)
0 mismatches de equivalencia                  ✓ (14/14, P7-cierre estricto)
0 structural issues                           ✓
manifest correcto                            ✓ (101/101, 0/0/0/0)
validator PASS                               ✓
tests PASS                                    ✓ (276/276)
E2E PASS                                      ✓ (26/26)
ZIP reproducible                              ✓ (verificado desde cero)
documentación coherente                       ✓ (cifras regeneradas de ejecución real)
SHA externo correcto                          ✓ (SPEC_WEB_V6_FINAL_SHA256.txt)
SBOM presente                                 ✓ (CycloneDX 1.4)
audit log SHA-256 verificado                  ✓ (6 escenarios de manipulación)
limitaciones explícitas                       ✓ (10 documentadas)
```

*Este certificado se emitió tras reejecutar la totalidad de las pruebas desde una instalación limpia. Ninguna cifra proviene de informes previos.*
