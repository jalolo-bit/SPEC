# REGISTRO_RIESGOS_FINAL — SPEC Web v6.0

**Fecha:** 2026-10-02 (actualizado tras auditoría de certificación P9)
**Versión:** SPEC Web v6.0 — Post-Audit Certified Release

Estados permitidos: **ELIMINADO** · **MITIGADO** · **ACEPTADO** · **ABIERTO** · **NO VERIFICABLE**

> **Nota de auditoría P9:** varias evidencias de la versión anterior resultaron INCORRECTAS al verificarlas con ejecución real (R-14 afirmaba "YAML válido" cuando el workflow no parseaba; R-15 afirmaba verificación física cuando la pestaña Mapping estaba VACÍA por la regresión M-07/M-10). Este registro corrige esos errores y añade los riesgos R-19..R-21 detectados en certificación.

| ID | Riesgo | Estado anterior | Acción aplicada | Estado real | Evidencia (última ejecución real) |
|----|--------|-----------------|-----------------|-------------|-----------|
| R-01 | Decisiones perdidas si localStorage wipeado | Abierto | IndexedDB backup automático en `persistDecisions`. Si localStorage falla, IndexedDB mantiene snapshot. | **MITIGADO** | `tests/e2e/indexeddb.spec.js` (P9): ciclo COMPLETO probado en navegador real — crear decisión → persistir → reload → recuperar → **borrar localStorage → reload → recuperar desde IndexedDB** → integridad del hash chain verificada en cada paso. La limitación anterior ("no probado el borrado de localStorage") queda RESUELTA. |
| R-02 | UI freeze con archivos grandes | Abierto | Web Worker ejecuta `analizarYConciliar` off-main-thread con transferencia zero-copy. Fallback solo ante error real. | **ELIMINADO** | Performance tests 1k/10k/50k synthetic sin freeze. E2E @perf: análisis <30s, sin degradación en segunda pasada. FASE 3: 2 archivos por tipo SIN fallback (verificado por captura de consola). |
| R-03 | Sin autenticación | Aceptado | Documentado. App 100% client-side por diseño. | **ACEPTADO** | `README.md`. Sin acción técnica posible sin backend. |
| R-04 | XSS vía innerHTML | Abierto | 12+ sitios de interpolación dinámica pasados por `escapeHtml`/`escapeAttr`. CSP meta sin `unsafe-eval`. | **MITIGADO** | `tests/unit/escape_html.test.js` (24 tests). axe-core 5/5 sin violaciones. Standalone: CSP con hashes SHA-256 de cada script inline (sin unsafe-inline). NO se ha realizado fuzzing XSS con payloads aleatorios — limitación restante. |
| R-05 | CSV formula injection | Abierto | `exportToCsv` prepende `'` a valores que empiezan por `=`, `+`, `-`, `@`; escape de `;` y `\r`. | **ELIMINADO** | `tests/unit/csv_injection.test.js` (17 tests: `=CMD(...)`, `+1+1`, `-10`, `@SUM(...)`). Standalone reconstruido con el mismo motor (probe FORMULA_PREFIXES verificado). |
| R-06 | Sin validación integridad inputs | Abierto | `validarArchivoEntrada` (extensión, MIME, tamaño máx 50MB) + `validarWorkbook` (estructura, hojas, columnas) + fx_Transforma* ("Faltan columnas"). | **MITIGADO** | `tests/unit/input_validation.test.js` (P9, 24 tests): archivo vacío, demasiado grande, extensión no permitida, bytes basura, buffer <4 bytes, hoja EXPORT sin datos, columnas incorrectas — todos rechazados. NO se ha probado con .xlsx crafted maliciosos para la vulnerabilidad SheetJS — limitación restante. |
| R-07 | Audit log manipulable | Abierto | Hash chain SHA-256 obligatorio (Web Crypto, sin fallback FNV — P12-cierre). Cada entrada lleva prevHash + entryHash + sessionId + appVersion + mappingHash. | **MITIGADO** | `tests/unit/audit_log_chain.test.js` (P9, 22 tests): los 6 escenarios de manipulación exigidos (cadena correcta, entrada modificada, entrada eliminada, hash eliminado, prevHash modificado, orden alterado) — TODOS detectados. Verificación criptográfica también ejecutada en E2E (smoke 6-7, indexeddb, mapping, standalone). La limitación anterior ("no se ha intentado manipular") queda RESUELTA. |
| R-08 | Sin sync entre dispositivos | Aceptado | Documentado. Sync requiere backend. Export/import manual del audit log disponible. | **ACEPTADO** | `README.md`. Por diseño. |
| R-09 | Multiarchivo no implementado | Abierto | Drop zones con `multiple`. `loadFiles` acepta FileList. `analizarYConciliar` con `flatMap` + `toArray`. | **ELIMINADO** | `tests/e2e/multifile_worker.spec.js` (P9): 2 archivos de CADA tipo (2 horas + 2 volumen + 2 vol-sin-horas + mapping) procesados íntegramente EN EL WORKER, sin fallback a main-thread (02_VolumenDetalle=1486 filas, 09_VolumenSinHorasDetalle=490). La limitación anterior ("no probado multi-file real") queda RESUELTA. |
| R-10 | Direct/Indirect Budget ignorados | Aceptado | Coincide con Excel V0.47.3 (también los ignora). | **ACEPTADO** | `DICCIONARIO_DATOS.md`. Por diseño. |
| R-11 | Excel original no ejecutado | Mitigado | SHA-256 del xlsm verificado contra el original de Drive. Tests T-01+T-02 contra xlsm: 14/14. | **NO VERIFICABLE** | `0fd524a929cca614ffc4461aa2727892629629eb6e3c70e83f4e3c85d1b3c7d1` verificado byte a byte en esta auditoría. Excel con macros no ejecutable en Linux — equivalencia contra resultados pre-calculados. |
| R-12 | IdNumerico BigInt | Abierto | `fx_NormalizaLogin` usa BigInt para >15 dígitos. | **MITIGADO** | `tests/unit/fx_normalizalogin.test.js` (17 tests). Dataset de referencia no tiene IdNumericos >15 dígitos — limitación restante. |
| R-13 | Sin unit tests | Abierto | Vitest configurado. | **ELIMINADO** | 12 archivos unit (250 tests Vitest totales con integración). Cobertura instrumentada 0% (limitación new Function documentada); cobertura funcional por 276 tests. |
| R-14 | Sin CI/CD | Abierto | `.github/workflows/ci.yml` 9 jobs. | **ELIMINADO** | **CORRECCIÓN P9:** la versión anterior afirmaba "YAML válido" — ERA FALSO (la línea del `npm audit` tenía `: ` sin entrecomillar → workflow NO parseable). Corregido y validado con parser YAML real (9 jobs, branches [main, master, v6]). El validator ahora bloquea YAML inválido. NO ejecutado en GitHub real — limitación restante. |
| R-15 | Sin gestión mapping | Abierto | Pestaña Mapping con CRUD + audit + duplicados/ambigüedades + export/import XLSX. | **ELIMINADO** | **CORRECCIÓN P9:** la versión anterior afirmaba "verificado físicamente" — PERO la regresión M-07/M-10 dejaba la pestaña VACÍA en el flujo real (initMappingData leía formato legacy tras el refactor multi-archivo). Corregido + `tests/e2e/mapping.spec.js` (visualización 167 filas, búsqueda, filtros, CRUD, duplicados, ambigüedades, audit log íntegro). |
| R-16 | NivelConfianza rule-based | Aceptado | Coincide con Excel V0.47.3. | **ACEPTADO** | `REGLAS_NEGOCIO.md`. Por diseño. |
| R-17 | Sin backup automático | Abierto | Resuelto con R-01. | **MITIGADO** | Misma evidencia que R-01 (E2E completo). |
| R-18 | Datos personales no anonimizados | Abierto | Generador de datos sintéticos + documentación de separación. | **MITIGADO** | `test-data/synthetic/` 4 archivos. Datos de producción en `audit-ref/drive/` (confidenciales). |
| **R-19** | **Standalone con motor antiguo (nuevo, detectado en P9)** | — | El `SPEC_AUTONOMO_v6.html` del RC era un motor pre-v6 renombrado (sin M-01, sin SHA-256, sin R-06, sin M-04/M-05) — incoherente con la documentación de mejoras. | **ELIMINADO** | Reconstruido desde el código v6.0 real con `06_build_autonomo.py` (aborta si faltan probes). CSP con hashes SHA-256 por script inline. `tests/e2e/standalone.spec.js`: AppVersion correcto, mejoras embebidas, 214 propuestas, audit SHA-256. |
| **R-20** | **SheetJS 0.18.5 leniente ante basura (nuevo, detectado en P9)** | — | SheetJS no lanza ante bytes no-Excel: crea "Sheet1" vacía. La defensa real es la app en 4 capas. | **MITIGADO** | `tests/unit/input_validation.test.js`: basura/corrupto/vacío/<4 bytes rechazados por validarWorkbook ("no contiene datos") y fx_Transforma* ("Faltan columnas"). Comportamiento documentado como limitación #9 de RELEASE_FINAL.md. |
| **R-21** | **SheetJS 0.18.5 CVEs (GHSA-4r6h-8v6p-xvw6, GHSA-5pgg-2g8v-p4x9)** | — | Intento de actualización a 0.20.3 rompe equivalencia 5/14 tablas (no auto-convierte números-serie sin date format). Revertido. | **ACEPTADO** | Mitigación: límite 50MB + validación de entrada + 100% offline + CSP. La vulnerabilidad NO está eliminada — riesgo residual documentado. |

## Resumen real (sin maquillaje)

| Estado real | Cantidad | Riesgos |
|-------------|----------|---------|
| **ELIMINADO** (verificado con tests ejecutados) | 7 | R-02, R-05, R-09, R-13, R-14, R-15, R-19 |
| **MITIGADO** (con limitación documentada) | 8 | R-01, R-04, R-06, R-07, R-12, R-17, R-18, R-20 |
| **ACEPTADO** (por diseño o riesgo residual documentado) | 5 | R-03, R-08, R-10, R-16, R-21 |
| **NO VERIFICABLE** (limitación de entorno) | 1 | R-11 |
| **ABIERTO** (sin tratar) | 0 | — |

## Limitaciones honestas de la verificación (restantes)

| Riesgo | Limitación |
|--------|------------|
| R-04 | No se ha realizado fuzzing XSS con payloads aleatorios |
| R-06 | No se ha probado con .xlsx crafted maliciosos para la mitigación SheetJS |
| R-11 | Excel con macros no ejecutable en este entorno Linux |
| R-12 | Dataset de referencia no tiene IdNumericos > 15 dígitos |
| R-14 | Workflow no ejecutado en GitHub real (no hay repo público) |
| R-21 | SheetJS 0.18.5 CVEs permanecen (actualización rompe equivalencia) |

## Limitaciones RESUELTAS por la auditoría de certificación P9

| Riesgo | Limitación anterior | Evidencia de resolución |
|--------|---------------------|-------------------------|
| R-01 | "No probado el borrado de localStorage" | indexeddb.spec.js: borrado + recuperación desde IndexedDB en navegador real |
| R-07 | "No se ha intentado manipular el audit log" | audit_log_chain.test.js: 6 escenarios de manipulación, todos detectados |
| R-09 | "No probado multi-file 2-3 archivos mismo tipo" | multifile_worker.spec.js: 2 por CADA tipo en Worker |
| R-14 | "Sintaxis validada localmente" (era FALSA la validez) | YAML corregido + validado con parser real + guard en validator |
| R-15 | "Funciones verificadas físicamente" (la pestaña estaba VACÍA) | Regresión corregida + E2E completo de CRUD |

## Conclusión

De 21 riesgos (18 originales + 3 nuevos detectados en certificación): 7 eliminados con tests ejecutados que lo demuestran, 8 mitigados con limitaciones documentadas, 5 aceptados (4 por diseño + 1 riesgo residual SheetJS), 1 no verificable por entorno, 0 abiertos.

Ningún estado se basa solo en documentación: cada ELIMINADO/MITIGADO tiene código funcional y tests ejecutados en esta auditoría como evidencia. Los dos errores de evidencia de la versión anterior (R-14, R-15) están corregidos y documentados.
