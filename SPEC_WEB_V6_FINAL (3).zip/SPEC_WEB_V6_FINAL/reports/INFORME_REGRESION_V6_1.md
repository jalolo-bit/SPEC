# INFORME DE REGRESIÓN — SPEC Web v6.1 / v6.1.1

**Fecha:** 2026-10-02 · **Base:** SPEC Web v6.0 certificada (276 tests) · **Iteración:** v6.1 (6 mejoras funcionales/analíticas) + **v6.1.1** (corrección y cierre de 2 puntos funcionales)

Este informe documenta la batería de regresión completa ejecutada tras implementar las 6 mejoras de la iteración v6.1, siguiendo el criterio del usuario: *"No romper ninguna funcionalidad que actualmente funciona. No eliminar las pruebas existentes. Después de implementar todas las mejoras: ejecutar la batería completa existente."*

---

## 1. Estrategia de no-regresión

1. **Inmunidad de equivalencia:** ninguna de las consultas 01–16 ni el `REPORTE_CAMBIOS_HR` se ha modificado. La nueva consulta `17_PersonaDiaAnalitica` y el estado `personaDiaRecords` son **aditivos** (el test de equivalencia compara la estructura de columnas de cada tabla — añadir columnas a tablas existentes habría roto 14/14, por eso no se hizo).
2. **Tests previos conservados:** los 250 tests Vitest y 26 Playwright de v6.0 se mantienen; solo se **adaptaron selectores** donde la MEJORA 2 (unificación de pestañas, pedida explícitamente) los invalidaba de forma inevitable: `data-tab="proceso"` → `data-tab="cargaanalizar"` (9 referencias en 6 archivos), `tab-carga/tab-proceso` → tabulación actual en a11y, versión esperada `6.0.0-post-audit` → `6.1.0`, recuento de tablas 13 → 14 (la nueva query), y `.first()` en clicks de ACEPTAR (la vista persona/día puede mostrar varias incidencias).
3. **Batería final:** lint + Vitest completo + Playwright completo (todas las suites) + equivalencia + validadores.

## 2. Resultados de la batería final (ejecución real, 2026-10-02)

| Batería | Resultado | Detalle |
|---|---|---|
| `npm run lint` | ✅ PASS | 0 errors (23 warnings de estilo preexistentes: `no-unused-vars` heredados) |
| `npm test` (Vitest) | ✅ **339/339** | 20 archivos: 250 v6.0 + 89 nuevos v6.1, 0 fail, 0 skip |
| `npx playwright test` | ✅ **34/34** | 26 v6.0 (selectores adaptados) + 8 nuevos E2E v6.1, en 2 lotes |
| `npm run test:a11y` | ✅ 5/5 | axe-core WCAG 2.1 AA: claro, oscuro, teclado, foco, tablist |
| `npm run test:perf` | ✅ 3/3 | @perf reales (latencia + no-degradación; sin fuga cuadrática con las mejoras activas) |
| Equivalencia (`07_test_equivalencia_valores.cjs`) | ✅ **14/14 tablas · 0 mismatches · 74.672 celdas** | Intacta; JSON estructurado regenerado |
| `validate_manifest.cjs` | ✅ PASS | 116 verificados, missing=0, hash=0, size=0, unexpected=0 |
| `validate_release.cjs` | ✅ PASS | 78/78 checks |

## 3. Tests nuevos de la iteración (89 unitarios + 8 E2E)

| Archivo | Tests | Cubre |
|---|---:|---|
| `tests/unit/turnos.test.js` | 27 | MEJORA 1: límites exactos (05:59/06:00/13:59/14:00/21:59/22:00/23:59/00:00), cobertura 1440 min sin huecos, fecha operativa nocturna (incluye cruces de mes y año), extracción de hora de seriales |
| `tests/unit/actividad_analisis.test.js` | 16 | MEJORA 4: reglas explícitas del usuario, AGV/manual, ambiguas→OTRA, robustez (\r\n, dobles espacios), overrides por tarea, productividades |
| `tests/unit/reparto_tiempos.test.js` | 12 | MEJORA 4: ejemplo del usuario (900+520 uds/8h), 1/2/3 actividades, 0 uds, solo-OTRA, mezclas, 1e9 uds, conservación exacta < 1e-9 |
| `tests/unit/persona_dia.test.js` | 15 | MEJORAS 4/6: 2 tareas=UNA revisión, 3 tareas=reparto, claves estables, MIXTO, dedupe de horas, fingerprints, semanas ISO (validadas contra Python) |
| `tests/unit/undo_persist.test.js` | 11 | MEJORA 5: aceptar/rechazar/mantener→undo, acciones consecutivas (bug fix), varios undos mezclados, pureza del núcleo |
| `tests/unit/mapping_persist.test.js` | 8 | MEJORA 3: SHA-256 determinista y sensible a cambios, orden de propiedades, snapshot de hash/productividades en históricos |
| `tests/e2e/mejoras_v6.spec.js` | 8 | Los 8 E2E OBLIGATORIOS del usuario (carga unificada, mapping persistente, cambio de mapping, UNA revisión, reparto, undo, 2 días persistentes, filtro NOCHE) |

## 4. Defectos detectados y corregidos DURANTE la iteración (por los propios tests)

| # | Defecto | Detección | Corrección |
|---|---|---|---|
| D-1 | Bucle infinito de MutationObserver en el checklist de carga (re-entrancia) | Smoke v6.1: la página colgaba en `load` | Guard de re-entrancia + escritura solo si cambia |
| D-2 | La zona unificada heredaba listeners del loop `.drop-zone` original → `loadFiles('unified')` limpiaba el input antes del listener v6.1 | E2E 1: no se cargaba nada | Clase CSS propia `dropzone-unified` |
| D-3 | `undoDecision` restauraba la entrada MÁS ANTIGUA (findIndex) → estados obsoletos con acciones consecutivas | Unit + E2E 6 | Núcleo puro `SPEC.undoApply` (entrada MÁS RECIENTE) |
| D-4 | Doble recuento de horas en `horasConIncidencia` con propuestas múltiples (604h vs 321h reales) | KPIs del smoke | Dedupe por ID REGISTRO (en records y en error de asignación) |
| D-5 | `dataFingerprint` pasaba un string a `calcularMappingHash` (mapea campos de objeto) → TODAS las huellas idénticas | Test unitario "cambian los datos → cambia el fingerprint" | `fnv1aStr` dedicado |
| D-6 | Race: dos análisis consecutivos intercalaban sus upserts de históricos (quedaba el hash del mapping viejo) | E2E 3 (flaky 2 veces) | Cola de persistencia SERIALIZADA `encolarPersistenciaRecords` |
| D-7 | Auto-navegación post-análiso pisaba pestañas visitadas durante el análisis | mapping.spec (fill no visible) | Solo navegar si `UI.activeTab === 'cargaanalizar'` |
| D-8 | `UI.activeTab` inicial conservaba `'carga'` (pestaña eliminada) → la auto-nav nunca disparaba | E2E 1/4/5/6/8 tras el fix D-7 | Inicialización a `'cargaanalizar'` |
| D-9 | 58 violaciones de contraste AA en modo oscuro (colores v6.1 hardcodeados) | a11y dark mode | Bloque v6.1 reescrito con variables temáticas reales |
| D-10 | Records con hash FNV del motor en lugar del SHA-256 del mapping versionado | E2E 3 (hash esperado) | `recomputarPersonaDia` usa `UI.mappingMeta.hash`; el FNV queda para la cadena de auditoría |

**Ninguno de estos defectos existía en la v6.0 certificada** (todos provienen del código nuevo de esta iteración; todos fueron corregidos y quedan cubiertos por tests).

## 5. Compatibilidad verificada explícitamente

- ✅ Equivalencia Excel (14/14/0/74672) — re-ejecutada tras TODOS los cambios.
- ✅ Worker: procesamiento multi-archivo sigue en el Worker (multifile_worker.spec 2/2); la mejora v6.1 solo añade recompute ligero post-done.
- ✅ IndexedDB de decisiones (spec_decisions_db) intacta (2/2) + nueva spec_history_db separada.
- ✅ PWA offline (4/4), sw-register, manifest v6.1 (cache `spec-web-v6-1`).
- ✅ Mapping CRUD + audit log (1/1) + flujo persistente nuevo (E2E 2/3).
- ✅ Exports, audit log SHA-256, accesibilidad, filtros existentes (smoke 8/8, a11y 5/5).
- ✅ Standalone single-file reconstruido con probes v6.1 (CSP por hashes, 14 tablas).

## 6. Limitaciones conocidas de la iteración

1. **Turnos con archivos day-level:** los archivos reales de referencia solo tienen fecha (sin hora) → los persona/día se clasifican `SIN HORA` y no se desplazan fechas. La lógica NOCHE/fecha operativa está implementada y verificada con fixtures con hora real (`test-data/turnos/`). Cuando los export incluyan hora, funcionará sin cambios.
2. **Worker vs recompute:** el Worker calcula `17_PersonaDiaAnalitica` con productividades por defecto; la UI la recalcula inmediatamente con las preferencias del usuario (post-done). Documentado en el código.
3. **Decisiones por id de propuesta:** las decisiones siguen ligadas a `ID_REGISTRO@FILA` de cada procesado (herencia v5); un reprocesado con otros archivos reordena los IDs y las decisiones previas pueden no reaplicarse. Comportamiento preexistente, no agravado.
4. **Playwright waitForFunction asíncrono:** se detectó resolución errónea con predicados async en este entorno; los waits de IDB del E2E 3 usan sondeo desde Node (determinista).

## 7. Conclusión

La iteración v6.1 se integra **sin romper ninguna funcionalidad certificada de v6.0**: 373/373 tests reales PASS, equivalencia 14/14 intacta, validadores PASS, y 10 defectos nuevos detectados y corregidos por la propia batería durante el desarrollo.

---

# APÉNDICE v6.1.1 — Corrección y cierre de dos puntos funcionales (2026-10-02)

**Alcance (petición expresa del usuario, NO auditoría ni funcionalidades nuevas):**

1. **Filtro REAL de turnos en Revisar incidencias** — el select de turno era informativo en la cadena de filtrado (`getFilteredPersonDays` no lo aplicaba). Corregido con la función centralizada `SPEC.filtrarRegistrosPorTurno()` usada en Revisar, Patrones, Persona/Día e históricos. SIN HORA: los registros day-level nunca aparecen al filtrar un turno concreto; aviso explícito «Este registro no contiene hora de fichaje.» en la lista y nueva tabla «Fichajes del día» en el detalle.
2. **PRODUCTIVIDAD POR TAREA (overrides por TASK_WMS)** — existía la lógica interna pero NO interfaz. Nueva sección compacta en ⚙ Productividades de referencia: buscar/seleccionar TASK_WMS, actividad, productividad (> 0 si productiva), guardar, editar, resetear; tabla con columna **Fuente** (DEFAULT / PRODUCTIVIDAD ACTIVIDAD / OVERRIDE TASK_WMS / OTRA). OTRA editable a cualquier actividad productiva.
3. **Motor corregido** — `q17_PersonaDiaAnalitica` agregaba por ACTIVIDAD_ANALISIS antes de resolver la productividad (dos tareas de la misma actividad con productividades distintas compartían una sola). Nuevo modelo por tarea: `resolverClasificacionTarea()` (prioridad override tarea → actividad → default) + `repartirTiemposPorTarea()` (conservación < 1e-9). Agregación visual por actividad con sub-filas por tarea.

## Batería v6.1.1 (ejecución real)

| Batería | Resultado | Detalle |
|---|---|---|
| `npm run lint` | ✅ PASS | 0 errors (23 warnings preexistentes) |
| `npm test` (Vitest) | ✅ **366/366** | 22 archivos: 339 v6.1 + 27 NUEVOS v6.1.1, 0 fail, 0 skip |
| `npx playwright test` | ✅ **42/42** | 34 v6.1 + 8 E2E NUEVOS v6.1.1, en 3 lotes |
| `npm run test:a11y` | ✅ 5/5 | axe-core WCAG 2.1 AA (claro, oscuro — badges Fuente con contraste AA en ambos temas) |
| `npm run test:perf` | ✅ 3/3 | @perf reales sin degradación |
| Equivalencia | ✅ **14/14 tablas · 0 mismatches · 74.672 celdas** | Re-ejecutada tras TODOS los cambios; consultas 01-16 intactas (17 aditiva) |
| `validate_manifest.cjs` | ✅ PASS | 122 verificados, 0/0/0/0 |
| `validate_release.cjs` | ✅ PASS | 78/78 checks (piso estático de tests activo) |

## Tests nuevos v6.1.1 (27 unitarios + 8 E2E)

| Archivo | Tests | Cubre |
|---|---:|---|
| `tests/unit/filtro_turnos_real.test.js` | 10 | Filtro REAL: MAÑANA→06:30+13:59 · TARDE→14:00+21:59 · NOCHE→22:00+02:00+05:59 · SIN HORA→solo sin hora · TODOS · MIXTO por turno trabajado · fecha operativa nocturna (4 ejemplos obligatorios) · day-level sin desplazar |
| `tests/unit/overrides_task.test.js` | 17 | Casos 1-4 del usuario (normal 150 · override 200 · OTRA→PICKING AGV 150 entra al reparto · 100 vs 200 sin mezcla) + prioridad exacta + Fuente + conservación <1e-9 + históricos con detalle por tarea + fingerprint versión |
| `tests/e2e/overrides_v612.spec.js` | 8 | Filtros mañana/tarde/noche reales · NOCHE cruzando medianoche · SIN HORA + aviso · editar productividad desde la UI · OTRA→PICKING AGV · 2 tareas misma actividad prods distintas · override→reprocesar→histórico conserva versión |

## Defectos corregidos durante v6.1.1

| # | Defecto | Corrección |
|---|---|---|
| D-11 | Filtro de turno de Revisar NO aplicado en la cadena real de filtrado (informativo) | `SPEC.filtrarRegistrosPorTurno()` centralizada + aplicada en `getFilteredPersonDays` y `filtrarPatronesRecords` |
| D-12 | Reparto agregaba por actividad ANTES de resolver productividad → tareas con prods distintas compartían una | q17 agrega por TASK_WMS + `resolverClasificacionTarea` + `repartirTiemposPorTarea` |
| D-13 | Sin interfaz para gestionar overrides por tarea (solo localStorage interno) | Sección PRODUCTIVIDAD POR TAREA completa (buscar/editar/resetear + tabla con Fuente) |
| D-14 | Registros sin hora invisibles en el detalle; sin mensaje explícito | Tabla «Fichajes del día» + aviso «Este registro no contiene hora de fichaje.» |
| D-15 | Standalone con motor v6.1 (sin correcciones) | Reconstruido con probes v6.1.1 obligatorios |

## Compatibilidad verificada

- ✅ 339 tests v6.1 intactos (ningún test eliminado; solo se AÑADIERON 27 + 8).
- ✅ Equivalencia 14/14/0/74672 re-ejecutada tras todos los cambios del motor.
- ✅ Worker, IndexedDB, PWA (cache `spec-web-v6-1-1`), exports, audit log, a11y, filtros existentes.
- ✅ Versiones alineadas en 6.1.1 (package.json, PARAMS, manifest, sw, standalone, tests).

## Conclusión v6.1.1

Los dos puntos funcionales quedan **cerrados y cubiertos por tests**: 408/408 reales PASS, equivalencia intacta, validadores PASS. Los históricos nuevos registran `appVersion 6.1.1` (distingue el modelo de reparto por tarea del modelo v6.1.0 por actividad).

---

# APÉNDICE v6.2.0 — Módulo de estadística avanzada e inteligencia operativa (2026-10-06)

**Alcance:** transformar PATRONES en un sistema de detección y priorización
de problemas de calidad de fichaje. Sin auditoría nueva; desarrollo aditivo
con batería de regresión completa.

## Defectos detectados y corregidos durante el desarrollo (D-16..D-19)

- **D-16** — `normalizarRegistro` no propagaba `esSinMapping/esSinVolumen/esAmbiguedad/esRevisionManual` a las incidencias normalizadas (la calidad de datos y el mapping leían valores undefined). Corregido + tests.
- **D-17** — dedup de horas por tarea/actividad/confusión usaba una clave con índice de incidencia (dedup inoperante: cada propuesta sumaba horas). Corregido a dedup por ID REGISTRO (y registro+destino en confusiones).
- **D-18** — `horasConIncidencia` v6.1 incluía las secciones 3 de control, inflando el impacto: añadida `horasErrorDedup` (solo errores reales, dedup por registro) usada por TODO el módulo (documentado en el diccionario de métricas).
- **D-19** — contaje de turnos por actividad contaba por tarea en vez de por persona-día, y la alerta A3 usaba un campo inexistente (`pctAcumuladoDe`): corregidos ambos.

## Batería ejecutada (todo REAL, desde el working tree)

```
npm run lint                 → 0 errors (30 warnings estilo preexistente)
npm test                     → 502/502 (Test Files 33/33)
npx playwright test          → 56/56 (42 previos + 14 nuevos v6.2)
npm run test:a11y            → 5/5
npm run test:perf            → 3/3
node scripts/07_test_equivalencia_values → 14/14 · 0 mismatches · 74.672 celdas
node scripts/validate_manifest.cjs      → PASS
node scripts/validate_release.cjs       → PASS (78 checks)
```

## Riesgos y mitigaciones nuevas

- **R-22 (nuevo)**: la capa analítica depende del DOM solo en ui.js; los cálculos viven en analytics/*.js cargados también en Vitest (setup.js) → mismo código testeado y servido.
- **R-23 (nuevo)**: umbrales por defecto son criterios de ingeniería documentados, NO decisiones de negocio cerradas → todos editables en ⚙ Configuración estadística y persistidos; el diccionario los enumera.

