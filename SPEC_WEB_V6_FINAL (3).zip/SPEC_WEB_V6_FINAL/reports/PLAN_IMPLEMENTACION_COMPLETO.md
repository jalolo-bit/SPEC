# PLAN_IMPLEMENTACION_COMPLETO — SPEC Web v6.0 Post-Audit

Documento maestro que registra **todos** los hallazgos de la auditoría (dev package + independent audit) y las acciones a ejecutar. Se actualiza conforme avanza la implementación.

**Versión inicial:** v6.0-pre (en construcción)
**Versión final objetivo:** SPEC Web v6.0 — Post-Audit Release
**Fecha de inicio:** 2026-10-01
**Baseline:** 14/14 tablas equivalentes, 0 diferencias en 74.672 celdas (NE: el doc original dice 74.172 — typo AUD-MED-001).

## Convención de estados
- ⏳ Pendiente
- 🔄 En progreso
- ✅ Completado
- ⚠️ Mitigado (no eliminable arquitectónicamente)
- ❌ No resuelto (fuera de alcance del entorno)

## Matriz de hallazgos → acciones

| ID | Hallazgo | Riesgo asociado | Acción | Dependencias | Archivos afectados | Prioridad | Estado | Test asociado |
|----|----------|-----------------|--------|--------------|---------------------|-----------|--------|---------------|
| AUD-CRIT-001 | index.html no carga app.js → modular roto | R-22 (entrega) | Añadir `<script src="app.js"></script>` antes de ui.js | — | `index.html` | CRÍTICA | ⏳ | smoke E2E |
| AUD-CRIT-002 | ui.js línea 1502 `ReferenceError: loadFile is not defined` → v3/v4/v5 muertas | R-04, R-07, R-17, M-02, M-03, M-04, M-05, M-08, M-09 | Exportar símbolos privados del IIFE a `window` (escapeHtml, escapeAttr, UI, loadFile, analizar, init, timestamp, reiniciarCarga, reiniciarProceso, validarArchivos, setStatus, addMessage, checkAllLoaded, renderResultadosPanel, showTable, renderViewerTable, renderReportePanel, renderReporteTable, renderTrazabilidadPanel, mostrarTrazabilidad, renderExportarPanel) | — | `ui.js` | CRÍTICA | ⏳ | smoke E2E + 9 tabs |
| AUD-HIGH-001 | escapeHtml/escapeAttr/UI/timestamp privados al IIFE, 56+ usos externos | R-04, M-02 | Resuelto por AUD-CRIT-002 (export a window) | AUD-CRIT-002 | `ui.js` | ALTA | ⏳ | XSS tests |
| AUD-HIGH-002 | 4 hashes MANIFEST rotos (incl. MANIFEST.txt auto-hash) | R-22 (integridad) | Regenerar MANIFEST al final (FASE 20), auto-excluyendo | FASE 19 | `MANIFEST.txt` | ALTA | ⏳ | sha256sum -c |
| AUD-HIGH-003 | ESLint sin `no-undef` → 113 errores ocultos | R-13, R-14 | Configurar ESLint con `no-undef` + CI gate | FASE 5/11 | `.eslintrc.cjs`, `package.json` | ALTA | ⏳ | eslint en CI |
| AUD-MED-001 | "74,172 cells" es typo, real es 74,672 | R-13 | Corregir 4 docs | FASE 19 | 4 .md | MEDIA | ⏳ | doc lint |
| AUD-MED-002 | RESPUESTA_FINAL declara 92/2.8MB/92, real 106/1.28MB/105 | R-22 | Regenerar RESPUESTA_FINAL desde MANIFEST | FASE 19 | `RESPUESTA_FINAL.md` | MEDIA | ⏳ | doc lint |
| AUD-MED-003 | PRUEBAS_EQUIVALENCIA §2.4/2.5 muestra pre-fix numbers | R-13 | Regenerar secciones 2.4/2.5 desde tool outputs | FASE 19 | `PRUEBAS_EQUIVALENCIA.md` | MEDIA | ⏳ | doc lint |
| AUD-MED-004 | SPEC_AUTONOMO_v.5.html no está en audit-package | R-22 | Incluirlo en entrega final + unificar versiones | FASE 20 | paquete final | MEDIA | ⏳ | zip inspect |
| AUD-MED-005 | SheetJS 0.18.5 vulnerable (Prototype Pollution CVSS 7.8 + ReDoS CVSS 7.5) | R-06, R-19 | Mitigar: límite estricto tamaño + validación estructura + documentar (no se puede actualizar bundle sin conexión a CDN oficial SheetJS) | R-06 (FASE 2) | `app.js`, `MANUAL_USUARIO.md`, `SECURITY.md` | MEDIA | ⏳ | input validation test |
| AUD-MED-006 | Equivalencia solo demostrada para 1 día (25/08/2026) | R-20 | Crear dataset sintético multi-periodo + re-ejecutar tests | FASE 13 | `test-data/` | MEDIA | ⏳ | equivalencia multi-periodo |
| AUD-MED-007 | CSV formula injection en exportToCsv (= + - @ no escapados) | R-05, M-01 | Prepend `'` a valores que empiecen por `= + - @`; añadir `;` al trigger de escape | AUD-CRIT-002 | `app.js` `exportToCsv()` | ALTA | ⏳ | CSV injection tests |
| AUD-MED-008 | Datos personales no anonimizados en paquete y evidencias | R-18 | Crear datasets sintéticos + policy + doc PRIVACY_TEST_DATA.md | FASE 13 | `test-data/`, `PRIVACY_TEST_DATA.md` | MEDIA | ⏳ | privacy scan |
| AUD-MED-009 | Scripts con paths absolutos hardcoded | R-14 | Migrar a paths relativos CLI args | FASE 19 | `scripts/05,07,06` | MEDIA | ⏳ | re-run tests |
| AUD-LOW-001 | VBA fallback "WMS TASK VACIA" no portado | R-21 (equivalencia) | Añadir fallback en JS `r['WMS_TASK'] \|\| 'WMS TASK VACIA'` | — | `app.js` `ProcesarFilaVolumen` equivalent | BAJA | ⏳ | unit test |
| AUD-LOW-002 | Conteos menores en docs (310 vs 311 M lines; 1086 vs 1085 VBA) | — | Corregir en regeneración | FASE 19 | docs | BAJA | ⏳ | doc lint |
| AUD-LOW-003 | "Indirect Budget" tiene 24 duplicados | R-10 | Documentar (sheet no usada por diseño) | FASE 19 | docs | BAJA | ⏳ | — |
| AUD-LOW-004 | 3 bugs fixeados sin tests de regresión | R-13 | Añadir regression tests por cada fix | FASE 5 | `tests/` | BAJA-MEDIA | ⏳ | regression tests |

### Riesgos R-01..R-18 (REGISTRO_RIESGOS.md original) — tratamiento

| Riesgo | Estado anterior | Acción | Estado objetivo | Fase |
|--------|-----------------|--------|----------------|------|
| R-01 decisiones perdidas si localStorage wipeado | Abierto | M-04 auto-backup a IndexedDB + export JSON | MITIGADO | FASE 3 |
| R-02 UI freeze con archivos grandes | Abierto | M-03 Web Worker | ELIMINADO | FASE 4 |
| R-03 sin auth | Aceptado | Documentar (no backend by design) | ACEPTADO POR DISEÑO | FASE 19 |
| R-04 XSS innerHTML | Abierto | M-02 escapeHtml en todas las rutas + CSP | MITIGADO | FASE 2 |
| R-05 CSV injection | Abierto | M-01 prepend `'` | ELIMINADO | FASE 2 |
| R-06 sin validación integridad inputs | Abierto | Hash + estructura + columnas + tamaño + tipos | MITIGADO | FASE 2 |
| R-07 audit log manipulable | Abierto | Hash chain + IndexedDB + sessionId + mappingHash | MITIGADO | FASE 3 |
| R-08 sin sync entre dispositivos | Aceptado | Documentar + export/import JSON | ACEPTADO POR DISEÑO | FASE 19 |
| R-09 sin multiarchivo | Abierto | M-10 multi-file selector | ELIMINADO | FASE 9 |
| R-10 Direct/Indirect Budget ignorados | Aceptado | Coincide con Excel V0.47.3 | ACEPTADO POR DISEÑO | FASE 19 |
| R-11 Excel no ejecutado | Mitigado | Mantener; documentar SHA-256 + procedencia | MITIGADO | FASE 14 |
| R-12 IdNumerico BigInt | Abierto | Detectar >15 dígitos y usar BigInt | MITIGADO | FASE 2 (app.js) |
| R-13 sin unit tests | Abierto | M-06 Vitest + tests fx_* y q* | ELIMINADO | FASE 5 |
| R-14 sin CI/CD | Abierto | M-14 GitHub Actions | ELIMINADO | FASE 11 |
| R-15 sin gestión mapping | Abierto | M-07 pestaña Mapping CRUD + audit | ELIMINADO | FASE 8 |
| R-16 NivelConfianza rule-based | Aceptado | Documentar | ACEPTADO POR DISEÑO | FASE 19 |
| R-17 sin backup automático | Abierto | M-04 (mismo que R-01) | MITIGADO | FASE 3 |
| R-18 datos personales no anonimizados | Abierto | Datasets sintéticos + PRIVACY_TEST_DATA.md | MITIGADO | FASE 13 |

### Mejoras M-01..M-15 (MEJORAS_PRIORIZADAS.md original) — tratamiento

| Mejora | Prioridad | Acción | Estado objetivo | Fase |
|--------|-----------|--------|----------------|------|
| M-01 CSV formula escape | ALTA | Implementar en `exportToCsv` | ELIMINADO | FASE 2 |
| M-02 innerHTML audit | ALTA | escapeHtml en 100% de rutas dinámicas | ELIMINADO | FASE 2 |
| M-03 Web Worker | ALTA | Extraer motor a `worker.js` + postMessage progreso | ELIMINADO | FASE 4 |
| M-04 auto-backup audit log | ALTA | IndexedDB + export JSON + hash chain | ELIMINADO | FASE 3 |
| M-05 virtual scrolling | MEDIA | Render solo filas visibles (ventana 50+overscan) | ELIMINADO | FASE 4 |
| M-06 unit tests | MEDIA | Vitest + casos fx_*/q*/calcularMaterialidad | ELIMINADO | FASE 5 |
| M-07 Mapping tab | MEDIA | Nueva pestaña con CRUD + audit + hash mapping | ELIMINADO | FASE 8 |
| M-08 auto-advance configurable | MEDIA | Checkbox en Revisar + persistencia | ELIMINADO | FASE 9 |
| M-09 filtros fecha/turno | MEDIA | date-from/to + turno + sección + otros | ELIMINADO | FASE 9 |
| M-10 multiarchivo | BAJA | Selector múltiple + listado + trazabilidad origen | ELIMINADO | FASE 9 |
| M-11 CSP + headers | BAJA | `<meta http-equiv>` CSP + headers Next.js | MITIGADO | FASE 2 |
| M-12 IndexedDB | BAJA | Migrar persistencia grande a IndexedDB | ELIMINADO | FASE 3 |
| M-13 TypeScript | BAJA | Tipado progresivo de núcleo (.d.ts + JSDoc) | MITIGADO | FASE 10 |
| M-14 CI/CD | BAJA | GitHub Actions: lint+test+e2e+a11y+build+sbom | ELIMINADO | FASE 11 |
| M-15 PWA | BAJA | Manifest + service worker offline | APLAZADO | (post-entrega) |

## Orden de ejecución óptimo

```
F0  Baseline ───────────────────────────────────────────────────── [✓ done]
F1  PLAN ───────────────────────────────────────────────────────── [in progress]
F2  Seguridad + fix bugs críticos (AUD-CRIT-001/002 + M-01/02/11 + R-06/12)
F3  Trazabilidad + IndexedDB + hash chain + sessionId + mappingHash (M-04, M-12, R-01/07/17)
F4  Web Worker + virtual scrolling (M-03, M-05, R-02)
F5  Testing: Vitest unit + integración + Playwright E2E + rendimiento (M-06, R-13)
F6  Accesibilidad axe-core + WCAG 2.1 AA
F7  Cobertura Istanbul/nyc
F8  Mapping tab CRUD (M-07, R-15)
F9  UX: auto-advance + filtros + multiarchivo (M-08, M-09, M-10, R-09)
F10 TypeScript progresivo (M-13)
F11 CI/CD GitHub Actions (M-14, R-14)
F12 SBOM CycloneDX (AUD-MED-005 mitigación doc)
F13 Privacidad + datasets sintéticos (R-18, AUD-MED-006/008)
F14 Integridad Excel original (SHA-256 + procedencia; R-11)
F15 Equivalencia funcional re-ejecución (14/14 + 74.672 cells)
F16 Regresión completa
F17 REGISTRO_RIESGOS_FINAL.md
F18 Tabla final M-01..M-15
F19 Documentación completa
F20 Versión final + FINAL_VALIDATION_REPORT.md + AUDITORIA_POST_IMPLEMENTACION.md + MANIFEST regenerado
```

## Notas

- El entorno no tiene Excel/VBA/Power Query. La FASE 14 (referencia fresca desde Excel) y la FASE 15 (re-conciliación contra Excel vivo) se documentan como **no verificables en este entorno**. Se reutilizarán los resultados de equivalencia del paquete de auditoría (14/14 tablas, 0/74.672 cells) como referencia congelada, y se re-ejecutarán los tests T-01 y T-02 contra el xlsm.
- SheetJS no se actualizará a ≥0.20.2 porque el CDN oficial SheetJS no es accesible desde este entorno. Se mitiga con límite estricto de tamaño + validación estructural + documentación.
- La migración completa a TypeScript (M-13) se limita a tipado progresivo de núcleo (interfaces + JSDoc + .d.ts) — no se convierte todo el código a .ts para evitar riesgos de build.
- PWA (M-15) queda aplazada a post-entrega por baja prioridad.
