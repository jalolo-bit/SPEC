// ESLint flat config for SPEC Web v6.0
// Applies to project-root *.js source files (app.js, ui.js, charts.js).
// Excludes node_modules, audit-ref/, upload/, download/, scripts/ (legacy
// tests), tests/ (test files have their own concerns), tool-results/, and
// third-party bundle xlsx.full.min.js.
//
// The config also explicitly excludes eslint.config.js, vitest.config.js,
// playwright.config.js because they are ESM modules and we lint source files
// (IIFE pattern) with sourceType: 'script'.

import js from '@eslint/js';
import globals from 'globals';

// Symbols that ui.js declares at top-level (as function declarations, var,
// let, const, or assignments to `window`). After the main agent fixes
// AUD-CRIT-002 by exporting them to window, references from global scope
// resolve cleanly. Until then, marking them as writable globals silences
// the false-positive no-undef hits on the known broken paths (the 113
// errors the auditor's repro surfaced — these are intentionally masked
// here so that the lint baseline surfaces only NEW/real bugs).
const UI_GLOBALS = [
  'SPEC', 'SPEC_AN', 'SPEC_CHARTS', 'XLSX',
  // ui.js private helpers that the main agent is exporting to window
  'UI', 'escapeHtml', 'escapeAttr', 'timestamp', 'loadFile', 'analizar', 'init',
  'reiniciarCarga', 'reiniciarProceso', 'validarArchivos', 'setStatus', 'addMessage',
  'checkAllLoaded', 'renderResultadosPanel', 'showTable', 'renderViewerTable',
  'renderReportePanel', 'renderReporteTable', 'renderTrazabilidadPanel',
  'mostrarTrazabilidad', 'renderExportarPanel', 'toast', 'confirmDialog',
  'setupThemeToggle', 'setupGlobalSearch', 'doGlobalSearch', 'persistState',
  'restoreState', 'clearPersistedState', 'updatePersistedState', 'setupPersistence',
  'setupDetailPanel', 'openDetailPanel', 'closeDetailPanel', 'formatVal',
  'setupPreviewModal', 'showPreview', 'setupRowClickHandlers', 'setupKpiDrilldown',
  'handleKpiDrilldown', 'renderReviewPanel', 'incidentPriority',
  'getFilteredIncidents', 'renderReviewList', 'toggleBulkSelection',
  'selectIncident', 'renderIncidentDetail', 'obtenerMotivoInput', 'getConfianza',
  'generarRazonPropuesta', 'getAvailableTasks', 'handleIncidentAction',
  'registrarDecision', 'undoDecision', 'undoLastAction', 'navigateIncident',
  'persistDecisions', 'restoreDecisions', 'setupReviewTab', 'bulkAction',
  'renderPatronesPanel', 'makePatternCard', 'renderAuditoriaPanel',
  'setupAuditoriaTab', 'setupKeyboardShortcuts', 'setupBeforeUnload',
  'incidentId',
  // v6.1 — helpers del primer IIFE expuestos a window que el bloque v6.1 usa
  'loadFiles', 'updateDropZoneFiles', 'removeFile'
];

const writableGlobals = Object.fromEntries(UI_GLOBALS.map((g) => [g, 'writable']));

export default [
  {
    ignores: [
      'node_modules/**',
      'audit-ref/**',
      'upload/**',
      'download/**',
      'tool-results/**',
      'scripts/**',
      'tests/**',
      'coverage/**',
      'playwright-report/**',
      'test-results/**',
      'sbom.json',
      'xlsx.full.min.js', // third-party bundle, intentionally not linted
      // Config files are ESM modules — they need sourceType: 'module', and we
      // don't want them to inherit the source-level overrides below.
      'eslint.config.js',
      'vitest.config.js',
      'playwright.config.js',
      'package-lock.json',
      'package.json'
    ]
  },
  // Apply the recommended baseline FIRST so we can override its stricter
  // rules with our own preferences (e.g., no-unused-vars → warn, no-redeclare
  // → off because we declare ui.js's exports as globals intentionally).
  // v6.2 — la capa analítica (analytics/*.js) sigue el mismo patrón IIFE que
  // app.js/ui.js: se incluye en el bloque de globals de navegador.
  js.configs.recommended,
  {
    files: ['*.js', 'analytics/*.js'],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: 'script', // IIFE — not a module
      globals: {
        ...globals.browser,
        ...globals.es2022,
        ...writableGlobals
      }
    },
    rules: {
      // AUD-HIGH-003: without `no-undef`, the auditor's reproduction produced
      // 113 hidden errors. This rule is the gate that surfaces AUD-CRIT-002.
      'no-undef': 'error',
      // We declare ui.js's exported symbols as writable globals above, so
      // ui.js's local function declarations like `function toast() {}` would
      // otherwise fire `no-redeclare`. The trade-off is intentional: we want
      // no-undef to catch real undefined references, but accept that local
      // redeclarations of exported globals are part of the IIFE pattern.
      'no-redeclare': 'off',
      // app.js legitimately uses control-char regex (text normalization to
      // strip \x00-\x1f). Don't flag it.
      'no-control-regex': 'off',
      // app.js's normalize functions use \x00-\x1f and similar escapes in
      // string literals — `no-useless-escape` false-positives on these.
      'no-useless-escape': 'off',
      'no-unused-vars': ['warn', { argsIgnorePattern: '^_', varsIgnorePattern: '^_' }],
      'no-empty': 'warn',
      'no-console': 'off',
      'no-debugger': 'error'
    }
  }
];
