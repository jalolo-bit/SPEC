// Vitest config for SPEC Web v6.0
// Unit & integration tests run in Node (no DOM — we test pure JS functions in
// app.js + charts.js). E2E tests (ui.js) are handled separately by Playwright.

import { defineConfig } from 'vitest/config';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));

export default defineConfig({
  test: {
    // tests/setup.js eval's xlsx.full.min.js + app.js into the Node global
    // scope, so each test file inherits a SPEC global.
    setupFiles: [resolve(__dirname, 'tests/setup.js')],
    environment: 'node',
    include: [
      'tests/unit/**/*.test.js',
      'tests/integration/**/*.test.js'
    ],
    exclude: ['tests/e2e/**', 'node_modules/**', 'audit-ref/**'],
    globals: true,
    coverage: {
      provider: 'istanbul',
      reporter: ['text', 'html', 'lcov'],
      reportsDirectory: 'coverage',
      include: ['app.js', 'charts.js'],
      exclude: ['ui.js', 'xlsx.full.min.js', 'node_modules/**', 'tests/**']
    }
  },
  css: false,
  esbuild: false,
  // F-closure-fix — prevent vite from auto-loading postcss.config from
  // parent directories (we're a vanilla JS project, no CSS processing needed).
  // `css:false` doesn't fully disable postcss resolution; this empty config
  // stub explicitly tells vite "no postcss config, don't search upward".
  plugins: [{
    name: 'no-postcss-search',
    config() {
      return {
        css: {
          postcss: {
            plugins: []  // empty — no postcss processing
          }
        }
      };
    }
  }]
});
