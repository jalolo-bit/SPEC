/* SPEC Web v6.0 — Service Worker (M-15 PWA)
 *
 * Estrategia de cache: Cache-First con fallback a Network para los recursos
 * estáticos de la app (HTML, CSS, JS, image, xlsx bundle). Esto permite
 * funcionamiento offline total tras la primera carga.
 *
 * Para los datos de entrada (.xlsx cargados por el usuario), NO se cachean:
 * son archivos del usuario, no recursos de la app.
 *
 * Versiones:
 *   - SW v6.0.0 (espejo de PARAMS.AppVersion)
 *   - Cache name: spec-web-v6
 *
 * Eventos:
 *   - install: precache de los recursos core (no bloquea; skipWaiting)
 *   - activate: limpia caches antiguas (claim inmediato)
 *   - fetch: Cache-First para same-origin GET; Network fallback con cache update
 */

const CACHE_NAME = 'spec-web-v6-2';
const SW_VERSION = '6.2.0';
const CORE_ASSETS = [
  './',
  './index.html',
  './styles.css',
  './app.js',
  './ui.js',
  './charts.js',
  './worker.js',
  './xlsx.full.min.js',
  './logo_idl.png',
  './manifest.json',
  './analytics/analyticsCore.js',
  './analytics/personAnalytics.js',
  './analytics/taskAnalytics.js',
  './analytics/activityAnalytics.js',
  './analytics/confusionAnalytics.js',
  './analytics/trendAnalytics.js',
  './analytics/paretoAnalytics.js',
  './analytics/alertAnalytics.js',
  './analytics/dataQualityAnalytics.js'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      // No usar addAll porque si un recurso falla, todo falla.
      // Cachear individualmente para que un fallo individual no rompa todo.
      return Promise.allSettled(
        CORE_ASSETS.map((url) =>
          cache.add(url).catch((err) => {
            console.warn('SW: no se pudo cachear', url, err.message);
          })
        )
      );
    }).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  // Solo manejar GET same-origin
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  // Cache-First con Network fallback y actualización de cache
  event.respondWith(
    caches.match(req).then((cached) => {
      if (cached) {
        // Devolver cache, y en background actualizar
        fetch(req).then((res) => {
          if (res && res.status === 200 && res.type === 'basic') {
            const clone = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(req, clone));
          }
        }).catch(() => { /* offline — usar cache */ });
        return cached;
      }
      // No en cache: ir a red, cachear si OK, fallback si falla
      return fetch(req).then((res) => {
        if (!res || res.status !== 200 || res.type !== 'basic') return res;
        const clone = res.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(req, clone));
        return res;
      }).catch(() => {
        // Offline: intentar devolver index.html como fallback para SPA-like nav
        if (req.destination === 'document') return caches.match('./index.html');
        return new Response('', { status: 504, statusText: 'Offline' });
      });
    })
  );
});

self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});
