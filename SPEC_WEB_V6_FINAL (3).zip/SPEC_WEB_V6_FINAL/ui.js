/* ============================================================================
 * SPEC Web — UI: gestión de archivos, pestañas, render de tablas,
 * filtros, trazabilidad y exportación.
 *
 * Depende de app.js (módulo global SPEC) y SheetJS (XLSX).
 * ========================================================================== */
(function () {
'use strict';

const TAB_QUERY_MAP = {
  '01_HorasSinVolumen': '01_HorasSinVolumen',
  '02_VolumenDetalle': '02_VolumenDetalle',
  '03_VolumenPersonaDia': '03_VolumenPersonaDia',
  '05_VolumenIdNumericoDia': '05_VolumenIdNumericoDia',
  '07_Conciliacion': '07_Conciliacion',
  '08_Validaciones': '08_Validaciones',
  '09_VolumenSinHorasDetalle': '09_VolumenSinHorasDetalle',
  '10_VolumenSinHorasPersonaDia': '10_VolumenSinHorasPersonaDia',
  '12_MapeoActividadSPEC': '12_MapeoActividadSPEC',
  '13_VolumenMapeadoSPEC': '13_VolumenMapeadoSPEC',
  '14_VolumenPersonaDiaActividadSPEC': '14_VolumenPersonaDiaActividadSPEC',
  '15_VolumenSinHorasPersonaDiaActividadSPEC': '15_VolumenSinHorasPersonaDiaActividadSPEC',
  '16_ControlMapeoSPEC': '16_ControlMapeoSPEC',
  'REPORTE_CAMBIOS_HR': '__reporte__'
};

const TAB_ORDER = [
  '01_HorasSinVolumen', '02_VolumenDetalle', '03_VolumenPersonaDia',
  '05_VolumenIdNumericoDia', '07_Conciliacion', '08_Validaciones',
  '09_VolumenSinHorasDetalle', '10_VolumenSinHorasPersonaDia',
  '12_MapeoActividadSPEC', '13_VolumenMapeadoSPEC',
  '14_VolumenPersonaDiaActividadSPEC', '15_VolumenSinHorasPersonaDiaActividadSPEC',
  '16_ControlMapeoSPEC', 'REPORTE_CAMBIOS_HR'
];

const TAB_DESC = {
  '01_HorasSinVolumen': 'Detalle de horas trabajadas sin volumen productivo (117 filas).',
  '02_VolumenDetalle': 'Detalle de volumen WMS (744 filas).',
  '03_VolumenPersonaDia': 'Agregación de volumen por persona y día (213 filas).',
  '05_VolumenIdNumericoDia': 'Agregación por IdNumerico normalizado (197 filas).',
  '07_Conciliacion': 'Tabla central de conciliación (117 filas × 65 columnas).',
  '08_Validaciones': '19 KPIs de validación.',
  '09_VolumenSinHorasDetalle': 'Detalle de volumen sin horas imputadas (246 filas).',
  '10_VolumenSinHorasPersonaDia': 'VSH agregado por persona y día (84 filas).',
  '12_MapeoActividadSPEC': 'Mapeo TASK_WMS → TASK_SPEC (135 filas).',
  '13_VolumenMapeadoSPEC': 'Volumen con mapeo SPEC aplicado (744 filas × 36 columnas).',
  '14_VolumenPersonaDiaActividadSPEC': 'Volumen por persona/día/ActividadSPEC (311 filas).',
  '15_VolumenSinHorasPersonaDiaActividadSPEC': 'VSH por persona/día/Activity (93 filas).',
  '16_ControlMapeoSPEC': '14 KPIs de control de mapeo.',
  'REPORTE_CAMBIOS_HR': 'Reporte de propuestas de cambio de RR.HH. (215 filas × 20 columnas).'
};

const UI = {
  activeTab: 'carga',
  activeTable: null,
  activeData: null,
  viewerSort: { col: null, dir: 1 },
  reporteFilter: { search: '', seccion: '', materialidad: '', cambio: '' },
  traceability: { currentTable: null, currentRow: null },
  // F4-A — worker activo (para poder abortarlo con terminate() si el usuario
  // reinicia el proceso). null cuando no hay worker corriendo.
  activeWorker: null,
  // M-08 (Tarea F9) — auto-advance toggle. Si true, tras registrar una
  // decisión en registrarDecision(), se llama setTimeout(navigateIncident(1), 200)
  // para cargar la siguiente incidencia. Persistente en localStorage bajo la
  // clave 'spec_auto_advance'. Setup en setupReviewTab().
  autoAdvance: false
};

/* ===== F4-B — Virtual scrolling state for #viewer-table =====
 * Module-level (IIFE-private) cache. Evita re-renderizar todo el <tbody> en
 * cada scroll si la ventana visible no cambió de fila. Se resetea al
 * re-llamar renderViewerTable() (nueva tabla, nuevo sort, nueva búsqueda).
 */
const VIEWER_ROW_HEIGHT = 32;    // px (CSS: padding 8+8 + border 1 + content ~15 = ~32)
const VIEWER_THRESHOLD = 200;    // ≤200 filas: render directo, sin virtual scroll
const VIEWER_OVERSCAN = 10;      // filas arriba/abajo del viewport que sí se renderizan
const VIEWER_VISIBLE = 50;        // mínimo de filas visibles (refinado por altura del viewport)
let _viewerSortedData = null;     // array filtrado+ordenado actual (referencia, no copia)
let _viewerCols = null;            // columnas de la tabla (Object.keys(UI.activeData[0]))
let _viewerLastFirst = -1;          // último first renderizado (debounce)
let _viewerLastLast = -1;            // último last renderizado
let _viewerScrollRafId = null;       // rAF pendiente para re-render
let _viewerScrollWrap = null;         // .viewer-table-wrap (listener target)

/* ===== Tab navigation ===== */
/* F6 — ARIA tabs pattern: toggle aria-selected on activation, move focus to
 * the active tab, and support arrow-left/right to move between tabs.
 * (https://www.w3.org/WAI/ARIA/apg/patterns/tabs/)
 */
function setupTabs() {
  document.querySelectorAll('.tab').forEach(t => {
    t.addEventListener('click', () => {
      const tab = t.dataset.tab;
      UI.activeTab = tab;
      document.querySelectorAll('.tab').forEach(x => {
        const isActive = x === t;
        x.classList.toggle('active', isActive);
        x.setAttribute('aria-selected', isActive ? 'true' : 'false');
        x.tabIndex = isActive ? 0 : -1; // roving tabindex pattern
      });
      document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
      const panel = document.getElementById('panel-' + tab);
      if (panel) panel.classList.add('active');
      // Move keyboard focus to the active tab (ARIA tabs best practice).
      t.focus();
      if (tab === 'revisar') {
        // M-08/M-09 (Tarea F9) — Lazy setup of review tab listeners. The init
        // wrap chain (_origInit2 etc.) does NOT reliably intercept DOMContentLoaded
        // (the listener captures the IIFE-local init0, not the wrapped init2).
        // setupMappingTab already used this same pattern. Idempotent via flag.
        if (!UI.reviewSetupDone) {
          try { setupReviewTab(); } catch (e) { console.warn('setupReviewTab:', e); }
          UI.reviewSetupDone = true;
        }
        renderReviewPanel();
      }
      if (tab === 'resultados') {
        // F6 — Lazy setup of row-click handlers (the init wrap chain does not
        // reliably intercept DOMContentLoaded; same pattern as revisar/mapping).
        if (!UI.rowClickSetupDone) {
          try { setupRowClickHandlers(); } catch (e) { console.warn('setupRowClickHandlers:', e); }
          UI.rowClickSetupDone = true;
        }
        renderResultadosPanel();
      }
      if (tab === 'reporte') renderReportePanel();
      if (tab === 'patrones') renderPatronesPanel();
      if (tab === 'trazabilidad') renderTrazabilidadPanel();
      if (tab === 'auditoria') renderAuditoriaPanel();
      if (tab === 'exportar') renderExportarPanel();
      if (tab === 'mapping') {
        // F8 — Gestión del Mapping. Setup es idempotente (flag), así que
        // llamarlo aquí es seguro aunque init() ya lo haya llamado.
        if (!UI.mappingSetupDone) {
          try { setupMappingTab(); } catch (e) { console.warn('setupMappingTab:', e); }
          UI.mappingSetupDone = true;
        }
        initMappingData();
        renderMappingTable();
      }
    });
    // Arrow key navigation between tabs (ARIA tabs best practice).
    t.addEventListener('keydown', e => {
      if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight' && e.key !== 'Home' && e.key !== 'End') return;
      e.preventDefault();
      const tabs = Array.from(document.querySelectorAll('.tab'));
      const i = tabs.indexOf(t);
      let next;
      if (e.key === 'ArrowRight') next = tabs[(i + 1) % tabs.length];
      else if (e.key === 'ArrowLeft') next = tabs[(i - 1 + tabs.length) % tabs.length];
      else if (e.key === 'Home') next = tabs[0];
      else if (e.key === 'End') next = tabs[tabs.length - 1];
      if (next) {
        next.focus();
        next.click();
      }
    });
  });
}

/* ===== Drop zones =====
 * F6 — Each drop-zone has role="button" tabindex="0" (set in HTML) so it's
 * keyboard-focusable. Here we register the keydown handler so Enter/Space
 * open the file picker, matching the click behavior.
 */
function setupDropZones() {
  document.querySelectorAll('.drop-zone').forEach(dz => {
    const tipo = dz.dataset.tipo;
    const input = dz.querySelector('input[type=file]');
    dz.addEventListener('click', () => input.click());
    // Keyboard activation: Enter or Space triggers file picker.
    dz.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        input.click();
      }
    });
    dz.addEventListener('dragover', e => { e.preventDefault(); dz.classList.add('dragover'); });
    dz.addEventListener('dragleave', () => dz.classList.remove('dragover'));
    dz.addEventListener('drop', async e => {
      e.preventDefault();
      dz.classList.remove('dragover');
      if (e.dataTransfer.files.length > 0) {
        await loadFiles(tipo, e.dataTransfer.files);
      }
    });
    input.addEventListener('change', async () => {
      if (input.files.length > 0) {
        await loadFiles(tipo, input.files);
        // Reset value para que el change event vuelva a disparar si el
        // usuario selecciona el MISMO archivo (caso: lo quita y lo vuelve
        // a cargar) — sin esto, el change no dispararía porque el value
        // no cambia.
        input.value = '';
      }
    });
  });
  document.getElementById('btn-validar').addEventListener('click', validarArchivos);
  document.getElementById('btn-reiniciar').addEventListener('click', reiniciarCarga);
  document.getElementById('btn-analizar').addEventListener('click', analizar);
  document.getElementById('btn-reiniciar-proceso').addEventListener('click', reiniciarProceso);
  document.getElementById('viewer-close').addEventListener('click', () => {
    // F4-B — al cerrar el viewer, desconectar el scroll listener del modo
    // virtual y resetear el cache. Sin esto, los listeners se acumularían
    // si el usuario abre y cierra varias tablas grandes.
    _viewerDetachScroll();
    _viewerSortedData = null;
    _viewerCols = null;
    _viewerLastFirst = -1;
    _viewerLastLast = -1;
    document.getElementById('table-viewer').style.display = 'none';
    UI.activeTable = null;
  });
  document.getElementById('viewer-search').addEventListener('input', e => {
    UI.viewerSearch = e.target.value;
    renderViewerTable();
  });
  document.getElementById('viewer-export-xlsx').addEventListener('click', () => {
    if (UI.activeTable && UI.activeData) {
      const fname = UI.activeTable.replace(/[^\w]/g, '_') + '_' + timestamp() + '.xlsx';
      SPEC.exportToXlsx(UI.activeData, fname, UI.activeTable.slice(0, 31));
    }
  });
  document.getElementById('viewer-export-csv').addEventListener('click', () => {
    if (UI.activeTable && UI.activeData) {
      const fname = UI.activeTable.replace(/[^\w]/g, '_') + '_' + timestamp() + '.csv';
      SPEC.exportToCsv(UI.activeData, fname);
    }
  });
  document.getElementById('reporte-search').addEventListener('input', e => {
    UI.reporteFilter.search = e.target.value;
    renderReporteTable();
  });
  document.getElementById('reporte-filter-seccion').addEventListener('change', e => {
    UI.reporteFilter.seccion = e.target.value;
    renderReporteTable();
  });
  document.getElementById('reporte-filter-materialidad').addEventListener('change', e => {
    UI.reporteFilter.materialidad = e.target.value;
    renderReporteTable();
  });
  document.getElementById('reporte-filter-cambio').addEventListener('change', e => {
    UI.reporteFilter.cambio = e.target.value;
    renderReporteTable();
  });
  document.getElementById('reporte-export-xlsx').addEventListener('click', () => {
    if (SPEC.STATE.reporte) {
      const fname = 'REPORTE_CAMBIOS_HR_' + timestamp() + '.xlsx';
      SPEC.exportToXlsx(SPEC.STATE.reporte, fname, 'REPORTE_CAMBIOS_HR');
    }
  });
  document.getElementById('reporte-export-csv').addEventListener('click', () => {
    if (SPEC.STATE.reporte) {
      const fname = 'REPORTE_CAMBIOS_HR_' + timestamp() + '.csv';
      SPEC.exportToCsv(SPEC.STATE.reporte, fname);
    }
  });
  document.getElementById('btn-traz').addEventListener('click', mostrarTrazabilidad);
}

function timestamp() {
  const d = new Date();
  return d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '_' + pad(d.getHours()) + pad(d.getMinutes());
}
function pad(n) { return String(n).padStart(2, '0'); }

/* M-10 (Tarea F9) — loadFile es un wrapper backward-compat que delega en
 * loadFiles con un array de 1 elemento. El punto de entrada real para el
 * flujo multi-archivo es loadFiles(tipo, FileList|array).
 * Se mantiene la firma antigua porque el override de la línea ~1833 la
 * sobrescribe (añade el botón de vista previa), y tests / código legacy
 * pueden llamarla con un único File.
 */
async function loadFile(tipo, file) {
  if (!file) return;
  return loadFiles(tipo, [file]);
}

/* M-10 — Carga múltiples archivos del mismo tipo. Cada archivo se lee con
 * SPEC.leerArchivoExcel y se pusha a SPEC.STATE.archivos[tipo] (que es un
 * array de { name, workbook, file }).
 *
 * Detección de duplicados: si el usuario vuelve a cargar un archivo con el
 * MISMO name, lo reemplazamos (en vez de duplicarlo) para evitar dobles
 * cargas por accidente.
 *
 * Estado visual: mientras se procesa, el .dz-status muestra "Leyendo...".
 * Al terminar, se renderiza la lista en .dz-files-list y el status muestra
 * el recuento total. Si alguno falla, se muestra el error pero se preservan
 * los que sí cargaron (el usuario puede quitar el roto y reintentar).
 */
async function loadFiles(tipo, files) {
  const dz = document.querySelector(`.drop-zone[data-tipo="${tipo}"]`);
  if (!dz) return;
  const status = dz.querySelector('.dz-status');
  const fileArr = Array.from(files || []);
  if (fileArr.length === 0) return;
  // Asegurar que STATE.archivos[tipo] es un array (M-10 migration path:
  // el motor anterior usaba {name, workbook, file}; lo normalizamos a []).
  if (!Array.isArray(SPEC.STATE.archivos[tipo])) {
    SPEC.STATE.archivos[tipo] = [];
  }
  dz.classList.remove('loaded', 'error');
  status.textContent = 'Leyendo...';
  status.className = 'dz-status info';
  let okCount = 0;
  let lastErr = null;
  for (const file of fileArr) {
    try {
      const wb = await SPEC.leerArchivoExcel(file);
      // F4-A — guardamos también el File original. El worker no puede recibir
      // el workbook (no es structured-cloneable), así que analizamos() re-lee
      // cada File como ArrayBuffer y lo transfiere. Sin .file, el path del
      // worker falla y cae al fallback main-thread.
      // M-10 — dedup por nombre de archivo: si ya estaba cargado, lo
      // reemplazamos (mismo nombre = mismo archivo recargado).
      const arr = SPEC.STATE.archivos[tipo];
      const existingIdx = arr.findIndex(a => a && a.name === file.name);
      const entry = { name: file.name, workbook: wb, file: file };
      if (existingIdx >= 0) arr[existingIdx] = entry;
      else arr.push(entry);
      okCount++;
    } catch (err) {
      lastErr = err;
      // Continuamos con el siguiente archivo; el error se reporta al final.
    }
  }
  // Update status based on outcome
  const total = SPEC.STATE.archivos[tipo].length;
  if (total > 0) {
    dz.classList.add('loaded');
    if (lastErr && okCount === 0) {
      status.textContent = 'Error: ' + (lastErr.message || String(lastErr));
      status.className = 'dz-status error';
      dz.classList.add('error');
      setStatus('Error al cargar', 'error');
    } else if (lastErr) {
      status.textContent = `${total} archivo(s) cargado(s) · 1 error`;
      status.className = 'dz-status ok';
      setStatus('Carga parcial', 'info');
    } else {
      status.textContent = `${total} archivo(s) cargado(s) ✓`;
      status.className = 'dz-status ok';
      setStatus('Carga parcial', 'info');
    }
  } else {
    dz.classList.add('error');
    status.textContent = 'Error: ' + (lastErr ? lastErr.message : 'no se pudo cargar ningún archivo');
    status.className = 'dz-status error';
    setStatus('Error al cargar', 'error');
  }
  // M-10 — render the file list with remove buttons
  updateDropZoneFiles(tipo);
  checkAllLoaded();
}

/* M-10 — Render the list of loaded files in the .dz-files-list div below the
 * drop-zone status. Each file gets a row with name + × remove button.
 * Uses escapeHtml/escapeAttr for the filename (defensive XSS). */
function updateDropZoneFiles(tipo) {
  const list = document.querySelector(`.dz-files-list[data-tipo="${tipo}"]`);
  if (!list) return;
  const arr = Array.isArray(SPEC.STATE.archivos[tipo]) ? SPEC.STATE.archivos[tipo] : [];
  list.innerHTML = '';
  arr.forEach((entry, idx) => {
    if (!entry) return;
    const item = document.createElement('div');
    item.className = 'dz-file-item';
    item.innerHTML =
      '<span class="dz-file-name" title="' + escapeAttr(entry.name || '') + '">📄 '
      + escapeHtml(entry.name || '') + '</span>'
      + '<button class="dz-file-remove" type="button" aria-label="Quitar '
      + escapeAttr(entry.name || '') + '" data-idx="' + idx + '" title="Quitar">×</button>';
    const btn = item.querySelector('.dz-file-remove');
    btn.addEventListener('click', e => {
      e.stopPropagation();
      removeFile(tipo, idx);
    });
    list.appendChild(item);
  });
  // Also re-create the preview button on the drop-zone (the override at
  // line ~1833 used to do this; we now centralize here so multi-file is
  // consistent).
  const dz = document.querySelector(`.drop-zone[data-tipo="${tipo}"]`);
  if (!dz) return;
  let prevBtn = dz.querySelector('.btn-preview');
  if (arr.length > 0) {
    if (!prevBtn) {
      prevBtn = document.createElement('button');
      prevBtn.className = 'btn btn-link btn-preview';
      prevBtn.textContent = '👁 Vista previa';
      prevBtn.style.cssText = 'display:block; margin-top:6px; padding:2px 6px; font-size:11px;';
      prevBtn.addEventListener('click', e => {
        e.stopPropagation();
        const arch = SPEC.STATE.archivos[tipo];
        if (Array.isArray(arch) && arch.length > 0) {
          // Mostrar el primer archivo del tipo (si hay varios, el usuario
          // puede pedir el siguiente en una futura mejora).
          showPreview(tipo, arch[0].name, arch[0].workbook);
        }
      });
      dz.appendChild(prevBtn);
    }
  } else if (prevBtn) {
    prevBtn.remove();
  }
}

/* M-10 — Remove a single file from a drop-zone's array. Re-renders the list
 * and re-evaluates checkAllLoaded(). */
function removeFile(tipo, index) {
  if (!Array.isArray(SPEC.STATE.archivos[tipo])) return;
  if (index < 0 || index >= SPEC.STATE.archivos[tipo].length) return;
  const removed = SPEC.STATE.archivos[tipo].splice(index, 1)[0];
  // Update status
  const dz = document.querySelector(`.drop-zone[data-tipo="${tipo}"]`);
  if (dz) {
    const status = dz.querySelector('.dz-status');
    const arr = SPEC.STATE.archivos[tipo];
    if (arr.length === 0) {
      dz.classList.remove('loaded', 'error');
      status.textContent = 'Pendiente';
      status.className = 'dz-status';
    } else {
      status.textContent = arr.length + ' archivo(s) cargado(s) ✓';
      status.className = 'dz-status ok';
    }
  }
  updateDropZoneFiles(tipo);
  checkAllLoaded();
  if (removed && removed.name) {
    toast(`Archivo ${removed.name} quitado.`, { level: 'info', duration: 1500 });
  }
}

function checkAllLoaded() {
  // M-10 — arrays: each tipo is "loaded" if its array has >= 1 entry.
  const all = Object.values(SPEC.STATE.archivos).filter(
    x => Array.isArray(x) ? x.length > 0 : (x != null)
  ).length;
  const total = 4;
  document.getElementById('btn-validar').disabled = all < total;
  document.getElementById('btn-analizar').disabled = all < total;
  if (all === total) setStatus('4 archivos cargados. Listo para procesar.', 'info');
}

function setStatus(msg, level) {
  const s = document.getElementById('globalStatus');
  s.textContent = msg;
  s.className = 'global-status ' + (level || '');
}

function validarArchivos() {
  const msgs = document.getElementById('carga-mensajes');
  msgs.innerHTML = '';
  const required = {
    horas: { file: 'HORA SIN VOLUMEN.xlsx', cols: ['Site name', 'Department', 'Activity', 'Subactivity', 'Date', 'HR Task', 'WMS Login', 'Name', 'Hours without volume'] },
    volumen: { file: 'VOLUMEN.xlsx', cols: ['DATE', 'SAP_CODE', 'CUSTOMER', 'WMS_TASK', 'WMS_LOGIN', 'USER_NAME', 'WMS_UOM'] },
    volSinHoras: { file: 'VOL SIN HORAS.xlsx', cols: ['Site name', 'Department', 'Activity', 'Subactivity', 'Date', 'HR Task', 'WMS Login', 'Name', 'Volume Without Hours'] },
    mapping: { file: 'Mapping.xlsx', requiredSheets: ['Mapping'], requiredCols: ['SAP_CODE', 'WMS_DC', 'CUSTOMER', 'DEPARTMENT', 'ACTIVITY', 'SUB_ACTIVITY', 'TASK_WMS', 'TASK_SPEC'] }
  };
  let allOk = true;
  for (const k of Object.keys(required)) {
    const cfg = required[k];
    // M-10 — archivos[k] ahora es un array; si está vacío, falta el tipo.
    const archArr = Array.isArray(SPEC.STATE.archivos[k]) ? SPEC.STATE.archivos[k] : [];
    if (archArr.length === 0) {
      addMessage(msgs, `Falta ${cfg.file}`, 'error');
      allOk = false;
      continue;
    }
    // Validar cada archivo del tipo (puede haber varios). Basta con que
    // falle uno para reportar error, pero validamos todos para mostrar el
    // detalle por archivo.
    let tipoOk = true;
    for (const arch of archArr) {
      try {
        if (k === 'horas') SPEC.fx_TransformaHoras(arch.workbook, arch.name);
        else if (k === 'volumen') SPEC.fx_TransformaVolumen(arch.workbook, arch.name);
        else if (k === 'volSinHoras') SPEC.fx_TransformaVolumenSinHoras(arch.workbook, arch.name);
        else if (k === 'mapping') SPEC.leerMapping(arch.workbook);
      } catch (err) {
        addMessage(msgs, `${cfg.file} (${arch.name}): ${err.message}`, 'error');
        tipoOk = false;
        allOk = false;
      }
    }
    if (tipoOk) {
      const lbl = archArr.length === 1 ? `${cfg.file}: estructura válida` : `${cfg.file}: ${archArr.length} archivos válidos`;
      addMessage(msgs, lbl, 'ok');
    }
  }
  if (allOk) {
    addMessage(msgs, 'Todos los archivos son válidos. Listo para procesar.', 'ok');
    setStatus('Validado. Listo para procesar.', 'ok');
  } else {
    setStatus('Errores en la carga', 'error');
  }
}

function addMessage(container, msg, level) {
  const div = document.createElement('div');
  div.className = 'message-item ' + (level || 'info');
  div.textContent = msg;
  container.appendChild(div);
}

function reiniciarCarga() {
  if (!confirm('¿Borrar los 4 archivos cargados?')) return;
  // M-10 — reset a arrays vacíos (estructura multi-archivo).
  SPEC.STATE.archivos = { horas: [], volumen: [], volSinHoras: [], mapping: [] };
  document.querySelectorAll('.drop-zone').forEach(dz => {
    dz.classList.remove('loaded', 'error');
    dz.querySelector('.dz-status').textContent = 'Pendiente';
    dz.querySelector('.dz-status').className = 'dz-status';
    dz.querySelector('input[type=file]').value = '';
    // M-10 — limpiar la lista de archivos del drop-zone
    const list = dz.querySelector('.dz-files-list');
    if (list) list.innerHTML = '';
    const prevBtn = dz.querySelector('.btn-preview');
    if (prevBtn) prevBtn.remove();
  });
  document.getElementById('carga-mensajes').innerHTML = '';
  document.getElementById('btn-validar').disabled = true;
  document.getElementById('btn-analizar').disabled = true;
  setStatus('Sin procesar');
}

function reiniciarProceso() {
  if (!confirm('¿Reiniciar el proceso? Se borrarán los resultados actuales.')) return;
  // F4-A — si hay un worker corriendo, abortarlo para que no actualice STATE
  // después de que el usuario ya haya reseteado.
  if (UI.activeWorker) {
    try { UI.activeWorker.terminate(); } catch { /* noop */ }
    UI.activeWorker = null;
  }
  SPEC.STATE.queries = {};
  SPEC.STATE.reporte = null;
  SPEC.STATE.log = [];
  document.getElementById('log-area').innerHTML = '';
  document.getElementById('progress-fill').style.width = '0%';
  document.getElementById('progress-text').textContent = 'Listo';
  setStatus('Sin procesar');
}

/* ===== Análisis =====
 * F4-A — el orquestador SPEC.analizarYConciliar puede correr en un Web Worker
 * para no congelar el hilo principal en archivos grandes (M-03 / R-02).
 * analizar() decide el path:
 *   - Si window.Worker existe y los 4 archivos conservan el File original,
 *     invoca analizarConWorker() (off-main-thread, con progress events).
 *   - Si no, cae a analizarEnMainThread() (comportamiento legacy / Node tests).
 * Si el worker falla por cualquier motivo (parseo de worker.js, error interno,
 * problema de serialización), hacemos fallback al main thread.
 */
async function analizar() {
  const btn = document.getElementById('btn-analizar');
  btn.disabled = true;
  setStatus('Procesando...', 'info');
  const log = document.getElementById('log-area');
  log.innerHTML = '';
  window.__appendLog = (level, msg) => {
    const div = document.createElement('div');
    div.className = 'log-line ' + level;
    const t = new Date().toLocaleTimeString('es-ES');
    div.textContent = `[${t}] ${msg}`;
    log.appendChild(div);
    log.scrollTop = log.scrollHeight;
  };
  try {
    let done = false;
    if (typeof Worker !== 'undefined') {
      try {
        await analizarConWorker();
        done = true;
      } catch (e) {
        // Fallback silencioso: si el worker arranca y luego falla con un
        // error de cálculo, el main-thread reproducirá el mismo error y el
        // catch exterior lo mostrará. Si el worker no pudo ni arrancar
        // (Worker no soportado / worker.js inaccesible), el main thread
        // tomará el relevo.
        console.warn('Path worker falló, fallback a main thread:', e);
      }
    }
    if (!done) {
      await analizarEnMainThread();
    }
    setStatus('Proceso completado ✓', 'ok');
    window.__appendLog('ok', `Proceso completado en ${SPEC.STATE.stats.totalMs} ms.`);
    // Render inmediato de resultados
    renderResultadosPanel();
    renderReportePanel();
  } catch (err) {
    window.__appendLog('error', 'ERROR: ' + err.message);
    setStatus('Error en el proceso', 'error');
    console.error(err);
  } finally {
    btn.disabled = false;
    UI.activeWorker = null;
  }
}

/* Path worker: re-lee cada File como ArrayBuffer, lo transfiere al worker,
 * y delega la ejecución de analizarYConciliar. Recibe progress events y
 * el payload final con { queries, reporte, log, stats }.
 *
 * F8 — Multi-archivo soportado de verdad: cada tipo puede tener 1 o N archivos.
 * El worker reconstruye cada workbook y construye el array que analizarYConciliar
 * espera. NO se cae al main-thread simplemente porque haya multi-archivo.
 *
 * Fallback al main-thread solo si:
 *   - Worker API no soportada (window.Worker undefined)
 *   - Fallo real del Worker (excepción al instanciar o al ejecutar)
 */
async function analizarConWorker() {
  const tipos = ['horas', 'volumen', 'volSinHoras', 'mapping'];
  const archivos = {};
  const transfer = [];
  for (const k of tipos) {
    const arr = Array.isArray(SPEC.STATE.archivos[k]) ? SPEC.STATE.archivos[k] : [];
    if (arr.length === 0) {
      throw new Error('No hay File original para "' + k + '".');
    }
    // F8 — enviar TODOS los archivos del tipo como array al worker
    const entries = [];
    for (const entry of arr) {
      if (!entry || !entry.file) {
        throw new Error('No hay File original para una entrada de "' + k + '".');
      }
      const buf = await entry.file.arrayBuffer();
      entries.push({ name: entry.file.name, buffer: buf });
      transfer.push(buf);
    }
    archivos[k] = entries;
  }
  return new Promise((resolve, reject) => {
    let worker;
    try {
      worker = new Worker('worker.js');
    } catch (e) {
      reject(e);
      return;
    }
    UI.activeWorker = worker;
    let settled = false;
    worker.onmessage = function (e) {
      const m = e && e.data ? e.data : null;
      if (!m) return;
      if (m.type === 'progress') {
        const fill = document.getElementById('progress-fill');
        const txt = document.getElementById('progress-text');
        if (fill) fill.style.width = (m.pct || 0) + '%';
        if (txt) txt.textContent = m.label || '';
        if (window.__appendLog) window.__appendLog('info', m.label || '');
      } else if (m.type === 'done') {
        settled = true;
        // Volcamos el STATE del worker al STATE del hilo principal. El
        // worker no conservaba el workbook del main thread (lo reconstruyó
        // localmente), pero STATE.archivos[k] ya sigue presente aquí con el
        // workbook original (lo creó loadFile). Solo actualizamos
        // queries/reporte/log/stats.
        if (m.state) {
          SPEC.STATE.queries = m.state.queries;
          SPEC.STATE.reporte = m.state.reporte;
          SPEC.STATE.log = m.state.log;
          SPEC.STATE.stats = m.state.stats;
        }
        worker.terminate();
        UI.activeWorker = null;
        resolve();
      } else if (m.type === 'error') {
        settled = true;
        worker.terminate();
        UI.activeWorker = null;
        const err = new Error(m.message || 'Error desconocido en worker');
        if (m.stack) err.stack = m.stack;
        reject(err);
      }
    };
    worker.onerror = function (e) {
      if (settled) return;
      settled = true;
      worker.terminate();
      UI.activeWorker = null;
      const detail = e && e.message ? e.message : ('worker ' + (e && e.filename ? e.filename + ':' + e.lineno : 'sin detalles'));
      reject(new Error('Error en Web Worker: ' + detail));
    };
    // Transferimos los 4 ArrayBuffers para evitar copia (zero-copy).
    worker.postMessage({ type: 'start', archivos: archivos }, transfer);
  });
}

/* Path main-thread: comportamiento legacy. Necesario para:
 *   - Navegadores sin Worker (legacy)
 *   - Tests de Node (vitest) — Worker no está soportado en el entorno node
 *   - Fallback si el worker falla
 * No mueve el cálculo del hilo principal; en archivos grandes puede congelar
 * la UI brevemente.
 */
async function analizarEnMainThread() {
  await SPEC.analizarYConciliar((p, msg) => {
    document.getElementById('progress-fill').style.width = p + '%';
    document.getElementById('progress-text').textContent = msg;
    window.__appendLog('info', msg);
  });
}

/* ===== Render resultados ===== */
function renderResultadosPanel() {
  const summary = document.getElementById('resultados-summary');
  summary.innerHTML = '';
  const q = SPEC.STATE.queries || {};
  const cards = [
    { label: 'Reg. horas válidos', value: q['01_HorasSinVolumen']?.length || 0, level: 'info', action: 'show-table', table: '01_HorasSinVolumen' },
    { label: 'Reg. volumen válidos', value: q['02_VolumenDetalle']?.length || 0, level: 'info', action: 'show-table', table: '02_VolumenDetalle' },
    { label: 'Reg. VSH válidos', value: q['09_VolumenSinHorasDetalle']?.length || 0, level: 'info', action: 'show-table', table: '09_VolumenSinHorasDetalle' },
    { label: 'Mapeos SPEC', value: q['12_MapeoActividadSPEC']?.length || 0, level: 'info', action: 'show-table', table: '12_MapeoActividadSPEC' },
    { label: 'Filas conciliadas', value: q['07_Conciliacion']?.length || 0, level: 'info', action: 'show-table', table: '07_Conciliacion' },
    { label: 'Propuestas HR', value: SPEC.STATE.reporte?.length || 0, level: 'info', action: 'show-table', table: 'REPORTE_CAMBIOS_HR' }
  ];
  for (const c of cards) {
    const el = document.createElement('div');
    el.className = 'kpi-card ' + c.level + ' clickable';
    el.dataset.action = c.action;
    el.dataset.table = c.table;
    el.innerHTML = `<div class="label">${escapeHtml(c.label)}</div><div class="value">${escapeHtml(c.value)}</div>`;
    summary.appendChild(el);
  }
  // Renderizar charts
  if (window.SPEC_CHARTS) {
    window.SPEC_CHARTS.renderChartsGrid('charts-grid');
  }
  const list = document.getElementById('table-list');
  list.innerHTML = '';
  for (const name of TAB_ORDER) {
    if (name === 'REPORTE_CAMBIOS_HR') continue;
    const data = q[name];
    if (!data) continue;
    const li = document.createElement('li');
    li.innerHTML = `
      <div>
        <span class="name">${escapeHtml(name)}</span><br>
        <span class="meta">${escapeHtml(TAB_DESC[name] || '')}</span>
      </div>
      <div>
        <span class="rows">${data.length} filas</span>
      </div>`;
    li.addEventListener('click', () => showTable(name, data));
    list.appendChild(li);
  }
}

function showTable(name, data) {
  UI.activeTable = name;
  UI.activeData = data;
  UI.viewerSearch = '';
  document.getElementById('viewer-search').value = '';
  const viewer = document.getElementById('table-viewer');
  viewer.style.display = 'block';
  document.getElementById('table-list').scrollIntoView({ behavior: 'smooth' });
  renderViewerTable();
}

function renderViewerTable() {
  const tbl = document.getElementById('viewer-table');
  if (!tbl) return;
  if (!UI.activeData || UI.activeData.length === 0) {
    // Reset VS state — sin listener activo
    _viewerDetachScroll();
    _viewerSortedData = null;
    _viewerCols = null;
    _viewerLastFirst = -1;
    _viewerLastLast = -1;
    tbl.innerHTML = '<tbody><tr><td>Sin datos</td></tr></tbody>';
    return;
  }
  // 1. Search filter (igual que antes)
  let data = UI.activeData;
  if (UI.viewerSearch) {
    const s = UI.viewerSearch.toLowerCase();
    data = data.filter(r =>
      Object.values(r).some(v => v != null && String(v).toLowerCase().indexOf(s) >= 0)
    );
  }
  const cols = Object.keys(UI.activeData[0]);
  // 2. Sort — M-02 bugfix: ordenar una COPIA del array filtrado para no
  // mutar UI.activeData (que es STATE.queries[name], compartido).
  if (UI.viewerSort.col) {
    const col = UI.viewerSort.col;
    const dir = UI.viewerSort.dir;
    data = data.slice().sort((a, b) => {
      let va = a[col], vb = b[col];
      if (va instanceof Date) va = va.getTime();
      if (vb instanceof Date) vb = vb.getTime();
      if (typeof va === 'number' && typeof vb === 'number') return (va - vb) * dir;
      va = (va == null ? '' : String(va));
      vb = (vb == null ? '' : String(vb));
      return va < vb ? -dir : (va > vb ? dir : 0);
    });
  }
  // 3. Cache VS state para que el handler de scroll no recalcule el sort/filter
  _viewerSortedData = data;
  _viewerCols = cols;
  _viewerLastFirst = -1;
  _viewerLastLast = -1;

  // 4. Render del <thead> (idempotente en cada re-render; el CSS lo pega arriba)
  // F6 — accessibility: scope="col" + aria-sort on the sorted <th>.
  let thead = '<thead><tr>';
  for (const c of cols) {
    const isSorted = UI.viewerSort.col === c;
    const ind = isSorted ? (UI.viewerSort.dir > 0 ? '▲' : '▼') : '';
    const sortAttr = isSorted
      ? ` aria-sort="${UI.viewerSort.dir > 0 ? 'ascending' : 'descending'}"`
      : '';
    thead += `<th scope="col" data-col="${escapeAttr(c)}"${sortAttr}>${escapeHtml(c)} <span class="sort-indicator" aria-hidden="true">${ind}</span></th>`;
  }
  thead += '</tr></thead>';
  // F6 — accessible caption identifying the table (sr-only via CSS class).
  const caption = `<caption class="sr-only">Tabla: ${escapeHtml(UI.activeTable || '')}</caption>`;

  if (data.length <= VIEWER_THRESHOLD) {
    // Render directo (tablas pequeñas / queries 07_Conciliacion 117 filas,
    // 01_HorasSinVolumen 117 filas, etc.). Sin overhead de scroll listener.
    _viewerDetachScroll();
    let html = caption + thead + '<tbody>';
    for (const r of data) {
      html += '<tr>' + _viewerRowCellsHtml(r, cols) + '</tr>';
    }
    html += '</tbody>';
    tbl.innerHTML = html;
  } else {
    // Virtual scrolling: tabla grande (02_VolumenDetalle 744 filas, etc.).
    // Estructura del <tbody>:
    //   <tr style="height:TopPad px">  ← padding superior (filas saltadas)
    //   <tr>…</tr> × N               ← filas visibles + overscan
    //   <tr style="height:BottomPad px"> ← padding inferior (altura total correcta)
    // El scrollbar del .viewer-table-wrap refleja N*VIEWER_ROW_HEIGHT px
    // gracias a los paddings.
    // Inicializa tbody con top pad 0 y todas las filas del primer viewport.
    // El scroll handler posteriormente actualizará topPad + filas + bottomPad.
    const wrap = tbl.closest('.viewer-table-wrap') || tbl.parentElement;
    _viewerScrollWrap = wrap;
    if (wrap) {
      wrap.scrollTop = 0;  // reset al re-render (nueva tabla / sort / search)
    }
    // Render inicial (caption + thead + tbody vacío; la ventana se pinta abajo)
    let html = caption + thead + '<tbody>';
    html += '</tbody>';
    tbl.innerHTML = html;
    _viewerLastFirst = -1;
    _viewerLastLast = -1;
    _viewerRenderWindow();
    // Listener (idempotente: addEventListener descarta duplicados idénticos).
    if (wrap) {
      wrap.addEventListener('scroll', _viewerOnScroll, { passive: true });
      // Re-render on resize (si cambió el viewport, hay que recalcular visibleCount)
      wrap.addEventListener('resize', _viewerOnScroll, { passive: true });
      window.addEventListener('resize', _viewerOnScroll, { passive: true });
    }
  }

  // 5. Sort handlers (en ambas modalidades — virtual y no-virtual)
  tbl.querySelectorAll('th').forEach(th => {
    th.addEventListener('click', () => {
      const c = th.dataset.col;
      if (UI.viewerSort.col === c) UI.viewerSort.dir = -UI.viewerSort.dir;
      else { UI.viewerSort.col = c; UI.viewerSort.dir = 1; }
      renderViewerTable();
    });
  });

  // 6. Hint al usuario si está en modo virtual
  if (data.length > VIEWER_THRESHOLD) {
    const note = document.getElementById('viewer-table-note');
    if (note) {
      note.textContent = `Mostrando ventana virtual de ${data.length} filas (${VIEWER_ROW_HEIGHT}px/fila).`;
    }
  } else {
    const note = document.getElementById('viewer-table-note');
    if (note) note.textContent = '';
  }
}

/* Construye el HTML de las <td> de una fila. Factorizado para que el
 * render virtual y el directo compartan la misma lógica de formato. */
function _viewerRowCellsHtml(r, cols) {
  let html = '';
  for (const c of cols) {
    let v = r[c];
    let cls = '';
    if (v instanceof Date) v = SPEC.formatFecha(v);
    else if (typeof v === 'number') { cls = 'numeric'; v = SPEC.formatNum(v); }
    else if (typeof v === 'boolean') { cls = v ? 'bool-true' : 'bool-false'; v = v ? 'SÍ' : 'NO'; }
    else if (v == null) v = '';
    else v = String(v);
    html += `<td class="${cls}">${escapeHtml(v)}</td>`;
  }
  return html;
}

/* Handler de scroll: batched con rAF para no saturar el event loop. */
function _viewerOnScroll() {
  if (_viewerScrollRafId) return;
  _viewerScrollRafId = window.requestAnimationFrame(() => {
    _viewerScrollRafId = null;
    _viewerRenderWindow();
  });
}

/* Desconecta listeners de scroll + cancela rAF pendiente. Se llama cuando:
 *  - Se abre una tabla pequeña (modo directo)
 *  - Se cierra el viewer
 *  - Se resetea UI.activeData
 */
function _viewerDetachScroll() {
  if (_viewerScrollRafId) {
    window.cancelAnimationFrame(_viewerScrollRafId);
    _viewerScrollRafId = null;
  }
  if (_viewerScrollWrap) {
    _viewerScrollWrap.removeEventListener('scroll', _viewerOnScroll);
    _viewerScrollWrap.removeEventListener('resize', _viewerOnScroll);
  }
  window.removeEventListener('resize', _viewerOnScroll);
  _viewerScrollWrap = null;
}

/* Re-render del <tbody> con solo la ventana visible + overscan.
 * Top/bottom padding rows mantienen la altura total del scrollbar.
 * Debounce: si first/last no cambiaron desde la última renderización, sale. */
function _viewerRenderWindow() {
  const tbl = document.getElementById('viewer-table');
  if (!tbl) return;
  const data = _viewerSortedData;
  const cols = _viewerCols;
  if (!data || !cols || data.length === 0) return;
  const wrap = _viewerScrollWrap || tbl.closest('.viewer-table-wrap');
  if (!wrap) return;
  const scrollTop = wrap.scrollTop || 0;
  const viewportH = wrap.clientHeight || 0;
  const total = data.length;
  const visibleCount = Math.max(VIEWER_VISIBLE, Math.ceil(viewportH / VIEWER_ROW_HEIGHT));
  // first = max(0, fila-en-el-top-del-viewport - OVERSCAN)
  const first = Math.max(0, Math.floor(scrollTop / VIEWER_ROW_HEIGHT) - VIEWER_OVERSCAN);
  // last = min(total, first + visibleCount + 2*OVERSCAN)
  const last = Math.min(total, first + visibleCount + 2 * VIEWER_OVERSCAN);
  // Debounce — si no cambió la ventana, no re-renderizamos.
  if (first === _viewerLastFirst && last === _viewerLastLast) return;
  _viewerLastFirst = first;
  _viewerLastLast = last;
  const topPad = first * VIEWER_ROW_HEIGHT;
  const bottomPad = (total - last) * VIEWER_ROW_HEIGHT;
  let html = '';
  if (topPad > 0) {
    html += `<tr class="vs-pad-top" style="height:${topPad}px"><td colspan="${cols.length}"></td></tr>`;
  }
  for (let i = first; i < last; i++) {
    html += '<tr>' + _viewerRowCellsHtml(data[i], cols) + '</tr>';
  }
  if (bottomPad > 0) {
    html += `<tr class="vs-pad-bottom" style="height:${bottomPad}px"><td colspan="${cols.length}"></td></tr>`;
  }
  const tbody = tbl.querySelector('tbody');
  if (tbody) {
    tbody.innerHTML = html;
  }
}

/* ===== Render reporte ===== */
function renderReportePanel() {
  const summary = document.getElementById('reporte-summary');
  summary.innerHTML = '';
  const rep = SPEC.STATE.reporte;
  if (!rep || rep.length === 0) {
    summary.innerHTML = '<p>El reporte aún no está generado.</p>';
    return;
  }
  // KPIs por sección
  const counts = {};
  for (const r of rep) {
    const sec = r['SECCION'] || '(sin sección)';
    counts[sec] = (counts[sec] || 0) + 1;
  }
  for (const sec of Object.keys(counts)) {
    const card = document.createElement('div');
    card.className = 'kpi-card info clickable';
    card.dataset.action = 'filter-seccion';
    card.dataset.value = sec;
    card.innerHTML = `<div class="label">${escapeHtml(sec)}</div><div class="value">${counts[sec]}</div>`;
    summary.appendChild(card);
  }
  const requiere = {};
  for (const r of rep) {
    const v = r['REQUIERE CAMBIO RRHH'] || '?';
    requiere[v] = (requiere[v] || 0) + 1;
  }
  for (const k of ['SI', 'REVISAR', 'NO']) {
    if (requiere[k] != null) {
      const card = document.createElement('div');
      card.className = 'kpi-card ' + (k === 'SI' ? 'warn' : (k === 'NO' ? 'ok' : 'info')) + ' clickable';
      card.dataset.action = 'filter-requiere';
      card.dataset.value = k;
      card.innerHTML = `<div class="label">Requiere: ${escapeHtml(k)}</div><div class="value">${requiere[k]}</div>`;
      summary.appendChild(card);
    }
  }
  // Materialidad KPIs (clicables)
  const matCounts = {};
  for (const r of rep) {
    const m = r['MATERIALIDAD'] || '?';
    matCounts[m] = (matCounts[m] || 0) + 1;
  }
  for (const m of ['CRITICA >= 4 H', 'ALTA 1-4 H', 'MEDIA < 1 H', 'BAJA < 15 MIN', 'MICRO < 5 MIN']) {
    if (matCounts[m] != null) {
      const card = document.createElement('div');
      card.className = 'kpi-card ' + (m.startsWith('CRITICA') ? 'error' : (m.startsWith('ALTA') ? 'warn' : 'info')) + ' clickable';
      card.dataset.action = 'filter-materialidad';
      card.dataset.value = m;
      card.innerHTML = `<div class="label">${escapeHtml(m)}</div><div class="value">${matCounts[m]}</div>`;
      summary.appendChild(card);
    }
  }
  renderReporteTable();
}

function renderReporteTable() {
  const tbl = document.getElementById('reporte-table');
  const rep = SPEC.STATE.reporte;
  if (!rep) { tbl.innerHTML = ''; return; }
  let data = rep;
  // Filters
  if (UI.reporteFilter.seccion) data = data.filter(r => r['SECCION'] === UI.reporteFilter.seccion);
  if (UI.reporteFilter.materialidad) data = data.filter(r => r['MATERIALIDAD'] === UI.reporteFilter.materialidad);
  if (UI.reporteFilter.cambio) data = data.filter(r => r['REQUIERE CAMBIO RRHH'] === UI.reporteFilter.cambio);
  if (UI.reporteFilter.search) {
    const s = UI.reporteFilter.search.toLowerCase();
    data = data.filter(r => Object.values(r).some(v => v != null && String(v).toLowerCase().indexOf(s) >= 0));
  }
  const cols = Object.keys(rep[0]);
  const limited = data.slice(0, 1000);
  // F6 — accessible caption + scope="col" + aria-sort on the sorted <th>.
  let html = '<caption class="sr-only">Tabla: REPORTE_CAMBIOS_HR</caption><thead><tr>';
  for (const c of cols) {
    const isSorted = UI.viewerSort.col === c;
    const sortAttr = isSorted
      ? ` aria-sort="${UI.viewerSort.dir > 0 ? 'ascending' : 'descending'}"`
      : '';
    html += `<th scope="col" data-col="${escapeAttr(c)}"${sortAttr}>${escapeHtml(c)}</th>`;
  }
  html += '</tr></thead><tbody>';
  for (const r of limited) {
    html += '<tr>';
    for (const c of cols) {
      let v = r[c];
      let cls = '';
      if (v instanceof Date) v = SPEC.formatFecha(v);
      else if (typeof v === 'number') { cls = 'numeric'; v = SPEC.formatNum(v); }
      else if (v == null) v = '';
      else v = String(v);
      if (c === 'SECCION') {
        const m = (v.match(/^(\d)/) || [])[1];
        if (m) cls = 'section-' + m;
      }
      html += `<td class="${escapeHtml(cls)}">${escapeHtml(v)}</td>`;
    }
    html += '</tr>';
  }
  html += '</tbody>';
  tbl.innerHTML = html;
  tbl.querySelectorAll('th').forEach(th => {
    th.addEventListener('click', () => {
      const c = th.dataset.col;
      if (UI.viewerSort.col === c) UI.viewerSort.dir = -UI.viewerSort.dir;
      else { UI.viewerSort.col = c; UI.viewerSort.dir = 1; }
      // M-02 bugfix: do NOT mutate STATE.reporte in place — sort a copy of the
      // filtered data, then re-render. The previous code mutated `rep` (the
      // original STATE.reporte array) which permanently changed data order.
      data = data.slice().sort((a, b) => {
        let va = a[c], vb = b[c];
        if (va instanceof Date) va = va.getTime();
        if (vb instanceof Date) vb = vb.getTime();
        if (typeof va === 'number' && typeof vb === 'number') return (va - vb) * UI.viewerSort.dir;
        va = (va == null ? '' : String(va));
        vb = (vb == null ? '' : String(vb));
        return va < vb ? -UI.viewerSort.dir : (va > vb ? UI.viewerSort.dir : 0);
      });
      renderReporteTable();
    });
  });
}

/* ===== Trazabilidad ===== */
function renderTrazabilidadPanel() {
  const sel = document.getElementById('traz-tabla');
  sel.innerHTML = '<option value="">—</option>';
  for (const name of TAB_ORDER) {
    const opt = document.createElement('option');
    opt.value = name;
    opt.textContent = name;
    sel.appendChild(opt);
  }
  sel.value = UI.traceability.currentTable || '';
  document.getElementById('traz-fila').value = UI.traceability.currentRow || 1;
}

function mostrarTrazabilidad() {
  const tabla = document.getElementById('traz-tabla').value;
  const filaStr = document.getElementById('traz-fila').value;
  const result = document.getElementById('traz-result');
  if (!tabla) { result.innerHTML = '<p>Selecciona una tabla.</p>'; return; }
  const fila = parseInt(filaStr, 10);
  if (!isFinite(fila) || fila < 1) { result.innerHTML = '<p>Fila inválida.</p>'; return; }
  UI.traceability.currentTable = tabla;
  UI.traceability.currentRow = fila;
  // Obtener data
  let data;
  if (tabla === 'REPORTE_CAMBIOS_HR') data = SPEC.STATE.reporte;
  else data = SPEC.STATE.queries[tabla];
  if (!data || data.length === 0) {
    result.innerHTML = '<p>Tabla vacía o no procesada.</p>';
    return;
  }
  if (fila > data.length) {
    result.innerHTML = `<p>La tabla solo tiene ${data.length} filas.</p>`;
    return;
  }
  const r = data[fila - 1];
  let html = '';
  html += '<div class="traz-section"><h4>Origen del registro</h4><dl>';
  if (tabla === 'REPORTE_CAMBIOS_HR') {
    html += `<dt>Tabla origen</dt><dd>Generado por GenerarReporteCambiosHR (VBA port)</dd>`;
    html += `<dt>ID REGISTRO (origen)</dt><dd>${escapeHtml(String(r['ID REGISTRO'] || ''))}</dd>`;
    html += `<dt>Archivo origen volumen</dt><dd>${escapeHtml(String(r['ARCHIVO ORIGEN'] || ''))}</dd>`;
    html += `<dt>Fila origen volumen</dt><dd>${escapeHtml(String(r['FILA ORIGEN'] || ''))}</dd>`;
    html += `<dt>Sección asignada</dt><dd>${escapeHtml(String(r['SECCION'] || ''))}</dd>`;
    html += `<dt>Tipo coincidencia</dt><dd>${escapeHtml(String(r['TIPO COINCIDENCIA'] || ''))}</dd>`;
    html += `<dt>Requiere cambio RRHH</dt><dd>${escapeHtml(String(r['REQUIERE CAMBIO RRHH'] || ''))}</dd>`;
  } else if (tabla === '01_HorasSinVolumen' || tabla === '02_VolumenDetalle' || tabla === '09_VolumenSinHorasDetalle') {
    const archKey = tabla === '09_VolumenSinHorasDetalle' ? 'ArchivoOrigenVSH' : 'ArchivoOrigen';
    const filaKey = tabla === '09_VolumenSinHorasDetalle' ? 'FilaOrigenVSH' : 'FilaOrigen';
    html += `<dt>Archivo de origen</dt><dd>${escapeHtml(String(r[archKey] || ''))}</dd>`;
    html += `<dt>Fila en archivo</dt><dd>${escapeHtml(String(r[filaKey] || ''))}</dd>`;
    html += `<dt>Registro válido</dt><dd>${escapeHtml(String(r[(tabla === '09_VolumenSinHorasDetalle' ? 'RegistroValidoVSH' : 'RegistroValido')] || ''))}</dd>`;
    html += `<dt>Clave natural</dt><dd>${escapeHtml(String(r[(tabla === '09_VolumenSinHorasDetalle' ? 'ClaveNaturalVSH' : 'ClaveNatural')] || ''))}</dd>`;
    html += `<dt>Posible duplicado</dt><dd>${escapeHtml(String(r[(tabla === '09_VolumenSinHorasDetalle' ? 'PosibleDuplicadoVSH' : 'PosibleDuplicado')] || ''))}</dd>`;
  }
  html += '</dl></div>';
  html += '<div class="traz-section"><h4>Transformaciones aplicadas</h4><ul>';
  if (tabla === '01_HorasSinVolumen' || tabla === '02_VolumenDetalle' || tabla === '09_VolumenSinHorasDetalle') {
    html += '<li>fx_NormalizaTexto: trim + clean + upper + collapse spaces</li>';
    html += '<li>fx_Fecha: parse a fecha date-only</li>';
    html += '<li>fx_NormalizaLogin: extrae LoginCanonico + IdNumerico + Prefijo</li>';
    html += '<li>Cálculo de RegistroValido (Fecha + Login + Activity/Task + Volumen/Horas)</li>';
    html += '<li>Construcción de ClaveNatural</li>';
    html += '<li>RepeticionesClave (GROUP BY) y PosibleDuplicado</li>';
    html += '<li>Filtro RegistroValido = true</li>';
  } else if (tabla === '12_MapeoActividadSPEC') {
    html += '<li>Excel.Workbook → leerMapping → promote headers</li>';
    html += '<li>Normalización de nombres de columnas</li>';
    html += '<li>Validación de columnas obligatorias</li>';
    html += '<li>fx_NormalizaTexto en 8 columnas</li>';
    html += '<li>Filas válidas: SAP_CODE≠null AND CUSTOMER≠null AND TASK_WMS≠null</li>';
    html += '<li>GROUP BY (SAP_CODE, CUSTOMER, TASK_WMS) con agregaciones</li>';
    html += '<li>Cálculo de EstadoMapeoSPEC (SIN TASK_SPEC / UNICO / AMBIGUO)</li>';
  } else if (tabla === '13_VolumenMapeadoSPEC') {
    html += '<li>LEFT OUTER JOIN 02_VolumenDetalle × 12_MapeoActividadSPEC por (SAP_CODE, CUSTOMER, WMS_TASK)</li>';
    html += '<li>Expansión de 11 columnas del mapeo</li>';
    html += '<li>EstadoMapeoFinal = EstadoMapeoSPEC ?? "SIN MAPEO"</li>';
  } else if (tabla === '07_Conciliacion') {
    html += '<li>Base: 01_HorasSinVolumen</li>';
    html += '<li>LEFT OUTER JOIN con 03_VolumenPersonaDia por (Fecha, LoginCanonico)</li>';
    html += '<li>LEFT OUTER JOIN con 14_VolumenPersonaDiaActividadSPEC por (Fecha, LoginCanonico, Activity)</li>';
    html += '<li>LEFT OUTER JOIN con 05_VolumenIdNumericoDia por (Fecha, IdNumericoNormalizado)</li>';
    html += '<li>LEFT OUTER JOIN con 10_VolumenSinHorasPersonaDia por (Fecha, LoginCanonico)</li>';
    html += '<li>LEFT OUTER JOIN con 15_VolumenSinHorasPersonaDiaActividadSPEC por (Fecha, LoginCanonico, Activity)</li>';
    html += '<li>GROUP BY (Fecha, LoginCanonico) interno → NumActHR</li>';
    html += '<li>Reemplazo null → 0 (numéricos) y null → false (booleanos)</li>';
    html += '<li>Cálculo VolumenOtrasActividadesPositivo = MAX(0, Total - Misma)</li>';
    html += '<li>Clasificacion (10 categorías en orden)</li>';
    html += '<li>NivelConfianza (ALTA / MEDIA / NO DETERMINABLE)</li>';
    html += '<li>Evidencia (texto concatenado con "; ")</li>';
    html += '<li>Explicacion + AccionRecomendada + Materialidad</li>';
  } else if (tabla === 'REPORTE_CAMBIOS_HR') {
    html += '<li>Pre-indexar 13_VolumenMapeadoSPEC por (Fecha|LoginCanonico) y (Fecha|IdNumNorm)</li>';
    html += '<li>Para cada fila de 01_HorasSinVolumen:</li>';
    html += '<li>  Pass 1: LOGIN EXACTO (Fecha + LoginCanonico)</li>';
    html += '<li>  Pass 2 (si Pass 1 falla): MISMO NUMERO, DISTINTO PREFIJO</li>';
    html += '<li>  Multi HR Task → modo REVISION MANUAL - MULTIPLES HR TASK</li>';
    html += '<li>  Ambigüedad IdNum → modo REVISION MANUAL - AMBIGUEDAD ID NUMERICO</li>';
    html += '<li>  Clasificación en sección 1-7 según estado, coincidencias, TasksSPEC</li>';
    html += '<li>  Una fila de salida por cada match encontrado</li>';
    html += '<li>  Materialidad (MICRO/BAJA/MEDIA/ALTA/CRITICA)</li>';
    html += '<li>  REQUIERE CAMBIO RRHH (SI/NO/REVISAR)</li>';
  }
  html += '</ul></div>';
  // Datos completos del registro
  html += '<div class="traz-section"><h4>Registro completo</h4><dl>';
  for (const k of Object.keys(r)) {
    let v = r[k];
    if (v instanceof Date) v = SPEC.formatFecha(v);
    else if (v == null) v = '(null)';
    else v = String(v);
    html += `<dt>${escapeHtml(k)}</dt><dd>${escapeHtml(v)}</dd>`;
  }
  html += '</dl></div>';
  result.innerHTML = html;
}

/* ===== Exportar ===== */
function renderExportarPanel() {
  const list = document.getElementById('export-list');
  list.innerHTML = '';
  for (const name of TAB_ORDER) {
    let data;
    if (name === 'REPORTE_CAMBIOS_HR') data = SPEC.STATE.reporte;
    else data = SPEC.STATE.queries[name];
    if (!data || data.length === 0) continue;
    const li = document.createElement('li');
    li.innerHTML = `
      <div>
        <span class="name">${name}</span><br>
        <span class="meta">${data.length} filas · ${Object.keys(data[0] || {}).length} columnas</span>
      </div>
      <div class="actions">
        <button class="btn btn-secondary btn-export-xlsx" data-name="${name}">XLSX</button>
        <button class="btn btn-secondary btn-export-csv" data-name="${name}">CSV</button>
      </div>`;
    list.appendChild(li);
  }
  // Añadir exportación de decisiones y auditoría
  const decisions = Object.keys(SPEC.STATE.decisions || {}).length;
  const audit = (SPEC.STATE.auditLog || []).length;
  if (decisions > 0 || audit > 0) {
    const liDec = document.createElement('li');
    liDec.innerHTML = `
      <div>
        <span class="name">Correcciones aprobadas</span><br>
        <span class="meta">${decisions} decisión(es) · Incluye valor original, propuesta, valor final, motivo y confianza</span>
      </div>
      <div class="actions">
        <button class="btn btn-primary btn-export-decisions-xlsx">XLSX</button>
        <button class="btn btn-secondary btn-export-decisions-csv">CSV</button>
      </div>`;
    list.appendChild(liDec);
    liDec.querySelector('.btn-export-decisions-xlsx').addEventListener('click', () => {
      const data = Object.entries(SPEC.STATE.decisions).map(([id, d]) => ({
        'ID Incidencia': id,
        'ID Registro': d.idRegistro || '',
        'Persona': d.persona || '',
        'Fecha': d.fecha ? SPEC.formatFecha(d.fecha) : '',
        'Sección': d.seccion || '',
        'Tarea original (HR Task fichada)': d.tareaOriginal || '',
        'Propuesta automática (Mapping)': d.propuesta || '',
        'Tarea final seleccionada': d.tareaFinal || '',
        'Decisión': d.decision || '',
        'Motivo': d.motivo || '',
        'Nivel confianza': d.nivelConfianza || '',
        'Fecha decisión': new Date(d.timestamp).toLocaleString('es-ES'),
        'Usuario': d.usuario || ''
      }));
      SPEC.exportToXlsx(data, `Correcciones_aprobadas_${timestamp()}.xlsx`, 'Correcciones');
      toast('Correcciones exportadas.', { level: 'success' });
    });
    liDec.querySelector('.btn-export-decisions-csv').addEventListener('click', () => {
      const data = Object.entries(SPEC.STATE.decisions).map(([id, d]) => ({
        'ID Incidencia': id,
        'ID Registro': d.idRegistro || '',
        'Persona': d.persona || '',
        'Fecha': d.fecha ? SPEC.formatFecha(d.fecha) : '',
        'Sección': d.seccion || '',
        'Tarea original': d.tareaOriginal || '',
        'Propuesta': d.propuesta || '',
        'Tarea final': d.tareaFinal || '',
        'Decisión': d.decision || '',
        'Motivo': d.motivo || '',
        'Confianza': d.nivelConfianza || '',
        'Fecha decisión': new Date(d.timestamp).toLocaleString('es-ES')
      }));
      SPEC.exportToCsv(data, `Correcciones_aprobadas_${timestamp()}.csv`);
      toast('Correcciones exportadas a CSV.', { level: 'success' });
    });
  }
  list.querySelectorAll('.btn-export-xlsx').forEach(b => b.addEventListener('click', e => {
    const name = e.target.dataset.name;
    const data = name === 'REPORTE_CAMBIOS_HR' ? SPEC.STATE.reporte : SPEC.STATE.queries[name];
    if (data) {
      const fname = name.replace(/[^\w]/g, '_') + '_' + timestamp() + '.xlsx';
      SPEC.exportToXlsx(data, fname, name.slice(0, 31));
    }
  }));
  list.querySelectorAll('.btn-export-csv').forEach(b => b.addEventListener('click', e => {
    const name = e.target.dataset.name;
    const data = name === 'REPORTE_CAMBIOS_HR' ? SPEC.STATE.reporte : SPEC.STATE.queries[name];
    if (data) {
      const fname = name.replace(/[^\w]/g, '_') + '_' + timestamp() + '.csv';
      SPEC.exportToCsv(data, fname);
    }
  }));
}

/* ===== Utilidades HTML ===== */
function escapeHtml(s) {
  if (s == null) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
function escapeAttr(s) {
  return escapeHtml(s).replace(/"/g, '&quot;');
}

/* ===== Init ===== */
function init() {
  // FASE-init-fix — idempotency guard. The init-wrap chain (v3.0 + v4.0 blocks)
  // reassigns `window.init` to wrap the original; this means the DOMContentLoaded
  // listener registered inside this IIFE (next line) captures the ORIGINAL init
  // by reference. The wrapped init (with all v3/v4 setups) is therefore never
  // called on DOMContentLoaded. The fix has two parts:
  //   1. Add an idempotency guard here so the original init can run only once.
  //   2. Add a NEW DOMContentLoaded listener at the end of the v4.0 block that
  //      calls `window.init` (the wrapped version), which calls _origInit (this
  //      function, guarded) and then runs all v3/v4 setups.
  if (window.__spec_init_done) return;
  window.__spec_init_done = true;
  setupTabs();
  setupDropZones();
  // Log append hook
  window.__appendLog = null;
}
document.addEventListener('DOMContentLoaded', init);

/* ===== AUD-CRIT-002 / AUD-HIGH-001 fix — export IIFE privates to window =====
 * The original IIFE encapsulated escapeHtml, escapeAttr, UI, loadFile, init,
 * timestamp, etc. as private closure symbols. The v3.0+ block (lines 778+)
 * reassigns and references these symbols as if they were global, causing
 * `ReferenceError: loadFile is not defined` at line ~1502 which halts script
 * execution and kills ALL v3/v4/v5 features (dark mode, review, decisions,
 * audit log, patterns, persistence, search, preview, undo, shortcuts).
 *
 * Fix: explicitly expose every symbol that the post-IIFE global code
 * reassigns or calls. This is the minimum surgical change that unblocks
 * the v3/v4/v5 layers without rewriting the file.
 */
Object.assign(window, {
  UI,
  escapeHtml,
  escapeAttr,
  timestamp,
  pad,
  loadFile,
  loadFiles,
  updateDropZoneFiles,
  removeFile,
  checkAllLoaded,
  setStatus,
  validarArchivos,
  addMessage,
  reiniciarCarga,
  reiniciarProceso,
  analizar,
  analizarConWorker,
  analizarEnMainThread,
  renderResultadosPanel,
  showTable,
  renderViewerTable,
  renderReportePanel,
  renderReporteTable,
  renderTrazabilidadPanel,
  mostrarTrazabilidad,
  renderExportarPanel,
  init
});

})();

/* ============================================================================
 * MEJORAS v3.0 — Toasts, Dark Mode, Global Search, Persistence,
 * Detail Panel, File Preview, KPI Drilldown
 * ========================================================================== */

/* ===================== TOAST SYSTEM ===================== */
function toast(message, opts = {}) {
  const container = document.getElementById('toast-container');
  if (!container) {
    // Fallback a alert si no existe el contenedor
    alert(message);
    return;
  }
  const level = opts.level || 'info';
  const title = opts.title || ({
    success: '✓ Éxito',
    error: '✕ Error',
    warn: '⚠ Atención',
    info: 'ℹ Información'
  })[level] || 'ℹ';
  const t = document.createElement('div');
  t.className = 'toast ' + level;
  let actionsHtml = '';
  if (opts.confirm) {
    actionsHtml = `<div class="toast-actions">
      <button class="confirm">${opts.confirmLabel || 'Aceptar'}</button>
      <button class="cancel">${opts.cancelLabel || 'Cancelar'}</button>
    </div>`;
  } else if (opts.action) {
    actionsHtml = `<div class="toast-actions">
      <button class="confirm">${opts.actionLabel || 'Ir'}</button>
    </div>`;
  }
  t.innerHTML = `
    <div class="toast-icon">${title.split(' ')[0]}</div>
    <div class="toast-body">
      <div class="toast-title">${title.split(' ').slice(1).join(' ') || title}</div>
      <div class="toast-msg">${escapeHtml(message)}</div>
      ${actionsHtml}
    </div>`;
  container.appendChild(t);
  // Auto-dismiss after 4s unless confirm
  let timeout = null;
  function dismiss() {
    if (timeout) clearTimeout(timeout);
    t.classList.add('toast-out');
    setTimeout(() => t.remove(), 200);
  }
  if (!opts.confirm) {
    timeout = setTimeout(dismiss, opts.duration || 4000);
  }
  // Action handlers
  const confirmBtn = t.querySelector('.confirm');
  const cancelBtn = t.querySelector('.cancel');
  if (confirmBtn) {
    confirmBtn.addEventListener('click', () => {
      if (opts.confirm) opts.confirm();
      else if (opts.action) opts.action();
      dismiss();
    });
  }
  if (cancelBtn) {
    cancelBtn.addEventListener('click', () => {
      if (opts.cancelAction) opts.cancelAction();
      dismiss();
    });
  }
  return { dismiss };
}

function confirmDialog(message, onConfirm, opts = {}) {
  toast(message, {
    level: 'warn',
    title: '⚠ Confirmar',
    confirm: onConfirm,
    confirmLabel: opts.confirmLabel || 'Sí',
    cancelLabel: opts.cancelLabel || 'No',
    duration: 0
  });
}

/* ===================== DARK MODE (3 estados: light/dark/auto) ===================== */
function setupThemeToggle() {
  const btn = document.getElementById('theme-toggle');
  const icon = document.getElementById('theme-icon');
  const label = document.getElementById('theme-label');
  if (!btn) return;

  const THEMES = [
    { id: 'light', icon: '☀', label: 'Modo claro' },
    { id: 'dark', icon: '🌙', label: 'Modo oscuro' },
    { id: 'auto', icon: '🌓', label: 'Automático (sistema)' }
  ];

  function applyTheme(themeId) {
    const t = THEMES.find(x => x.id === themeId) || THEMES[0];
    icon.textContent = t.icon;
    label.textContent = t.label;
    const isDark = themeId === 'dark' ||
      (themeId === 'auto' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
    document.body.classList.toggle('dark', isDark);
    if (themeId === 'auto') {
      document.body.setAttribute('data-theme-mode', 'auto');
    } else {
      document.body.setAttribute('data-theme-mode', themeId);
    }
  }

  // Restore saved
  const saved = localStorage.getItem('spec_theme') || 'auto';
  applyTheme(saved);

  // Listen to OS changes if in auto mode
  if (window.matchMedia) {
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const mqListener = () => {
      if ((localStorage.getItem('spec_theme') || 'auto') === 'auto') {
        applyTheme('auto');
      }
    };
    if (mq.addEventListener) mq.addEventListener('change', mqListener);
    else if (mq.addListener) mq.addListener(mqListener);
  }

  btn.addEventListener('click', () => {
    const current = localStorage.getItem('spec_theme') || 'auto';
    const idx = THEMES.findIndex(x => x.id === current);
    const next = THEMES[(idx + 1) % THEMES.length];
    localStorage.setItem('spec_theme', next.id);
    applyTheme(next.id);
    toast(`Tema cambiado a: ${next.label}`, { level: 'info', duration: 1500 });
  });
}

/* ===================== GLOBAL SEARCH ===================== */
function setupGlobalSearch() {
  const input = document.getElementById('global-search');
  const results = document.getElementById('global-search-results');
  if (!input || !results) return;
  let timeout = null;
  input.addEventListener('input', e => {
    if (timeout) clearTimeout(timeout);
    const q = e.target.value.trim().toLowerCase();
    if (!q || q.length < 2) {
      results.classList.remove('open');
      results.innerHTML = '';
      return;
    }
    timeout = setTimeout(() => doGlobalSearch(q, results), 200);
  });
  // Cerrar al hacer clic fuera
  document.addEventListener('click', e => {
    if (!e.target.closest('#global-search-wrap')) {
      results.classList.remove('open');
    }
  });
  // Tecla / para enfocar
  document.addEventListener('keydown', e => {
    if (e.key === '/' && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
      e.preventDefault();
      input.focus();
    }
    if (e.key === 'Escape') {
      results.classList.remove('open');
      input.blur();
    }
  });
}

function doGlobalSearch(query, resultsEl) {
  const matches = [];
  const tables = Object.assign({}, SPEC.STATE.queries, { 'REPORTE_CAMBIOS_HR': SPEC.STATE.reporte });
  for (const [tableName, rows] of Object.entries(tables)) {
    if (!rows || rows.length === 0) continue;
    // Limit search to first 200 rows for performance
    for (let i = 0; i < Math.min(rows.length, 500); i++) {
      const r = rows[i];
      for (const [col, val] of Object.entries(r)) {
        if (val == null) continue;
        let s;
        if (val instanceof Date) s = SPEC.formatFecha(val);
        else if (typeof val === 'number') s = String(val);
        else s = String(val);
        const idx = s.toLowerCase().indexOf(query);
        if (idx >= 0) {
          // Build snippet
          const start = Math.max(0, idx - 30);
          const end = Math.min(s.length, idx + query.length + 30);
          const snippet = (start > 0 ? '…' : '') + s.slice(start, end) + (end < s.length ? '…' : '');
          matches.push({ tableName, col, rowIdx: i + 1, snippet });
          if (matches.length >= 50) break;
        }
      }
      if (matches.length >= 50) break;
    }
    if (matches.length >= 50) break;
  }
  if (matches.length === 0) {
    resultsEl.innerHTML = '<div class="gsr-empty">Sin resultados en ninguna tabla</div>';
    resultsEl.classList.add('open');
    return;
  }
  resultsEl.innerHTML = `<div class="gsr-header">${matches.length} resultado(s) en ${new Set(matches.map(m => m.tableName)).size} tabla(s)</div>`;
  for (const m of matches.slice(0, 50)) {
    const item = document.createElement('div');
    item.className = 'gsr-item';
    item.innerHTML = `
      <div class="gsr-table">${m.tableName}</div>
      <div class="gsr-snippet"><strong>${escapeHtml(m.col)}:</strong> ${escapeHtml(m.snippet)}</div>
      <div class="gsr-row">Fila ${m.rowIdx}</div>
    `;
    item.addEventListener('click', () => {
      resultsEl.classList.remove('open');
      const input = document.getElementById('global-search');
      input.value = '';
      // Navegar y abrir tabla
      document.querySelector('.tab[data-tab="resultados"]').click();
      let data;
      if (m.tableName === 'REPORTE_CAMBIOS_HR') data = SPEC.STATE.reporte;
      else data = SPEC.STATE.queries[m.tableName];
      if (data) {
        showTable(m.tableName, data);
        // Highlight row m.rowIdx
        setTimeout(() => {
          const tbl = document.getElementById('viewer-table');
          const row = tbl.querySelector(`tbody tr:nth-child(${Math.min(m.rowIdx, 1000)})`);
          if (row) {
            row.scrollIntoView({ block: 'center', behavior: 'smooth' });
            row.style.background = '#fff5d6';
            setTimeout(() => row.style.background = '', 2500);
          }
        }, 100);
      }
    });
    resultsEl.appendChild(item);
  }
  resultsEl.classList.add('open');
}

/* ===================== PERSISTENCE ===================== */
function persistState() {
  try {
    const toSave = {
      queries: {},
      reporte: SPEC.STATE.reporte,
      stats: SPEC.STATE.stats,
      savedAt: new Date().toISOString()
    };
    // Serialize queries, converting Date to ISO for storage
    for (const [k, v] of Object.entries(SPEC.STATE.queries)) {
      toSave.queries[k] = v.map(row => {
        const r = {};
        for (const [kk, vv] of Object.entries(row)) {
          if (vv instanceof Date) r[kk] = { __date: vv.toISOString() };
          else r[kk] = vv;
        }
        return r;
      });
    }
    localStorage.setItem('spec_state', JSON.stringify(toSave));
    updatePersistIndicator(true);
    return true;
  } catch (e) {
    console.warn('No se pudo persistir el estado:', e);
    return false;
  }
}

function restoreState() {
  try {
    const raw = localStorage.getItem('spec_state');
    if (!raw) return false;
    const saved = JSON.parse(raw);
    if (!saved || !saved.queries) return false;
    // Deserialize Date objects
    function revive(obj) {
      if (obj && typeof obj === 'object') {
        if (obj.__date) return new Date(obj.__date);
        const out = Array.isArray(obj) ? [] : {};
        for (const [k, v] of Object.entries(obj)) out[k] = revive(v);
        return out;
      }
      return obj;
    }
    SPEC.STATE.queries = revive(saved.queries);
    SPEC.STATE.reporte = revive(saved.reporte);
    SPEC.STATE.stats = saved.stats || {};
    updatePersistIndicator(true);
    setStatus('Resultados restaurados de sesión anterior', 'info');
    return true;
  } catch (e) {
    console.warn('No se pudo restaurar:', e);
    return false;
  }
}

function clearPersistedState() {
  localStorage.removeItem('spec_state');
  updatePersistIndicator(false);
}

function updatePersistIndicator(hasData) {
  const ind = document.getElementById('persist-indicator');
  if (!ind) return;
  if (hasData) {
    ind.className = 'persist-indicator has-data';
    const savedAt = (() => {
      try {
        const raw = localStorage.getItem('spec_state');
        if (raw) {
          const parsed = JSON.parse(raw);
          if (parsed.savedAt) return new Date(parsed.savedAt).toLocaleString('es-ES');
        }
      } catch (e) {}
      return '';
    })();
    ind.textContent = `Guardado${savedAt ? ': ' + savedAt : ''}`;
    ind.title = 'Resultados guardados localmente. Clic para limpiar.';
    ind.onclick = () => {
      confirmDialog('¿Borrar los resultados guardados en este navegador?', () => {
        clearPersistedState();
        toast('Resultados guardados eliminados.', { level: 'success' });
      });
    };
  } else {
    ind.className = 'persist-indicator empty';
    ind.textContent = 'Sin guardar';
    ind.title = 'Sin resultados guardados localmente';
    ind.onclick = null;
  }
}

function setupPersistence() {
  const ind = document.getElementById('persist-indicator');
  if (!ind) return;
  updatePersistIndicator(!!localStorage.getItem('spec_state'));
  // Si hay estado guardado, ofrecer restaurar
  if (localStorage.getItem('spec_state')) {
    setTimeout(() => {
      toast('Tienes resultados guardados de una sesión anterior.', {
        level: 'info',
        title: 'ℹ Sesión anterior',
        action: () => {
          if (restoreState()) {
            // Activar pestaña resultados
            document.querySelector('.tab[data-tab="resultados"]').click();
            renderResultadosPanel();
            renderReportePanel();
            toast('Resultados restaurados.', { level: 'success' });
          }
        },
        actionLabel: 'Restaurar',
        duration: 10000
      });
    }, 800);
  }
}

/* ===================== MODAL FOCUS TRAP (F6 accessibility) =====================
 * Simple focus trap for modal dialogs (#detail-panel, #preview-modal).
 * On open: stores document.activeElement, moves focus to the close button,
 * intercepts Tab/Shift+Tab to cycle within the modal.
 * On close: removes the listener and restores focus to the previously-focused
 * element. Single modal at a time is assumed.
 */
let _modalFocusState = null; // { modalEl, handler, previouslyFocused }

function _modalFocusables(modalEl) {
  // Returns a snapshot of visible, focusable elements inside the modal.
  const sel = 'button:not([disabled]), [href], input:not([disabled]),' +
    ' select:not([disabled]), textarea:not([disabled]),' +
    ' [tabindex]:not([tabindex="-1"])';
  return Array.from(modalEl.querySelectorAll(sel)).filter(el => {
    // Skip elements that are not visible (display:none, visibility:hidden, or hidden parent).
    if (el.offsetParent === null && el.tagName !== 'INPUT') return false;
    if (el.type === 'file' && el.hasAttribute('hidden')) return false;
    return true;
  });
}

function _trapFocus(modalEl) {
  const previouslyFocused = document.activeElement;
  const handler = e => {
    if (e.key !== 'Tab') return;
    const arr = _modalFocusables(modalEl);
    if (arr.length === 0) return;
    const first = arr[0];
    const last = arr[arr.length - 1];
    if (e.shiftKey) {
      if (document.activeElement === first || !modalEl.contains(document.activeElement)) {
        e.preventDefault();
        last.focus();
      }
    } else {
      if (document.activeElement === last || !modalEl.contains(document.activeElement)) {
        e.preventDefault();
        first.focus();
      }
    }
  };
  modalEl.addEventListener('keydown', handler);
  _modalFocusState = { modalEl, handler, previouslyFocused };
  // Move focus into the modal — close button first, fall back to first focusable.
  const closeBtn = modalEl.querySelector('button[class*="close"], .detail-panel-close');
  if (closeBtn) closeBtn.focus();
  else {
    const arr = _modalFocusables(modalEl);
    if (arr.length > 0) arr[0].focus();
  }
}

function _releaseFocus() {
  if (!_modalFocusState) return;
  const { modalEl, handler, previouslyFocused } = _modalFocusState;
  modalEl.removeEventListener('keydown', handler);
  _modalFocusState = null;
  if (previouslyFocused && typeof previouslyFocused.focus === 'function') {
    try { previouslyFocused.focus(); } catch { /* noop */ }
  }
}

/* ===================== ROW DETAIL PANEL ===================== */
function setupDetailPanel() {
  const panel = document.getElementById('detail-panel');
  const backdrop = document.getElementById('detail-backdrop');
  const closeBtn = document.getElementById('detail-panel-close');
  if (!panel || !closeBtn) return;
  closeBtn.addEventListener('click', closeDetailPanel);
  backdrop.addEventListener('click', closeDetailPanel);
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && panel.classList.contains('open')) {
      closeDetailPanel();
    }
  });
}

function openDetailPanel(tableName, rowIdx) {
  // F6 — Lazy setup of the Escape/backdrop handlers. The init wrap chain
  // (line 2243+) does not reliably intercept DOMContentLoaded, so we
  // ensure setupDetailPanel has run before the first open. Idempotent via flag.
  if (!UI.detailPanelSetupDone) {
    try { setupDetailPanel(); } catch (e) { console.warn('setupDetailPanel (lazy):', e); }
    UI.detailPanelSetupDone = true;
  }
  const panel = document.getElementById('detail-panel');
  const backdrop = document.getElementById('detail-backdrop');
  const body = document.getElementById('detail-panel-body');
  const title = document.getElementById('detail-panel-title');
  let data;
  if (tableName === 'REPORTE_CAMBIOS_HR') data = SPEC.STATE.reporte;
  else data = SPEC.STATE.queries[tableName];
  if (!data || rowIdx < 1 || rowIdx > data.length) {
    toast('Fila no encontrada.', { level: 'error' });
    return;
  }
  const r = data[rowIdx - 1];
  title.textContent = `${tableName} · Fila ${rowIdx}`;
  body.innerHTML = '';

  if (tableName === '07_Conciliacion') {
    // Sección: registro base
    const sec1 = document.createElement('div');
    sec1.className = 'detail-section';
    sec1.innerHTML = `<h4>Registro base (01_HorasSinVolumen)</h4>`;
    const dl1 = document.createElement('dl');
    const fields1 = ['IdRegistroHoras', 'Fecha', 'Name', 'LoginCanonico', 'WMSLoginOriginal', 'Site name', 'Department', 'Activity', 'Subactivity', 'HR Task', 'HorasSinVolumen', 'HorasTotalesPersonaDia', 'ArchivoOrigen', 'FilaOrigen'];
    for (const f of fields1) {
      dl1.innerHTML += `<dt>${escapeHtml(f)}</dt><dd>${escapeHtml(formatVal(r[f]))}</dd>`;
    }
    sec1.appendChild(dl1);
    body.appendChild(sec1);

    // Sección: Clasificacion
    const sec2 = document.createElement('div');
    sec2.className = 'detail-section';
    sec2.innerHTML = `<h4>Clasificación de conciliación</h4>
      <div class="detail-content">
        <strong>${escapeHtml(r['Clasificacion'] || '')}</strong>
        <div style="margin-top: 6px; font-size: 11px; color: var(--c-text-muted);">Confianza: ${escapeHtml(r['NivelConfianza'] || '')}</div>
      </div>`;
    body.appendChild(sec2);

    // Sección: Materialidad
    const secM = document.createElement('div');
    secM.className = 'detail-section';
    secM.innerHTML = `<h4>Materialidad</h4>
      <div class="detail-content">
        <strong style="font-size: 18px;">${escapeHtml(r['Materialidad'] || '')}</strong>
        <div style="margin-top: 4px; color: var(--c-text-muted);">${SPEC.formatNum2(r['HorasSinVolumen'])} h sin volumen</div>
      </div>`;
    body.appendChild(secM);

    // Sección: Evidencia
    const sec3 = document.createElement('div');
    sec3.className = 'detail-section evidence';
    sec3.innerHTML = `<h4>Evidencia</h4>
      <div class="detail-content">${escapeHtml(r['Evidencia'] || '')}</div>`;
    body.appendChild(sec3);

    // Sección: Explicación
    const sec4 = document.createElement('div');
    sec4.className = 'detail-section';
    sec4.innerHTML = `<h4>Explicación</h4>
      <div class="detail-content">${escapeHtml(r['Explicacion'] || '')}</div>`;
    body.appendChild(sec4);

    // Sección: Acción recomendada
    const sec5 = document.createElement('div');
    sec5.className = 'detail-section action';
    sec5.innerHTML = `<h4>Acción recomendada</h4>
      <div class="detail-content">${escapeHtml(r['AccionRecomendada'] || '')}</div>`;
    body.appendChild(sec5);

    // Sección: Volumen y joins
    const sec6 = document.createElement('div');
    sec6.className = 'detail-section';
    const fields6 = [
      ['VolumenTotalPositivo', 'Volumen total positivo'],
      ['VolumenMismaActividadPositivo', 'Volumen misma Activity SPEC'],
      ['VolumenOtrasActividadesPositivo', 'Volumen otras actividades'],
      ['VolumenSinHorasPersonaDia', 'Volumen sin horas total'],
      ['VolumenSinHorasMismaActividad', 'Volumen sin horas misma Activity'],
      ['VolumenMismoNumeroPositivo', 'Volumen mismo IdNumerico (otro prefijo)'],
      ['EsAmbiguoIdNumerico', 'Ambigüedad IdNumerico'],
      ['NumeroHRTaskDistintas', 'Número de HR Task distintas'],
      ['HRTaskDistintas', 'HR Task distintas (lista)'],
      ['LoginsMismoNumero', 'Logins con mismo número'],
      ['TieneDuplicadosVolumen', 'Tiene duplicados de volumen'],
      ['TieneDuplicadosVSH', 'Tiene duplicados de VSH'],
      ['PosibleDuplicado', 'Posible duplicado']
    ];
    let dl6 = '<dl>';
    for (const [k, label] of fields6) {
      dl6 += `<dt>${escapeHtml(label)}</dt><dd>${escapeHtml(formatVal(r[k]))}</dd>`;
    }
    dl6 += '</dl>';
    sec6.innerHTML = `<h4>Datos de conciliación</h4>${dl6}`;
    body.appendChild(sec6);

    // Sección: Origen
    const sec7 = document.createElement('div');
    sec7.className = 'detail-section';
    sec7.innerHTML = `<h4>Trazabilidad de origen</h4>
      <div class="detail-content">
        Archivo: <code>${escapeHtml(r['ArchivoOrigen'] || '')}</code><br>
        Fila: <code>${escapeHtml(String(r['FilaOrigen'] || ''))}</code><br>
        Clave natural: <code>${escapeHtml(r['ClaveNatural'] || '')}</code><br>
        IdRegistroHoras: <code>${escapeHtml(String(r['IdRegistroHoras'] || ''))}</code>
      </div>`;
    body.appendChild(sec7);

  } else if (tableName === 'REPORTE_CAMBIOS_HR') {
    // Detalle de propuesta
    const fields = [
      ['SECCION', 'Sección'],
      ['ID REGISTRO', 'ID Registro'],
      ['FECHA', 'Fecha'],
      ['PERSONA', 'Persona'],
      ['LOGIN HORAS', 'Login horas'],
      ['HORAS SIN VOLUMEN', 'Horas sin volumen'],
      ['MATERIALIDAD', 'Materialidad'],
      ['HR TASK FICHADA', 'HR Task fichada'],
      ['TASKSPEC SEGUN MAPPING', 'Taskspec según Mapping'],
      ['VOLUMEN POSITIVO', 'Volumen positivo'],
      ['WMS TASK CON VOLUMEN', 'WMS Task con volumen'],
      ['TIPO COINCIDENCIA', 'Tipo de coincidencia'],
      ['LOGIN UTILIZADO EN VOLUMEN', 'Login utilizado en volumen'],
      ['SAP_CODE', 'SAP_CODE'],
      ['CUSTOMER', 'Customer'],
      ['WMS_DC', 'WMS_DC'],
      ['ARCHIVO ORIGEN', 'Archivo origen'],
      ['FILA ORIGEN', 'Fila origen'],
      ['REQUIERE CAMBIO RRHH', 'Requiere cambio RRHH'],
      ['OBSERVACION', 'Observación']
    ];
    const sec = document.createElement('div');
    sec.className = 'detail-section';
    let dl = '<dl>';
    for (const [k, label] of fields) {
      const v = r[k];
      const isImportant = (k === 'SECCION' || k === 'REQUIERE CAMBIO RRHH' || k === 'MATERIALIDAD');
      dl += `<dt>${escapeHtml(label)}</dt><dd${isImportant ? ` style="font-weight:700;color:var(--c-corp-red);"` : ''}>${escapeHtml(formatVal(v))}</dd>`;
    }
    dl += '</dl>';
    sec.innerHTML = `<h4>Propuesta de cambio</h4>${dl}`;
    body.appendChild(sec);
  } else {
    // Genérico: mostrar todas las columnas
    const sec = document.createElement('div');
    sec.className = 'detail-section';
    let dl = '<dl>';
    for (const k of Object.keys(r)) {
      dl += `<dt>${escapeHtml(k)}</dt><dd>${escapeHtml(formatVal(r[k]))}</dd>`;
    }
    dl += '</dl>';
    sec.innerHTML = `<h4>Registro completo</h4>${dl}`;
    body.appendChild(sec);
  }

  panel.classList.add('open');
  backdrop.classList.add('open');
  // F6 — Trap focus inside the modal and move it to the close button.
  _trapFocus(panel);
}

function closeDetailPanel() {
  const panel = document.getElementById('detail-panel');
  const backdrop = document.getElementById('detail-backdrop');
  if (panel) panel.classList.remove('open');
  if (backdrop) backdrop.classList.remove('open');
  // F6 — Restore focus to the previously-focused element.
  _releaseFocus();
}

function formatVal(v) {
  if (v == null) return '';
  if (v instanceof Date) return SPEC.formatFecha(v);
  if (typeof v === 'number') return SPEC.formatNum(v);
  if (typeof v === 'boolean') return v ? 'SÍ' : 'NO';
  return String(v);
}

/* ===================== FILE PREVIEW MODAL ===================== */
/* F6 — added focus trap + Escape handler for a11y parity with #detail-panel. */
function setupPreviewModal() {
  const modal = document.getElementById('preview-modal');
  const closeBtn = document.getElementById('preview-modal-close');
  if (!modal || !closeBtn) return;
  closeBtn.addEventListener('click', closePreviewModal);
  modal.addEventListener('click', e => {
    if (e.target === modal) closePreviewModal();
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && modal.classList.contains('open')) {
      closePreviewModal();
    }
  });
}

function closePreviewModal() {
  const modal = document.getElementById('preview-modal');
  if (!modal) return;
  modal.classList.remove('open');
  _releaseFocus();
}

function showPreview(tipo, fileName, workbook) {
  // F6 — Lazy setup of Escape/click-outside handlers (same pattern as
  // openDetailPanel above). Idempotent via flag.
  if (!UI.previewModalSetupDone) {
    try { setupPreviewModal(); } catch (e) { console.warn('setupPreviewModal (lazy):', e); }
    UI.previewModalSetupDone = true;
  }
  const modal = document.getElementById('preview-modal');
  const title = document.getElementById('preview-modal-title');
  const body = document.getElementById('preview-modal-body');
  if (!modal) return;
  title.textContent = `Vista previa: ${fileName}`;

  let html = '';
  try {
    // Determinar sheet
    let sheetName = null;
    for (const n of workbook.SheetNames) {
      if (n.toUpperCase().trim() === 'EXPORT' || n.toUpperCase().trim() === 'MAPPING') {
        sheetName = n; break;
      }
    }
    if (!sheetName) sheetName = workbook.SheetNames[0];
    const ws = workbook.Sheets[sheetName];
    const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: null });
    const headers = (aoa[0] || []).map(h => h == null ? '' : String(h));
    const dataRows = aoa.slice(1, 11); // 10 filas

    let required = [];
    if (tipo === 'horas') required = ['Site name', 'Department', 'Activity', 'Subactivity', 'Date', 'HR Task', 'WMS Login', 'Name', 'Hours without volume'];
    else if (tipo === 'volumen') required = ['DATE', 'SAP_CODE', 'CUSTOMER', 'WMS_TASK', 'WMS_LOGIN', 'USER_NAME', 'WMS_UOM'];
    else if (tipo === 'volSinHoras') required = ['Site name', 'Department', 'Activity', 'Subactivity', 'Date', 'HR Task', 'WMS Login', 'Name', 'Volume Without Hours'];
    else if (tipo === 'mapping') required = ['SAP_CODE', 'WMS_DC', 'CUSTOMER', 'DEPARTMENT', 'ACTIVITY', 'SUB_ACTIVITY', 'TASK_WMS', 'TASK_SPEC'];

    const found = required.filter(c => headers.some(h => h.trim().toUpperCase() === c.toUpperCase()));
    const missing = required.filter(c => !headers.some(h => h.trim().toUpperCase() === c.toUpperCase()));

    html = `<div class="preview-info">
      📊 Hoja: <strong>${escapeHtml(sheetName)}</strong> · ${aoa.length - 1} filas · ${headers.filter(h => h).length} columnas<br>
      ✓ Columnas requeridas encontradas: <strong>${found.length}/${required.length}</strong><br>
      ${missing.length > 0 ? '⚠ Faltan: <strong>' + escapeHtml(missing.join(', ')) + '</strong>' : '✓ Todas las columnas requeridas están presentes'}
    </div>`;

    html += '<table><caption class="sr-only">Vista previa del archivo cargado</caption><thead><tr>';
    for (const h of headers) {
      if (!h) continue;
      const isReq = required.some(r => r.toUpperCase() === h.trim().toUpperCase());
      html += `<th scope="col"${isReq ? ' style="background: var(--c-success-bg); color: var(--c-success);"' : ''}>${escapeHtml(h)}</th>`;
    }
    html += '</tr></thead><tbody>';
    for (const row of dataRows) {
      html += '<tr>';
      for (let i = 0; i < headers.length; i++) {
        if (!headers[i]) continue;
        let v = row[i];
        if (v instanceof Date) v = SPEC.formatFecha(v);
        else if (v == null) v = '';
        else v = String(v);
        html += `<td>${escapeHtml(v)}</td>`;
      }
      html += '</tr>';
    }
    html += '</tbody></table>';
  } catch (err) {
    html = `<div class="preview-info" style="background: var(--c-danger-bg); color: var(--c-danger); border-left-color: var(--c-danger);">Error al generar vista previa: ${escapeHtml(err.message)}</div>`;
  }
  body.innerHTML = html;
  modal.classList.add('open');
  // F6 — Trap focus inside the preview modal and move it to the close button.
  _trapFocus(modal);
}

/* ===================== ROW CLICK → DETAIL PANEL ===================== */
function setupRowClickHandlers() {
  // Tabla viewer
  const viewerTbl = document.getElementById('viewer-table');
  if (viewerTbl) {
    viewerTbl.addEventListener('click', e => {
      const td = e.target.closest('td');
      if (!td) return;
      const tr = td.closest('tr');
      if (!tr) return;
      const rowIdx = Array.from(tr.parentElement.children).indexOf(tr) + 1;
      if (UI.activeTable && UI.activeData) {
        openDetailPanel(UI.activeTable, rowIdx);
      }
    });
  }
  // Reporte table
  const repTbl = document.getElementById('reporte-table');
  if (repTbl) {
    repTbl.addEventListener('click', e => {
      const td = e.target.closest('td');
      if (!td) return;
      const tr = td.closest('tr');
      if (!tr) return;
      const rowIdx = Array.from(tr.parentElement.children).indexOf(tr) + 1;
      openDetailPanel('REPORTE_CAMBIOS_HR', rowIdx);
    });
  }
}

/* ===================== KPI DRILLDOWN ===================== */
function setupKpiDrilldown() {
  // Delegado: cualquier clic en un .kpi-card.clickable dispara drilldown
  document.addEventListener('click', e => {
    const card = e.target.closest('.kpi-card.clickable');
    if (!card) return;
    const action = card.dataset.action;
    if (!action) return;
    handleKpiDrilldown(action, card.dataset);
  });
}

function handleKpiDrilldown(action, data) {
  switch (action) {
    case 'filter-seccion': {
      // Ir al reporte y filtrar por sección
      document.querySelector('.tab[data-tab="reporte"]').click();
      const sf = document.getElementById('reporte-filter-seccion');
      sf.value = data.value;
      sf.dispatchEvent(new Event('change'));
      toast(`Filtrando reporte por sección: ${data.value}`, { level: 'info', duration: 2000 });
      break;
    }
    case 'filter-materialidad': {
      document.querySelector('.tab[data-tab="reporte"]').click();
      const mf = document.getElementById('reporte-filter-materialidad');
      mf.value = data.value;
      mf.dispatchEvent(new Event('change'));
      toast(`Filtrando por materialidad: ${data.value}`, { level: 'info', duration: 2000 });
      break;
    }
    case 'filter-requiere': {
      document.querySelector('.tab[data-tab="reporte"]').click();
      const rf = document.getElementById('reporte-filter-cambio');
      rf.value = data.value;
      rf.dispatchEvent(new Event('change'));
      toast(`Filtrando por requiere cambio: ${data.value}`, { level: 'info', duration: 2000 });
      break;
    }
    case 'show-table': {
      const tableName = data.table;
      const q = SPEC.STATE.queries[tableName];
      if (q) {
        document.querySelector('.tab[data-tab="resultados"]').click();
        setTimeout(() => showTable(tableName, q), 100);
      }
      break;
    }
    case 'filter-13-sin-mapeo': {
      document.querySelector('.tab[data-tab="resultados"]').click();
      setTimeout(() => {
        const vol = SPEC.STATE.queries['13_VolumenMapeadoSPEC'];
        if (vol) {
          showTable('13_VolumenMapeadoSPEC', vol);
          UI.viewerSearch = 'SIN MAPEO';
          document.getElementById('viewer-search').value = 'SIN MAPEO';
          renderViewerTable();
        }
      }, 100);
      break;
    }
    case 'filter-13-ambiguo': {
      document.querySelector('.tab[data-tab="resultados"]').click();
      setTimeout(() => {
        const vol = SPEC.STATE.queries['13_VolumenMapeadoSPEC'];
        if (vol) {
          showTable('13_VolumenMapeadoSPEC', vol);
          UI.viewerSearch = 'AMBIGUO';
          document.getElementById('viewer-search').value = 'AMBIGUO';
          renderViewerTable();
        }
      }, 100);
      break;
    }
  }
}

/* ===================== INTEGRACIÓN CON FUNCIONES EXISTENTES ===================== */
/* M-10 (Tarea F9) — El override original de loadFile (que añadía el botón
 * de vista previa) ya no es necesario porque esa lógica ahora vive en
 * updateDropZoneFiles() (se llama al final de loadFiles). loadFile actual es
 * un wrapper que delega en loadFiles, por lo que la cadena de overrides
 * funciona sin sobrescritura adicional.
 */

// Sobrecargar reiniciarCarga para usar toast/confirm
reiniciarCarga = function () {
  confirmDialog('¿Borrar los 4 archivos cargados?', () => {
    // M-10 — reset a arrays vacíos (estructura multi-archivo).
    SPEC.STATE.archivos = { horas: [], volumen: [], volSinHoras: [], mapping: [] };
    document.querySelectorAll('.drop-zone').forEach(dz => {
      dz.classList.remove('loaded', 'error');
      dz.querySelector('.dz-status').textContent = 'Pendiente';
      dz.querySelector('.dz-status').className = 'dz-status';
      dz.querySelector('input[type=file]').value = '';
      const prevBtn = dz.querySelector('.btn-preview');
      if (prevBtn) prevBtn.remove();
      // M-10 — limpiar la lista de archivos del drop-zone.
      const list = dz.querySelector('.dz-files-list');
      if (list) list.innerHTML = '';
    });
    document.getElementById('carga-mensajes').innerHTML = '';
    document.getElementById('btn-validar').disabled = true;
    document.getElementById('btn-analizar').disabled = true;
    setStatus('Sin procesar');
    toast('Archivos cargados eliminados.', { level: 'success' });
  });
};

// Sobrecargar reiniciarProceso para usar toast/confirm
reiniciarProceso = function () {
  confirmDialog('¿Reiniciar el proceso? Se borrarán los resultados actuales.', () => {
    SPEC.STATE.queries = {};
    SPEC.STATE.reporte = null;
    SPEC.STATE.log = [];
    document.getElementById('log-area').innerHTML = '';
    document.getElementById('progress-fill').style.width = '0%';
    document.getElementById('progress-text').textContent = 'Listo';
    setStatus('Sin procesar');
    clearPersistedState();
    toast('Proceso reiniciado.', { level: 'success' });
  });
};

// Sobrecargar analizar para persistir al terminar
const _origAnalizar = analizar;
analizar = async function () {
  await _origAnalizar();
  // Persistir resultados al terminar
  if (SPEC.STATE.reporte && SPEC.STATE.reporte.length > 0) {
    if (persistState()) {
      toast('Resultados guardados localmente. Podrás restaurarlos al recargar.', {
        level: 'success', duration: 3000
      });
    }
    // Renderizar charts
    if (window.SPEC_CHARTS) {
      window.SPEC_CHARTS.renderChartsGrid('charts-grid');
    }
  }
};

// Añadir setup de mejoras al init
const _origInit = init;
init = function () {
  _origInit();
  setupThemeToggle();
  setupGlobalSearch();
  setupDetailPanel();
  setupPreviewModal();
  setupRowClickHandlers();
  setupKpiDrilldown();
  setupPersistence();
};

/* ============================================================================
 * MEJORAS v4.0 — Revisar incidencias, decisiones, undo, auditoría, patrones
 * ========================================================================== */

/* Estado de decisiones: indexed by incidentId (id_registro@filaOrigen) */
if (!SPEC.STATE.decisions) SPEC.STATE.decisions = {};
if (!SPEC.STATE.auditLog) SPEC.STATE.auditLog = [];
if (!SPEC.STATE.undoStack) SPEC.STATE.undoStack = [];
if (!SPEC.STATE.bulkSelection) SPEC.STATE.bulkSelection = new Set();

/* M-09 (Tarea F9) — Filtros extendidos. dateFrom/dateTo son objetos Date
 * (o null). turno es string ('mañana'|'tarde'|'noche'|'') — informativo, los
 * archivos de entrada no incluyen hora del fichaje, así que actualmente no
 * filtra. confianza es string ('Alta'|'Media'|'Baja'|'No determinable'|'')
 * calculado por getConfianza(incident) en base a la sección. */
UI.reviewFilter = {
  search: '', seccion: '', decision: '', sort: 'prioridad',
  dateFrom: null, dateTo: null, turno: '', confianza: ''
};
UI.currentIncidentId = null;

/* Genera ID único de incidencia */
function incidentId(r) {
  // Para sección 4 (sin volumen) no hay match, usar solo ID REGISTRO
  // Para otras, combinar ID REGISTRO + FILA ORIGEN (para distinguir varias propuestas por registro)
  const idReg = r['ID REGISTRO'] || r.IdRegistroHoras || '?';
  const filaOr = r['FILA ORIGEN'] || r.FilaOrigen || '';
  if (filaOr) return `${idReg}@${filaOr}`;
  return `${idReg}@${r.SECCION || ''}`;
}

/* Render del panel de revisión */
function renderReviewPanel() {
  const rep = SPEC.STATE.reporte;
  if (!rep || rep.length === 0) {
    document.getElementById('review-summary').innerHTML =
      '<p style="color: var(--c-text-muted); font-size: 13px;">Procesa los archivos para ver las incidencias.</p>';
    document.getElementById('review-list').innerHTML = '';
    document.getElementById('incident-detail').innerHTML = '<div class="empty-state"><div class="empty-state-icon">📋</div><h3>Sin incidencias</h3><p>Procesa los archivos para ver las incidencias.</p></div>';
    return;
  }

  // KPIs operativos
  const summary = document.getElementById('review-summary');
  summary.innerHTML = '';
  const totals = {
    total: rep.length,
    pendientes: 0,
    resueltas: 0,
    horasAfectadas: 0,
    personas: new Set(),
    altaConfianza: 0,
    mediaConfianza: 0,
    bajaConfianza: 0,
    sinMapping: 0
  };
  for (const r of rep) {
    const id = incidentId(r);
    const decision = SPEC.STATE.decisions[id];
    if (decision) totals.resueltas++;
    else totals.pendientes++;
    totals.horasAfectadas += Number(r['HORAS SIN VOLUMEN']) || 0;
    if (r.PERSONA) totals.personas.add(r.PERSONA);
    // Confianza según sección
    const sec = (r.SECCION || '').charAt(0);
    if (sec === '1') totals.altaConfianza++;
    else if (sec === '2' || sec === '4' || sec === '5') totals.mediaConfianza++;
    else if (sec === '3') totals.altaConfianza++; // HR Task correcta = alta confianza
    else totals.bajaConfianza++;
    if ((r.SECCION || '').indexOf('5') === 0) totals.sinMapping++;
  }
  const cards = [
    { label: 'Total incidencias', value: totals.total, level: 'info' },
    { label: 'Pendientes', value: totals.pendientes, level: 'warn', action: 'filter-decision', filterValue: 'pendiente' },
    { label: 'Resueltas', value: totals.resueltas, level: 'ok', action: 'filter-decision-exclude-pending' },
    { label: 'Horas afectadas', value: SPEC.formatNum(totals.horasAfectadas), level: 'info' },
    { label: 'Personas afectadas', value: totals.personas.size, level: 'info' },
    { label: 'Confianza alta', value: totals.altaConfianza, level: 'ok' },
    { label: 'Confianza media', value: totals.mediaConfianza, level: 'warn' },
    { label: 'Confianza baja', value: totals.bajaConfianza, level: 'info' },
    { label: 'Sin mapping', value: totals.sinMapping, level: 'error', action: 'filter-seccion', filterValue: '5' }
  ];
  for (const c of cards) {
    const el = document.createElement('div');
    el.className = 'kpi-card ' + c.level;
    if (c.action) {
      el.classList.add('clickable');
      el.dataset.action = c.action;
      if (c.filterValue) el.dataset.value = c.filterValue;
    }
    el.innerHTML = `<div class="label">${escapeHtml(c.label)}</div><div class="value">${escapeHtml(c.value)}</div>`;
    summary.appendChild(el);
  }

  // Contadores en header
  const counters = document.getElementById('review-counters');
  counters.innerHTML = `<span class="badge-mini">${totals.pendientes} pendientes</span> · <span class="badge-mini">${totals.resueltas} resueltas</span> · <span class="badge-mini">${totals.total} total</span>`;

  renderReviewList();
}

/* Calcula prioridad de una incidencia */
function incidentPriority(r) {
  // Mayor horas + sección con cambio propuesto = mayor prioridad
  const horas = Number(r['HORAS SIN VOLUMEN']) || 0;
  const sec = (r.SECCION || '').charAt(0);
  let prio = 0;
  prio += horas * 10; // horas afectadas pesan mucho
  if (sec === '1') prio += 100; // cambio propuesto
  else if (sec === '2') prio += 50; // varias opciones
  else if (sec === '5') prio += 30; // sin mapping
  else if (sec === '4') prio += 10; // sin volumen
  else if (sec === '3') prio += 5; // ya correcta
  return prio;
}

/* Lista filtrada y ordenada de incidencias
 * M-09 (Tarea F9) — Añadidos filtros dateFrom/dateTo (Date | null) y
 * confianza (string). El filtro turno es informativo y NO se aplica aquí
 * porque los archivos de entrada solo tienen fecha (sin hora) — se
 * documenta en el worklog como limitación. Si en el futuro los archivos
 * incluyen hora, se puede inferir el turno (6-13=mañana, 14-21=tarde,
 * 22-5=noche) y aplicar el filtro. */
function getFilteredIncidents() {
  const rep = SPEC.STATE.reporte || [];
  let filtered = rep.slice();
  if (UI.reviewFilter.search) {
    const q = UI.reviewFilter.search.toLowerCase();
    filtered = filtered.filter(r =>
      (r.PERSONA && r.PERSONA.toLowerCase().indexOf(q) >= 0) ||
      (r['LOGIN HORAS'] && r['LOGIN HORAS'].toLowerCase().indexOf(q) >= 0) ||
      (r['HR TASK FICHADA'] && r['HR TASK FICHADA'].toLowerCase().indexOf(q) >= 0)
    );
  }
  if (UI.reviewFilter.seccion) {
    filtered = filtered.filter(r => (r.SECCION || '').charAt(0) === UI.reviewFilter.seccion);
  }
  if (UI.reviewFilter.decision) {
    filtered = filtered.filter(r => {
      const d = SPEC.STATE.decisions[incidentId(r)];
      const estado = d ? d.decision : 'pendiente';
      return estado === UI.reviewFilter.decision;
    });
  }
  // M-09 — Date range filter. r.FECHA es un Date (motor fx_Fecha lo produce).
  // Si por algún motivo no es Date, lo intentamos parsear.
  if (UI.reviewFilter.dateFrom) {
    const from = UI.reviewFilter.dateFrom instanceof Date
      ? UI.reviewFilter.dateFrom
      : new Date(UI.reviewFilter.dateFrom);
    filtered = filtered.filter(r => {
      const f = r.FECHA instanceof Date ? r.FECHA : (r.FECHA ? new Date(r.FECHA) : null);
      return f ? f >= from : false;
    });
  }
  if (UI.reviewFilter.dateTo) {
    const to = UI.reviewFilter.dateTo instanceof Date
      ? UI.reviewFilter.dateTo
      : new Date(UI.reviewFilter.dateTo);
    filtered = filtered.filter(r => {
      const f = r.FECHA instanceof Date ? r.FECHA : (r.FECHA ? new Date(r.FECHA) : null);
      return f ? f <= to : false;
    });
  }
  // M-09 — Confianza filter. getConfianza(incident) returns 'Alta'|'Media'|'Baja'|'No determinable'.
  if (UI.reviewFilter.confianza) {
    filtered = filtered.filter(r => getConfianza(r) === UI.reviewFilter.confianza);
  }
  // M-09 — Turno filter. Informativo: los archivos de entrada no incluyen
  // hora del fichaje (solo fecha), así que el filtro turno no aplica.
  // La limitación está documentada en el worklog. Si en el futuro los
  // archivos incluyen hora (campo FechaHoraOriginal), se puede inferir el
  // turno y aplicar el filtro aquí.
  // if (UI.reviewFilter.turno) { ... }
  // Sort
  switch (UI.reviewFilter.sort) {
    case 'horas_desc': filtered.sort((a, b) => (Number(b['HORAS SIN VOLUMEN']) || 0) - (Number(a['HORAS SIN VOLUMEN']) || 0)); break;
    case 'horas_asc': filtered.sort((a, b) => (Number(a['HORAS SIN VOLUMEN']) || 0) - (Number(b['HORAS SIN VOLUMEN']) || 0)); break;
    case 'fecha': filtered.sort((a, b) => {
      const fa = a.FECHA instanceof Date ? a.FECHA : (a.FECHA ? new Date(a.FECHA) : 0);
      const fb = b.FECHA instanceof Date ? b.FECHA : (b.FECHA ? new Date(b.FECHA) : 0);
      return fa - fb;
    }); break;
    case 'persona': filtered.sort((a, b) => (a.PERSONA || '').localeCompare(b.PERSONA || '')); break;
    case 'seccion': filtered.sort((a, b) => (a.SECCION || '').localeCompare(b.SECCION || '')); break;
    case 'prioridad':
    default: filtered.sort((a, b) => incidentPriority(b) - incidentPriority(a));
  }
  return filtered;
}

/* Render lista de incidencias */
function renderReviewList() {
  const list = document.getElementById('review-list');
  const incidents = getFilteredIncidents();
  list.innerHTML = '';
  if (incidents.length === 0) {
    list.innerHTML = '<div class="empty-state"><div class="empty-state-icon">🔍</div><h3>Sin incidencias</h3><p>No hay casos que coincidan con los filtros.</p></div>';
    return;
  }
  // Limit to 300 for performance
  const limited = incidents.slice(0, 300);
  for (const r of limited) {
    const id = incidentId(r);
    const sec = (r.SECCION || '').charAt(0);
    const decision = SPEC.STATE.decisions[id];
    const isSelected = SPEC.STATE.bulkSelection.has(id);
    const item = document.createElement('div');
    item.className = 'review-item';
    if (decision) item.classList.add('resolved');
    if (UI.currentIncidentId === id) item.classList.add('active');
    item.dataset.id = id;
    item.dataset.seccion = sec;
    item.innerHTML = `
      <div class="ri-icon">${sec}</div>
      <div class="ri-info">
        <div class="ri-title">${escapeHtml(r.PERSONA || '(sin nombre)')}</div>
        <div class="ri-meta">
          <span>📅 ${SPEC.formatFecha(r.FECHA)}</span>
          <span>⏱ ${SPEC.formatNum(r['HORAS SIN VOLUMEN'])}h</span>
          <span>👤 ${escapeHtml(r['LOGIN HORAS'] || '')}</span>
          ${r['HR TASK FICHADA'] ? `<span>📋 ${escapeHtml(r['HR TASK FICHADA'].split(' ')[0])}</span>` : ''}
        </div>
        <div style="font-size:10px; color: var(--c-text-muted); margin-top: 3px;">${escapeHtml(r.SECCION || '')}</div>
      </div>
      <div>
        ${isSelected ? '<div class="ri-decision" style="background:var(--c-corp-blue);color:#fff;">✓ Selecc.</div>' : ''}
        ${decision ? `<div class="ri-decision ${escapeAttr(decision.decision)}">${escapeHtml(decision.decision)}</div>` : ''}
      </div>`;
    item.addEventListener('click', e => {
      if (e.shiftKey || e.ctrlKey || e.metaKey) {
        // Bulk selection
        toggleBulkSelection(id);
        renderReviewList();
      } else {
        selectIncident(id);
      }
    });
    list.appendChild(item);
  }
  if (incidents.length > 300) {
    const more = document.createElement('div');
    more.style.cssText = 'padding: 12px; text-align: center; color: var(--c-text-muted); font-size: 11px; background: var(--c-bg-alt);';
    more.textContent = `Mostrando 300 de ${incidents.length} incidencias. Usa los filtros para reducir.`;
    list.appendChild(more);
  }
  // Bulk bar
  const bulkBar = document.getElementById('bulk-actions-bar');
  if (SPEC.STATE.bulkSelection.size > 0) {
    bulkBar.style.display = 'flex';
    document.getElementById('bulk-count').textContent = `${SPEC.STATE.bulkSelection.size} seleccionada(s)`;
  } else {
    bulkBar.style.display = 'none';
  }
}

function toggleBulkSelection(id) {
  if (SPEC.STATE.bulkSelection.has(id)) SPEC.STATE.bulkSelection.delete(id);
  else SPEC.STATE.bulkSelection.add(id);
}

/* Selecciona una incidencia y la muestra en el panel derecho */
function selectIncident(id) {
  UI.currentIncidentId = id;
  renderReviewList();
  renderIncidentDetail(id);
}

/* Render del detalle de la incidencia seleccionada */
function renderIncidentDetail(id) {
  const container = document.getElementById('incident-detail');
  const rep = SPEC.STATE.reporte || [];
  // Para reportes con varios matches por registro, mostramos el primero del ID
  const incident = rep.find(r => incidentId(r) === id);
  if (!incident) {
    container.innerHTML = '<div class="empty-state"><div class="empty-state-icon">❓</div><h3>Incidencia no encontrada</h3></div>';
    return;
  }
  const sec = (incident.SECCION || '').charAt(0);
  const decision = SPEC.STATE.decisions[id];

  // Buscar posición en la lista filtrada
  const incidents = getFilteredIncidents();
  const currentIdx = incidents.findIndex(r => incidentId(r) === id);

  // Buscar el registro de 07_Conciliacion para más detalle
  const idReg = incident['ID REGISTRO'];
  const conc = (SPEC.STATE.queries['07_Conciliacion'] || []).find(r => r.IdRegistroHoras === idReg);

  let html = `
    <div class="incident-detail-header">
      <h3>${escapeHtml(incident.PERSONA || '(sin nombre)')}</h3>
      <div class="incident-nav">
        <button id="inc-prev" ${currentIdx <= 0 ? 'disabled' : ''} title="Anterior (P)">↑</button>
        <button id="inc-next" ${currentIdx >= incidents.length - 1 ? 'disabled' : ''} title="Siguiente (N)">↓</button>
      </div>
    </div>
    <div class="incident-detail-body">`;

  // Bloque: Registro base
  html += `<div class="incident-block">
    <h4>Registro base (fichaje original)</h4>
    <div class="ib-row"><span class="lbl">ID registro</span><span class="val"><strong>${escapeHtml(String(incident['ID REGISTRO'] || ''))}</strong></span></div>
    <div class="ib-row"><span class="lbl">Fecha</span><span class="val">${SPEC.formatFecha(incident.FECHA)}</span></div>
    <div class="ib-row"><span class="lbl">Persona</span><span class="val"><strong>${escapeHtml(incident.PERSONA || '')}</strong></span></div>
    <div class="ib-row"><span class="lbl">Login horas</span><span class="val">${escapeHtml(incident['LOGIN HORAS'] || '')}</span></div>
    <div class="ib-row"><span class="lbl">HR Task fichada</span><span class="val"><strong style="color:var(--c-corp-red);">${escapeHtml(incident['HR TASK FICHADA'] || '')}</strong></span></div>
    <div class="ib-row"><span class="lbl">Horas sin volumen</span><span class="val"><strong>${SPEC.formatNum2(incident['HORAS SIN VOLUMEN'])} h</strong></span></div>
    <div class="ib-row"><span class="lbl">Materialidad</span><span class="val">${escapeHtml(incident.MATERIALIDAD || '')}</span></div>
  </div>`;

  // Bloque: Propuesta (si hay)
  if (incident['TASKSPEC SEGUN MAPPING']) {
    html += `<div class="incident-block propuesta">
      <h4>Propuesta de corrección</h4>
      <div class="propuesta-tarea">${escapeHtml(incident['TASKSPEC SEGUN MAPPING'])}</div>
      <div class="propuesta-razon">${escapeHtml(generarRazonPropuesta(incident))}</div>
      <div class="ib-row" style="margin-top:8px;"><span class="lbl">Volumen positivo</span><span class="val"><strong>${SPEC.formatNum(incident['VOLUMEN POSITIVO'])}</strong> unidades</span></div>
      <div class="ib-row"><span class="lbl">WMS Task</span><span class="val">${escapeHtml(incident['WMS TASK CON VOLUMEN'] || '')}</span></div>
      <div class="ib-row"><span class="lbl">SAP_CODE</span><span class="val">${escapeHtml(incident.SAP_CODE || '')}</span></div>
      <div class="ib-row"><span class="lbl">Customer</span><span class="val">${escapeHtml(incident.CUSTOMER || '')}</span></div>
      <div class="ib-row"><span class="lbl">Tipo coincidencia</span><span class="val">${escapeHtml(incident['TIPO COINCIDENCIA'] || '')}</span></div>
      <div class="ib-row"><span class="lbl">Nivel confianza</span><span class="val"><strong>${escapeHtml(getConfianza(incident))}</strong></span></div>
    </div>`;
  } else {
    html += `<div class="incident-block">
      <h4>Propuesta</h4>
      <div class="propuesta-razon" style="font-size:12px; color: var(--c-text-muted);">No hay propuesta automática: ${escapeHtml(incident.OBSERVACION || 'No se puede proponer corrección sin evidencia.')}</div>
    </div>`;
  }

  // Bloque: Evidencia (de 07_Conciliacion)
  if (conc) {
    html += `<div class="incident-block evidence">
      <h4>Evidencia disponible</h4>
      ${escapeHtml(conc.Evidencia || '(sin evidencia)')}
    </div>`;
    // Bloque: Datos de conciliación
    html += `<div class="incident-block">
      <h4>Datos de conciliación</h4>
      <div class="ib-row"><span class="lbl">Volumen total positivo</span><span class="val">${SPEC.formatNum(conc.VolumenTotalPositivo)}</span></div>
      <div class="ib-row"><span class="lbl">Volumen misma actividad</span><span class="val">${SPEC.formatNum(conc.VolumenMismaActividadPositivo)}</span></div>
      <div class="ib-row"><span class="lbl">Volumen otras</span><span class="val">${SPEC.formatNum(conc.VolumenOtrasActividadesPositivo)}</span></div>
      <div class="ib-row"><span class="lbl">Vol. sin horas total</span><span class="val">${SPEC.formatNum(conc.VolumenSinHorasPersonaDia)}</span></div>
      <div class="ib-row"><span class="lbl">HR Task distintas</span><span class="val">${escapeHtml(String(conc.NumeroHRTaskDistintas || 0))} (${escapeHtml(conc.HRTaskDistintas || '')})</span></div>
      <div class="ib-row"><span class="lbl">Ambigüedad IdNum</span><span class="val">${conc.EsAmbiguoIdNumerico ? 'SÍ' : 'NO'}</span></div>
      <div class="ib-row"><span class="lbl">Clasificación</span><span class="val">${escapeHtml(conc.Clasificacion || '')}</span></div>
      <div class="ib-row"><span class="lbl">Acción recomendada</span><span class="val">${escapeHtml(conc.AccionRecomendada || '')}</span></div>
    </div>`;
  }

  // Bloque: decisión actual
  if (decision) {
    html += `<div class="incident-block">
      <h4>Decisión actual</h4>
      <div class="ib-row"><span class="lbl">Estado</span><span class="val"><strong class="al-action-${escapeAttr(decision.decision)}">${escapeHtml(decision.decision.toUpperCase())}</strong></span></div>
      <div class="ib-row"><span class="lbl">Tarea final</span><span class="val">${escapeHtml(decision.tareaFinal || incident['HR TASK FICHADA'] || '')}</span></div>
      <div class="ib-row"><span class="lbl">Decidido</span><span class="val">${new Date(decision.timestamp).toLocaleString('es-ES')}</span></div>
      ${decision.motivo ? `<div class="ib-row"><span class="lbl">Motivo</span><span class="val">${escapeHtml(decision.motivo)}</span></div>` : ''}
    </div>`;
  }

  // Bloque: Acciones
  html += `<div class="incident-block" style="border-bottom: none;">
    <h4>Acciones</h4>
    <div class="incident-actions">
      ${incident['TASKSPEC SEGUN MAPPING'] ? `<button class="btn btn-accept" data-action="aceptar">✓ Aceptar propuesta</button>` : '<button class="btn" disabled>Sin propuesta</button>'}
      <button class="btn btn-keep" data-action="mantener">↩ Mantener fichaje</button>
      <button class="btn btn-other" data-action="otra">⚙ Elegir otra tarea</button>
      <button class="btn btn-review" data-action="revisar">⚠ Necesita revisión</button>
      ${decision ? '<button class="btn btn-undo btn-full" data-action="undo">↺ Deshacer decisión</button>' : '<button class="btn btn-undo btn-full" disabled>Sin decisión que deshacer</button>'}
    </div>
    ${SPEC.STATE.undoStack.length > 0 ? `
    <div class="incident-undo-bar">
      <span>Hay ${SPEC.STATE.undoStack.length} acción(es) en el historial de deshacer.</span>
      <button id="undo-last">↺ Deshacer última</button>
    </div>` : ''}
    <div id="task-selector-container" style="display:none;">
      <div class="task-selector">
        <h4 style="margin: 0 0 6px 0; font-size: 11px; color: var(--c-text-muted); text-transform: uppercase; letter-spacing: 0.5px;">Selecciona otra tarea</h4>
        <select id="task-selector-select">
          ${getAvailableTasks(incident).map(t => `<option value="${escapeAttr(t)}">${escapeHtml(t)}</option>`).join('')}
        </select>
        <div class="task-selector-actions">
          <button class="btn btn-secondary" id="task-selector-confirm" style="flex:1; padding:6px;">Confirmar</button>
          <button class="btn btn-link" id="task-selector-cancel" style="padding:6px;">Cancelar</button>
        </div>
      </div>
    </div>
    <div style="margin-top: 10px;">
      <label style="font-size: 11px; color: var(--c-text-muted); display: block; margin-bottom: 4px;">Observación (opcional):</label>
      <input type="text" id="incident-motivo" placeholder="Ej: Confirmado con el encargado" style="width: 100%; padding: 6px 10px; border: 1px solid var(--c-border); border-radius: var(--r-sm); font-size: 12px; background: var(--c-surface); color: var(--c-text); font-family: var(--font-sans);">
    </div>
  </div>`;

  html += '</div>';
  container.innerHTML = html;

  // Bind actions
  container.querySelectorAll('[data-action]').forEach(btn => {
    btn.addEventListener('click', () => handleIncidentAction(btn.dataset.action, incident));
  });
  const undoLast = container.querySelector('#undo-last');
  if (undoLast) undoLast.addEventListener('click', undoLastAction);
  const taskConfirm = container.querySelector('#task-selector-confirm');
  const taskCancel = container.querySelector('#task-selector-cancel');
  const taskSel = container.querySelector('#task-selector-select');
  if (taskConfirm) taskConfirm.addEventListener('click', () => {
    const nuevaTarea = taskSel.value;
    registrarDecision(incident, 'otra', nuevaTarea, obtenerMotivoInput(container));
  });
  if (taskCancel) taskCancel.addEventListener('click', () => {
    container.querySelector('#task-selector-container').style.display = 'none';
  });
  const prevBtn = container.querySelector('#inc-prev');
  const nextBtn = container.querySelector('#inc-next');
  if (prevBtn) prevBtn.addEventListener('click', () => navigateIncident(-1));
  if (nextBtn) nextBtn.addEventListener('click', () => navigateIncident(1));
}

function obtenerMotivoInput(container) {
  const input = container.querySelector('#incident-motivo');
  return input ? input.value.trim() : '';
}

function getConfianza(incident) {
  const sec = (incident.SECCION || '').charAt(0);
  if (sec === '1' || sec === '3') return 'Alta';
  if (sec === '2' || sec === '4' || sec === '5') return 'Media';
  if (sec === '6' || sec === '7') return 'Baja';
  return 'No determinable';
}

function generarRazonPropuesta(incident) {
  const sec = (incident.SECCION || '').charAt(0);
  const horas = SPEC.formatNum2(incident['HORAS SIN VOLUMEN']);
  const vol = SPEC.formatNum0(incident['VOLUMEN POSITIVO']);
  const wmsTask = incident['WMS TASK CON VOLUMEN'] || '';
  const propuesta = incident['TASKSPEC SEGUN MAPPING'] || '';
  const original = incident['HR TASK FICHADA'] || '';
  const tipo = incident['TIPO COINCIDENCIA'] || '';

  if (sec === '1') {
    let razon = `Se propone cambiar de "${original}" a "${propuesta}" porque el trabajador registró ${vol} unidades de "${wmsTask}" el mismo día.`;
    if (tipo && tipo !== 'LOGIN EXACTO') {
      razon += ` Coincidencia por ${tipo.toLowerCase()}.`;
    }
    return razon;
  } else if (sec === '2') {
    return `Hay varias TASKSPEC posibles para el volumen registrado. Revisar manualmente cuál corresponde.`;
  } else if (sec === '3') {
    return `La HR Task fichada (${original}) coincide con la TASKSPEC del Mapping. No requiere cambio.`;
  } else if (sec === '4') {
    return `No se encontró volumen productivo para esta persona en esta fecha. Posible fichaje incorrecto o actividad no medible.`;
  } else if (sec === '5') {
    return `Existe volumen pero la WMS Task "${wmsTask}" no tiene mapping a TASKSPEC. Completar el mapping para poder proponer.`;
  } else if (sec === '6') {
    return `La persona fichó varias HR Task el mismo día. No se puede determinar automáticamente cuál modificar.`;
  } else if (sec === '7') {
    return `Existen múltiples logins candidatos con el mismo IdNumerico. Revisión manual necesaria.`;
  }
  return incident.OBSERVACION || '';
}

function getAvailableTasks(incident) {
  // Tasks disponibles = todas las TASKSPEC distintas del reporte + la HR Task original
  const rep = SPEC.STATE.reporte || [];
  const set = new Set();
  if (incident['HR TASK FICHADA']) set.add(incident['HR TASK FICHADA']);
  if (incident['TASKSPEC SEGUN MAPPING']) set.add(incident['TASKSPEC SEGUN MAPPING']);
  for (const r of rep) {
    if (r['TASKSPEC SEGUN MAPPING']) set.add(r['TASKSPEC SEGUN MAPPING']);
  }
  return Array.from(set).sort();
}

function handleIncidentAction(action, incident) {
  const id = incidentId(incident);
  const container = document.getElementById('incident-detail');
  const motivo = obtenerMotivoInput(container);
  if (action === 'aceptar') {
    registrarDecision(incident, 'aceptada', incident['TASKSPEC SEGUN MAPPING'], motivo || 'Aceptada propuesta automática');
  } else if (action === 'mantener') {
    registrarDecision(incident, 'mantenida', incident['HR TASK FICHADA'], motivo || 'Se mantiene el fichaje original');
  } else if (action === 'revisar') {
    registrarDecision(incident, 'revisar', incident['HR TASK FICHADA'], motivo || 'Requiere revisión manual');
  } else if (action === 'otra') {
    container.querySelector('#task-selector-container').style.display = 'block';
  } else if (action === 'undo') {
    undoDecision(id);
  }
}

function registrarDecision(incident, decision, tareaFinal, motivo) {
  const id = incidentId(incident);
  const prev = SPEC.STATE.decisions[id];
  // Si ya había decisión, guardamos la previa en el undo stack
  SPEC.STATE.undoStack.push({
    id,
    prev: prev ? Object.assign({}, prev) : null,
    timestamp: Date.now()
  });
  SPEC.STATE.decisions[id] = {
    decision,
    tareaFinal: tareaFinal || '',
    motivo: motivo || '',
    timestamp: Date.now(),
    usuario: 'usuario_local', // anónimo
    evidencia: incident.OBSERVACION || '',
    seccion: incident.SECCION || '',
    idRegistro: incident['ID REGISTRO'],
    persona: incident.PERSONA,
    fecha: incident.FECHA,
    tareaOriginal: incident['HR TASK FICHADA'],
    propuesta: incident['TASKSPEC SEGUN MAPPING'] || '',
    nivelConfianza: getConfianza(incident)
  };
  // FASE 3 — Audit log con hash chain + sessionId + mappingHash + appVersion
  const prevHash = SPEC.STATE.auditLog.length > 0
    ? (SPEC.STATE.auditLog[SPEC.STATE.auditLog.length - 1].entryHash || null)
    : null;
  const entry = {
    timestamp: new Date().toISOString(),
    action: decision,
    id,
    idRegistro: incident['ID REGISTRO'],
    persona: incident.PERSONA,
    seccion: incident.SECCION,
    tareaOriginal: incident['HR TASK FICHADA'],
    propuesta: incident['TASKSPEC SEGUN MAPPING'] || '',
    tareaFinal: tareaFinal || '',
    motivo: motivo || '',
    nivelConfianza: getConfianza(incident),
    // FASE 3 — Metadatos de trazabilidad
    sessionId: (SPEC.STATE.stats && SPEC.STATE.stats.sessionId) || null,
    appVersion: (SPEC.STATE.stats && SPEC.STATE.stats.appVersion) || SPEC.PARAMS.AppVersion,
    mappingHash: (SPEC.STATE.stats && SPEC.STATE.stats.mappingHash) || null,
    schemaVersion: (SPEC.STATE.stats && SPEC.STATE.stats.schemaVersion) || SPEC.PARAMS.SchemaVersion,
    prevHash
  };
  // P12-cierre — SHA-256 obligatorio. Si crypto.subtle no disponible, marcar entrada como INSECURE_CONTEXT (NO se afirma criptografía).
  SPEC.calcularEntryHash(entry, prevHash).then(entryHash => {
    entry.entryHash = entryHash;
    // No re-render aquí; el render ya se hizo abajo. El entryHash se persiste
    // en la siguiente llamada a persistDecisions (async).
    persistDecisions();
  }).catch(err => {
    console.error('calcularEntryHash falló — entrada marcada como INSECURE_CONTEXT:', err); entry.integrity = 'INSECURE_CONTEXT';
    persistDecisions();
  });
  SPEC.STATE.auditLog.push(entry);
  toast(`Decisión registrada: ${decision.toUpperCase()}`, { level: 'success', duration: 1800 });
  persistDecisions();
  // Re-render y avanzar al siguiente
  renderReviewPanel();
  // Auto-advance si está activo el checkbox (lo añadiremos como opción)
  if (UI.autoAdvance) {
    setTimeout(() => navigateIncident(1), 200);
  } else {
    renderIncidentDetail(id);
  }
  renderAuditoriaPanel();
}

function undoDecision(id) {
  const idx = SPEC.STATE.undoStack.findIndex(u => u.id === id);
  if (idx < 0) {
    toast('No hay decisión previa para deshacer.', { level: 'warn' });
    return;
  }
  const entry = SPEC.STATE.undoStack.splice(idx, 1)[0];
  if (entry.prev) {
    SPEC.STATE.decisions[id] = entry.prev;
  } else {
    delete SPEC.STATE.decisions[id];
  }
  // FASE 3 — Audit log entry con hash chain y metadatos
  const prevHash = SPEC.STATE.auditLog.length > 0
    ? (SPEC.STATE.auditLog[SPEC.STATE.auditLog.length - 1].entryHash || null)
    : null;
  const incident = SPEC.STATE.reporte?.find(r => incidentId(r) === id);
  const logEntry = {
    timestamp: new Date().toISOString(),
    action: 'undo',
    id,
    idRegistro: incident ? incident['ID REGISTRO'] : null,
    persona: incident ? incident.PERSONA : null,
    seccion: incident ? incident.SECCION : null,
    tareaOriginal: incident ? incident['HR TASK FICHADA'] : null,
    propuesta: incident ? (incident['TASKSPEC SEGUN MAPPING'] || '') : '',
    tareaFinal: '',
    motivo: 'Deshacer decisión anterior',
    nivelConfianza: incident ? getConfianza(incident) : null,
    sessionId: (SPEC.STATE.stats && SPEC.STATE.stats.sessionId) || null,
    appVersion: (SPEC.STATE.stats && SPEC.STATE.stats.appVersion) || SPEC.PARAMS.AppVersion,
    mappingHash: (SPEC.STATE.stats && SPEC.STATE.stats.mappingHash) || null,
    schemaVersion: (SPEC.STATE.stats && SPEC.STATE.stats.schemaVersion) || SPEC.PARAMS.SchemaVersion,
    prevHash
  };
  SPEC.calcularEntryHash(logEntry, prevHash).then(h => { logEntry.entryHash = h; persistDecisions(); }).catch(err => { console.error('calcularEntryHash falló:', err); logEntry.integrity = 'INSECURE_CONTEXT'; persistDecisions(); });
  SPEC.STATE.auditLog.push(logEntry);
  toast('Decisión deshecha.', { level: 'info', duration: 1500 });
  persistDecisions();
  renderReviewPanel();
  renderIncidentDetail(id);
  renderAuditoriaPanel();
}

function undoLastAction() {
  if (SPEC.STATE.undoStack.length === 0) {
    toast('No hay acciones para deshacer.', { level: 'warn' });
    return;
  }
  const last = SPEC.STATE.undoStack.pop();
  if (last.prev) {
    SPEC.STATE.decisions[last.id] = last.prev;
  } else {
    delete SPEC.STATE.decisions[last.id];
  }
  // FASE 3 — Audit log entry con hash chain y metadatos
  const prevHash = SPEC.STATE.auditLog.length > 0
    ? (SPEC.STATE.auditLog[SPEC.STATE.auditLog.length - 1].entryHash || null)
    : null;
  const incident = SPEC.STATE.reporte?.find(r => incidentId(r) === last.id);
  const logEntry = {
    timestamp: new Date().toISOString(),
    action: 'undo',
    id: last.id,
    idRegistro: incident ? incident['ID REGISTRO'] : null,
    persona: incident ? incident.PERSONA : null,
    seccion: incident ? incident.SECCION : null,
    tareaOriginal: incident ? incident['HR TASK FICHADA'] : null,
    propuesta: incident ? (incident['TASKSPEC SEGUN MAPPING'] || '') : '',
    tareaFinal: '',
    motivo: 'Deshacer última acción',
    nivelConfianza: incident ? getConfianza(incident) : null,
    sessionId: (SPEC.STATE.stats && SPEC.STATE.stats.sessionId) || null,
    appVersion: (SPEC.STATE.stats && SPEC.STATE.stats.appVersion) || SPEC.PARAMS.AppVersion,
    mappingHash: (SPEC.STATE.stats && SPEC.STATE.stats.mappingHash) || null,
    schemaVersion: (SPEC.STATE.stats && SPEC.STATE.stats.schemaVersion) || SPEC.PARAMS.SchemaVersion,
    prevHash
  };
  SPEC.calcularEntryHash(logEntry, prevHash).then(h => { logEntry.entryHash = h; persistDecisions(); }).catch(err => { console.error('calcularEntryHash falló:', err); logEntry.integrity = 'INSECURE_CONTEXT'; persistDecisions(); });
  SPEC.STATE.auditLog.push(logEntry);
  toast('Última acción deshecha.', { level: 'info', duration: 1500 });
  persistDecisions();
  renderReviewPanel();
  if (UI.currentIncidentId === last.id) renderIncidentDetail(last.id);
  renderAuditoriaPanel();
}

function navigateIncident(delta) {
  const incidents = getFilteredIncidents();
  if (incidents.length === 0) return;
  const currentIdx = incidents.findIndex(r => incidentId(r) === UI.currentIncidentId);
  let newIdx = currentIdx + delta;
  if (newIdx < 0) newIdx = 0;
  if (newIdx >= incidents.length) newIdx = incidents.length - 1;
  if (newIdx === currentIdx) return;
  const newId = incidentId(incidents[newIdx]);
  UI.currentIncidentId = newId;
  renderReviewList();
  renderIncidentDetail(newId);
}

/* FASE 3 / M-04 / M-12 — IndexedDB para persistencia robusta de decisiones.
 * localStorage tiene 5-10 MB de cuota y es volátil; IndexedDB ofrece cuota
 * mucho mayor y es más resistente. Esta función abre (o crea) la BD
 * `spec_decisions_db` con un object store `decisions`.
 * Devuelve una Promise<IDBDatabase>.
 */
function idbOpen() {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB no soportado en este entorno'));
      return;
    }
    const req = indexedDB.open('spec_decisions_db', 1);
    req.onupgradeneeded = function (e) {
      const db = e.target.result;
      if (!db.objectStoreNames.contains('decisions')) {
        const os = db.createObjectStore('decisions', { keyPath: 'sessionId' });
        os.createIndex('savedAt', 'savedAt', { unique: false });
      }
    };
    req.onsuccess = function (e) { resolve(e.target.result); };
    req.onerror = function (e) { reject(e.target.error); };
  });
}

/* FASE 3 — Backup automático de decisiones a IndexedDB.
 * Se llama desde persistDecisions() para mantener localStorage + IndexedDB sincronizados.
 * Si IndexedDB falla (cuota, modo privado, etc.), no rompe el flujo.
 */
async function idbBackupDecisions(decisions, auditLog) {
  try {
    const db = await idbOpen();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('decisions', 'readwrite');
      const os = tx.objectStore('decisions');
      const record = {
        sessionId: (SPEC.STATE.stats && SPEC.STATE.stats.sessionId) || 'default',
        decisions,
        auditLog,
        savedAt: new Date().toISOString(),
        appVersion: (SPEC.STATE.stats && SPEC.STATE.stats.appVersion) || SPEC.PARAMS.AppVersion,
        mappingHash: (SPEC.STATE.stats && SPEC.STATE.stats.mappingHash) || null
      };
      os.put(record);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => reject(tx.error);
    });
  } catch (e) {
    console.warn('IndexedDB backup fallido (no crítico):', e);
    return false;
  }
}

/* FASE 3 — Restauración desde IndexedDB (fallback si localStorage está vacío).
 * Devuelve el registro más reciente o null.
 */
async function idbRestoreDecisions() {
  try {
    const db = await idbOpen();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('decisions', 'readonly');
      const os = tx.objectStore('decisions');
      const idx = os.index('savedAt');
      const req = idx.openCursor(null, 'prev');
      let latest = null;
      req.onsuccess = function (e) {
        const cursor = e.target.result;
        if (cursor && !latest) {
          latest = cursor.value;
        }
        if (cursor) cursor.continue();
      };
      tx.oncomplete = () => resolve(latest);
      tx.onerror = () => reject(tx.error);
    });
  } catch (e) {
    console.warn('IndexedDB restore fallido:', e);
    return null;
  }
}

/* FASE 3 — Verifica la integridad del audit log cargado (hash chain).
 * Devuelve { ok, brokenAt, expectedHash, actualHash }.
 */
async function verificarIntegridadAuditLog() {
  try {
    return await SPEC.verificarAuditLogChain(SPEC.STATE.auditLog);
  } catch (e) {
    console.warn('verificarIntegridadAuditLog fallido:', e);
    return { ok: false, brokenAt: -1, expectedHash: '', actualHash: '', error: String(e) };
  }
}

/* Persistencia de decisiones (separada del estado de queries) */
function persistDecisions() {
  try {
    const toSave = {
      decisions: SPEC.STATE.decisions,
      auditLog: SPEC.STATE.auditLog,
      savedAt: new Date().toISOString(),
      // FASE 3 — Metadatos de versión en cada snapshot
      appVersion: (SPEC.STATE.stats && SPEC.STATE.stats.appVersion) || SPEC.PARAMS.AppVersion,
      schemaVersion: (SPEC.STATE.stats && SPEC.STATE.stats.schemaVersion) || SPEC.PARAMS.SchemaVersion,
      mappingHash: (SPEC.STATE.stats && SPEC.STATE.stats.mappingHash) || null,
      sessionId: (SPEC.STATE.stats && SPEC.STATE.stats.sessionId) || null
    };
    localStorage.setItem('spec_decisions', JSON.stringify(toSave));
    // FASE 3 — Backup paralelo a IndexedDB (no bloquea el retorno)
    idbBackupDecisions(SPEC.STATE.decisions, SPEC.STATE.auditLog).catch(err => {
      console.warn('IDB backup async error (no crítico):', err);
    });
    return true;
  } catch (e) {
    console.warn('No se pudo persistir decisiones en localStorage:', e);
    // FASE 3 — Si localStorage falla (cuota llena?), intentar solo IndexedDB
    idbBackupDecisions(SPEC.STATE.decisions, SPEC.STATE.auditLog).catch(() => {});
    return false;
  }
}

function restoreDecisions() {
  try {
    const raw = localStorage.getItem('spec_decisions');
    if (!raw) {
      // FASE 3 — Si localStorage está vacío, intentar restaurar desde IndexedDB
      idbRestoreDecisions().then(saved => {
        if (saved && (saved.decisions || saved.auditLog)) {
          SPEC.STATE.decisions = saved.decisions || {};
          SPEC.STATE.auditLog = saved.auditLog || [];
          console.info('Decisiones restauradas desde IndexedDB (localStorage estaba vacío).');
          // Re-render si estamos en las pestañas relevantes
          if (UI.activeTab === 'revisar') renderReviewPanel();
          if (UI.activeTab === 'auditoria') renderAuditoriaPanel();
        }
      }).catch(err => console.warn('IDB restore fallido:', err));
      return false;
    }
    const saved = JSON.parse(raw);
    SPEC.STATE.decisions = saved.decisions || {};
    SPEC.STATE.auditLog = saved.auditLog || [];
    // FASE 3 — Verificar integridad del audit log restaurado (hash chain)
    if (SPEC.STATE.auditLog.length > 0) {
      verificarIntegridadAuditLog().then(integridad => {
        if (!integridad.ok) {
          console.error('ALERTA: integridad del audit log comprometida en entrada #' + (integridad.brokenAt + 1) +
            '. Esperado=' + integridad.expectedHash + ' actual=' + integridad.actualHash);
          toast('Alerta: integridad del audit log comprometida. Revisa la consola para detalles.', { level: 'error', duration: 8000 });
        }
      });
    }
    return true;
  } catch (e) {
    return false;
  }
}

/* Setup de la pestaña de revisión
 * M-08/M-09 (Tarea F9) — Añadidos listeners para:
 *   - Auto-advance checkbox (#auto-advance-toggle) — persistente en
 *     localStorage bajo 'spec_auto_advance'. Tras registrar una decisión,
 *     registrarDecision() invoca setTimeout(navigateIncident(1), 200).
 *   - Date from/to (#review-filter-date-from, #review-filter-date-to) —
 *     input type=date, se parsea a Date (con T00:00:00 / T23:59:59).
 *   - Confianza (#review-filter-confianza) — select string.
 *   - Turno (#review-filter-turno) — select string. Informativo: no aplica
 *     el filtro en getFilteredIncidents() porque los archivos no tienen hora.
 */
function setupReviewTab() {
  const search = document.getElementById('review-search');
  const fSec = document.getElementById('review-filter-seccion');
  const fDec = document.getElementById('review-filter-decision');
  const sort = document.getElementById('review-sort');
  if (search) search.addEventListener('input', e => { UI.reviewFilter.search = e.target.value; renderReviewList(); });
  if (fSec) fSec.addEventListener('change', e => { UI.reviewFilter.seccion = e.target.value; renderReviewList(); });
  if (fDec) fDec.addEventListener('change', e => { UI.reviewFilter.decision = e.target.value; renderReviewList(); });
  if (sort) sort.addEventListener('change', e => { UI.reviewFilter.sort = e.target.value; renderReviewList(); });

  // M-09 — Date range filters
  const dateFrom = document.getElementById('review-filter-date-from');
  const dateTo = document.getElementById('review-filter-date-to');
  if (dateFrom) dateFrom.addEventListener('change', () => {
    UI.reviewFilter.dateFrom = dateFrom.value ? new Date(dateFrom.value + 'T00:00:00') : null;
    renderReviewList();
  });
  if (dateTo) dateTo.addEventListener('change', () => {
    UI.reviewFilter.dateTo = dateTo.value ? new Date(dateTo.value + 'T23:59:59') : null;
    renderReviewList();
  });
  // M-09 — Confianza filter
  const conf = document.getElementById('review-filter-confianza');
  if (conf) conf.addEventListener('change', () => {
    UI.reviewFilter.confianza = conf.value;
    renderReviewList();
  });
  // M-09 — Turno filter (informativo, no aplica a la lista pero se persiste
  // el valor en UI.reviewFilter.turno para uso futuro cuando los archivos
  // incluyan hora del fichaje).
  const turno = document.getElementById('review-filter-turno');
  if (turno) turno.addEventListener('change', () => {
    UI.reviewFilter.turno = turno.value;
    renderReviewList();
  });

  // M-08 — Auto-advance toggle. Persistente en localStorage.
  const autoAdv = document.getElementById('auto-advance-toggle');
  if (autoAdv) {
    // Restore from localStorage
    try {
      const saved = localStorage.getItem('spec_auto_advance');
      if (saved === 'true') {
        autoAdv.checked = true;
        UI.autoAdvance = true;
      }
    } catch (e) { /* localStorage may be unavailable in some contexts */ }
    autoAdv.addEventListener('change', () => {
      UI.autoAdvance = autoAdv.checked;
      try { localStorage.setItem('spec_auto_advance', String(autoAdv.checked)); } catch (e) { /* noop */ }
      toast(`Auto-advance ${autoAdv.checked ? 'activado' : 'desactivado'}.`, { level: 'info', duration: 1500 });
    });
  }

  // Bulk actions
  const bulkAccept = document.getElementById('bulk-accept');
  const bulkKeep = document.getElementById('bulk-keep');
  const bulkClear = document.getElementById('bulk-clear');
  if (bulkAccept) bulkAccept.addEventListener('click', () => bulkAction('aceptada'));
  if (bulkKeep) bulkKeep.addEventListener('click', () => bulkAction('mantenida'));
  if (bulkClear) bulkClear.addEventListener('click', () => {
    SPEC.STATE.bulkSelection.clear();
    renderReviewList();
  });
}

function bulkAction(decision) {
  const rep = SPEC.STATE.reporte || [];
  let count = 0;
  for (const id of SPEC.STATE.bulkSelection) {
    const incident = rep.find(r => incidentId(r) === id);
    if (!incident) continue;
    // Para "aceptada", solo si hay propuesta
    if (decision === 'aceptada' && !incident['TASKSPEC SEGUN MAPPING']) continue;
    const tareaFinal = decision === 'aceptada' ? incident['TASKSPEC SEGUN MAPPING'] :
                       decision === 'mantenida' ? incident['HR TASK FICHADA'] : incident['HR TASK FICHADA'];
    SPEC.STATE.decisions[id] = {
      decision,
      tareaFinal,
      motivo: `Acción masiva (${count + 1})`,
      timestamp: Date.now(),
      usuario: 'usuario_local',
      evidencia: incident.OBSERVACION || '',
      seccion: incident.SECCION || '',
      idRegistro: incident['ID REGISTRO'],
      persona: incident.PERSONA,
      fecha: incident.FECHA,
      tareaOriginal: incident['HR TASK FICHADA'],
      propuesta: incident['TASKSPEC SEGUN MAPPING'] || '',
      nivelConfianza: getConfianza(incident)
    };
    SPEC.STATE.auditLog.push({
      timestamp: new Date().toISOString(),
      action: decision,
      id,
      idRegistro: incident['ID REGISTRO'],
      persona: incident.PERSONA,
      seccion: incident.SECCION,
      tareaOriginal: incident['HR TASK FICHADA'],
      propuesta: incident['TASKSPEC SEGUN MAPPING'] || '',
      tareaFinal,
      motivo: 'Acción masiva',
      nivelConfianza: getConfianza(incident)
    });
    count++;
  }
  SPEC.STATE.bulkSelection.clear();
  toast(`${count} decisión(es) registradas en lote.`, { level: 'success' });
  persistDecisions();
  renderReviewPanel();
  renderAuditoriaPanel();
}

/* ===================== PATRONES DETECTADOS ===================== */
function renderPatronesPanel() {
  const container = document.getElementById('patterns-grid');
  if (!container) return;
  container.innerHTML = '';
  const rep = SPEC.STATE.reporte || [];
  if (rep.length === 0) {
    container.innerHTML = '<p style="color: var(--c-text-muted); font-size: 13px;">Procesa los archivos para ver patrones.</p>';
    return;
  }

  // 1. Personas con incidencias recurrentes (top 10)
  const personasCount = {};
  for (const r of rep) {
    if (!r.PERSONA) continue;
    personasCount[r.PERSONA] = (personasCount[r.PERSONA] || 0) + 1;
  }
  const topPersonas = Object.entries(personasCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10);

  container.appendChild(makePatternCard(
    'Personas con incidencias recurrentes',
    'warn',
    topPersonas.map(([name, count]) => ({ name, count })),
    'No hay datos suficientes para detectar recurrencias.'
  ));

  // 2. Tareas con errores frecuentes de fichaje (HR TASK FICHADA)
  const tareasCount = {};
  for (const r of rep) {
    if (!r['HR TASK FICHADA']) continue;
    const t = r['HR TASK FICHADA'];
    tareasCount[t] = (tareasCount[t] || 0) + 1;
  }
  const topTareas = Object.entries(tareasCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10);

  container.appendChild(makePatternCard(
    'Tareas SPEC con más fichajes sin volumen',
    'danger',
    topTareas.map(([name, count]) => ({ name, count })),
    'Sin datos suficientes.'
  ));

  // 3. Actividades WMS sin mapping
  const mapeo = SPEC.STATE.queries['12_MapeoActividadSPEC'] || [];
  const volumen = SPEC.STATE.queries['02_VolumenDetalle'] || [];
  const mappedTasks = new Set(mapeo.map(m => m.TASK_WMS));
  const unmapped = {};
  for (const v of volumen) {
    if (!v.WMS_TASK) continue;
    if (!mappedTasks.has(v.WMS_TASK)) {
      unmapped[v.WMS_TASK] = (unmapped[v.WMS_TASK] || 0) + 1;
    }
  }
  const topUnmapped = Object.entries(unmapped)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10);

  container.appendChild(makePatternCard(
    'Actividades WMS sin mapping SPEC',
    'danger',
    topUnmapped.map(([name, count]) => ({ name, count })),
    'Todas las actividades WMS tienen mapping. ✓'
  ));

  // 4. Mappings ambiguos (EstadoMapeoSPEC = AMBIGUO)
  const ambiguos = mapeo.filter(m => m.EstadoMapeoSPEC === 'AMBIGUO');
  container.appendChild(makePatternCard(
    'Mappings ambiguos (varias TASKSPEC)',
    'warn',
    ambiguos.map(m => ({ name: `${m.SAP_CODE} / ${m.CUSTOMER} / ${m.TASK_WMS}`, count: m.NumeroTasksSPEC })),
    'No hay mappings ambiguos. ✓'
  ));

  // 5. Días con número anormal de incidencias
  const diasCount = {};
  for (const r of rep) {
    if (!r.FECHA) continue;
    const d = SPEC.formatFechaISO(r.FECHA);
    diasCount[d] = (diasCount[d] || 0) + 1;
  }
  const topDias = Object.entries(diasCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10);

  container.appendChild(makePatternCard(
    'Días con más incidencias',
    '',
    topDias.map(([name, count]) => ({ name, count })),
    'Sin datos suficientes.'
  ));

  // 6. Casos por sección (distribución)
  const secCount = {};
  for (const r of rep) {
    const s = r.SECCION || '(sin)';
    secCount[s] = (secCount[s] || 0) + 1;
  }
  const topSecs = Object.entries(secCount).sort((a, b) => b[1] - a[1]);
  container.appendChild(makePatternCard(
    'Distribución por sección',
    '',
    topSecs.map(([name, count]) => ({ name, count })),
    'Sin datos.'
  ));
}

function makePatternCard(title, level, items, emptyMsg) {
  const card = document.createElement('div');
  card.className = 'pattern-card' + (level ? ' ' + level : '');
  let html = `<h5>${escapeHtml(title)}</h5><div class="pattern-items">`;
  if (items.length === 0) {
    html += `<div class="pattern-empty">${escapeHtml(emptyMsg)}</div>`;
  } else {
    for (const item of items) {
      html += `<div class="pattern-item"><span class="pi-name">${escapeHtml(item.name)}</span><span class="pi-count">${item.count}</span></div>`;
    }
  }
  html += '</div>';
  card.innerHTML = html;
  return card;
}

/* ===================== AUDIT LOG ===================== */
function renderAuditoriaPanel() {
  const tbody = document.getElementById('audit-tbody');
  if (!tbody) return;
  const log = SPEC.STATE.auditLog || [];
  if (log.length === 0) {
    tbody.innerHTML = '<tr><td colspan="9" style="text-align:center; padding: 20px; color: var(--c-text-muted);">No hay decisiones registradas todavía.</td></tr>';
    return;
  }
  tbody.innerHTML = '';
  // Mostrar en orden inverso (más reciente primero)
  const reversed = log.slice().reverse();
  reversed.forEach((entry, i) => {
    const tr = document.createElement('tr');
    const fecha = new Date(entry.timestamp);
    tr.innerHTML = `
      <td>${log.length - i}</td>
      <td>${fecha.toLocaleString('es-ES')}</td>
      <td>${escapeHtml(String(entry.idRegistro || ''))}</td>
      <td>${escapeHtml(entry.persona || '')}</td>
      <td>${escapeHtml(entry.seccion || '')}</td>
      <td>${escapeHtml(entry.tareaOriginal || '')}</td>
      <td>${escapeHtml(entry.propuesta || '')}</td>
      <td class="al-action-${entry.action}">${escapeHtml(entry.action)}</td>
      <td>${escapeHtml(entry.motivo || '')}</td>
    `;
    tbody.appendChild(tr);
  });
}

function setupAuditoriaTab() {
  const expXlsx = document.getElementById('audit-export-xlsx');
  const expCsv = document.getElementById('audit-export-csv');
  const clear = document.getElementById('audit-clear');
  if (expXlsx) expXlsx.addEventListener('click', () => {
    const log = SPEC.STATE.auditLog || [];
    if (log.length === 0) { toast('No hay decisiones para exportar.', { level: 'warn' }); return; }
    const data = log.map((e, i) => ({
      '#': i + 1,
      'Fecha': new Date(e.timestamp).toLocaleString('es-ES'),
      'ID Registro': e.idRegistro || '',
      'Persona': e.persona || '',
      'Sección': e.seccion || '',
      'Tarea original': e.tareaOriginal || '',
      'Propuesta automática': e.propuesta || '',
      'Tarea final': e.tareaFinal || '',
      'Decisión': e.action || '',
      'Motivo': e.motivo || '',
      'Nivel confianza': e.nivelConfianza || ''
    }));
    SPEC.exportToXlsx(data, `Auditoria_decisiones_${timestamp()}.xlsx`, 'Auditoria');
    toast('Auditoría exportada a XLSX.', { level: 'success' });
  });
  if (expCsv) expCsv.addEventListener('click', () => {
    const log = SPEC.STATE.auditLog || [];
    if (log.length === 0) { toast('No hay decisiones para exportar.', { level: 'warn' }); return; }
    const data = log.map((e, i) => ({
      '#': i + 1,
      'Fecha': new Date(e.timestamp).toLocaleString('es-ES'),
      'ID Registro': e.idRegistro || '',
      'Persona': e.persona || '',
      'Sección': e.seccion || '',
      'Tarea original': e.tareaOriginal || '',
      'Propuesta automática': e.propuesta || '',
      'Tarea final': e.tareaFinal || '',
      'Decisión': e.action || '',
      'Motivo': e.motivo || '',
      'Nivel confianza': e.nivelConfianza || ''
    }));
    SPEC.exportToCsv(data, `Auditoria_decisiones_${timestamp()}.csv`);
    toast('Auditoría exportada a CSV.', { level: 'success' });
  });
  if (clear) clear.addEventListener('click', () => {
    confirmDialog('¿Vaciar todo el registro de auditoría? Esta acción no se puede deshacer.', () => {
      SPEC.STATE.auditLog = [];
      SPEC.STATE.decisions = {};
      SPEC.STATE.undoStack = [];
      persistDecisions();
      renderAuditoriaPanel();
      renderReviewPanel();
      toast('Registro de auditoría vaciado.', { level: 'success' });
    });
  });
}

/* ===================== KEYBOARD SHORTCUTS ===================== */
function setupKeyboardShortcuts() {
  document.addEventListener('keydown', e => {
    // Solo en la pestaña de revisión
    if (UI.activeTab !== 'revisar') return;
    // Ignorar si está escribiendo en un input
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') {
      if (e.key === 'Escape') e.target.blur();
      return;
    }
    if (!UI.currentIncidentId) return;
    const rep = SPEC.STATE.reporte || [];
    const incident = rep.find(r => incidentId(r) === UI.currentIncidentId);
    if (!incident) return;
    switch (e.key.toLowerCase()) {
      case 'a':
        if (incident['TASKSPEC SEGUN MAPPING']) {
          registrarDecision(incident, 'aceptada', incident['TASKSPEC SEGUN MAPPING'], 'Aceptada con atajo A');
        }
        break;
      case 'm':
        registrarDecision(incident, 'mantenida', incident['HR TASK FICHADA'], 'Mantenido con atajo M');
        break;
      case 'r':
        registrarDecision(incident, 'revisar', incident['HR TASK FICHADA'], 'Revisar con atajo R');
        break;
      case 'n':
        navigateIncident(1);
        break;
      case 'p':
        navigateIncident(-1);
        break;
      case 'u':
        undoLastAction();
        break;
    }
  });
}

/* ===================== WARN BEFORE LEAVING WITH CHANGES ===================== */
function setupBeforeUnload() {
  window.addEventListener('beforeunload', e => {
    const pendingDecisions = Object.keys(SPEC.STATE.decisions || {}).length;
    if (pendingDecisions > 0 && !localStorage.getItem('spec_decisions')) {
      // Hay decisiones sin persistir
      e.preventDefault();
      e.returnValue = '';
      return '';
    }
  });
}

/* ===================== INTEGRACIÓN CON INIT ===================== */
const _origInit2 = init;
init = function () {
  _origInit2();
  setupReviewTab();
  setupAuditoriaTab();
  setupKeyboardShortcuts();
  setupBeforeUnload();
  // FASE 3 — Restaurar decisiones (localStorage + IndexedDB fallback + verificación de hash chain)
  restoreDecisions();
};

/* FASE-init-fix — Register the wrapped init (window.init) to actually fire on
 * DOMContentLoaded. The listener at line 1337 inside the IIFE captured the
 * original unwrapped init by reference, so the v3/v4 setups (theme toggle,
 * global search, detail panel, preview modal, persistence, KPI drilldown,
 * review tab, auditoria tab, keyboard shortcuts, beforeunload, restoreDecisions,
 * mapping tab) were NEVER being called automatically on page load.
 *
 * We add a NEW DOMContentLoaded listener that calls the wrapped init (window.init).
 * The idempotency guard at the top of _origInit2 (window.__spec_init_done) ensures
 * setupTabs + setupDropZones run only once, even if both listeners fire.
 *
 * FASE-init-fix-2 — Skip in non-browser environments (Node tests load ui.js
 * via `new Function()` and don't have real DOM elements; setupDropZones calls
 * document.getElementById('btn-validar').addEventListener which would crash).
 * Only run when document.readyState is a real string ('loading' | 'interactive'
 * | 'complete'), which is only true in a browser.
 */
if (typeof document !== 'undefined' && typeof document.readyState === 'string') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => { try { init(); } catch (e) { console.warn('init error:', e); } });
  } else {
    // DOM already loaded (script at end of body without defer)
    try { init(); } catch (e) { console.warn('init error:', e); }
  }
}

/* ============================================================================
 * FASE 8 / M-07 — Gestión del Mapping (CRUD + audit)
 * Sub-pestaña "Mapping" entre Resultados y Reporte HR.
 * Permite consultar, buscar, filtrar, editar, crear y eliminar filas del
 * mapping TASK_WMS → TASK_SPEC cargado desde Mapping.xlsx. Todos los cambios
 * quedan registrados en el audit log con hash chain + sessionId + mappingHash.
 * ========================================================================== */

/* Estado de la pestaña Mapping */
UI.mappingFilter = { search: '', customer: '', activity: '' };
UI.mappingOriginal = [];   // snapshot del mapping cargado original (sin editar)
UI.mappingCurrent = [];    // versión actual (editable) — se persiste en localStorage
UI.mappingSetupDone = false; // evita re-bind de listeners en cada click de tab

/* setupMappingTab — attaches listeners a los controles del toolbar y al modal.
 * Idempotente vía UI.mappingSetupDone (también llamado desde setupTabs()
 * como fallback, ya que el wrap de init() puede no interceptar el
 * DOMContentLoaded cuando ui.js se carga como script top-level). */
function setupMappingTab() {
  const search = document.getElementById('mapping-search');
  const fCustomer = document.getElementById('mapping-filter-customer');
  const fActivity = document.getElementById('mapping-filter-activity');
  const btnDup = document.getElementById('mapping-detect-duplicates');
  const btnAmb = document.getElementById('mapping-detect-ambiguities');
  const btnNew = document.getElementById('mapping-new');
  const btnExp = document.getElementById('mapping-export');
  const btnImp = document.getElementById('mapping-import');
  const impInput = document.getElementById('mapping-import-input');
  const editForm = document.getElementById('mapping-edit-form');
  const editCancel = document.getElementById('mapping-edit-cancel');

  if (search) search.addEventListener('input', () => {
    UI.mappingFilter.search = search.value.toLowerCase();
    renderMappingTable();
  });
  if (fCustomer) fCustomer.addEventListener('change', () => {
    UI.mappingFilter.customer = fCustomer.value;
    renderMappingTable();
  });
  if (fActivity) fActivity.addEventListener('change', () => {
    UI.mappingFilter.activity = fActivity.value;
    renderMappingTable();
  });
  if (btnDup) btnDup.addEventListener('click', () => highlightDuplicates());
  if (btnAmb) btnAmb.addEventListener('click', () => highlightAmbiguities());
  if (btnNew) btnNew.addEventListener('click', () => openMappingEditor(-1));
  if (btnExp) btnExp.addEventListener('click', () => exportMappingXlsx());
  if (btnImp) btnImp.addEventListener('click', () => impInput && impInput.click());
  if (impInput) impInput.addEventListener('change', async e => {
    const file = e.target.files && e.target.files[0];
    if (file) await importMappingXlsx(file);
    impInput.value = ''; // permite re-importar el mismo archivo
  });
  if (editForm) editForm.addEventListener('submit', e => {
    e.preventDefault();
    saveMappingEdit();
  });
  if (editCancel) editCancel.addEventListener('click', () => closeMappingEditor());
}

/* initMappingData — (re)lee el mapping desde los workbooks cargados en
 * SPEC.STATE.archivos.mapping y construye UI.mappingOriginal/Current. Se llama
 * al cambiar a la pestaña Mapping y al terminar analizar(). No hace nada si
 * el usuario aún no ha cargado Mapping.xlsx.
 *
 * M-10 fix (regresión M-07 detectada por auditoría): desde el refactor
 * multi-archivo, SPEC.STATE.archivos.mapping es un ARRAY de entradas
 * { name, workbook } (igual que horas/volumen/volSinHoras). Esta función
 * aún leía el formato legacy (objeto con .workbook), por lo que la pestaña
 * Mapping quedaba VACÍA tras el flujo normal de carga multi-archivo.
 * Ahora soporta AMBOS formatos y fusiona todos los workbooks de mapping,
 * igual que hace analizarYConciliar (flatMap sobre leerMapping). */
function initMappingData() {
  if (!SPEC.STATE.archivos || !SPEC.STATE.archivos.mapping) {
    UI.mappingOriginal = [];
    UI.mappingCurrent = [];
    return;
  }
  // Normalizar a array de { name, workbook } (formato M-10; legacy = 1 entry)
  const mappingEntries = Array.isArray(SPEC.STATE.archivos.mapping)
    ? SPEC.STATE.archivos.mapping
    : (SPEC.STATE.archivos.mapping.workbook ? [SPEC.STATE.archivos.mapping] : []);
  if (mappingEntries.length === 0) {
    UI.mappingOriginal = [];
    UI.mappingCurrent = [];
    return;
  }
  // Re-leer mapping fresco (por si el usuario ha cargado otro archivo).
  // leerMapping lanza si la hoja Mapping no existe o faltan columnas — capturamos
  // y fusionamos TODOS los archivos de mapping (mismo criterio que el orquestador:
  // archivosArr.mapping.flatMap(a => leerMapping(a.workbook))).
  let rows;
  try {
    rows = [];
    for (const entry of mappingEntries) {
      if (!entry || !entry.workbook) continue;
      const part = SPEC.leerMapping(entry.workbook);
      rows = rows.concat(part);
    }
  } catch (err) {
    console.warn('initMappingData: no se pudo leer Mapping.xlsx:', err.message);
    UI.mappingOriginal = [];
    UI.mappingCurrent = [];
    return;
  }
  UI.mappingOriginal = rows.map(r => ({ ...r }));
  UI.mappingCurrent = rows.map(r => ({ ...r }));
  // Recalcular hash del mapping cargado y guardarlo en stats
  if (SPEC.STATE.stats) SPEC.STATE.stats.mappingHash = SPEC.calcularMappingHash(rows);
  // Rellenar los <select> de filtros a partir de los datos cargados
  populateMappingFilters();
}

/* Rellena los dropdown de Customer y Activity con valores únicos del
 * mapping actual. Idempotente: limpia opciones previas excepto el placeholder. */
function populateMappingFilters() {
  const fCustomer = document.getElementById('mapping-filter-customer');
  const fActivity = document.getElementById('mapping-filter-activity');
  if (!fCustomer || !fActivity) return;
  const customers = Array.from(new Set(UI.mappingCurrent.map(r => r.CUSTOMER).filter(v => v != null && v !== ''))).sort();
  const activities = Array.from(new Set(UI.mappingCurrent.map(r => r.ACTIVITY).filter(v => v != null && v !== ''))).sort();
  // Preserve current selection if possible
  const prevCustomer = UI.mappingFilter.customer;
  const prevActivity = UI.mappingFilter.activity;
  // Limpiar opciones excepto la primera (placeholder)
  while (fCustomer.options.length > 1) fCustomer.remove(1);
  while (fActivity.options.length > 1) fActivity.remove(1);
  for (const c of customers) {
    const o = document.createElement('option');
    o.value = c; o.textContent = String(c);
    fCustomer.appendChild(o);
  }
  for (const a of activities) {
    const o = document.createElement('option');
    o.value = a; o.textContent = String(a);
    fActivity.appendChild(o);
  }
  // Restaurar selección previa si sigue existiendo
  if (prevCustomer && Array.from(fCustomer.options).some(o => o.value === prevCustomer)) {
    fCustomer.value = prevCustomer;
  } else {
    fCustomer.value = '';
    UI.mappingFilter.customer = '';
  }
  if (prevActivity && Array.from(fActivity.options).some(o => o.value === prevActivity)) {
    fActivity.value = prevActivity;
  } else {
    fActivity.value = '';
    UI.mappingFilter.activity = '';
  }
}

/* renderMappingTable — pinta el tbody con las filas filtradas.
 * Sin virtual scrolling: el mapping típico son ~167 filas, muy por debajo
 * del threshold VIEWER_THRESHOLD=200 del viewer de Resultados. */
function renderMappingTable() {
  const tbody = document.getElementById('mapping-tbody');
  if (!tbody) return;
  // Empty state si no hay mapping cargado
  if (!UI.mappingCurrent || UI.mappingCurrent.length === 0) {
    tbody.innerHTML = '<tr><td colspan="9" style="text-align:center; padding:20px; color:var(--c-text-muted);">No hay mapping cargado. Carga Mapping.xlsx en la pestaña Carga.</td></tr>';
    updateMappingStats();
    return;
  }
  // Aplicar filtros
  let data = UI.mappingCurrent;
  if (UI.mappingFilter.search) {
    const q = UI.mappingFilter.search;
    data = data.filter(r =>
      Object.values(r).some(v => v != null && String(v).toLowerCase().indexOf(q) >= 0)
    );
  }
  if (UI.mappingFilter.customer) {
    data = data.filter(r => (r.CUSTOMER || '') === UI.mappingFilter.customer);
  }
  if (UI.mappingFilter.activity) {
    data = data.filter(r => (r.ACTIVITY || '') === UI.mappingFilter.activity);
  }
  // Render (limit to 1000 rows; mapping is typically <200)
  const limited = data.slice(0, 1000);
  let html = '';
  for (let i = 0; i < limited.length; i++) {
    const r = limited[i];
    const origIdx = UI.mappingCurrent.indexOf(r);
    html += '<tr data-idx="' + escapeAttr(String(origIdx)) + '">' +
      '<td>' + escapeHtml(r.SAP_CODE || '') + '</td>' +
      '<td>' + escapeHtml(r.WMS_DC || '') + '</td>' +
      '<td>' + escapeHtml(r.CUSTOMER || '') + '</td>' +
      '<td>' + escapeHtml(r.DEPARTMENT || '') + '</td>' +
      '<td>' + escapeHtml(r.ACTIVITY || '') + '</td>' +
      '<td>' + escapeHtml(r.SUB_ACTIVITY || '') + '</td>' +
      '<td>' + escapeHtml(r.TASK_WMS || '') + '</td>' +
      '<td>' + escapeHtml(r.TASK_SPEC || '') + '</td>' +
      '<td>' +
        '<button class="btn btn-link btn-mapping-edit" data-idx="' + escapeAttr(String(origIdx)) + '" title="Editar">✎</button>' +
        '<button class="btn btn-link btn-mapping-delete" data-idx="' + escapeAttr(String(origIdx)) + '" title="Eliminar">🗑</button>' +
      '</td>' +
    '</tr>';
  }
  if (data.length > 1000) {
    html += '<tr><td colspan="9" style="text-align:center; color:var(--c-text-muted);">Mostrando 1000 de ' + data.length + ' entradas. Aplica filtro para reducir.</td></tr>';
  }
  // M-07 fix (auditoría FASE 10): los filtros/búsqueda pueden dejar 0 filas —
  // mostrar un estado vacío explícito en lugar de un tbody en blanco.
  if (data.length === 0) {
    html = '<tr><td colspan="9" style="text-align:center; padding:20px; color:var(--c-text-muted);">No hay entradas que coincidan con la búsqueda o los filtros aplicados.</td></tr>';
  }
  tbody.innerHTML = html;
  // Bind edit/delete buttons
  tbody.querySelectorAll('.btn-mapping-edit').forEach(b => b.addEventListener('click', e => {
    e.stopPropagation();
    openMappingEditor(parseInt(b.dataset.idx, 10));
  }));
  tbody.querySelectorAll('.btn-mapping-delete').forEach(b => b.addEventListener('click', e => {
    e.stopPropagation();
    deleteMappingEntry(parseInt(b.dataset.idx, 10));
  }));
  updateMappingStats();
}

/* updateMappingStats — refresca los badges del toolbar. */
function updateMappingStats() {
  const count = document.getElementById('mapping-count');
  const uniqueTasks = document.getElementById('mapping-unique-tasks');
  const duplicates = document.getElementById('mapping-duplicates');
  const ambiguities = document.getElementById('mapping-ambiguities');
  const hash = document.getElementById('mapping-hash');
  if (count) count.textContent = (UI.mappingCurrent.length || 0) + ' entradas';
  if (uniqueTasks) {
    const set = new Set(UI.mappingCurrent.map(r => r.TASK_WMS).filter(Boolean));
    uniqueTasks.textContent = set.size + ' TASK_WMS únicos';
  }
  if (duplicates) duplicates.textContent = countDuplicates() + ' duplicados';
  if (ambiguities) ambiguities.textContent = countAmbiguities() + ' ambigüedades';
  if (hash) hash.textContent = 'Hash: ' + ((SPEC.STATE.stats && SPEC.STATE.stats.mappingHash) || '—');
}

/* Detección de duplicados: misma (SAP_CODE, CUSTOMER, TASK_WMS) aparece con
 * más de una fila (mismo o distinto TASK_SPEC). En la práctica estos son los
 * casos conflictivos: el WMS podría mapear a 2+ TASK_SPEC. */
function countDuplicates() {
  const map = {};
  for (const r of UI.mappingCurrent) {
    const k = (r.SAP_CODE || '') + '|' + (r.CUSTOMER || '') + '|' + (r.TASK_WMS || '');
    if (!map[k]) map[k] = new Set();
    if (r.TASK_SPEC) map[k].add(r.TASK_SPEC);
  }
  let c = 0;
  for (const k of Object.keys(map)) {
    if (map[k].size > 1) c++;
  }
  return c;
}

function highlightDuplicates() {
  const tbody = document.getElementById('mapping-tbody');
  if (!tbody) return;
  const map = {};
  UI.mappingCurrent.forEach((r, idx) => {
    const k = (r.SAP_CODE || '') + '|' + (r.CUSTOMER || '') + '|' + (r.TASK_WMS || '');
    if (!map[k]) map[k] = [];
    map[k].push(idx);
  });
  // Limpiar marcas previas y aplicar nuevas
  tbody.querySelectorAll('tr').forEach(tr => tr.classList.remove('duplicate', 'ambiguous'));
  for (const k of Object.keys(map)) {
    if (map[k].length > 1) {
      for (const idx of map[k]) {
        const tr = tbody.querySelector('tr[data-idx="' + CSS.escape(String(idx)) + '"]');
        if (tr) tr.classList.add('duplicate');
      }
    }
  }
  toast(countDuplicates() + ' duplicados resaltados.', { level: 'info' });
}

/* Ambigüedades = duplicados (misma definición en este contexto).
 * También marcamos filas sin TASK_SPEC como ambiguous (no se pueden resolver). */
function countAmbiguities() {
  return countDuplicates();
}

function highlightAmbiguities() {
  highlightDuplicates();
  const tbody = document.getElementById('mapping-tbody');
  if (tbody) {
    tbody.querySelectorAll('tr').forEach(tr => {
      const idx = parseInt(tr.dataset.idx, 10);
      const r = UI.mappingCurrent[idx];
      if (r && !r.TASK_SPEC) tr.classList.add('ambiguous');
    });
  }
  toast(countAmbiguities() + ' ambigüedades resaltadas.', { level: 'info' });
}

/* openMappingEditor — idx=-1 para crear, idx>=0 para editar. */
function openMappingEditor(idx) {
  const modal = document.getElementById('mapping-edit-modal');
  const title = document.getElementById('mapping-edit-title');
  const fIdx = document.getElementById('mapping-edit-index');
  const fSap = document.getElementById('mapping-edit-sap');
  const fWmsdc = document.getElementById('mapping-edit-wmsdc');
  const fCustomer = document.getElementById('mapping-edit-customer');
  const fDepartment = document.getElementById('mapping-edit-department');
  const fActivity = document.getElementById('mapping-edit-activity');
  const fSubactivity = document.getElementById('mapping-edit-subactivity');
  const fTaskwms = document.getElementById('mapping-edit-taskwms');
  const fTaskspec = document.getElementById('mapping-edit-taskspec');
  if (!modal) return;
  if (idx === -1) {
    if (title) title.textContent = 'Nuevo mapping';
    fIdx.value = '-1';
    fSap.value = ''; fWmsdc.value = ''; fCustomer.value = ''; fDepartment.value = '';
    fActivity.value = ''; fSubactivity.value = ''; fTaskwms.value = ''; fTaskspec.value = '';
  } else {
    if (title) title.textContent = 'Editar mapping #' + (idx + 1);
    const r = UI.mappingCurrent[idx];
    if (!r) return;
    fIdx.value = String(idx);
    fSap.value = r.SAP_CODE || '';
    fWmsdc.value = r.WMS_DC || '';
    fCustomer.value = r.CUSTOMER || '';
    fDepartment.value = r.DEPARTMENT || '';
    fActivity.value = r.ACTIVITY || '';
    fSubactivity.value = r.SUB_ACTIVITY || '';
    fTaskwms.value = r.TASK_WMS || '';
    fTaskspec.value = r.TASK_SPEC || '';
  }
  modal.style.display = 'flex';
  if (fTaskwms) fTaskwms.focus();
}

function closeMappingEditor() {
  const modal = document.getElementById('mapping-edit-modal');
  if (modal) modal.style.display = 'none';
}

/* saveMappingEdit — lee el form, valida, aplica el cambio a mappingCurrent y
 * registra la entrada de audit. */
function saveMappingEdit() {
  const idx = parseInt(document.getElementById('mapping-edit-index').value, 10);
  const oldRow = idx >= 0 ? { ...UI.mappingCurrent[idx] } : null;
  const newRow = {
    SAP_CODE: document.getElementById('mapping-edit-sap').value.trim(),
    WMS_DC: document.getElementById('mapping-edit-wmsdc').value.trim(),
    CUSTOMER: document.getElementById('mapping-edit-customer').value.trim(),
    DEPARTMENT: document.getElementById('mapping-edit-department').value.trim(),
    ACTIVITY: document.getElementById('mapping-edit-activity').value.trim(),
    SUB_ACTIVITY: document.getElementById('mapping-edit-subactivity').value.trim(),
    TASK_WMS: document.getElementById('mapping-edit-taskwms').value.trim(),
    TASK_SPEC: document.getElementById('mapping-edit-taskspec').value.trim()
  };
  if (!newRow.TASK_WMS || !newRow.TASK_SPEC) {
    toast('TASK_WMS y TASK_SPEC son obligatorios.', { level: 'error' });
    return;
  }
  if (idx === -1) {
    UI.mappingCurrent.push(newRow);
    logMappingChange('create', null, newRow);
    toast('Mapping creado.', { level: 'success' });
  } else {
    UI.mappingCurrent[idx] = newRow;
    logMappingChange('update', oldRow, newRow);
    toast('Mapping actualizado.', { level: 'success' });
  }
  // Recalcular hash del mapping actualizado
  if (SPEC.STATE.stats) SPEC.STATE.stats.mappingHash = SPEC.calcularMappingHash(UI.mappingCurrent);
  closeMappingEditor();
  populateMappingFilters();
  renderMappingTable();
  persistDecisions();
}

function deleteMappingEntry(idx) {
  if (idx < 0 || idx >= UI.mappingCurrent.length) return;
  const oldRow = { ...UI.mappingCurrent[idx] };
  if (!confirm('¿Eliminar mapping para TASK_WMS="' + oldRow.TASK_WMS + '" / TASK_SPEC="' + oldRow.TASK_SPEC + '"?')) return;
  UI.mappingCurrent.splice(idx, 1);
  logMappingChange('delete', oldRow, null);
  if (SPEC.STATE.stats) SPEC.STATE.stats.mappingHash = SPEC.calcularMappingHash(UI.mappingCurrent);
  populateMappingFilters();
  renderMappingTable();
  persistDecisions();
  toast('Mapping eliminado.', { level: 'info' });
}

/* logMappingChange — registra una entrada en SPEC.STATE.auditLog con hash
 * chain + sessionId + mappingHash (mismo formato que registrarDecision). */
function logMappingChange(action, oldRow, newRow) {
  const prevHash = SPEC.STATE.auditLog.length > 0
    ? (SPEC.STATE.auditLog[SPEC.STATE.auditLog.length - 1].entryHash || null)
    : null;
  const entry = {
    timestamp: new Date().toISOString(),
    action: 'mapping_' + action,
    id: 'mapping@' + Date.now() + '-' + Math.random().toString(36).slice(2, 8),
    idRegistro: null,
    persona: null,
    seccion: 'mapping',
    tareaOriginal: oldRow ? oldRow.TASK_WMS : '',
    propuesta: newRow ? newRow.TASK_WMS : '',
    tareaFinal: newRow ? newRow.TASK_SPEC : '',
    motivo: JSON.stringify({ old: oldRow, new: newRow }),
    nivelConfianza: null,
    sessionId: (SPEC.STATE.stats && SPEC.STATE.stats.sessionId) || null,
    appVersion: (SPEC.STATE.stats && SPEC.STATE.stats.appVersion) || SPEC.PARAMS.AppVersion,
    mappingHash: (SPEC.STATE.stats && SPEC.STATE.stats.mappingHash) || null,
    schemaVersion: (SPEC.STATE.stats && SPEC.STATE.stats.schemaVersion) || SPEC.PARAMS.SchemaVersion,
    prevHash
  };
  // P12-cierre — SHA-256 obligatorio. Si crypto.subtle no disponible, marcar entrada como INSECURE_CONTEXT (NO se afirma criptografía).
  SPEC.calcularEntryHash(entry, prevHash).then(h => {
    entry.entryHash = h;
    persistDecisions();
  }).catch(err => {
    console.error('calcularEntryHash falló (mapping) — entrada marcada como INSECURE_CONTEXT:', err);
    entry.integrity = 'INSECURE_CONTEXT';
    persistDecisions();
  });
  SPEC.STATE.auditLog.push(entry);
}

/* exportMappingXlsx — descarga mappingCurrent como XLSX. */
function exportMappingXlsx() {
  if (!UI.mappingCurrent || UI.mappingCurrent.length === 0) {
    toast('No hay mapping para exportar.', { level: 'warn' });
    return;
  }
  const cols = ['SAP_CODE', 'WMS_DC', 'CUSTOMER', 'DEPARTMENT', 'ACTIVITY', 'SUB_ACTIVITY', 'TASK_WMS', 'TASK_SPEC'];
  const data = UI.mappingCurrent.map(r => {
    const o = {};
    for (const c of cols) o[c] = r[c] || '';
    return o;
  });
  SPEC.exportToXlsx(data, 'mapping_export_' + timestamp() + '.xlsx', 'Mapping');
  toast('Mapping exportado a XLSX.', { level: 'success' });
}

/* importMappingXlsx — sobrescribe mappingCurrent con el contenido del XLSX
 * elegido. NO modifica el archivo original cargado en SPEC.STATE.archivos.mapping
 * (se mantiene como referencia). */
async function importMappingXlsx(file) {
  try {
    const wb = await SPEC.leerArchivoExcel(file);
    const rows = SPEC.leerMapping(wb);
    if (!rows || rows.length === 0) {
      toast('El archivo no contiene mappings válidos.', { level: 'error' });
      return;
    }
    UI.mappingCurrent = rows.map(r => ({ ...r }));
    if (SPEC.STATE.stats) SPEC.STATE.stats.mappingHash = SPEC.calcularMappingHash(rows);
    logMappingChange('import', null, { count: rows.length });
    populateMappingFilters();
    renderMappingTable();
    persistDecisions();
    toast(rows.length + ' mappings importados.', { level: 'success' });
  } catch (err) {
    toast('Error al importar: ' + (err.message || err), { level: 'error' });
  }
}

/* Hook: wrap init() para llamar a setupMappingTab() al arrancar.
 * Patrón idéntico al wrap de init() existente en la línea ~3316
 * (_origInit2). Si ui.js se carga como script top-level (modular), el wrap
 * puede que NO intercepte DOMContentLoaded (el listener captura la referencia
 * closure-private original). Por eso setupTabs() también llama a
 * setupMappingTab() la primera vez que el usuario clickea la pestaña Mapping
 * (vía flag UI.mappingSetupDone) — doble garantía. */
const _origInit3 = init;
init = function () {
  _origInit3();
  setupMappingTab();
  UI.mappingSetupDone = true;
};

/* Hook: wrap analizar() para refrescar mappingCurrent tras una corrida
 * (por si el usuario carga Mapping.xlsx de nuevo y procesa). */
const _origAnalizar2 = analizar;
analizar = async function () {
  await _origAnalizar2();
  initMappingData();
  if (UI.activeTab === 'mapping') renderMappingTable();
};

/* Expose to window para debugging desde la consola del navegador */
Object.assign(window, {
  setupMappingTab,
  initMappingData,
  populateMappingFilters,
  renderMappingTable,
  updateMappingStats,
  countDuplicates,
  countAmbiguities,
  highlightDuplicates,
  highlightAmbiguities,
  openMappingEditor,
  closeMappingEditor,
  saveMappingEdit,
  deleteMappingEntry,
  logMappingChange,
  exportMappingXlsx,
  importMappingXlsx
});

/* FASE 3 — Exponer funciones de trazabilidad/IndexedDB a window para depuración */
Object.assign(window, {
  idbOpen,
  idbBackupDecisions,
  idbRestoreDecisions,
  verificarIntegridadAuditLog,
  persistDecisions,
  restoreDecisions
});

/* ============================================================================
 * ============================================================================
 *  MEJORAS v6.1 — Turnos · Cargar y analizar · Mapping persistente ·
 *  Revisión unificada PERSONA+DÍA · Reparto de tiempos · Undo real ·
 *  Patrones históricos (PERSON_DAILY_RECORD en IndexedDB)
 * ============================================================================
 * ============================================================================
 * Este bloque se añade al final del script: las redeclaraciones de funciones
 * existentes (renderReviewPanel, registrarDecision, undoDecision, ...)
 * prevalecen por hoisting de declaraciones (la última declaración del mismo
 * script gana desde el inicio de la ejecución).
 * ========================================================================== */

/* ===== v6.1 — Estado UI adicional ===== */
// La pestaña activa inicial es 'cargaanalizar' (el base declaraba 'carga',
// el nombre de la pestaña eliminada en v6.1 — corrige el estado inicial).
UI.activeTab = 'cargaanalizar';
UI.patronesView = 'resumen';
UI.patronesSort = { col: 'dias', dir: -1 };
UI.evolGranularidad = 'dia';
UI.mappingMeta = null;        // { version, nombre, fechaImportacion, timestamp, hash, nRows }
UI.currentPersonDayId = null; // key del persona/día seleccionado
UI.patronesRecords = null;    // caché de registros históricos cargados de IndexedDB

/* ===== v6.1 — Preferencias: productividades y overrides por tarea ===== */

function cargarProductividades() {
  const def = Object.assign({}, SPEC.PARAMS.ProductividadesReferencia);
  try {
    const raw = localStorage.getItem('spec_productividades');
    if (raw) {
      const saved = JSON.parse(raw);
      for (const k of Object.keys(def)) {
        const v = Number(saved[k]);
        if (isFinite(v) && v > 0) def[k] = v;
      }
    }
  } catch (e) { /* valores por defecto */ }
  return def;
}

function guardarProductividades(map) {
  try {
    localStorage.setItem('spec_productividades', JSON.stringify(map));
    return true;
  } catch (e) {
    console.warn('No se pudieron guardar las productividades:', e);
    return false;
  }
}

function cargarTaskOverrides() {
  try {
    const raw = localStorage.getItem('spec_task_overrides');
    if (raw) {
      const o = JSON.parse(raw);
      if (o && typeof o === 'object') return o;
    }
  } catch (e) { /* sin overrides */ }
  return {};
}

function renderProductividadesEditor() {
  const grid = document.getElementById('prod-grid');
  if (!grid) return;
  const prods = cargarProductividades();
  const labels = {
    'AUDITORIA AGV': 'Auditoría AGV',
    'AUDITORIA MANUAL': 'Auditoría manual',
    'UBICACION MANUAL': 'Ubicación manual',
    'UBICACION AGV': 'Ubicación AGV',
    'PICKING MANUAL': 'Picking manual',
    'PICKING AGV': 'Picking AGV'
  };
  grid.innerHTML = '';
  for (const act of SPEC.ACTIVIDADES_ANALISIS) {
    if (act === 'OTRA') continue;
    const div = document.createElement('div');
    div.className = 'prod-item';
    div.innerHTML =
      '<label for="prod-' + escapeAttr(act.replace(/\s+/g, '_')) + '">' + escapeHtml(labels[act] || act) +
      ' <span class="prod-unit">(uds/h netas)</span></label>' +
      '<input type="number" min="1" step="1" id="prod-' + escapeAttr(act.replace(/\s+/g, '_')) + '" value="' + escapeAttr(String(prods[act])) + '" data-actividad="' + escapeAttr(act) + '">';
    grid.appendChild(div);
  }
}

function setupProductividadesEditor() {
  renderProductividadesEditor();
  const btnSave = document.getElementById('btn-guardar-productividades');
  const btnReset = document.getElementById('btn-reset-productividades');
  if (btnSave) btnSave.addEventListener('click', () => {
    const map = {};
    let valido = true;
    document.querySelectorAll('#prod-grid input[data-actividad]').forEach(inp => {
      const v = Number(inp.value);
      if (!isFinite(v) || v <= 0) { valido = false; inp.classList.add('invalid'); }
      else { inp.classList.remove('invalid'); map[inp.dataset.actividad] = v; }
    });
    if (!valido) {
      toast('Todas las productividades deben ser números > 0.', { level: 'error' });
      return;
    }
    guardarProductividades(map);
    if (recomputarPersonaDia()) {
      persistirPersonDailyRecords();
      renderReviewPanel();
      if (UI.activeTab === 'patrones') renderPatronesPanel();
      toast('Productividades guardadas. Reparto recalculado (los históricos previos conservan sus valores).', { level: 'success' });
    } else {
      toast('Productividades guardadas.', { level: 'success' });
    }
  });
  if (btnReset) btnReset.addEventListener('click', () => {
    guardarProductividades(SPEC.PARAMS.ProductividadesReferencia);
    renderProductividadesEditor();
    if (recomputarPersonaDia()) {
      persistirPersonDailyRecords();
      renderReviewPanel();
      if (UI.activeTab === 'patrones') renderPatronesPanel();
    }
    toast('Productividades restablecidas a los valores por defecto.', { level: 'info' });
  });
  setupTaskProdEditor();
}

/* ============================================================================
 * v6.1.1 — PRODUCTIVIDAD POR TAREA (overrides por TASK_WMS)
 *
 * Sección compacta dentro de ⚙ Productividades de referencia que permite:
 *   - buscar y seleccionar una TASK_WMS (de las conocidas por el mapping o
 *     el volumen cargado, o cualquier nombre escrito a mano);
 *   - asignarle ACTIVIDAD_ANALISIS (incluida la reasignación de una tarea
 *     OTRA a una actividad productiva) y productividad (> 0 obligatoria si
 *     la actividad es productiva);
 *   - guardar, editar y eliminar/resetear el override.
 *
 * Tabla: TASK_WMS | Actividad | Productividad | Fuente | Acción, donde
 * Fuente distingue DEFAULT / PRODUCTIVIDAD ACTIVIDAD / OVERRIDE TASK_WMS
 * (y OTRA para tareas fuera del reparto). El motor usa estos overrides con
 * prioridad exacta via resolverClasificacionTarea().
 * ========================================================================== */

/* Tareas conocidas: mapping (TASK_WMS) + volumen cargado (WMS_TASK) +
 * claves ya sobreescritas. Sin datos cargados devuelve solo las sobreescritas. */
function obtenerTareasConocidas() {
  const set = new Map(); // display → normalized
  const add = (name) => {
    const s = String(name || '').trim();
    if (!s) return;
    const n = SPEC.normalizarTareaWms(s);
    if (!n || set.has(n)) return;
    set.set(n, s);
  };
  for (const r of (UI.mappingCurrent || [])) add(r.TASK_WMS);
  const VM = (SPEC.STATE.queries && SPEC.STATE.queries['13_VolumenMapeadoSPEC']) || [];
  for (const r of VM) add(r['WMS_TASK']);
  const ov = cargarTaskOverrides();
  for (const k of Object.keys(ov)) {
    if (!set.has(k)) set.set(k, (ov[k] && ov[k].taskWmsDisplay) || k);
  }
  return Array.from(set.entries()).map(([norm, display]) => ({ norm, display }))
    .sort((a, b) => a.display.localeCompare(b.display));
}

/* Render de la tabla de PRODUCTIVIDAD POR TAREA + datalist de búsqueda. */
function renderTaskProdEditor() {
  const tbody = document.getElementById('task-prod-tbody');
  const datalist = document.getElementById('task-prod-datalist');
  const note = document.getElementById('task-prod-note');
  if (!tbody) return;
  const overrides = cargarTaskOverrides();
  const prods = cargarProductividades();
  const opciones = {
    productividades: prods,
    productividadesDefault: SPEC.PARAMS.ProductividadesReferencia,
    taskOverrides: overrides
  };
  const conocidas = obtenerTareasConocidas();
  if (datalist) {
    datalist.innerHTML = '';
    for (const t of conocidas) {
      const o = document.createElement('option');
      o.value = t.display;
      datalist.appendChild(o);
    }
  }
  // Filtro de búsqueda de la propia tabla
  const searchEl = document.getElementById('task-prod-search');
  const q = searchEl ? searchEl.value.trim().toLowerCase() : '';
  const filas = conocidas.filter(t => !q || t.display.toLowerCase().indexOf(q) >= 0);
  tbody.innerHTML = '';
  const MAX_ROWS = 250;
  const limited = filas.slice(0, MAX_ROWS);
  for (const t of limited) {
    const ovr = overrides[t.norm] || null;
    const cls = SPEC.resolverClasificacionTarea(t.display, opciones);
    const tr = document.createElement('tr');
    if (ovr) tr.className = 'task-override-row';
    const prodTxt = cls.productividad != null ? SPEC.formatNum0(cls.productividad) : '—';
    const fuenteTxt = cls.fuente || '';
    tr.innerHTML =
      '<td class="tp-task" title="' + escapeAttr(t.display) + '">' + escapeHtml(t.display) + '</td>' +
      '<td>' + escapeHtml(cls.actividad) + '</td>' +
      '<td class="num">' + escapeHtml(prodTxt) + '</td>' +
      '<td><span class="tp-fuente" data-fuente="' + escapeAttr(fuenteTxt) + '">' + escapeHtml(fuenteTxt) + '</span></td>' +
      '<td class="tp-actions">' +
      '<button type="button" class="btn btn-sm btn-secondary" data-tp-edit="' + escapeAttr(t.display) + '">✎ Editar</button>' +
      (ovr ? ' <button type="button" class="btn btn-sm btn-warn" data-tp-reset="' + escapeAttr(t.norm) + '">↺ Resetear</button>' : '') +
      '</td>';
    tbody.appendChild(tr);
  }
  if (filas.length > MAX_ROWS) {
    const tr = document.createElement('tr');
    tr.className = 'tp-more';
    tr.innerHTML = '<td colspan="5" class="list-note">Mostrando ' + MAX_ROWS + ' de ' + filas.length + ' tareas (afina la búsqueda).</td>';
    tbody.appendChild(tr);
  }
  if (filas.length === 0) {
    const tr = document.createElement('tr');
    tr.innerHTML = '<td colspan="5" class="list-note">' + (q ? 'Ninguna tarea conocida coincide con la búsqueda.' : 'Sin datos cargados todavía.') + '</td>';
    tbody.appendChild(tr);
  }
  if (note) {
    const n = Object.keys(overrides).length;
    note.textContent = n === 0
      ? 'Sin overrides activos. ' + conocidas.length + ' tareas conocidas (mapping + volumen cargado). Escribe cualquier nombre de TASK_WMS para crear un override manual.'
      : n + (n === 1 ? ' override activo. ' : ' overrides activos. ') + conocidas.length + ' tareas conocidas. Los overrides tienen prioridad sobre la productividad de la actividad.';
  }
}

/* Guarda un override por tarea y recalcula todo el reparto afectado. */
function guardarTaskOverride(taskWms, actividad, productividad) {
  const norm = SPEC.normalizarTareaWms(taskWms);
  if (!norm) return false;
  const overrides = cargarTaskOverrides();
  if (actividad === 'OTRA') {
    overrides[norm] = { actividad: 'OTRA', productividad: null, taskWmsDisplay: String(taskWms).trim(), updatedAt: new Date().toISOString() };
  } else {
    const p = Number(productividad);
    if (!isFinite(p) || p <= 0) return false; // actividad productiva → prod > 0
    overrides[norm] = { actividad, productividad: p, taskWmsDisplay: String(taskWms).trim(), updatedAt: new Date().toISOString() };
  }
  try {
    localStorage.setItem('spec_task_overrides', JSON.stringify(overrides));
  } catch (e) {
    console.warn('No se pudieron guardar los overrides:', e);
    return false;
  }
  return true;
}

/* Elimina el override de una tarea normalizada. */
function resetTaskOverride(norm) {
  const overrides = cargarTaskOverrides();
  if (!Object.prototype.hasOwnProperty.call(overrides, norm)) return false;
  delete overrides[norm];
  try {
    localStorage.setItem('spec_task_overrides', JSON.stringify(overrides));
  } catch (e) {
    console.warn('No se pudo eliminar el override:', e);
    return false;
  }
  return true;
}

/* Recalcula reparto + persistencia + vistas tras un cambio de overrides. */
function aplicarOverridesYRecalcular(mensaje) {
  renderTaskProdEditor();
  if (recomputarPersonaDia()) {
    encolarPersistenciaRecords();
    renderReviewPanel();
    renderTaskProdEditor(); // refrescar fuentes tras el recompute
    if (UI.currentPersonDayId) renderPersonDayDetail(UI.currentPersonDayId);
    if (UI.activeTab === 'patrones') renderPatronesPanel();
  }
  if (mensaje) toast(mensaje, { level: 'success' });
}

function setupTaskProdEditor() {
  const btnSave = document.getElementById('btn-task-prod-save');
  const search = document.getElementById('task-prod-search');
  const selAct = document.getElementById('task-prod-actividad');
  const valEl = document.getElementById('task-prod-value');
  if (!btnSave || !search || !selAct || !valEl) return;

  // Validación en vivo: OTRA deshabilita la productividad
  const syncProdDisabled = () => {
    const esOtra = selAct.value === 'OTRA';
    valEl.disabled = esOtra;
    valEl.required = !esOtra;
    if (esOtra) valEl.value = '';
  };
  selAct.addEventListener('change', syncProdDisabled);
  syncProdDisabled();

  // El buscador filtra la tabla en vivo (y alimenta el datalist)
  search.addEventListener('input', () => renderTaskProdEditor());

  const guardarForm = () => {
    const tarea = search.value.trim();
    if (!tarea) {
      toast('Escribe o selecciona una TASK_WMS primero.', { level: 'error' });
      search.focus();
      return;
    }
    const actividad = selAct.value;
    if (!SPEC.ACTIVIDADES_ANALISIS.includes(actividad)) {
      toast('Selecciona una actividad válida.', { level: 'error' });
      return;
    }
    if (actividad !== 'OTRA') {
      const p = Number(valEl.value);
      if (!isFinite(p) || p <= 0) {
        toast('Una actividad productiva exige productividad > 0 (uds/h).', { level: 'error' });
        valEl.focus();
        return;
      }
    }
    if (!guardarTaskOverride(tarea, actividad, actividad === 'OTRA' ? null : Number(valEl.value))) {
      toast('No se pudo guardar el override (revisa los valores).', { level: 'error' });
      return;
    }
    aplicarOverridesYRecalcular('Override guardado para «' + tarea + '» → ' + actividad + (actividad === 'OTRA' ? '' : ' · ' + Number(valEl.value) + ' uds/h') + '. Reparto recalculado.');
  };
  btnSave.addEventListener('click', guardarForm);
  search.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); guardarForm(); } });

  // Delegación de eventos de la tabla (Editar / Resetear)
  const wrap = document.getElementById('task-prod-table-wrap');
  if (wrap) {
    wrap.addEventListener('click', e => {
      const btn = e.target.closest('button[data-tp-edit], button[data-tp-reset]');
      if (!btn) return;
      if (btn.dataset.tpReset) {
        const norm = btn.dataset.tpReset;
        const overrides = cargarTaskOverrides();
        const display = (overrides[norm] && overrides[norm].taskWmsDisplay) || norm;
        if (resetTaskOverride(norm)) {
          aplicarOverridesYRecalcular('Override eliminado para «' + display + '»: vuelve a su clasificación y productividad por defecto.');
        }
        return;
      }
      if (btn.dataset.tpEdit) {
        const tarea = btn.dataset.tpEdit;
        search.value = tarea;
        const cls = SPEC.resolverClasificacionTarea(tarea, {
          productividades: cargarProductividades(),
          productividadesDefault: SPEC.PARAMS.ProductividadesReferencia,
          taskOverrides: cargarTaskOverrides()
        });
        selAct.value = SPEC.ACTIVIDADES_ANALISIS.includes(cls.actividad) ? cls.actividad : 'OTRA';
        valEl.value = cls.productividad != null ? String(cls.productividad) : '';
        syncProdDisabled();
        renderTaskProdEditor();
        search.focus();
        search.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    });
  }
  renderTaskProdEditor();
}

/* ===== v6.1 — MEJORA 3/6: IndexedDB de históricos (spec_history_db) ===== */

function idbHistoryOpen() {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB no soportado en este entorno'));
      return;
    }
    const req = indexedDB.open('spec_history_db', 1);
    req.onupgradeneeded = function (e) {
      const db = e.target.result;
      if (!db.objectStoreNames.contains('mappings')) {
        db.createObjectStore('mappings', { keyPath: 'version' });
      }
      if (!db.objectStoreNames.contains('person_daily_records')) {
        const os = db.createObjectStore('person_daily_records', { keyPath: 'key' });
        os.createIndex('login', 'login', { unique: false });
        os.createIndex('fechaOperativaISO', 'fechaOperativaISO', { unique: false });
        os.createIndex('semana', 'semana', { unique: false });
        os.createIndex('mes', 'mes', { unique: false });
      }
    };
    req.onsuccess = function (e) { resolve(e.target.result); };
    req.onerror = function (e) { reject(e.target.error); };
  });
}

/* Guarda una nueva versión del mapping. Devuelve el meta guardado. */
async function guardarMappingVersion(nombre, rows) {
  const hash = await SPEC.calcularMappingHashSHA256(rows);
  const db = await idbHistoryOpen();
  const ultimo = await cargarUltimoMapping();
  const version = ultimo ? (ultimo.version + 1) : 1;
  const meta = {
    version,
    nombre: nombre || 'Mapping.xlsx',
    fechaImportacion: new Date().toISOString(),
    timestamp: Date.now(),
    hash,
    hashAlgoritmo: 'SHA-256',
    nRows: rows.length,
    rows
  };
  await new Promise((resolve, reject) => {
    const tx = db.transaction('mappings', 'readwrite');
    tx.objectStore('mappings').put(meta);
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
  return meta;
}

/* Carga el mapping más reciente (o null). No incluye rows salvo conRows=true. */
async function cargarUltimoMapping(conRows) {
  try {
    const db = await idbHistoryOpen();
    return await new Promise((resolve, reject) => {
      const tx = db.transaction('mappings', 'readonly');
      const req = tx.objectStore('mappings').getAll();
      req.onsuccess = function (e) {
        const all = e.target.result || [];
        if (all.length === 0) { resolve(null); return; }
        all.sort((a, b) => b.version - a.version);
        const top = all[0];
        if (!conRows) { resolve({ version: top.version, nombre: top.nombre, fechaImportacion: top.fechaImportacion, timestamp: top.timestamp, hash: top.hash, hashAlgoritmo: top.hashAlgoritmo, nRows: top.nRows }); }
        else resolve(top);
      };
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    console.warn('cargarUltimoMapping falló:', e);
    return null;
  }
}

/* Reconstruye un workbook + File a partir de las rows persistidas, para que
 * el motor (y el Worker, que relee el File como ArrayBuffer) funcionen igual
 * que con un mapping cargado manualmente. */
function reconstruirMappingEntry(meta) {
  const rows = meta.rows || [];
  const cols = ['SAP_CODE', 'WMS_DC', 'CUSTOMER', 'DEPARTMENT', 'ACTIVITY', 'SUB_ACTIVITY', 'TASK_WMS', 'TASK_SPEC'];
  const data = rows.map(r => {
    const o = {};
    for (const c of cols) o[c] = r[c] != null ? r[c] : '';
    return o;
  });
  const ws = XLSX.utils.json_to_sheet(data, { header: cols });
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Mapping');
  const buf = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const file = new File([buf], meta.nombre || 'Mapping.xlsx', { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  return { name: file.name, workbook: wb, file: file };
}

/* Aplica un mapping (entry {name, workbook, file}) al estado de la app. */
function aplicarMappingEntry(entry, meta) {
  SPEC.STATE.archivos.mapping = [entry];
  UI.mappingMeta = meta || null;
  if (SPEC.STATE.stats) SPEC.STATE.stats.mappingHash = SPEC.calcularMappingHash(SPEC.leerMapping(entry.workbook));
  updateDropZoneFiles('mapping');
  checkAllLoaded();
  renderMappingActivoCard();
}

/* MEJORA 3 — carga del mapping persistente al arrancar (silenciosa). */
async function cargarMappingPersistente() {
  const meta = await cargarUltimoMapping(true);
  if (!meta || !meta.rows || meta.rows.length === 0) {
    renderMappingActivoCard();
    return false;
  }
  // Evitar duplicar si ya hay un mapping cargado con el mismo hash
  const arr = Array.isArray(SPEC.STATE.archivos.mapping) ? SPEC.STATE.archivos.mapping : [];
  if (arr.length > 0) {
    try {
      const actual = SPEC.calcularMappingHashSHA256(SPEC.leerMapping(arr[0].workbook));
      if (actual === meta.hash) {
        UI.mappingMeta = meta;
        renderMappingActivoCard();
        return true;
      }
    } catch (e) { /* continúa */ }
  }
  const entry = reconstruirMappingEntry(meta);
  aplicarMappingEntry(entry, meta);
  setStatus('Mapping guardado cargado automáticamente (' + meta.nombre + ')', 'info');
  return true;
}

/* MEJORA 3 — tarjeta "Mapping activo". */
function renderMappingActivoCard() {
  const info = document.getElementById('mapping-activo-info');
  if (!info) return;
  const meta = UI.mappingMeta;
  const arr = Array.isArray(SPEC.STATE.archivos.mapping) ? SPEC.STATE.archivos.mapping : [];
  if (meta) {
    const fecha = meta.fechaImportacion ? new Date(meta.fechaImportacion).toLocaleString('es-ES') : '—';
    info.innerHTML =
      '<div class="mac-line"><strong>Mapping activo</strong></div>' +
      '<div class="mac-line">' + escapeHtml(meta.nombre || 'Mapping.xlsx') + '</div>' +
      '<div class="mac-line">v' + escapeAttr(String(meta.version)) + ' · ' + meta.nRows + ' filas</div>' +
      '<div class="mac-line">Hash: <code title="' + escapeAttr(meta.hash) + '">' + escapeHtml(String(meta.hash).slice(0, 12)) + '…</code></div>' +
      '<div class="mac-line">Última actualización: ' + escapeHtml(fecha) + '</div>' +
      (arr.length === 0 ? '<div class="mac-warn">El mapping está guardado pero no cargado: pulsa IMPORTAR para usarlo.</div>' : '');
    info.classList.add('has-mapping');
  } else if (arr.length > 0) {
    info.innerHTML = '<div class="mac-line"><strong>Mapping cargado</strong> (' + arr.length + ' archivo(s)) — aún no guardado como persistente. Se guardará al usarlo.</div>';
    info.classList.remove('has-mapping');
  } else {
    info.innerHTML = '<span class="mac-empty">No existe mapping guardado. Importa Mapping.xlsx para comenzar; quedará guardado para las próximas sesiones.</span>';
    info.classList.remove('has-mapping');
  }
}

/* MEJORA 3 — flujo de cambio de mapping con confirmación old vs new. */
async function procesarMappingCargado(file, wb) {
  let rows;
  try {
    rows = SPEC.leerMapping(wb);
  } catch (err) {
    toast('El archivo no es un mapping válido: ' + err.message, { level: 'error' });
    return;
  }
  const nuevoHash = await SPEC.calcularMappingHashSHA256(rows);
  const actual = UI.mappingMeta;
  const mismoQueActual = actual && actual.hash === nuevoHash;
  const cargar = (meta) => {
    aplicarMappingEntry({ name: file.name, workbook: wb, file: file }, meta);
    initMappingData();
    if (UI.activeTab === 'mapping') renderMappingTable();
  };
  if (!actual) {
    // Primera vez: guardar y usar
    const meta = await guardarMappingVersion(file.name, rows);
    delete meta.rows; // el entry en memoria ya tiene el workbook
    UI.mappingMeta = meta;
    cargar(meta);
    toast('Mapping guardado (v' + meta.version + ', ' + meta.nRows + ' filas). Se reutilizará automáticamente en próximas sesiones.', { level: 'success' });
    return;
  }
  if (mismoQueActual) {
    cargar(actual);
    toast('Es el mismo mapping (hash idéntico). Sin cambios.', { level: 'info' });
    return;
  }
  // Hay un mapping distinto → confirmación obligatoria antes de sustituir
  dialogoCambiarMapping(actual, {
    nombre: file.name,
    fechaImportacion: new Date().toISOString(),
    hash: nuevoHash,
    nRows: rows.length
  }, async () => {
    const meta = await guardarMappingVersion(file.name, rows);
    delete meta.rows;
    UI.mappingMeta = meta;
    cargar(meta);
    toast('Mapping sustituido por la versión ' + meta.version + ' (' + meta.nRows + ' filas).', { level: 'success' });
  });
}

/* Modal de confirmación de cambio de mapping (antes de sustituir). */
function dialogoCambiarMapping(actual, nuevo, onConfirm) {
  const fmt = (iso) => iso ? new Date(iso).toLocaleString('es-ES') : '—';
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML =
    '<div class="modal-box mapping-change-modal" role="dialog" aria-modal="true" aria-labelledby="mcm-title">' +
    '  <h3 id="mcm-title">🗺 Cambiar mapping</h3>' +
    '  <p>Vas a sustituir el mapping actual. Los históricos ya guardados NO cambian (conservan su hash).</p>' +
    '  <div class="mcm-grid">' +
    '    <div class="mcm-col"><h4>Mapping actual</h4>' +
    '      <div><strong>' + escapeHtml(actual.nombre || '—') + '</strong></div>' +
    '      <div>Fecha: ' + escapeHtml(fmt(actual.fechaImportacion)) + '</div>' +
    '      <div>Hash: <code>' + escapeHtml(String(actual.hash || '—').slice(0, 16)) + '…</code></div>' +
    '      <div>Filas: ' + escapeHtml(String(actual.nRows != null ? actual.nRows : '—')) + '</div></div>' +
    '    <div class="mcm-col new"><h4>Nuevo mapping</h4>' +
    '      <div><strong>' + escapeHtml(nuevo.nombre || '—') + '</strong></div>' +
    '      <div>Fecha: ' + escapeHtml(fmt(nuevo.fechaImportacion)) + '</div>' +
    '      <div>Hash: <code>' + escapeHtml(String(nuevo.hash || '—').slice(0, 16)) + '…</code></div>' +
    '      <div>Filas: ' + escapeHtml(String(nuevo.nRows != null ? nuevo.nRows : '—')) + '</div></div>' +
    '  </div>' +
    '  <div class="modal-actions">' +
    '    <button class="btn btn-primary" id="mcm-confirm">Usar este nuevo mapping</button>' +
    '    <button class="btn btn-secondary" id="mcm-cancel">Cancelar</button>' +
    '  </div>' +
    '</div>';
  document.body.appendChild(overlay);
  const cerrar = () => { overlay.remove(); };
  overlay.querySelector('#mcm-cancel').addEventListener('click', cerrar);
  overlay.querySelector('#mcm-confirm').addEventListener('click', () => { cerrar(); onConfirm(); });
  overlay.addEventListener('click', e => { if (e.target === overlay) cerrar(); });
  const btn = overlay.querySelector('#mcm-confirm');
  if (btn) btn.focus();
}

/* ===== v6.1 — MEJORA 2: zona de carga unificada con detección automática ===== */

/* Detecta el tipo de un workbook probando cada transformador del motor.
 * Los conjuntos de columnas requeridos son mutuamente excluyentes. */
function detectarTipoArchivo(wb) {
  try { SPEC.fx_TransformaHoras(wb, '_detect_'); return 'horas'; } catch (e) { /* sigue */ }
  try { SPEC.fx_TransformaVolumen(wb, '_detect_'); return 'volumen'; } catch (e) { /* sigue */ }
  try { SPEC.fx_TransformaVolumenSinHoras(wb, '_detect_'); return 'volSinHoras'; } catch (e) { /* sigue */ }
  try { SPEC.leerMapping(wb); return 'mapping'; } catch (e) { /* sigue */ }
  return null;
}

/* Carga un conjunto heterogéneo de archivos detectando el tipo de cada uno. */
async function cargarArchivosUnificados(files) {
  const fileArr = Array.from(files || []);
  if (fileArr.length === 0) return;
  const status = document.getElementById('unified-status');
  const dz = document.getElementById('drop-unified');
  if (status) { status.textContent = 'Detectando tipos...'; status.className = 'dz-status info'; }
  const errores = [];
  const porTipo = { horas: [], volumen: [], volSinHoras: [], mapping: [] };
  for (const file of fileArr) {
    try {
      const wb = await SPEC.leerArchivoExcel(file);
      const tipo = detectarTipoArchivo(wb);
      if (!tipo) {
        errores.push(file.name + ': estructura no reconocida (ni Horas, Volumen, Volumen sin horas ni Mapping)');
        continue;
      }
      porTipo[tipo].push(file);
    } catch (err) {
      errores.push(file.name + ': ' + (err.message || String(err)));
    }
  }
  // Mapping: flujo especial (persistencia + confirmación de cambio)
  if (porTipo.mapping.length > 0) {
    for (const f of porTipo.mapping) {
      try {
        const wb = await SPEC.leerArchivoExcel(f);
        await procesarMappingCargado(f, wb);
      } catch (err) {
        errores.push(f.name + ': ' + (err.message || String(err)));
      }
    }
  }
  // El resto de tipos en lote
  for (const tipo of ['horas', 'volumen', 'volSinHoras']) {
    if (porTipo[tipo].length > 0) {
      await loadFiles(tipo, porTipo[tipo]);
    }
  }
  // Estado de la zona unificada
  if (status) {
    const counts = {
      horas: (Array.isArray(SPEC.STATE.archivos.horas) ? SPEC.STATE.archivos.horas : []).length,
      volumen: (Array.isArray(SPEC.STATE.archivos.volumen) ? SPEC.STATE.archivos.volumen : []).length,
      volSinHoras: (Array.isArray(SPEC.STATE.archivos.volSinHoras) ? SPEC.STATE.archivos.volSinHoras : []).length,
      mapping: (Array.isArray(SPEC.STATE.archivos.mapping) ? SPEC.STATE.archivos.mapping : []).length
    };
    const total = counts.horas + counts.volumen + counts.volSinHoras + counts.mapping;
    if (errores.length === fileArr.length) {
      status.textContent = 'Error: ningún archivo pudo cargarse';
      status.className = 'dz-status error';
      if (dz) dz.classList.add('error');
    } else {
      status.textContent = total + ' archivo(s) cargado(s) ✓' + (errores.length > 0 ? ' · ' + errores.length + ' error(es)' : '');
      status.className = 'dz-status ok';
      if (dz) { dz.classList.remove('error'); dz.classList.add('loaded'); }
    }
  }
  if (errores.length > 0) {
    const msgs = document.getElementById('carga-mensajes');
    if (msgs) {
      for (const e of errores) addMessage(msgs, e, 'error');
    }
    setStatus('Carga parcial: ' + errores.length + ' archivo(s) con error', 'error');
  }
  actualizarUnifiedChecklist();
  checkAllLoaded();
}

/* Actualiza el checklist resumen (✓ Horas (2 archivos) ...)
 * Re-entrancy guard: la actualización escribe en el MISMO panel que observa
 * el MutationObserver de setupUnifiedZone — sin el guard sería un bucle
 * infinito de mutaciones (detectado en smoke test v6.1). */
function actualizarUnifiedChecklist() {
  if (UI._ucUpdating) return;
  UI._ucUpdating = true;
  try {
    const tipos = ['horas', 'volumen', 'volSinHoras', 'mapping'];
    const ids = { horas: 'uc-horas', volumen: 'uc-volumen', volSinHoras: 'uc-volSinHoras', mapping: 'uc-mapping' };
    for (const t of tipos) {
      const el = document.getElementById(ids[t]);
      if (!el) continue;
      const arr = Array.isArray(SPEC.STATE.archivos[t]) ? SPEC.STATE.archivos[t] : [];
      const count = el.querySelector('.uc-count');
      if (count) {
        const txt = arr.length > 0 ? '✓ ' + arr.length + (arr.length === 1 ? ' archivo' : ' archivos') : '—';
        if (count.textContent !== txt) count.textContent = txt; // solo escribir si cambia
      }
      el.classList.toggle('ok', arr.length > 0);
      el.classList.toggle('pending', arr.length === 0);
    }
  } finally {
    UI._ucUpdating = false;
  }
}

/* Observa cambios en las zonas de carga para refrescar el checklist
 * (captura también la carga por tipo del bloque avanzado y las eliminaciones). */
function setupUnifiedZone() {
  const dz = document.getElementById('drop-unified');
  if (dz) {
    const input = dz.querySelector('input[type=file]');
    dz.addEventListener('click', () => input.click());
    dz.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); input.click(); }
    });
    dz.addEventListener('dragover', e => { e.preventDefault(); dz.classList.add('dragover'); });
    dz.addEventListener('dragleave', () => dz.classList.remove('dragover'));
    dz.addEventListener('drop', async e => {
      e.preventDefault();
      dz.classList.remove('dragover');
      if (e.dataTransfer.files.length > 0) await cargarArchivosUnificados(e.dataTransfer.files);
    });
    input.addEventListener('change', async () => {
      if (input.files.length > 0) {
        await cargarArchivosUnificados(input.files);
        input.value = '';
      }
    });
  }
  // Botón IMPORTAR / ACTUALIZAR MAPPING
  const btnUpd = document.getElementById('btn-mapping-update');
  const inpUpd = document.getElementById('mapping-update-input');
  if (btnUpd && inpUpd) {
    btnUpd.addEventListener('click', () => inpUpd.click());
    inpUpd.addEventListener('change', async e => {
      const file = e.target.files && e.target.files[0];
      if (file) {
        try {
          const wb = await SPEC.leerArchivoExcel(file);
          await procesarMappingCargado(file, wb);
        } catch (err) {
          toast('Error al leer el mapping: ' + (err.message || err), { level: 'error' });
        }
      }
      inpUpd.value = '';
    });
  }
  // MutationObserver para el checklist
  const panel = document.getElementById('panel-cargaanalizar');
  if (panel && typeof MutationObserver !== 'undefined') {
    const mo = new MutationObserver(() => actualizarUnifiedChecklist());
    mo.observe(panel, { childList: true, subtree: true, characterData: true });
  }
  actualizarUnifiedChecklist();
}

/* ===== v6.1 — Post-análisis: recompute con preferencias + persistencia ===== */

/* Recalcula 17_PersonaDiaAnalitica + records con las productividades y
 * overrides del usuario (el Worker calcula con los valores por defecto). */
function recomputarPersonaDia() {
  const q = SPEC.STATE.queries || {};
  const H = q['01_HorasSinVolumen'] || [];
  if (H.length === 0) return false;
  const VM = q['13_VolumenMapeadoSPEC'] || [];
  const VSH = q['09_VolumenSinHorasDetalle'] || [];
  const opciones = {
    productividades: cargarProductividades(),
    productividadesDefault: SPEC.PARAMS.ProductividadesReferencia,
    taskOverrides: cargarTaskOverrides()
  };
  const PD = SPEC.q17_PersonaDiaAnalitica(H, VM, VSH, opciones);
  SPEC.STATE.queries['17_PersonaDiaAnalitica'] = PD;
  // El hash de trazabilidad de los records es el SHA-256 del mapping
  // VERSIONADO (identidad de MEJORA 3); el FNV de stats.mappingHash queda
  // para la cadena de auditoría (compatibilidad).
  SPEC.STATE.personaDiaRecords = SPEC.generarPersonDailyRecords(PD, SPEC.STATE.reporte || [], {
    mappingHash: (UI.mappingMeta && UI.mappingMeta.hash) || (SPEC.STATE.stats && SPEC.STATE.stats.mappingHash) || null,
    mappingVersion: UI.mappingMeta ? UI.mappingMeta.version : null,
    productividades: opciones.productividades,
    taskOverrides: opciones.taskOverrides,
    appVersion: SPEC.PARAMS.AppVersion,
    sessionId: (SPEC.STATE.stats && SPEC.STATE.stats.sessionId) || null,
    timestamp: new Date().toISOString()
  });
  sincronizarDecisionesEnRecords();
  return true;
}

/* Sincroniza las decisiones actuales (STATE.decisions) en los records en memoria. */
function sincronizarDecisionesEnRecords() {
  const recs = SPEC.STATE.personaDiaRecords || [];
  for (const rec of recs) {
    if (!rec.incidencias) continue;
    let conDecision = 0;
    for (const inc of rec.incidencias) {
      const d = SPEC.STATE.decisions[inc.id];
      inc.decision = d ? d.decision : null;
      if (d) conDecision++;
    }
    rec.decision = rec.incidencias.length === 0 ? 'SIN INCIDENCIAS'
      : (conDecision === 0 ? 'PENDIENTE' : (conDecision === rec.incidencias.length ? 'COMPLETADA' : 'EN REVISIÓN'));
  }
}

/* MEJORA 6 — Persistencia de registros diarios en IndexedDB SIN duplicados:
 * misma clave (login|fechaOperativaISO) + mismo fingerprint → update de
 * decisión; fingerprint distinto → nueva versión conservando trazabilidad. */
async function persistirPersonDailyRecords() {
  const recs = SPEC.STATE.personaDiaRecords || [];
  if (recs.length === 0) return false;
  try {
    const db = await idbHistoryOpen();
    for (const rec of recs) {
      const existente = await new Promise((resolve, reject) => {
        const tx = db.transaction('person_daily_records', 'readonly');
        const req = tx.objectStore('person_daily_records').get(rec.key);
        req.onsuccess = () => resolve(req.result || null);
        req.onerror = () => reject(req.error);
      });
      let toPut;
      if (!existente) {
        toPut = rec; // versión 1 (ya viene así del motor)
      } else if (existente.dataFingerprint === rec.dataFingerprint) {
        // Mismos datos → solo refrescar decisiones y sesión
        toPut = Object.assign({}, rec, {
          version: existente.version || 1,
          createdAt: existente.createdAt,
          previousVersions: existente.previousVersions || []
        });
      } else {
        // Datos distintos → nueva versión con trazabilidad del núcleo anterior
        const prevCompact = {
          version: existente.version || 1,
          updatedAt: existente.updatedAt,
          mappingHash: existente.mappingHash,
          productividades: existente.productividades,
          horasAnalizables: existente.horasAnalizables,
          udsTotales: existente.udsTotales,
          desviacion: existente.desviacion,
          actividades: existente.actividades,
          incidencias: existente.incidencias
        };
        const prevs = (existente.previousVersions || []).slice();
        prevs.push(prevCompact);
        while (prevs.length > 10) prevs.shift(); // cap de trazabilidad
        toPut = Object.assign({}, rec, {
          version: (existente.version || 1) + 1,
          createdAt: existente.createdAt,
          previousVersions: prevs
        });
      }
      await new Promise((resolve, reject) => {
        const tx = db.transaction('person_daily_records', 'readwrite');
        tx.objectStore('person_daily_records').put(toPut);
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => reject(tx.error);
      });
    }
    UI.patronesRecords = null; // invalidar caché
    return true;
  } catch (e) {
    console.warn('persistirPersonDailyRecords falló (no crítico):', e);
    return false;
  }
}

/* Encola una persistencia de registros DIARIOS de forma SERIALIZADA.
 * Sin esto, dos análisis consecutivos pueden intercalar sus bucles de
 * upsert (el primero con el hash del mapping viejo) y el último write por
 * clave no sería el del análisis más reciente (detectado en E2E 3). */
function encolarPersistenciaRecords() {
  UI._persistChain = (UI._persistChain || Promise.resolve())
    .then(() => persistirPersonDailyRecords())
    .catch(e => { console.warn('persistirPersonDailyRecords (encolado) falló:', e); });
  return UI._persistChain;
}

/* Carga todos los registros históricos (con caché). Fusiona los de la sesión
 * en memoria por si la persistencia aún no terminó. */
async function cargarTodosRecords() {
  let list = [];
  try {
    const db = await idbHistoryOpen();
    list = await new Promise((resolve, reject) => {
      const tx = db.transaction('person_daily_records', 'readonly');
      const req = tx.objectStore('person_daily_records').getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    console.warn('cargarTodosRecords: IndexedDB no disponible:', e);
  }
  // Fusionar records en memoria (misma clave → prioridad a IDB si ya está)
  const byKey = new Map();
  for (const r of list) byKey.set(r.key, r);
  for (const r of (SPEC.STATE.personaDiaRecords || [])) {
    if (!byKey.has(r.key)) byKey.set(r.key, r);
  }
  const merged = Array.from(byKey.values());
  // Revivir fechas (structured clone las conserva, pero por si vienen de JSON)
  for (const r of merged) {
    if (!(r.fechaOperativa instanceof Date)) {
      const d = new Date(r.fechaOperativaISO + 'T00:00:00Z');
      if (!isNaN(d)) r.fechaOperativa = d;
    }
  }
  return merged;
}

/* ============================================================================
 * v6.1 — MEJORA 4: REVISAR INCIDENCIAS POR PERSONA + FECHA OPERATIVA
 * Reemplaza la vista por-incidencia por la vista por persona/día.
 * ========================================================================== */

/* Estado agregado de decisión de un record (persona/día). */
function estadoDecisionRecord(rec) {
  if (!rec.incidencias || rec.incidencias.length === 0) return 'SIN INCIDENCIAS';
  let conDecision = 0;
  for (const inc of rec.incidencias) if (inc.decision) conDecision++;
  if (conDecision === 0) return 'PENDIENTE';
  if (conDecision === rec.incidencias.length) return 'COMPLETADA';
  return 'EN REVISIÓN';
}

/* Los records actuales (persona/día) — desde memoria o fallback a la query 17. */
function getPersonaDiaRecords() {
  if (SPEC.STATE.personaDiaRecords && SPEC.STATE.personaDiaRecords.length > 0) {
    return SPEC.STATE.personaDiaRecords;
  }
  return [];
}

/* Lista filtrada de persona/día (filtros combinables). */
function getFilteredPersonDays() {
  let list = getPersonaDiaRecords().slice();
  const f = UI.reviewFilter || {};
  if (f.search) {
    const q = f.search.toLowerCase();
    list = list.filter(r =>
      (r.persona && r.persona.toLowerCase().indexOf(q) >= 0) ||
      (r.login && r.login.toLowerCase().indexOf(q) >= 0)
    );
  }
  if (f.dateFrom) {
    const from = f.dateFrom instanceof Date ? f.dateFrom : new Date(f.dateFrom);
    list = list.filter(r => {
      const d = r.fechaOperativa instanceof Date ? r.fechaOperativa : new Date(r.fechaOperativaISO + 'T00:00:00Z');
      return d >= from;
    });
  }
  if (f.dateTo) {
    const to = f.dateTo instanceof Date ? f.dateTo : new Date(f.dateTo);
    list = list.filter(r => {
      const d = r.fechaOperativa instanceof Date ? r.fechaOperativa : new Date(r.fechaOperativaISO + 'T00:00:00Z');
      return d <= to;
    });
  }
  if (f.turno) {
    // v6.1.1 — FILTRO REAL vía función centralizada (misma que Patrones e
    // históricos): un persona/día pertenece a un turno si su turno agregado
    // coincide o si ALGUNO de sus fichajes es de ese turno. Los registros
    // SIN HORA nunca aparecen al filtrar un turno concreto.
    list = SPEC.filtrarRegistrosPorTurno(list, f.turno);
  }
  if (f.seccion) {
    list = list.filter(r => (r.incidencias || []).some(i => String(i.seccion || '').charAt(0) === f.seccion));
  }
  if (f.decision) {
    list = list.filter(r => estadoDecisionRecord(r) === f.decision);
  }
  if (f.confianza) {
    // Mantenemos compatibilidad: el filtro confianza aplica si ALGUNA de sus
    // incidencias (reporte) tiene ese nivel.
    list = list.filter(r => (r.incidencias || []).some(i => {
      const rep = (SPEC.STATE.reporte || []).find(x => incidentId(x) === i.id);
      return rep && getConfianza(rep) === f.confianza;
    }));
  }
  // Orden
  switch (f.sort) {
    case 'horas_desc': list.sort((a, b) => b.horasAnalizables - a.horasAnalizables); break;
    case 'horas_asc': list.sort((a, b) => a.horasAnalizables - b.horasAnalizables); break;
    case 'fecha': list.sort((a, b) => String(a.fechaOperativaISO).localeCompare(String(b.fechaOperativaISO))); break;
    case 'persona': list.sort((a, b) => (a.persona || '').localeCompare(b.persona || '')); break;
    case 'seccion': list.sort((a, b) => (b.incidencias || []).length - (a.incidencias || []).length); break;
    case 'prioridad':
    default:
      list.sort((a, b) => (Math.abs(b.desviacion) + b.horasConIncidencia * 10 + (b.incidencias || []).length) -
                          (Math.abs(a.desviacion) + a.horasConIncidencia * 10 + (a.incidencias || []).length));
  }
  return list;
}

/* ===== Render del panel de revisión (KPIs + lista persona/día) ===== */
function renderReviewPanel() {
  const recs = getPersonaDiaRecords();
  const summary = document.getElementById('review-summary');
  if (recs.length === 0) {
    if (summary) summary.innerHTML = '<p style="color: var(--c-text-muted); font-size: 13px;">Procesa los archivos para ver la revisión por persona/día.</p>';
    const list = document.getElementById('review-list');
    if (list) list.innerHTML = '';
    const det = document.getElementById('incident-detail');
    if (det) det.innerHTML = '<div class="empty-state"><div class="empty-state-icon">👤</div><h3>Sin datos</h3><p>Procesa los archivos para ver la revisión por persona/día.</p></div>';
    const counters = document.getElementById('review-counters');
    if (counters) counters.innerHTML = '';
    return;
  }
  // KPIs agregados
  let horasAnalizables = 0, udsTotales = 0, hEquiv = 0, hAsig = 0, desvTotal = 0;
  let incidencias = 0, pendientes = 0, completadas = 0, enRevision = 0;
  const personas = new Set();
  for (const r of recs) {
    horasAnalizables += r.horasAnalizables || 0;
    udsTotales += r.udsTotales || 0;
    hEquiv += r.horasEquivalentes || 0;
    hAsig += r.horasAsignadas || 0;
    desvTotal += r.desviacion || 0;
    incidencias += (r.incidencias || []).length;
    personas.add(r.login);
    const est = estadoDecisionRecord(r);
    if (est === 'PENDIENTE') pendientes++;
    else if (est === 'COMPLETADA') completadas++;
    else if (est === 'EN REVISIÓN') enRevision++;
  }
  const cards = [
    { label: 'Persona / día', value: recs.length, level: 'info' },
    { label: 'Personas', value: personas.size, level: 'info' },
    { label: 'Horas analizables', value: SPEC.formatNum(horasAnalizables), level: 'info' },
    { label: 'UDS totales', value: SPEC.formatNum0(udsTotales), level: 'info' },
    { label: 'H. equivalentes', value: SPEC.formatNum(hEquiv), level: 'info' },
    { label: 'H. asignadas', value: SPEC.formatNum(hAsig), level: 'ok' },
    { label: 'Desviación Σ', value: SPEC.formatNum(desvTotal) + ' h', level: Math.abs(desvTotal) > horasAnalizables * 0.2 ? 'error' : 'warn' },
    { label: 'Incidencias', value: incidencias, level: 'warn' },
    { label: 'Pendientes', value: pendientes, level: 'warn' },
    { label: 'En revisión', value: enRevision, level: 'info' },
    { label: 'Completadas', value: completadas, level: 'ok' }
  ];
  if (summary) {
    summary.innerHTML = '';
    for (const c of cards) {
      const el = document.createElement('div');
      el.className = 'kpi-card ' + c.level;
      el.innerHTML = '<div class="label">' + escapeHtml(c.label) + '</div><div class="value">' + escapeHtml(String(c.value)) + '</div>';
      summary.appendChild(el);
    }
  }
  const counters = document.getElementById('review-counters');
  if (counters) counters.innerHTML =
    '<span class="badge-mini">' + pendientes + ' pendientes</span> · ' +
    '<span class="badge-mini">' + completadas + ' completadas</span> · ' +
    '<span class="badge-mini">' + recs.length + ' persona/día</span>';
  renderReviewList();
}

/* ===== Lista compacta persona/día (vista compacta requerida) ===== */
function renderReviewList() {
  const list = document.getElementById('review-list');
  if (!list) return;
  const recs = getFilteredPersonDays();
  list.innerHTML = '';
  if (recs.length === 0) {
    // v6.1.1 — aviso explícito cuando el filtro de turno oculta registros
    // SIN HORA: nunca se les inventa pertenencia a un turno.
    const turnoFiltro = (UI.reviewFilter || {}).turno;
    let sinHoraHtml = '';
    if (turnoFiltro && turnoFiltro !== 'SIN HORA') {
      const sinHora = SPEC.filtrarRegistrosPorTurno(getPersonaDiaRecords(), 'SIN HORA');
      if (sinHora.length > 0) {
        sinHoraHtml = '<p class="list-note sin-hora-note" role="note">' +
          '⚠ ' + sinHora.length + (sinHora.length === 1 ? ' registro no contiene hora de fichaje' : ' registros no contienen hora de fichaje') +
          ' y no puede asignarse a ningún turno. «Este registro no contiene hora de fichaje.»' +
          ' Selecciona «Sin hora» en el filtro para verlos.</p>';
      }
    }
    list.innerHTML = '<div class="empty-state"><div class="empty-state-icon">🔍</div><h3>Sin resultados</h3><p>No hay persona/día que coincidan con los filtros.</p></div>' + sinHoraHtml;
    return;
  }
  // v6.1.1 — nota informativa cuando el filtro de turno activo excluye a
  // registros SIN HORA (aunque la lista no esté vacía).
  const turnoFiltro2 = (UI.reviewFilter || {}).turno;
  if (turnoFiltro2 && turnoFiltro2 !== 'SIN HORA') {
    const sinHora = SPEC.filtrarRegistrosPorTurno(getPersonaDiaRecords(), 'SIN HORA');
    if (sinHora.length > 0) {
      const note = document.createElement('div');
      note.className = 'list-note sin-hora-note';
      note.setAttribute('role', 'note');
      note.textContent = '⚠ ' + sinHora.length + (sinHora.length === 1 ? ' registro no contiene hora de fichaje' : ' registros no contienen hora de fichaje') +
        ' y queda oculto por el filtro de turno (no se le asigna turno artificialmente).';
      list.appendChild(note);
    }
  }
  const limited = recs.slice(0, 300);
  for (const r of limited) {
    const est = estadoDecisionRecord(r);
    const item = document.createElement('div');
    item.className = 'review-item person-day' + (est !== 'PENDIENTE' && est !== 'SIN INCIDENCIAS' ? ' resolved' : '') + (UI.currentPersonDayId === r.key ? ' active' : '');
    item.dataset.key = r.key;
    // Sección principal del persona/día (para filtros/drilldowns): prioriza
    // la 1 (cambio propuesto) y si no, la primera de sus incidencias.
    const secciones = (r.incidencias || []).map(i => String(i.seccion || '').charAt(0)).filter(Boolean);
    item.dataset.seccion = secciones.indexOf('1') >= 0 ? '1' : (secciones[0] || '');
    const fechaStr = r.fechaOperativa instanceof Date ? SPEC.formatFecha(r.fechaOperativa) : String(r.fechaOperativaISO || '');
    const turnoCls = String(r.turno || '').replace(/\s+/g, '_').toLowerCase();
    item.innerHTML =
      '<div class="pd-main">' +
      '  <div class="pd-title">' + escapeHtml(r.persona || '(sin nombre)') + '</div>' +
      '  <div class="pd-meta">' +
      '    <span>📅 ' + escapeHtml(fechaStr) + '</span>' +
      '    <span class="pd-turno ' + escapeAttr(turnoCls) + '">' + escapeHtml(r.turno || '—') + '</span>' +
      '    <span>👤 ' + escapeHtml(r.login || '') + '</span>' +
      '  </div>' +
      '</div>' +
      '<div class="pd-stats">' +
      '  <span class="pd-stat" title="Tiempo fichado/analizable"><strong>' + SPEC.formatNum(r.horasAnalizables) + ' h</strong></span>' +
      '  <span class="pd-stat" title="UDS totales">' + SPEC.formatNum0(r.udsTotales) + ' uds</span>' +
      '  <span class="pd-stat" title="Desviación = horas analizables − horas equivalentes">' + (r.desviacion >= 0 ? '+' : '') + SPEC.formatNum(r.desviacion) + ' h</span>' +
      '  <span class="pd-stat" title="Nº actividades">' + (r.nActividades || 0) + ' act.</span>' +
      '</div>' +
      '<div class="pd-side">' +
      '  <span class="pd-inc" title="Incidencias">' + (r.incidencias || []).length + ' inc.</span>' +
      '  <span class="pd-decision ' + escapeAttr(est.replace(/\s+/g, '_').toLowerCase()) + '">' + escapeHtml(est) + '</span>' +
      '</div>';
    item.addEventListener('click', () => {
      UI.currentPersonDayId = r.key;
      renderReviewList();
      renderPersonDayDetail(r.key);
    });
    list.appendChild(item);
  }
  if (recs.length > 300) {
    const note = document.createElement('div');
    note.className = 'list-note';
    note.textContent = 'Mostrando 300 de ' + recs.length + ' (afina los filtros para ver más).';
    list.appendChild(note);
  }
}

/* ===== Detalle de persona/día desplegado ===== */
function renderPersonDayDetail(key) {
  const det = document.getElementById('incident-detail');
  if (!det) return;
  const r = getPersonaDiaRecords().find(x => x.key === key);
  if (!r) {
    det.innerHTML = '<div class="empty-state"><div class="empty-state-icon">👤</div><h3>Selecciona una persona/día</h3><p>Pulsa cualquier persona de la lista para ver su día completo.</p></div>';
    return;
  }
  const fechaStr = r.fechaOperativa instanceof Date ? SPEC.formatFecha(r.fechaOperativa) : String(r.fechaOperativaISO || '');
  let html =
    '<div class="pdd-head">' +
    '  <div>' +
    '    <h3>' + escapeHtml(r.persona || '(sin nombre)') + '</h3>' +
    '    <div class="pdd-sub">' + escapeHtml(fechaStr) + ' · ' + escapeHtml(r.login || '') + ' · Turno: <strong>' + escapeHtml(r.turno || '—') + '</strong></div>' +
    '  </div>' +
    '  <div class="pdd-badges">' +
    '    <span class="pd-turno ' + escapeAttr(String(r.turno || '').replace(/\s+/g, '_').toLowerCase()) + '">' + escapeHtml(r.turno || '—') + '</span>' +
    '    <span class="badge-mini" title="Semana ISO">' + escapeHtml(r.semana || '') + '</span>' +
    '    <span class="badge-mini" title="Mes">' + escapeHtml(r.mes || '') + '</span>' +
    (r.mappingHash ? '<span class="badge-mini" title="Hash del mapping usado (los históricos NO cambian al cambiar el mapping)">map: ' + escapeHtml(String(r.mappingHash).slice(0, 8)) + '</span>' : '') +
    '  </div>' +
    '</div>';

  // Resumen del día
  html +=
    '<div class="pdd-grid">' +
    pddKpi('Tiempo fichado/analizable', SPEC.formatNum(r.horasAnalizables) + ' h') +
    pddKpi('UDS totales', SPEC.formatNum0(r.udsTotales)) +
    pddKpi('H. equivalentes', SPEC.formatNum(r.horasEquivalentes)) +
    pddKpi('H. asignadas', SPEC.formatNum(r.horasAsignadas)) +
    pddKpi('Desviación', (r.desviacion >= 0 ? '+' : '') + SPEC.formatNum(r.desviacion) + ' h') +
    pddKpi('Nº actividades', String(r.nActividades || 0)) +
    (r.udsSinHoras > 0 ? pddKpi('UDS sin horas (info)', SPEC.formatNum0(r.udsSinHoras)) : '') +
    pddKpi('Match volumen', r.modoVolumen || '—') +
    '</div>';

  // v6.1.1 — Fichajes del día: hora + turno por registro. Los registros sin
  // hora muestran el mensaje explícito «Este registro no contiene hora de
  // fichaje.» y NO se les asigna turno artificialmente.
  const regs = r.registros || [];
  if (regs.length > 0) {
    html += '<h4>Fichajes del día (' + regs.length + ')</h4>' +
      '<div class="pdd-table-wrap"><table class="data-table pdd-fichajes-table"><caption class="sr-only">Fichajes del día con hora y turno</caption><thead><tr>' +
      '<th scope="col">ID registro</th><th scope="col">HR Task</th><th scope="col">Hora</th><th scope="col">Turno</th><th scope="col">Horas</th>' +
      '</tr></thead><tbody>';
    for (const rg of regs) {
      const tieneHora = rg.hora != null;
      const horaTxt = tieneHora
        ? String(Math.floor(rg.hora / 60)).padStart(2, '0') + ':' + String(rg.hora % 60).padStart(2, '0')
        : '—';
      const turnoTxt = tieneHora ? (rg.turno || '—') : 'SIN HORA';
      html += '<tr' + (tieneHora ? '' : ' class="sin-hora-row"') + '>' +
        '<td>' + escapeHtml(String(rg.idRegistroHoras != null ? rg.idRegistroHoras : '—')) + '</td>' +
        '<td>' + escapeHtml(rg.hrTask || '—') + '</td>' +
        '<td class="num">' + horaTxt + '</td>' +
        '<td>' + (tieneHora
          ? '<span class="pd-turno ' + escapeAttr(String(turnoTxt).replace(/\s+/g, '_').toLowerCase()) + '">' + escapeHtml(turnoTxt) + '</span>'
          : '<span class="pd-turno sin_hora">' + escapeHtml(turnoTxt) + '</span> <em class="sin-hora-msg">Este registro no contiene hora de fichaje.</em>') + '</td>' +
        '<td class="num">' + SPEC.formatNum(rg.horas || 0) + '</td>' +
        '</tr>';
    }
    html += '</tbody></table></div>';
  }

  // Tabla de actividades con el reparto (v6.1.1: filas de detalle POR TAREA)
  html += '<h4>Actividades y reparto de tiempo</h4>' +
    '<div class="pdd-table-wrap"><table class="data-table pdd-act-table"><caption class="sr-only">Actividades del día con reparto de tiempo</caption><thead><tr>' +
    '<th scope="col">Actividad / TASK_WMS</th><th scope="col">UDS</th><th scope="col">Product. ref.</th><th scope="col">H equiv.</th><th scope="col">Peso</th><th scope="col">H asignadas</th><th scope="col">Product. implícita</th>' +
    '</tr></thead><tbody>';
  for (const a of (r.actividades || [])) {
    const nTareas = (a.tareas || []).length;
    const prodTxt = a.productividad != null ? SPEC.formatNum0(a.productividad)
      : (nTareas > 1 ? 'varias' : '—');
    const prodTitle = a.productividad != null ? 'Productividad de referencia'
      : (nTareas > 1 ? 'Las tareas de esta actividad tienen productividades distintas (ver detalle por tarea)' : 'Sin productividad de referencia');
    html += '<tr' + (a.actividad === 'OTRA' ? ' class="otra-row"' : '') + '>' +
      '<td>' + escapeHtml(a.actividad) +
      (nTareas > 1 ? ' <span class="pdd-ntareas">(' + nTareas + ' tareas)</span>' : '') + '</td>' +
      '<td class="num">' + SPEC.formatNum0(a.uds) + '</td>' +
      '<td class="num" title="' + escapeAttr(prodTitle) + '">' + escapeHtml(prodTxt) + '</td>' +
      '<td class="num">' + (a.horasEquivalentes != null ? SPEC.formatNum(a.horasEquivalentes) : '—') + '</td>' +
      '<td class="num">' + (a.peso != null ? SPEC.formatNum(a.peso * 100) + '%' : '—') + '</td>' +
      '<td class="num"><strong>' + SPEC.formatNum(a.horasAsignadas) + '</strong></td>' +
      '<td class="num">' + (a.productividadImplicita != null ? SPEC.formatNum0(a.productividadImplicita) : '—') + '</td>' +
      '</tr>';
    // v6.1.1 — detalle POR TAREA: TASK_WMS | UDS | Productividad | H eq. | Peso | H asignadas | Fuente
    for (const t of (a.tareas || [])) {
      html += '<tr class="pdd-task-row" title="Fuente de la productividad: ' + escapeAttr(t.fuente || '') + '">' +
        '<td class="pdd-task-cell">↳ ' + escapeHtml(t.taskWms || '(sin tarea)') + '</td>' +
        '<td class="num">' + SPEC.formatNum0(t.uds) + '</td>' +
        '<td class="num">' + (t.productividad != null ? SPEC.formatNum0(t.productividad) : '—') + '</td>' +
        '<td class="num">' + (t.horasEquivalentes != null ? SPEC.formatNum(t.horasEquivalentes) : '—') + '</td>' +
        '<td class="num">' + (t.peso != null ? SPEC.formatNum(t.peso * 100) + '%' : '—') + '</td>' +
        '<td class="num">' + SPEC.formatNum(t.horasAsignadas || 0) + '</td>' +
        '<td class="num pdd-fuente">' + escapeHtml(t.fuente || '') + '</td>' +
        '</tr>';
    }
  }
  const sumAsig = (r.actividades || []).reduce((s, a) => s + (a.horasAsignadas || 0), 0);
  html += '</tbody></table></div>';
  html += '<p class="pdd-note">Σ horas asignadas = <strong>' + SPEC.formatNum(sumAsig) + ' h</strong> · tiempo analizable = <strong>' + SPEC.formatNum(r.horasAnalizables) + ' h</strong>' +
    (Math.abs(sumAsig - r.horasAnalizables) < 1e-9 || sumAsig === 0 ? ' ✓ (conservación exacta)' : ' ⚠ diferencia ' + SPEC.formatNum(sumAsig - r.horasAnalizables)) +
    ' · Las actividades <em>OTRA</em> no participan del reparto. La productividad implícita NO es productividad real medida.</p>';

  // Incidencias con acciones
  const incs = r.incidencias || [];
  if (incs.length > 0) {
    html += '<h4>Incidencias (' + incs.length + ')</h4><div class="pdd-incs">';
    for (const inc of incs) {
      const rep = (SPEC.STATE.reporte || []).find(x => incidentId(x) === inc.id);
      const conf = rep ? getConfianza(rep) : 'No determinable';
      const d = SPEC.STATE.decisions[inc.id];
      html +=
        '<div class="pdd-inc" data-inc-id="' + escapeAttr(inc.id) + '">' +
        '  <div class="pdd-inc-head">' +
        '    <span class="ri-icon">' + escapeHtml(String(inc.seccion || '').charAt(0) || '?') + '</span>' +
        '    <div class="pdd-inc-title">' + escapeHtml(String(inc.seccion || '')) + '</div>' +
        (d ? '    <span class="ri-decision ' + escapeAttr(d.decision) + '">' + escapeHtml(d.decision) + '</span>' : '    <span class="ri-decision pendiente">pendiente</span>') +
        '  </div>' +
        '  <div class="pdd-inc-body">' +
        '    <div>Fichada: <strong>' + escapeHtml(inc.tareaOriginal || '—') + '</strong></div>' +
        '    <div>Propuesta mapping: <strong>' + escapeHtml(inc.propuesta || '—') + '</strong></div>' +
        '    <div>Horas: <strong>' + SPEC.formatNum(inc.horasAfectadas) + ' h</strong> · Confianza: ' + escapeHtml(conf) + '</div>' +
        '  </div>' +
        '  <div class="pdd-inc-actions">' +
        '    <label class="sr-only" for="motivo-' + escapeAttr(inc.id) + '">Motivo</label>' +
        '    <input type="text" id="motivo-' + escapeAttr(inc.id) + '" class="pdd-motivo" placeholder="Motivo (opcional)">' +
        '    <button class="btn btn-sm btn-primary" data-action="aceptar" ' + (inc.propuesta ? '' : 'disabled title="Sin propuesta de mapping"') + '>✓ ACEPTAR</button>' +
        '    <button class="btn btn-sm btn-secondary" data-action="mantener">↩ MANTENER</button>' +
        '    <button class="btn btn-sm btn-secondary" data-action="revisar">👀 REVISAR</button>' +
        (d ? '<button class="btn btn-sm btn-warn" data-action="undo">↺ DESHACER</button>' : '') +
        '  </div>' +
        '</div>';
    }
    html += '</div>';
  } else {
    html += '<h4>Incidencias</h4><p class="pdd-note">Sin incidencias para esta persona/día.</p>';
  }
  det.innerHTML = html;

  // Listeners de acciones
  det.querySelectorAll('.pdd-inc').forEach(el => {
    const incId = el.dataset.incId;
    el.querySelectorAll('button[data-action]').forEach(btn => {
      btn.addEventListener('click', () => {
        const rep = (SPEC.STATE.reporte || []).find(x => incidentId(x) === incId);
        if (!rep) { toast('No se encuentra la incidencia en el reporte actual.', { level: 'warn' }); return; }
        const action = btn.dataset.action;
        const motivoInput = el.querySelector('.pdd-motivo');
        const motivo = motivoInput ? motivoInput.value : '';
        if (action === 'aceptar') {
          registrarDecision(rep, 'aceptada', rep['TASKSPEC SEGUN MAPPING'], motivo || 'Aceptada propuesta automática');
        } else if (action === 'mantener') {
          registrarDecision(rep, 'mantenida', rep['HR TASK FICHADA'], motivo || 'Se mantiene el fichaje original');
        } else if (action === 'revisar') {
          registrarDecision(rep, 'revisar', rep['HR TASK FICHADA'], motivo || 'Requiere revisión manual');
        } else if (action === 'undo') {
          undoDecision(incId);
        }
      });
    });
  });
}

function pddKpi(label, value) {
  return '<div class="pdd-kpi"><div class="label">' + escapeHtml(label) + '</div><div class="value">' + escapeHtml(value) + '</div></div>';
}

/* Navegación persona/día (para auto-advance y atajos N/P). */
function navigateIncident(delta) {
  const recs = getFilteredPersonDays();
  if (recs.length === 0) return;
  const idx = recs.findIndex(r => r.key === UI.currentPersonDayId);
  let newIdx = idx + delta;
  if (newIdx < 0) newIdx = 0;
  if (newIdx >= recs.length) newIdx = recs.length - 1;
  if (newIdx === idx && recs.length > 1) return;
  UI.currentPersonDayId = recs[newIdx].key;
  renderReviewList();
  renderPersonDayDetail(recs[newIdx].key);
}

/* Selección de incidencia desde drilldowns de KPI (compatibilidad): navega al
 * persona/día que contiene la incidencia. */
function selectIncident(id) {
  const recs = getPersonaDiaRecords();
  const rec = recs.find(r => (r.incidencias || []).some(i => i.id === id));
  if (rec) {
    UI.currentPersonDayId = rec.key;
    renderReviewList();
    renderPersonDayDetail(rec.key);
    return;
  }
  // Fallback: abrir el detalle del primer persona/día
  if (recs.length > 0) {
    UI.currentPersonDayId = recs[0].key;
    renderPersonDayDetail(recs[0].key);
  }
}

/* ============================================================================
 * v6.1 — MEJORA 5: REGISTRAR DECISIÓN + UNDO REAL (persistente y auditable)
 * Reemplaza a las versiones anteriores (la última declaración del script gana).
 * Cada acción guarda: acción, estado anterior, estado posterior, usuario/
 * sessionId, timestamp, mappingHash. El undo restaura, registra la entrada de
 * undo en el audit log (NO borra el registro), actualiza IndexedDB + pantalla
 * + históricos. undoDecision usa la entrada MÁS RECIENTE del id (bug fix).
 * ========================================================================== */

function registrarDecision(incident, decision, tareaFinal, motivo) {
  const id = incidentId(incident);
  const prev = SPEC.STATE.decisions[id];
  // Undo stack: guardar el estado ANTERIOR para poder restaurarlo
  SPEC.STATE.undoStack.push({
    id,
    prev: prev ? Object.assign({}, prev) : null,
    timestamp: Date.now()
  });
  const nuevo = {
    decision,
    tareaFinal: tareaFinal || '',
    motivo: motivo || '',
    timestamp: Date.now(),
    usuario: 'usuario_local', // anónimo
    evidencia: incident.OBSERVACION || '',
    seccion: incident.SECCION || '',
    idRegistro: incident['ID REGISTRO'],
    persona: incident.PERSONA,
    fecha: incident.FECHA,
    tareaOriginal: incident['HR TASK FICHADA'],
    propuesta: incident['TASKSPEC SEGUN MAPPING'] || '',
    nivelConfianza: getConfianza(incident)
  };
  SPEC.STATE.decisions[id] = nuevo;
  // Audit log con hash chain + estado anterior/posterior
  const prevHash = SPEC.STATE.auditLog.length > 0
    ? (SPEC.STATE.auditLog[SPEC.STATE.auditLog.length - 1].entryHash || null)
    : null;
  const entry = {
    timestamp: new Date().toISOString(),
    action: decision,
    id,
    idRegistro: incident['ID REGISTRO'],
    persona: incident.PERSONA,
    seccion: incident.SECCION,
    tareaOriginal: incident['HR TASK FICHADA'],
    propuesta: incident['TASKSPEC SEGUN MAPPING'] || '',
    tareaFinal: tareaFinal || '',
    motivo: motivo || '',
    nivelConfianza: getConfianza(incident),
    sessionId: (SPEC.STATE.stats && SPEC.STATE.stats.sessionId) || null,
    appVersion: (SPEC.STATE.stats && SPEC.STATE.stats.appVersion) || SPEC.PARAMS.AppVersion,
    mappingHash: (SPEC.STATE.stats && SPEC.STATE.stats.mappingHash) || null,
    schemaVersion: (SPEC.STATE.stats && SPEC.STATE.stats.schemaVersion) || SPEC.PARAMS.SchemaVersion,
    estadoAnterior: prev ? prev.decision : null,
    estadoPosterior: decision,
    prevHash
  };
  SPEC.calcularEntryHash(entry, prevHash).then(entryHash => {
    entry.entryHash = entryHash;
    persistDecisions();
  }).catch(err => {
    console.error('calcularEntryHash falló — entrada marcada como INSECURE_CONTEXT:', err);
    entry.integrity = 'INSECURE_CONTEXT';
    persistDecisions();
  });
  SPEC.STATE.auditLog.push(entry);
  toast('Decisión registrada: ' + decision.toUpperCase(), { level: 'success', duration: 1800 });
  // Actualizar históricos (persona/día) y pantalla
  sincronizarDecisionesEnRecords();
  encolarPersistenciaRecords();
  persistDecisions();
  renderReviewPanel();
  if (UI.autoAdvance) {
    setTimeout(() => navigateIncident(1), 200);
  } else if (UI.currentPersonDayId) {
    renderPersonDayDetail(UI.currentPersonDayId);
  }
  renderAuditoriaPanel();
}

/* UNDO de una decisión concreta (por id de incidencia). Usa el NÚCLEO PURO
 * SPEC.undoApply → restaura la entrada MÁS RECIENTE del id. */
function undoDecision(id) {
  const res = SPEC.undoApply(SPEC.STATE.undoStack, SPEC.STATE.decisions, id);
  if (!res.ok) {
    toast('No hay decisión previa para deshacer.', { level: 'warn' });
    return;
  }
  SPEC.STATE.decisions = res.decisions;
  SPEC.STATE.undoStack = res.undoStack;
  const incident = (SPEC.STATE.reporte || []).find(r => incidentId(r) === id);
  const prevHash = SPEC.STATE.auditLog.length > 0
    ? (SPEC.STATE.auditLog[SPEC.STATE.auditLog.length - 1].entryHash || null)
    : null;
  const logEntry = {
    timestamp: new Date().toISOString(),
    action: 'undo',
    id,
    idRegistro: incident ? incident['ID REGISTRO'] : null,
    persona: incident ? incident.PERSONA : null,
    seccion: incident ? incident.SECCION : null,
    tareaOriginal: incident ? incident['HR TASK FICHADA'] : null,
    propuesta: incident ? (incident['TASKSPEC SEGUN MAPPING'] || '') : '',
    tareaFinal: '',
    motivo: 'Deshacer decisión anterior',
    nivelConfianza: incident ? getConfianza(incident) : null,
    sessionId: (SPEC.STATE.stats && SPEC.STATE.stats.sessionId) || null,
    appVersion: (SPEC.STATE.stats && SPEC.STATE.stats.appVersion) || SPEC.PARAMS.AppVersion,
    mappingHash: (SPEC.STATE.stats && SPEC.STATE.stats.mappingHash) || null,
    schemaVersion: (SPEC.STATE.stats && SPEC.STATE.stats.schemaVersion) || SPEC.PARAMS.SchemaVersion,
    estadoAnterior: res.estadoAnterior,
    estadoPosterior: null,
    prevHash
  };
  SPEC.calcularEntryHash(logEntry, prevHash).then(h => { logEntry.entryHash = h; persistDecisions(); })
    .catch(err => { console.error('calcularEntryHash falló:', err); logEntry.integrity = 'INSECURE_CONTEXT'; persistDecisions(); });
  SPEC.STATE.auditLog.push(logEntry);
  toast('Decisión deshecha' + (res.estadoAnterior ? ' (restaurada a: ' + res.estadoAnterior + ')' : ' (vuelve a pendiente)') + '.', { level: 'info', duration: 1800 });
  // Persistir undo + actualizar históricos y pantalla
  sincronizarDecisionesEnRecords();
  encolarPersistenciaRecords();
  persistDecisions();
  renderReviewPanel();
  if (UI.currentPersonDayId) renderPersonDayDetail(UI.currentPersonDayId);
  renderAuditoriaPanel();
}

/* UNDO de la última acción (global). */
function undoLastAction() {
  if (!SPEC.STATE.undoStack || SPEC.STATE.undoStack.length === 0) {
    toast('No hay acciones para deshacer.', { level: 'warn' });
    return;
  }
  const lastId = SPEC.STATE.undoStack[SPEC.STATE.undoStack.length - 1].id;
  undoDecision(lastId);
}

/* Persistencia de decisiones — v6.1: incluye undoStack (undo persistente). */
function persistDecisions() {
  try {
    const toSave = {
      decisions: SPEC.STATE.decisions,
      auditLog: SPEC.STATE.auditLog,
      undoStack: SPEC.STATE.undoStack || [],
      savedAt: new Date().toISOString(),
      appVersion: (SPEC.STATE.stats && SPEC.STATE.stats.appVersion) || SPEC.PARAMS.AppVersion,
      schemaVersion: (SPEC.STATE.stats && SPEC.STATE.stats.schemaVersion) || SPEC.PARAMS.SchemaVersion,
      mappingHash: (SPEC.STATE.stats && SPEC.STATE.stats.mappingHash) || null,
      sessionId: (SPEC.STATE.stats && SPEC.STATE.stats.sessionId) || null
    };
    localStorage.setItem('spec_decisions', JSON.stringify(toSave));
    idbBackupDecisions(SPEC.STATE.decisions, SPEC.STATE.auditLog).catch(err => {
      console.warn('IDB backup async error (no crítico):', err);
    });
    return true;
  } catch (e) {
    console.warn('No se pudo persistir decisiones en localStorage:', e);
    idbBackupDecisions(SPEC.STATE.decisions, SPEC.STATE.auditLog).catch(() => {});
    return false;
  }
}

/* Restauración de decisiones — v6.1: restaura también el undoStack. */
function restoreDecisions() {
  try {
    const raw = localStorage.getItem('spec_decisions');
    const aplicar = (saved) => {
      if (!saved) return false;
      SPEC.STATE.decisions = saved.decisions || {};
      SPEC.STATE.auditLog = saved.auditLog || [];
      SPEC.STATE.undoStack = saved.undoStack || [];
      return true;
    };
    if (!raw) {
      idbRestoreDecisions().then(saved => {
        if (saved && (saved.decisions || saved.auditLog)) {
          aplicar(saved);
          console.info('Decisiones restauradas desde IndexedDB (localStorage estaba vacío).');
          if (UI.activeTab === 'revisar') renderReviewPanel();
          if (UI.activeTab === 'auditoria') renderAuditoriaPanel();
        }
      }).catch(err => console.warn('IDB restore falló:', err));
      return false;
    }
    const saved = JSON.parse(raw);
    aplicar(saved);
    verificarIntegridadAuditLog();
    if (UI.activeTab === 'revisar') renderReviewPanel();
    if (UI.activeTab === 'auditoria') renderAuditoriaPanel();
    return true;
  } catch (e) {
    console.warn('restoreDecisions falló:', e);
    return false;
  }
}

/* ============================================================================
 * v6.1 — MEJORA 6: PATRONES (registros históricos diarios)
 * Reemplaza la vista de tarjetas por el análisis histórico completo.
 * ========================================================================== */

/* ============================================================================
 * v6.2 — PATRONES: ESTADÍSTICA AVANZADA E INTELIGENCIA OPERATIVA
 * (reemplaza la vista v6.1; la capa de cálculo vive en analytics/*.js)
 * ========================================================================== */

/* Aplica los filtros GLOBALES combinables a los records históricos (crudos).
 * El filtro de turno usa la función centralizada v6.1.1 (un persona/día
 * aparece si ALGUNO de sus registros es de ese turno — mismo criterio que
 * Revisar). v6.2 añade TASK_WMS (subcadena), cliente y mapping (hash). */
function filtrarPatronesRecords(records) {
  let list = records.slice();
  const v = id => (document.getElementById(id) || {}).value || '';
  const from = v('patrones-filter-date-from');
  const to = v('patrones-filter-date-to');
  const persona = v('patrones-filter-persona').toLowerCase();
  const turno = v('patrones-filter-turno');
  const actividad = v('patrones-filter-actividad');
  const decision = v('patrones-filter-decision');
  const semana = v('patrones-filter-semana').trim();
  const mes = v('patrones-filter-mes').trim();
  const task = v('patrones-filter-task').trim().toLowerCase();
  const cliente = v('patrones-filter-cliente').trim();
  const mapping = v('patrones-filter-mapping').trim();
  if (from) list = list.filter(r => String(r.fechaOperativaISO || '') >= from);
  if (to) list = list.filter(r => String(r.fechaOperativaISO || '') <= to);
  if (persona) list = list.filter(r =>
    (r.persona || '').toLowerCase().indexOf(persona) >= 0 ||
    (r.login || '').toLowerCase().indexOf(persona) >= 0);
  if (turno) {
    // v6.1.1 — filtro centralizado (misma función que Revisar)
    list = SPEC.filtrarRegistrosPorTurno(list, turno);
  }
  if (actividad) list = list.filter(r => (r.actividades || []).some(a => a.actividad === actividad));
  if (decision) list = list.filter(r => estadoDecisionRecord(r) === decision);
  if (semana) list = list.filter(r => (r.semana || '').toUpperCase() === semana.toUpperCase());
  if (mes) list = list.filter(r => (r.mes || '') === mes);
  if (task) list = list.filter(r => (r.actividades || []).some(a =>
    (a.tareasWms || []).some(t => String(t).toLowerCase().indexOf(task) >= 0) ||
    (a.tareas || []).some(t => String(t.taskWms || '').toLowerCase().indexOf(task) >= 0)));
  if (cliente) list = list.filter(r => {
    const enTareas = (r.actividades || []).some(a => (a.tareas || []).some(t =>
      String(t.cliente || '').toLowerCase().indexOf(cliente.toLowerCase()) >= 0));
    const enIncs = (r.incidencias || []).some(i => String(i.cliente || '').toLowerCase().indexOf(cliente.toLowerCase()) >= 0);
    return enTareas || enIncs;
  });
  if (mapping) list = list.filter(r => String(r.mappingHash || '') === mapping);
  return list;
}

/* Snapshot analítica de Patrones: normaliza + filtra + calcula TODO lo que
 * necesitan las 8 vistas. Memoizada por firma de filtros+config+datos
 * (§53: no recalcular con cada cambio visual). */
function patronesSnapshot() {
  const raw = UI.patronesRecords || [];
  const AN = window.SPEC_AN;
  const cfg = AN.loadConfig();
  const v = id => (document.getElementById(id) || {}).value || '';
  const firma = JSON.stringify([
    v('patrones-filter-date-from'), v('patrones-filter-date-to'), v('patrones-filter-persona'),
    v('patrones-filter-turno'), v('patrones-filter-actividad'), v('patrones-filter-decision'),
    v('patrones-filter-semana'), v('patrones-filter-mes'), v('patrones-filter-task'),
    v('patrones-filter-cliente'), v('patrones-filter-mapping'),
    raw.length, UI.patronesRecordsStamp || 0, JSON.stringify(cfg)
  ]);
  if (UI._patronesSnap && UI._patronesSnapFirma === firma) return UI._patronesSnap;
  const norm = AN.normalizarRecords(raw);
  const filtradosRaw = filtrarPatronesRecords(raw);
  const byKey = new Set(filtradosRaw.map(r => r.key));
  const list = norm.filter(r => byKey.has(r.key));
  const partes = AN.partirPorMitades(list);
  const snap = {
    cfg, list, norm,
    kpi: AN.kpisBase(list),
    kpiA: AN.kpisBase(partes.A),
    kpiB: AN.kpisBase(partes.B),
    comp: AN.compararPeriodos(partes.A, partes.B),
    personas: AN.person.computePersonStats(list, cfg),
    tendPersonas: AN.person.computePersonTendencia(list, cfg),
    tareas: AN.task.computeTaskStats(list, cfg),
    tendTareas: AN.task.computeTaskTendencia(list, cfg),
    fichaje: AN.task.computeFichajeStats(list, cfg),
    actividades: AN.activity.computeActivityStats(list, cfg),
    turnos: AN.activity.computeTurnoStats(list, cfg),
    matrix: AN.confusion.computeConfusionMatrix(list),
    recurrencias: AN.confusion.computeRecurrencias(list, cfg),
    daily: AN.trend.computeDailySeries(list, cfg),
    semanal: AN.trend.computeBucketSeries(list, 'semana', cfg),
    mensual: AN.trend.computeBucketSeries(list, 'mes', cfg),
    paretoTareas: AN.pareto.computeParetoTareas(AN.task.computeTaskStats(list, cfg)),
    paretoPersonas: AN.pareto.computeParetoPersonas(AN.person.computePersonStats(list, cfg)),
    paretoActividades: AN.pareto.computeParetoActividades(AN.activity.computeActivityStats(list, cfg)),
    alerts: AN.alerts.computeAlerts(list, cfg),
    top: AN.alerts.computeTopPrioridades(list, cfg, 5),
    dq: AN.dataQuality.computeDataQuality(list),
    mq: AN.dataQuality.computeMappingQuality(list)
  };
  UI._patronesSnap = snap;
  UI._patronesSnapFirma = firma;
  return snap;
}

function patronesStampRecords() {
  // Invalida la memo cuando cambia el histórico (post-análisis/persistencia)
  UI.patronesRecordsStamp = Date.now();
  UI._patronesSnap = null;
  UI._patronesSnapFirma = null;
}

async function renderPatronesPanel() {
  // Cargar registros (con fusión de la sesión en memoria)
  if (!UI.patronesRecords) {
    UI.patronesRecords = await cargarTodosRecords();
    patronesStampRecords();
  }
  renderPatronesView(UI.patronesRecords);
}

function renderPatronesView(all) {
  const AN = window.SPEC_AN;
  if (!AN) { console.warn('SPEC_AN no disponible (¿analytics/*.js cargados?)'); return; }
  if (!all || all.length === 0) {
    renderPatronesVacio();
    return;
  }
  const snap = patronesSnapshot();
  renderKpisResumen(snap);
  renderFocosResumen(snap);
  renderPersonasView(snap);
  renderTareasView(snap);
  renderActividadesView(snap);
  renderErroresView(snap);
  renderEvolucionView(snap);
  renderParetoView(snap);
  renderCalidadView(snap);
  poblarFiltrosDinamicos(snap);
}

/* Estado vacío (E2E 1: Patrones con histórico vacío). */
function renderPatronesVacio() {
  const msg = '<p style="color: var(--c-text-muted); font-size: 13px;">No hay registros diarios todavía. Carga los Excel y pulsa ANALIZAR: los históricos se guardan automáticamente en este navegador (y se acumulan día a día sin duplicarse).</p>';
  const kpi = document.getElementById('patrones-kpis');
  if (kpi) kpi.innerHTML = msg;
  const focos = document.getElementById('patrones-resumen-focos');
  if (focos) focos.innerHTML = '';
  const resto = document.getElementById('patrones-resumen-resto');
  if (resto) resto.innerHTML = '';
  for (const id of ['patrones-view-personas', 'patrones-view-tareas', 'patrones-view-actividades', 'patrones-view-errores', 'patrones-view-pareto', 'patrones-view-calidad']) {
    const el = document.getElementById(id);
    if (el) el.innerHTML = msg;
  }
  const ev = document.getElementById('patrones-evolucion');
  if (ev) ev.innerHTML = msg;
  const per = document.getElementById('patrones-periodos');
  if (per) per.innerHTML = '';
  const prof = document.getElementById('patrones-profile');
  if (prof) { prof.hidden = true; prof.innerHTML = ''; }
}

/* KPI con tooltip de explicabilidad (§45): fórmula, denominador, periodo. */
function kpiCardPAT(label, value, tooltip, cls) {
  const tip = tooltip ? ' title="' + escapeAttr(tooltip) + '" data-tip="1"' : '';
  return '<div class="kpi-card ' + (cls || 'info') + '"' + tip + '>' +
    '<div class="label">' + escapeHtml(label) + (tooltip ? ' <span class="kpi-info" aria-hidden="true">ℹ</span>' : '') + '</div>' +
    '<div class="value">' + escapeHtml(String(value)) + '</div></div>';
}

/* BLOQUE 1 — Estado actual + evolución (§4/§61). */
function renderKpisResumen(snap) {
  const wrap = document.getElementById('patrones-kpis');
  if (!wrap) return;
  const k = snap.kpi, c = snap.comp.cambios, AN = window.SPEC_AN;
  const etiqueta = AN.etiquetaComparacion(snap.comp, snap.cfg);
  const fmtN = SPEC.formatNum, fmt0 = SPEC.formatNum0;
  const cards = [
    kpiCardPAT('Personas analizadas', k.personas, 'Logins distintos en los persona-día que pasan los filtros globales.', 'info'),
    kpiCardPAT('Días analizados', k.dias, 'Fechas operativas distintas presentes en el histórico filtrado.', 'info'),
    kpiCardPAT('Persona-día', k.personaDia, 'Registros PERSONA+FECHA_OPERATIVA (unidad del histórico).', 'info'),
    kpiCardPAT('Horas analizadas', fmtN(k.horasAnalizables) + ' h', 'Σ horas analizables de los persona-día filtrados.', 'info'),
    kpiCardPAT('Incidencias', fmt0(k.incidencias), 'Σ líneas de propuesta (todas las secciones 1-7, incluida la 3 de control).', 'warn'),
    kpiCardPAT('% persona-día con incidencia', fmtN(k.pctPersonaDiaConIncidencia) + '%', 'persona-día con ≥1 incidencia / persona-día filtrados. Denominador: ' + k.personaDia + '.', (k.pctPersonaDiaConIncidencia > 50 ? 'error' : 'warn')),
    kpiCardPAT('Persona-día con error', fmt0(k.personaDiaConError), 'Persona-día con ≥1 error real (secciones 1/2/4/5/6/7; la 3 es control sin error).', 'warn'),
    kpiCardPAT('% persona-día con error', fmtN(k.pctPersonaDiaConError) + '%', 'persona-día con ≥1 error / persona-día. Denominador: ' + k.personaDia + '.', (k.pctPersonaDiaConError > 50 ? 'error' : 'warn')),
    kpiCardPAT('Horas afectadas', fmtN(k.horasAfectadas) + ' h', 'Σ horas con incidencia (cada registro de horas cuenta una vez por persona/día).', 'error'),
    kpiCardPAT('% horas afectadas', fmtN(k.pctHorasAfectadas) + '%', 'horas afectadas / horas analizadas (' + fmtN(k.horasAnalizables) + ' h).', 'error'),
    kpiCardPAT('Errores de asignación', fmt0(k.erroresAsignacion), 'Incidencias sección 1 (cambio de HR task propuesto) + decisiones aceptadas.', 'error'),
    kpiCardPAT('% errores de asignación', fmtN(k.pctErroresAsignacion) + '%', 'errores de asignación / incidencias (' + k.incidencias + ').', 'error')
  ];
  // Evolución: actual vs anterior (mitades del rango filtrado) — §4
  const evolucion =
    '<div class="patrones-evolucion-box"><h4>Evolución (periodo actual vs anterior' +
    ' <span class="hint-inline">— mitades del rango filtrado: ' + escapeHtml(snap.kpiA.personaDia + ' vs ' + snap.kpiB.personaDia + ' persona-día') + '</span>)</h4>' +
    '<div class="kpi-grid">' +
    kpiCardPAT('Incidencias · Actual', fmt0(snap.kpiB.incidencias), 'Periodo actual (2ª mitad del rango filtrado).', 'info') +
    kpiCardPAT('Incidencias · Anterior', fmt0(snap.kpiA.incidencias), 'Periodo anterior (1ª mitad del rango filtrado).', 'info') +
    kpiCardPAT('Cambio incidencias', (c.incidencias > 0 ? '+' : '') + fmtN(c.incidencias) + (c.incidenciasPct != null ? ' (' + (c.incidenciasPct > 0 ? '+' : '') + fmtN(c.incidenciasPct) + '%)' : ''), 'Δ = actual − anterior. % relativo solo si el periodo anterior tenía datos.', (c.incidencias > 0 ? 'error' : 'success')) +
    kpiCardPAT('% persona-día con error · Δ', (c.pctPersonaDiaConError.deltaPP > 0 ? '+' : '') + fmtN(c.pctPersonaDiaConError.deltaPP) + ' pp', 'PUNTOS PORCENTUALES (§18): tasa actual − tasa anterior. Umbrales de mejora/empeora: ±' + snap.cfg.umbralCambioPP + ' pp (configurables).', (c.pctPersonaDiaConError.deltaPP > 0 ? 'error' : 'success')) +
    kpiCardPAT('Horas afectadas · Δ', (c.horasAfectadas > 0 ? '+' : '') + fmtN(c.horasAfectadas) + ' h', 'Δ de horas afectadas entre mitades.', (c.horasAfectadas > 0 ? 'error' : 'success')) +
    kpiCardPAT('Veredicto tendencia', etiqueta, 'Etiqueta determinista sobre el Δ en pp del % de persona-día con error, con umbral configurable. Requiere ≥ ' + snap.cfg.minDiasComparar + ' persona-día por mitad (sin evidencia → SIN DATOS).', (etiqueta === 'MEJORA' ? 'success' : (etiqueta === 'EMPEORA' ? 'error' : 'info'))) +
    '</div></div>';
  wrap.innerHTML = cards.join('') + evolucion;
}


/* BLOQUE 2 — DÓNDE PONER EL OJO: TOP 5 prioridades + alertas (§5/§6/§62). */
function renderFocosResumen(snap) {
  const focos = document.getElementById('patrones-resumen-focos');
  if (!focos) return;
  const resto = document.getElementById('patrones-resumen-resto');
  if (snap.list.length === 0) { focos.innerHTML = ''; if (resto) resto.innerHTML = ''; return; }
  let html = '<h3 class="focos-title">🎯 Dónde poner el ojo — Top 5 prioridades</h3>';
  if (snap.top.length === 0) {
    html += '<p class="pdd-note">Sin errores ni horas afectadas con los filtros actuales: no hay focos de atención.</p>';
  } else {
    html += '<p class="pdd-note">Índice de prioridad transparente (0-100) = media ponderada de frecuencia (' + snap.cfg.pesoFrecuencia +
      '), tasa (' + snap.cfg.pesoTasa + '), horas (' + snap.cfg.pesoHoras + '), recurrencia (' + snap.cfg.pesoRecurrencia +
      '), tendencia (' + snap.cfg.pesoTendencia + ') y personas (' + snap.cfg.pesoPersonas + '), normalizadas por el máximo del conjunto. Pesos editables en ⚙ Configuración.</p>';
    html += '<ol class="prioridades-list">';
    snap.top.forEach(function (p, i) {
      html += '<li class="prioridad-item nivel-' + p.nivel.toLowerCase() + '" data-tipo="' + escapeAttr(p.tipo) + '" data-nombre="' + escapeAttr(p.nombre) + '" tabindex="0" role="button">' +
        '<div class="pi-cab"><span class="pi-rank">#' + (i + 1) + '</span>' +
        '<strong class="pi-nombre">' + escapeHtml(p.nombre) + '</strong>' +
        '<span class="badge-mini">' + escapeHtml(p.tipo) + '</span>' +
        '<span class="pi-prioridad ' + ('prio-' + p.nivel.toLowerCase()) + '">PRIORIDAD ' + p.nivel + ' · ' + p.score + '</span></div>' +
        '<div class="pi-detalle">' +
        '<span title="Nº de errores imputados">Frecuencia: <strong>' + p.desglose.frecuencia.valor + '</strong></span>' +
        '<span title="Errores / oportunidades">Tasa: <strong>' + SPEC.formatNum(p.desglose.tasa.valor) + '%</strong></span>' +
        '<span title="Horas con incidencia imputadas">Impacto: <strong>' + SPEC.formatNum(p.desglose.horas.valor) + ' h</strong></span>' +
        '<span title="Días distintos con error">Recurrencia: <strong>' + p.desglose.recurrencia.valor + ' d</strong></span>' +
        '<span title="Δ tasa entre mitades (pp); ↑ empeora">Tendencia: <strong>' + p.flecha + (p.desglose.tendencia.valor != null ? ' (' + (p.desglose.tendencia.valor > 0 ? '+' : '') + SPEC.formatNum(p.desglose.tendencia.valor) + ' pp)' : '') + '</strong></span>' +
        '<span title="Personas distintas afectadas">Personas: <strong>' + p.desglose.personas.valor + '</strong></span>' +
        '</div></li>';
    });
    html += '</ol>';
  }
  // Alertas deterministas (§37)
  html += '<h3 class="focos-title">🔔 Alertas (reglas deterministas, umbrales configurables)</h3>';
  if (snap.alerts.length === 0) {
    html += '<p class="pdd-note">Ninguna alerta con los filtros y umbrales actuales.</p>';
  } else {
    html += '<ul class="alerts-list">';
    snap.alerts.slice(0, 12).forEach(function (a) {
      html += '<li class="alert-item sev-' + String(a.severidad).toLowerCase() + '">' +
        '<span class="alert-sev">' + escapeHtml(a.severidad) + '</span>' +
        '<div><strong>' + escapeHtml(a.titulo) + '</strong><br><span class="pdd-note">' + escapeHtml(a.detalle) + '</span></div></li>';
    });
    html += '</ul>';
    if (snap.alerts.length > 12) html += '<p class="pdd-note">… y ' + (snap.alerts.length - 12) + ' alerta(s) más (ver exportación).</p>';
  }
  focos.innerHTML = html;
  // Bloques 3-5 (resumen compacto: quién / qué / dónde)
  if (resto) {
    let r = '<div class="resumen-trio">';
    r += '<div><h4>👤 Quién — top personas</h4>' + miniLista(snap.personas.filter(function (p) { return !p.muestraPequena; }).slice(0, 5).map(function (p) {
      return { nombre: p.persona, valor: SPEC.formatNum(p.pctDiasConError) + '% días con error', extra: p.errores + ' err · ' + SPEC.formatNum(p.horasAfectadas) + ' h' };
    }), 'Ordenado por % de días con error (excluye MUESTRA PEQUEÑA <' + snap.cfg.minObservaciones + ' días).') + '</div>';
    r += '<div><h4>📦 Qué — top tareas</h4>' + miniLista(snap.tareas.slice(0, 5).map(function (t) {
      return { nombre: t.taskWms, valor: t.errores + ' err (' + SPEC.formatNum(t.pctError) + '%)', extra: SPEC.formatNum(t.horasAfectadas) + ' h' };
    }), 'Errores imputados a la TASK_WMS con volumen de cada incidencia.') + '</div>';
    r += '<div><h4>📍 Dónde — actividad y turno</h4>' + miniLista(snap.actividades.filter(function (a) { return a.errores > 0; }).slice(0, 5).map(function (a) {
      return { nombre: a.actividad, valor: a.errores + ' err', extra: SPEC.formatNum(a.horasAfectadas) + ' h' };
    }), 'Errores imputados solo a la actividad de la tarea afectada (§11).') +
      miniLista(snap.turnos.turnos.map(function (t) {
        return { nombre: 'Turno ' + t.turno, valor: SPEC.formatNum(t.pctError) + '%', extra: t.registros + ' reg.' };
      }), '% persona-día con error por turno (SIN HORA nunca se reparte).') + '</div>';
    r += '</div>';
    resto.innerHTML = r;
  }
}

function miniLista(items, nota) {
  if (!items || items.length === 0) return '<p class="pdd-note">Sin datos.</p>';
  let h = '<ul class="mini-list">';
  items.forEach(function (i) {
    h += '<li><span class="ml-nombre">' + escapeHtml(String(i.nombre).slice(0, 42)) + '</span>' +
      '<span class="ml-valor">' + escapeHtml(String(i.valor)) + '</span>' +
      (i.extra ? '<span class="ml-extra">' + escapeHtml(String(i.extra)) + '</span>' : '') + '</li>';
  });
  h += '</ul>';
  if (nota) h += '<p class="pdd-note">' + escapeHtml(nota) + '</p>';
  return h;
}

/* Orden estable por columna numérica o de texto (usado en tablas patrones). */
function patSorter(rows, col, dir, numCols) {
  const esNum = numCols.indexOf(col) >= 0;
  return rows.slice().sort(function (a, b) {
    let va = a[col], vb = b[col];
    if (esNum) { va = Number(va) || 0; vb = Number(vb) || 0; return (va - vb) * dir; }
    return String(va == null ? '' : va).localeCompare(String(vb == null ? '' : vb)) * dir;
  });
}

function thSortablePAT(id, cols, col, dir, numCols) {
  let h = '<tr>';
  cols.forEach(function (c) {
    const arrow = col === c.key ? (dir === 1 ? ' ↑' : ' ↓') : '';
    h += '<th scope="col" data-col="' + escapeAttr(c.key) + '" class="sortable' + (numCols.indexOf(c.key) >= 0 ? ' num' : '') + '" tabindex="0" role="button" title="Ordenar por ' + escapeAttr(c.label) + '">' + escapeHtml(c.label + arrow) + '</th>';
  });
  h += '</tr>';
  return h;
}

function wireSortablePAT(wrap, id, cols, numCols, onSorted) {
  wrap.querySelectorAll('th[data-col]').forEach(function (th) {
    const handler = function () {
      const c = th.dataset.col;
      const cur = UI.patronesSorts[id] || { col: cols[0].key, dir: -1 };
      if (cur.col === c) UI.patronesSorts[id] = { col: c, dir: -cur.dir };
      else UI.patronesSorts[id] = { col: c, dir: -1 };
      onSorted();
    };
    th.addEventListener('click', handler);
    th.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); handler(); } });
  });
}

/* Vista PERSONAS (§7/§8/§9) — frecuencia + tasa + impacto + confianza +
 * semáforo + muestra pequeña + recurrencia + tendencia. Clic → perfil. */
function renderPersonasView(snap) {
  const wrap = document.getElementById('patrones-view-personas');
  if (!wrap) return;
  if (snap.list.length === 0) { wrap.innerHTML = '<p class="pdd-note">Sin registros para los filtros actuales.</p>'; return; }
  UI.patronesSorts = UI.patronesSorts || {};
  const sort = UI.patronesSorts['personas'] || { col: 'pctError', dir: -1 };
  const tendIdx = {};
  snap.tendPersonas.forEach(function (t) { tendIdx[t.login] = t; });
  const rows = snap.personas.map(function (p) {
    const t = tendIdx[p.login] || {};
    return {
      persona: p.persona, login: p.login, dias: p.dias, diasError: p.diasConError,
      pctError: p.pctDiasConError, incidencias: p.incidencias, incPorDia: p.incidenciasPorDia,
      horas: p.horasAfectadas, pctHoras: p.pctHorasAfectadas, cambios: p.cambiosTarea,
      recurrencia: p.diasConError, racha: p.maxRacha, semaforo: p.semaforo,
      muestra: p.muestraPequena ? 'MUESTRA PEQUEÑA' : '',
      flecha: t.flecha || '—', deltaPP: t.deltaPP != null ? t.deltaPP : null,
      _obj: p
    };
  });
  const cols = [
    { key: 'persona', label: 'Persona' },
    { key: 'dias', label: 'Días' }, { key: 'diasError', label: 'Días con error' },
    { key: 'pctError', label: '% días con error' }, { key: 'incidencias', label: 'Incidencias' },
    { key: 'incPorDia', label: 'Inc./día' }, { key: 'horas', label: 'Horas afectadas' },
    { key: 'pctHoras', label: '% horas afectadas' }, { key: 'cambios', label: 'Cambios tarea' },
    { key: 'recurrencia', label: 'Recurrencia (días)' }, { key: 'racha', label: 'Racha máx.' },
    { key: 'flecha', label: 'Tendencia' }, { key: 'semaforo', label: 'Semáforo' }
  ];
  const numCols = ['dias', 'diasError', 'pctError', 'incidencias', 'incPorDia', 'horas', 'pctHoras', 'cambios', 'recurrencia', 'racha'];
  const sorted = patSorter(rows, sort.col, sort.dir, numCols);
  let html = '<div class="pdd-table-wrap"><table class="data-table patrones-table" id="patrones-personas-table"><caption class="sr-only">Personas: días, errores, horas afectadas y tendencia</caption><thead>' +
    thSortablePAT('patrones-personas-table', cols, sort.col, sort.dir, numCols) + '</thead><tbody>';
  sorted.forEach(function (p) {
    const semCls = 'sem-' + String(p.semaforo).toLowerCase().replace(/[^a-z]/g, '');
    html += '<tr class="pat-row" data-login="' + escapeAttr(p.login) + '" tabindex="0" role="button" title="Ver perfil histórico">' +
      '<td>' + escapeHtml(p.persona) + ' <span class="hint-inline">' + escapeHtml(p.login) + '</span>' + (p.muestra ? ' <span class="badge-mini warn">' + escapeHtml(p.muestra) + '</span>' : '') + '</td>' +
      '<td class="num">' + p.dias + '</td>' +
      '<td class="num">' + p.diasError + '</td>' +
      '<td class="num">' + SPEC.formatNum(p.pctError) + '%' + '</td>' +
      '<td class="num">' + p.incidencias + '</td>' +
      '<td class="num">' + SPEC.formatNum(p.incPorDia) + '</td>' +
      '<td class="num">' + SPEC.formatNum(p.horas) + '</td>' +
      '<td class="num">' + SPEC.formatNum(p.pctHoras) + '%</td>' +
      '<td class="num">' + p.cambios + '</td>' +
      '<td class="num">' + p.recurrencia + '</td>' +
      '<td class="num">' + p.racha + '</td>' +
      '<td class="num tend-' + (p.flecha === '↑' ? 'up' : (p.flecha === '↓' ? 'down' : 'flat')) + '">' + p.flecha + (p.deltaPP != null ? ' ' + (p.deltaPP > 0 ? '+' : '') + SPEC.formatNum(p.deltaPP) + ' pp' : '') + '</td>' +
      '<td><span class="sem-dot ' + semCls + '">' + escapeHtml(p.semaforo) + '</span></td></tr>';
  });
  html += '</tbody></table></div>';
  html += '<p class="pdd-note">Frecuencia (incidencias) y tasa (% días con error = días con error / días analizados) se muestran JUNTAS para no castigar a quien tiene más días analizados (§8). Semáforo: umbrales por defecto ' +
    'MUY BUENO 0% · BUENO ≤' + snap.cfg.semaforoBueno + '% · NORMAL ≤' + snap.cfg.semaforoNormal + '% · ATENCIÓN ≤' + snap.cfg.semaforoAtencion + '% · CRÍTICO >' + snap.cfg.semaforoAtencion + '% (configurables; con <' + snap.cfg.semaforoMinDias + ' días → MUESTRA PEQUEÑA). ' +
    'Tendencia: Δ pp de la tasa entre mitades del rango (requiere ≥' + snap.cfg.minDiasComparar + ' días por mitad). Error = sección ≠ 3.</p>';
  wrap.innerHTML = html;
  wireSortablePAT(wrap, 'patrones-personas-table', cols, numCols, function () { renderPersonasView(snap); });
  wrap.querySelectorAll('tr.pat-row').forEach(function (tr) {
    const open = function () { renderPatronesProfile(snap, 'persona', tr.dataset.login); };
    tr.addEventListener('click', open);
    tr.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } });
  });
}


/* Vista TAREAS — ranking TASK_WMS (§10) con imputación a la tarea afectada. */
function renderTareasView(snap) {
  const wrap = document.getElementById('patrones-view-tareas');
  if (!wrap) return;
  if (snap.list.length === 0) { wrap.innerHTML = '<p class="pdd-note">Sin registros para los filtros actuales.</p>'; return; }
  UI.patronesSorts = UI.patronesSorts || {};
  const sort = UI.patronesSorts['tareas'] || { col: 'errores', dir: -1 };
  const tendIdx = {};
  snap.tendTareas.forEach(function (t) { tendIdx[t.taskWms] = t; });
  const rows = snap.tareas.map(function (t) {
    const td = tendIdx[t.taskWms] || {};
    return {
      taskWms: t.taskWms, actividad: t.actividad, oportunidades: t.oportunidades,
      errores: t.errores, pctError: t.pctError, personas: t.personasN, dias: t.diasN,
      horas: t.horasAfectadas, uds: t.uds, hAsig: t.horasAsignadas,
      prod: t.productividad != null ? t.productividad : '—', fuente: t.fuente,
      muestra: t.muestraPequena ? 'MUESTRA PEQUEÑA' : '',
      flecha: td.flecha || '—', deltaPP: td.deltaPP != null ? td.deltaPP : null
    };
  });
  const cols = [
    { key: 'taskWms', label: 'TASK_WMS' }, { key: 'actividad', label: 'Actividad' },
    { key: 'oportunidades', label: 'Oportunidades' }, { key: 'errores', label: 'Errores' },
    { key: 'pctError', label: '% error' }, { key: 'personas', label: 'Personas' },
    { key: 'dias', label: 'Días' }, { key: 'horas', label: 'Horas afectadas' },
    { key: 'uds', label: 'UDS' }, { key: 'hAsig', label: 'H asignadas' },
    { key: 'flecha', label: 'Tendencia' }
  ];
  const numCols = ['oportunidades', 'errores', 'pctError', 'personas', 'dias', 'horas', 'uds', 'hAsig'];
  const sorted = patSorter(rows, sort.col, sort.dir, numCols);
  let html = '<div class="pdd-table-wrap"><table class="data-table patrones-table" id="patrones-tareas-table"><caption class="sr-only">Ranking de TASK_WMS por errores</caption><thead>' +
    thSortablePAT('patrones-tareas-table', cols, sort.col, sort.dir, numCols) + '</thead><tbody>';
  sorted.forEach(function (t) {
    html += '<tr class="pat-row" data-task="' + escapeAttr(t.taskWms) + '" tabindex="0" role="button" title="Ver detalle de la tarea">' +
      '<td>' + escapeHtml(t.taskWms) + (t.muestra ? ' <span class="badge-mini warn">' + escapeHtml(t.muestra) + '</span>' : '') + '</td>' +
      '<td>' + escapeHtml(t.actividad) + '</td>' +
      '<td class="num" title="Persona-día en los que la tarea tuvo volumen">' + t.oportunidades + '</td>' +
      '<td class="num">' + t.errores + '</td>' +
      '<td class="num">' + SPEC.formatNum(t.pctError) + '%</td>' +
      '<td class="num">' + t.personas + '</td>' +
      '<td class="num">' + t.dias + '</td>' +
      '<td class="num">' + SPEC.formatNum(t.horas) + '</td>' +
      '<td class="num">' + SPEC.formatNum0(t.uds) + '</td>' +
      '<td class="num">' + SPEC.formatNum(t.hAsig) + '</td>' +
      '<td class="num tend-' + (t.flecha === '↑' ? 'up' : (t.flecha === '↓' ? 'down' : 'flat')) + '">' + t.flecha + (t.deltaPP != null ? ' ' + (t.deltaPP > 0 ? '+' : '') + SPEC.formatNum(t.deltaPP) + ' pp' : '') + '</td></tr>';
  });
  html += '</tbody></table></div>';
  html += '<p class="pdd-note">Oportunidades = persona-día en los que la TASK_WMS tuvo volumen. Errores = incidencias imputadas SOLO a la tarea realmente afectada (la TASK_WMS con volumen de la propuesta — §11: nunca a todas las tareas del día). ' +
    'Tasa = errores / oportunidades. MUESTRA PEQUEÑA si oportunidades < ' + snap.cfg.minObservaciones + '. Tendencia: Δ pp entre mitades con ≥' + snap.cfg.minObservaciones + ' oportunidades por mitad.</p>';
  // Tareas en mejora / deterioro (§20/§21)
  const mejora = snap.tendTareas.filter(function (t) { return t.veredicto === 'MEJORA'; });
  const deterioro = snap.tendTareas.filter(function (t) { return t.veredicto === 'EMPEORA'; });
  html += '<div class="ea-grid"><div><h4>📈 Tareas en mejora</h4>' + miniLista(mejora.slice(0, 8).map(function (t) {
    return { nombre: t.taskWms, valor: (t.tasaA != null ? SPEC.formatNum(t.tasaA) : '—') + '% → ' + (t.tasaB != null ? SPEC.formatNum(t.tasaB) : '—') + '%', extra: 'Δ ' + SPEC.formatNum(t.deltaPP) + ' pp' };
  }), 'Δ pp de la tasa entre mitades, con evidencia suficiente.') + '</div>' +
    '<div><h4>📉 Tareas en deterioro</h4>' + miniLista(deterioro.slice(0, 8).map(function (t) {
      return { nombre: t.taskWms, valor: (t.tasaA != null ? SPEC.formatNum(t.tasaA) : '—') + '% → ' + (t.tasaB != null ? SPEC.formatNum(t.tasaB) : '—') + '%', extra: 'Δ +' + SPEC.formatNum(t.deltaPP) + ' pp' };
    }), 'Δ pp de la tasa entre mitades, con evidencia suficiente.') + '</div></div>';
  wrap.innerHTML = html;
  wireSortablePAT(wrap, 'patrones-tareas-table', cols, numCols, function () { renderTareasView(snap); });
  wrap.querySelectorAll('tr.pat-row').forEach(function (tr) {
    const open = function () { renderPatronesProfile(snap, 'tarea', tr.dataset.task); };
    tr.addEventListener('click', open);
    tr.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } });
  });
}

/* Vista ACTIVIDADES (§11/§28) + turnos (§27) + análisis OTRA (§29). */
function renderActividadesView(snap) {
  const wrap = document.getElementById('patrones-view-actividades');
  if (!wrap) return;
  if (snap.list.length === 0) { wrap.innerHTML = '<p class="pdd-note">Sin registros para los filtros actuales.</p>'; return; }
  const partes = window.SPEC_AN.partirPorMitades(snap.list);
  const stA = window.SPEC_AN.activity.computeActivityStats(partes.A, snap.cfg);
  const stB = window.SPEC_AN.activity.computeActivityStats(partes.B, snap.cfg);
  const ix = {};
  stA.forEach(function (a) { ix[a.actividad] = a; });
  const ixB = {};
  stB.forEach(function (a) { ixB[a.actividad] = a; });
  let html = '<h4>Actividades</h4><div class="pdd-table-wrap"><table class="data-table patrones-table" id="patrones-actividades-table"><caption class="sr-only">Actividades con errores y horas</caption><thead><tr>' +
    '<th scope="col">Actividad</th><th scope="col">Oportunidades</th><th scope="col">Errores</th><th scope="col">% error</th><th scope="col">Personas</th><th scope="col">Días</th><th scope="col">Horas afectadas</th><th scope="col">UDS</th><th scope="col">H asignadas</th><th scope="col">Nº tareas</th><th scope="col">Tendencia</th></tr></thead><tbody>';
  snap.actividades.forEach(function (a) {
    const anterior = ix[a.actividad], actual = ixB[a.actividad];
    let flecha = '—', delta = null;
    if (anterior && actual && anterior.oportunidades >= snap.cfg.minObservaciones && actual.oportunidades >= snap.cfg.minObservaciones) {
      delta = window.SPEC_AN.round2(actual.pctError - anterior.pctError);
      flecha = window.SPEC_AN.flechaTendencia(delta, snap.cfg.umbralCambioPP);
    }
    const cls = a.actividad === 'OTRA' ? ' class="fila-otra"' : '';
    html += '<tr' + cls + ' data-actividad="' + escapeAttr(a.actividad) + '" tabindex="0" role="button" title="Ver detalle de la actividad">' +
      '<td>' + escapeHtml(a.actividad) + (a.muestraPequena ? ' <span class="badge-mini warn">MUESTRA PEQUEÑA</span>' : '') + '</td>' +
      '<td class="num">' + a.oportunidades + '</td>' +
      '<td class="num">' + a.errores + '</td>' +
      '<td class="num">' + SPEC.formatNum(a.pctError) + '%</td>' +
      '<td class="num">' + a.personas + '</td>' +
      '<td class="num">' + a.dias + '</td>' +
      '<td class="num">' + SPEC.formatNum(a.horasAfectadas) + '</td>' +
      '<td class="num">' + SPEC.formatNum0(a.uds) + '</td>' +
      '<td class="num">' + SPEC.formatNum(a.horasAsignadas) + '</td>' +
      '<td class="num">' + a.nTareas + '</td>' +
      '<td class="num tend-' + (flecha === '↑' ? 'up' : (flecha === '↓' ? 'down' : 'flat')) + '">' + flecha + (delta != null ? ' ' + (delta > 0 ? '+' : '') + SPEC.formatNum(delta) + ' pp' : '') + '</td></tr>';
  });
  html += '</tbody></table></div>';
  html += '<p class="pdd-note">Los errores se imputan a la actividad de la TASK_WMS afectada por cada incidencia (§11: no se copian al resto de actividades del día). Oportunidades = apariciones persona-día-actividad. OTRA se muestra SIEMPRE (no se oculta): volumen sin clasificación productiva.</p>';
  // Turnos (§27)
  html += '<h4>Turnos</h4><div class="pdd-table-wrap"><table class="data-table patrones-table"><caption class="sr-only">Errores por turno</caption><thead><tr>' +
    '<th scope="col">Turno</th><th scope="col">Registros</th><th scope="col">Con error</th><th scope="col">% error</th><th scope="col">Incidencias</th><th scope="col">Errores asignación</th><th scope="col">Horas afectadas</th><th scope="col">% horas afectadas</th><th scope="col">Tendencia Δpp</th></tr></thead><tbody>';
  snap.turnos.turnos.forEach(function (t) {
    const td = snap.turnos.tendencia[t.turno] || {};
    html += '<tr><td>' + escapeHtml(t.turno) + '</td>' +
      '<td class="num">' + t.registros + '</td>' +
      '<td class="num">' + t.conError + '</td>' +
      '<td class="num">' + SPEC.formatNum(t.pctError) + '%</td>' +
      '<td class="num">' + t.incidencias + '</td>' +
      '<td class="num">' + t.erroresAsignacion + '</td>' +
      '<td class="num">' + SPEC.formatNum(t.horasAfectadas) + '</td>' +
      '<td class="num">' + SPEC.formatNum(t.pctHorasAfectadas) + '%</td>' +
      '<td class="num">' + (td.deltaPP != null ? (td.deltaPP > 0 ? '+' : '') + SPEC.formatNum(td.deltaPP) + ' pp' : '—') + '</td></tr>';
  });
  html += '</tbody></table></div>';
  html += '<p class="pdd-note">NOCHE usa FECHA_OPERATIVA_TURNO (22:00–06:00 del día operativo anterior). Los registros SIN HORA permanecen como SIN HORA y no se reparten artificialmente. Tendencia: Δ pp de la tasa entre mitades (mín. ' + snap.cfg.minDiasComparar + ' registros por mitad).</p>';
  // OTRA (§29)
  const otra = snap.actividades.filter(function (a) { return a.actividad === 'OTRA'; })[0];
  if (otra) {
    const otrasTareas = snap.mq.tareasOtra;
    html += '<h4>🧩 Análisis de OTRA</h4><div class="kpi-grid">' +
      kpiCardPAT('Tareas OTRA', otrasTareas.length, 'TASK_WMS distintas clasificadas OTRA en el histórico filtrado.', 'warn') +
      kpiCardPAT('UDS en OTRA', SPEC.formatNum0(otra.uds), 'Σ uds de tareas OTRA.', 'warn') +
      kpiCardPAT('Registros con OTRA', otra.oportunidades, 'Persona-día con alguna tarea OTRA.', 'warn') +
      '</div>';
    if (otrasTareas.length > 0) {
      html += '<p class="pdd-note">⚠ Hay ' + otrasTareas.length + ' TASK_WMS sin clasificación productiva. Clasifícalas desde ⚙ Productividades → PRODUCTIVIDAD POR TAREA si deben entrar en el reparto.</p>';
      html += miniLista(otrasTareas.slice(0, 10).map(function (t) {
        return { nombre: t.taskWms, valor: SPEC.formatNum0(t.uds) + ' uds', extra: t.dias + ' d · ' + t.personas + ' pers.' };
      }), 'Tareas OTRA ordenadas por uds.');
    }
  }
  wrap.innerHTML = html;
  wrap.querySelectorAll('#patrones-actividades-table tbody tr').forEach(function (tr) {
    const open = function () { renderPatronesProfile(snap, 'actividad', tr.dataset.actividad); };
    tr.addEventListener('click', open);
    tr.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } });
  });
}

/* Vista ERRORES — matriz fichada→correcta (§12/§13), recurrencias (§22/§23)
 * y tareas que peor se fichan (espacio HR Task). */
function renderErroresView(snap) {
  const wrap = document.getElementById('patrones-view-errores');
  if (!wrap) return;
  if (snap.list.length === 0) { wrap.innerHTML = '<p class="pdd-note">Sin registros para los filtros actuales.</p>'; return; }
  let html = '';
  // 1) Ranking de tareas fichadas (espacio HR Task)
  html += '<h4>Tareas que peor se fichan (espacio HR Task)</h4>';
  const fich = snap.fichaje.filter(function (f) { return f.erroresCambio > 0; });
  if (fich.length === 0) {
    html += '<p class="pdd-note">Sin errores de fichaje (sección 1) con los filtros actuales.</p>';
  } else {
    html += '<div class="pdd-table-wrap"><table class="data-table patrones-table"><caption class="sr-only">Tareas fichadas con más cambios propuestos</caption><thead><tr>' +
      '<th scope="col">HR Task fichada</th><th scope="col">Fichajes</th><th scope="col">Cambios propuestos</th><th scope="col">Correctas</th><th scope="col">% cambio</th><th scope="col">Personas</th><th scope="col">Horas</th><th scope="col">Propuesta habitual</th></tr></thead><tbody>';
    fich.slice(0, 30).forEach(function (f) {
      html += '<tr><td>' + escapeHtml(f.hrTask) + (f.muestraPequena ? ' <span class="badge-mini warn">MUESTRA PEQUEÑA</span>' : '') + '</td>' +
        '<td class="num">' + f.fichajes + '</td>' +
        '<td class="num">' + f.erroresCambio + '</td>' +
        '<td class="num">' + f.correctas + '</td>' +
        '<td class="num">' + SPEC.formatNum(f.tasaCambio) + '%</td>' +
        '<td class="num">' + f.personas + '</td>' +
        '<td class="num">' + SPEC.formatNum(f.horasAfectadas) + '</td>' +
        '<td>' + escapeHtml(f.propuestaHabitual || '—') + '</td></tr>';
    });
    html += '</tbody></table></div>';
    html += '<p class="pdd-note">% cambio = cambios propuestos / (cambios + correctas): proporción de veces que esa tarea fichada acaba con propuesta de cambio. Fichajes = nº de registros de horas con esa HR Task.</p>';
  }
  // 2) Matriz fichada→correcta (§12)
  html += '<h4>Matriz tarea fichada → tarea correcta (confusiones)</h4>';
  if (snap.matrix.length === 0) {
    html += '<p class="pdd-note">Sin confusiones (sección 1) con los filtros actuales.</p>';
  } else {
    html += '<div class="pdd-table-wrap"><table class="data-table patrones-table" id="confusion-table"><caption class="sr-only">Matriz de confusiones fichada a correcta</caption><thead><tr>' +
      '<th scope="col">Fichada</th><th scope="col">Correcta (propuesta)</th><th scope="col">Casos</th><th scope="col">Personas</th><th scope="col">Días</th><th scope="col">Horas</th><th scope="col">TASK_WMS origen</th></tr></thead><tbody>';
    snap.matrix.slice(0, 50).forEach(function (cel) {
      html += '<tr><td>' + escapeHtml(cel.origen) + '</td><td>' + escapeHtml(cel.destino) + '</td>' +
        '<td class="num">' + cel.casos + '</td><td class="num">' + cel.personas + '</td>' +
        '<td class="num">' + cel.dias + '</td><td class="num">' + SPEC.formatNum(cel.horas) + '</td>' +
        '<td class="t-wms">' + escapeHtml(cel.wmsTasks.slice(0, 2).join(' · ')) + '</td></tr>';
    });
    html += '</tbody></table></div>';
    // 3) Heatmap (§13) + tabla siempre disponible
    html += '<h5>Mapa de calor (casos fichada→correcta)</h5>' + patHeatmap(snap.matrix);
  }
  // 4) Errores recurrentes (§22) + persistencia (§23)
  html += '<h4>Errores recurrentes (persona + confusión)</h4>';
  const recs = snap.recurrencias.filter(function (r) { return r.dias >= 2; });
  if (recs.length === 0) {
    html += '<p class="pdd-note">Sin errores recurrentes (2+ días) con los filtros actuales. Todo error es AISLADO (1 día).</p>';
  } else {
    html += '<div class="pdd-table-wrap"><table class="data-table patrones-table"><caption class="sr-only">Errores recurrentes por persona</caption><thead><tr>' +
      '<th scope="col">Persona</th><th scope="col">Confusión</th><th scope="col">Días</th><th scope="col">Casos</th><th scope="col">Horas</th><th scope="col">Persistencia</th><th scope="col">Turnos</th></tr></thead><tbody>';
    recs.slice(0, 40).forEach(function (r) {
      html += '<tr><td>' + escapeHtml(r.persona) + '</td>' +
        '<td>' + escapeHtml(r.origen + ' → ' + r.destino) + '</td>' +
        '<td class="num">' + r.dias + '</td><td class="num">' + r.casos + '</td>' +
        '<td class="num">' + SPEC.formatNum(r.horas) + '</td>' +
        '<td><span class="badge-mini ' + (r.persistencia === 'HABITUAL' ? 'error' : (r.persistencia === 'RECURRENTE' ? 'warn' : '')) + '">' + escapeHtml(r.persistencia) + '</span></td>' +
        '<td>' + escapeHtml(r.turnos.join(', ')) + '</td></tr>';
    });
    html += '</tbody></table></div>';
    html += '<p class="pdd-note">Persistencia (umbrales configurables): AISLADO = 1 día · RECURRENTE = 2-' + snap.cfg.recurrenciaRecurrente + ' días · HABITUAL = >' + snap.cfg.recurrenciaRecurrente + ' días.</p>';
  }
  wrap.innerHTML = html;
}

/* Vista EVOLUCIÓN (§14/§15/§16/§47/§17) — series + media móvil + periodos. */
function renderEvolucionView(snap) {
  const container = document.getElementById('patrones-evolucion');
  const periodosWrap = document.getElementById('patrones-periodos');
  if (!container) return;
  if (snap.list.length === 0) { container.innerHTML = '<p class="pdd-note">Sin registros para los filtros actuales.</p>'; if (periodosWrap) periodosWrap.innerHTML = ''; return; }
  const gran = (document.getElementById('evol-granularidad') || {}).value || UI.evolGranularidad || 'dia';
  UI.evolGranularidad = gran;
  if (gran === 'semana' || gran === 'mes') {
    const serie = gran === 'semana' ? snap.semanal : snap.mensual;
    const label = gran === 'semana' ? 'semana ISO' : 'mes';
    container.innerHTML =
      '<h4>Persona-día con error y % de error por ' + label + '</h4>' +
      evolSvgChart(serie.map(function (s) { return { label: s.clave, horas: s.registros, horasInc: s.conError, incs: s.incidencias }; }), 'horas', 'horasInc') +
      '<h4>Incidencias por ' + label + '</h4>' +
      evolSvgChart(serie.map(function (s) { return { label: s.clave, value: s.incidencias }; }), 'value') +
      '<h4>Δ frente al ' + label + ' anterior</h4>' +
      '<div class="pdd-table-wrap"><table class="data-table patrones-table"><caption class="sr-only">Cambio entre ' + label + 's consecutivas</caption><thead><tr><th scope="col">' + (gran === 'semana' ? 'Semana' : 'Mes') + '</th><th scope="col">Incidencias</th><th scope="col">Δ incidencias</th><th scope="col">% persona-día con error</th><th scope="col">Δ pp</th><th scope="col">Horas afectadas</th></tr></thead><tbody>' +
      serie.map(function (s) {
        return '<tr><td>' + escapeHtml(s.clave) + '</td><td class="num">' + s.incidencias + '</td>' +
          '<td class="num">' + (s.deltaIncidencias != null ? (s.deltaIncidencias > 0 ? '+' : '') + s.deltaIncidencias : '—') + '</td>' +
          '<td class="num">' + SPEC.formatNum(s.pctPersonaDiaError) + '%</td>' +
          '<td class="num">' + (s.deltaPP != null ? (s.deltaPP > 0 ? '+' : '') + SPEC.formatNum(s.deltaPP) + ' pp' : '—') + '</td>' +
          '<td class="num">' + SPEC.formatNum(s.horasAfectadas) + '</td></tr>';
      }).join('') + '</tbody></table></div>';
  } else {
    const d = snap.daily;
    container.innerHTML =
      '<h4>Evolución diaria — % persona-día con error' + (d.serie.length >= snap.cfg.ventanaMediaMovil ? ' (línea = media móvil ' + snap.cfg.ventanaMediaMovil + ' días)' : ' (sin media móvil: se necesita ≥' + snap.cfg.ventanaMediaMovil + ' días)') + '</h4>' +
      patLineChart(d.serie, 'pctPersonaDiaError', 'mediaMovilTasa', '%', 'mediaMovilTasa') +
      '<h4>Incidencias por día' + (d.serie.length >= snap.cfg.ventanaMediaMovil ? ' (con media móvil ' + snap.cfg.ventanaMediaMovil + 'd)' : '') + '</h4>' +
      patLineChart(d.serie, 'incidencias', 'mediaMovilIncidencias', 'n', 'mediaMovilIncidencias') +
      '<h4>Horas afectadas por día</h4>' +
      patLineChart(d.serie, 'horasAfectadas', 'mediaMovilHoras', 'h', 'mediaMovilHoras') +
      '<h4>Desglose diario</h4>' +
      '<div class="pdd-table-wrap"><table class="data-table patrones-table"><caption class="sr-only">Detalle diario</caption><thead><tr><th scope="col">Fecha operativa</th><th scope="col">Registros</th><th scope="col">Con error</th><th scope="col">% error</th><th scope="col">Incidencias</th><th scope="col">Errores asign.</th><th scope="col">Horas afectadas</th><th scope="col">% horas</th><th scope="col">MM' + snap.cfg.ventanaMediaMovil + ' tasa</th><th scope="col">Rolling 7d</th></tr></thead><tbody>' +
      d.serie.map(function (s) {
        return '<tr><td>' + escapeHtml(s.fechaISO) + '</td><td class="num">' + s.registros + '</td>' +
          '<td class="num">' + s.conError + '</td><td class="num">' + SPEC.formatNum(s.pctPersonaDiaError) + '%</td>' +
          '<td class="num">' + s.incidencias + '</td><td class="num">' + s.erroresAsignacion + '</td>' +
          '<td class="num">' + SPEC.formatNum(s.horasAfectadas) + '</td><td class="num">' + SPEC.formatNum(s.pctHorasAfectadas) + '%</td>' +
          '<td class="num">' + (s.mediaMovilTasa != null ? SPEC.formatNum(s.mediaMovilTasa) + '%' : '—') + '</td>' +
          '<td class="num">' + (s.rolling7 ? s.rolling7.incidencias + ' inc / ' + s.rolling7.tasa + '%' : '—') + '</td></tr>';
      }).join('') + '</tbody></table></div>' +
      (d.rolling.ultimo7 ? '<p class="pdd-note">Rolling 7 días (último día con datos): ' + d.rolling.ultimo7.incidencias + ' incidencias sobre ' + d.rolling.ultimo7.registros + ' persona-día (' + d.rolling.ultimo7.tasa + '%).</p>' : '') +
      (d.rolling.ultimo28 ? '<p class="pdd-note">Rolling 28 días: ' + d.rolling.ultimo28.incidencias + ' incidencias sobre ' + d.rolling.ultimo28.registros + ' persona-día (' + d.rolling.ultimo28.tasa + '%).</p>' : '');
  }
  // Comparación de periodos (§17) — mitades del rango filtrado
  if (periodosWrap) {
    const c = snap.comp;
    const et = window.SPEC_AN.etiquetaComparacion(c, snap.cfg);
    let h = '<h4>Comparación de periodos (mitades del rango filtrado)</h4>';
    h += '<div class="kpi-grid">' +
      kpiCardPAT('Periodo A (anterior)', c.A.personaDia + ' reg · ' + c.A.dias + ' días', 'Primera mitad de las fechas filtradas.', 'info') +
      kpiCardPAT('Periodo B (actual)', c.B.personaDia + ' reg · ' + c.B.dias + ' días', 'Segunda mitad de las fechas filtradas.', 'info') +
      kpiCardPAT('Incidencias', c.A.incidencias + ' → ' + c.B.incidencias, 'Δ ' + (c.cambios.incidencias > 0 ? '+' : '') + SPEC.formatNum(c.cambios.incidencias) + (c.cambios.incidenciasPct != null ? ' (' + (c.cambios.incidenciasPct > 0 ? '+' : '') + SPEC.formatNum(c.cambios.incidenciasPct) + '%)' : ' (sin base)'), (c.cambios.incidencias > 0 ? 'error' : 'success')) +
      kpiCardPAT('% persona-día con error', SPEC.formatNum(c.A.pctPersonaDiaConError) + '% → ' + SPEC.formatNum(c.B.pctPersonaDiaConError) + '%', 'Δ ' + (c.cambios.pctPersonaDiaConError.deltaPP > 0 ? '+' : '') + SPEC.formatNum(c.cambios.pctPersonaDiaConError.deltaPP) + ' pp', (c.cambios.pctPersonaDiaConError.deltaPP > 0 ? 'error' : 'success')) +
      kpiCardPAT('Horas afectadas', SPEC.formatNum(c.A.horasAfectadas) + ' → ' + SPEC.formatNum(c.B.horasAfectadas) + ' h', 'Δ ' + (c.cambios.horasAfectadas > 0 ? '+' : '') + SPEC.formatNum(c.cambios.horasAfectadas) + ' h', (c.cambios.horasAfectadas > 0 ? 'error' : 'success')) +
      kpiCardPAT('Errores asignación', c.A.erroresAsignacion + ' → ' + c.B.erroresAsignacion, 'Sección 1 + aceptadas por periodo.', 'info') +
      kpiCardPAT('Personas', c.A.personas + ' → ' + c.B.personas, 'Logins distintos por periodo.', 'info') +
      kpiCardPAT('Veredicto', et, 'MEJORA / EMPEORA / SIN CAMBIO según Δ pp con umbral ±' + snap.cfg.umbralCambioPP + ' pp.', (et === 'MEJORA' ? 'success' : (et === 'EMPEORA' ? 'error' : 'info'))) +
      '</div>';
    // Mejoran / empeoran (§18/§19)
    const mejoran = snap.tendPersonas.filter(function (t) { return t.veredicto === 'MEJORA'; });
    const empeoran = snap.tendPersonas.filter(function (t) { return t.veredicto === 'EMPEORA'; });
    h += '<div class="ea-grid"><div><h4>📈 Personas que más mejoran</h4>' + miniLista(mejoran.slice(0, 8).map(function (t) {
      return { nombre: t.persona, valor: SPEC.formatNum(t.tasaA) + '% → ' + SPEC.formatNum(t.tasaB) + '%', extra: 'Δ ' + SPEC.formatNum(t.deltaPP) + ' pp' };
    }), 'Δ en pp de días con error entre mitades (mín. ' + snap.cfg.minDiasComparar + ' días por mitad).') + '</div>' +
      '<div><h4>📉 Personas que empeoran</h4>' + miniLista(empeoran.slice(0, 8).map(function (t) {
        return { nombre: t.persona, valor: SPEC.formatNum(t.tasaA) + '% → ' + SPEC.formatNum(t.tasaB) + '%', extra: 'Δ +' + SPEC.formatNum(t.deltaPP) + ' pp' };
      }), 'Empeoramiento SOSTENIDO: solo con evidencia suficiente (nunca con 1 día).') + '</div></div>';
    periodosWrap.innerHTML = h;
  }
}

/* Vista PARETO (§24/§25/§26) — concentración + matriz frecuencia×impacto. */
function renderParetoView(snap) {
  const wrap = document.getElementById('patrones-view-pareto');
  if (!wrap) return;
  if (snap.list.length === 0) { wrap.innerHTML = '<p class="pdd-note">Sin registros para los filtros actuales.</p>'; return; }
  const AN = window.SPEC_AN;
  let html = '';
  const paretos = [
    { titulo: 'Pareto de tareas (por errores)', p: snap.paretoTareas.porErrores, nombre: 'TASK_WMS' },
    { titulo: 'Pareto de tareas (por horas afectadas)', p: snap.paretoTareas.porHoras, nombre: 'TASK_WMS' },
    { titulo: 'Pareto de personas (por errores)', p: snap.paretoPersonas, nombre: 'Persona' },
    { titulo: 'Pareto de actividades (por errores)', p: snap.paretoActividades, nombre: 'Actividad' }
  ];
  paretos.forEach(function (x) {
    html += '<h4>' + escapeHtml(x.titulo) + '</h4>';
    if (x.p.items.length === 0) {
      html += '<p class="pdd-note">Sin datos con valor > 0.</p>';
      return;
    }
    const n80 = x.p.nPara80, pct80 = x.p.pctElementos80;
    html += '<p class="pdd-note">' +
      (x.p.cumple8020
        ? '✔ La regla 80/20 SE CUMPLE: el ' + pct80 + '% de los elementos (' + n80 + ' de ' + x.p.nElementos + ') concentra el 80% del total (' + x.p.total + ').'
        : '✘ La regla 80/20 NO se cumple: hacen falta el ' + pct80 + '% de los elementos (' + n80 + ' de ' + x.p.nElementos + ') para llegar al 80% del total (' + x.p.total + '). El problema está más repartido.') +
      ' Comprobación real sobre los datos (nunca afirmada por defecto).</p>';
    html += patParetoChart(x.p);
    html += '<div class="pdd-table-wrap"><table class="data-table patrones-table"><caption class="sr-only">Curva de Pareto</caption><thead><tr>' +
      '<th scope="col">' + x.nombre + '</th><th scope="col">Valor</th><th scope="col">% individual</th><th scope="col">% acumulado</th></tr></thead><tbody>' +
      x.p.items.slice(0, 20).map(function (i) {
        return '<tr><td>' + escapeHtml(String(i.taskWms || i.persona || i.actividad || i.nombre || '').slice(0, 48)) + '</td>' +
          '<td class="num">' + SPEC.formatNum(i.valor) + '</td>' +
          '<td class="num">' + SPEC.formatNum(i.pctIndividual) + '%</td>' +
          '<td class="num">' + SPEC.formatNum(i.pctAcumulado) + '%</td></tr>';
      }).join('') + '</tbody></table></div>';
  });
  // Matriz frecuencia × impacto (§26)
  html += '<h4>Matriz frecuencia × impacto (prioridades reales)</h4>';
  const itemsT = snap.tareas.map(function (t) { return { nombre: t.taskWms, tipo: 'TAREA', errores: t.errores, horasAfectadas: t.horasAfectadas }; });
  const itemsP = snap.personas.map(function (p) { return { nombre: p.persona, tipo: 'PERSONA', errores: p.errores, horasAfectadas: p.horasAfectadas }; });
  const fiT = AN.trend.computeFrecuenciaImpacto(itemsT);
  const fiP = AN.trend.computeFrecuenciaImpacto(itemsP);
  html += patScatter(fiT, 'Tareas') + patScatter(fiP, 'Personas');
  html += '<p class="pdd-note">Cuadrantes por MEDIANA del conjunto (documentado): arriba-derecha = alto volumen y alto impacto (actuar primero); arriba-izquierda = bajo volumen pero alto impacto (errores caros); abajo-derecha = mucho ruido de bajo impacto; abajo-izquierda = anecdótico.</p>';
  wrap.innerHTML = html;
}

/* Vista CALIDAD DE DATOS (§49/§50/§30/§31). */
function renderCalidadView(snap) {
  const wrap = document.getElementById('patrones-view-calidad');
  if (!wrap) return;
  if (snap.list.length === 0) { wrap.innerHTML = '<p class="pdd-note">Sin registros para los filtros actuales.</p>'; return; }
  const dq = snap.dq, mq = snap.mq;
  let html = '<h4>Calidad de datos</h4><div class="kpi-grid">' +
    kpiCardPAT('Días cargados', dq.diasCargados, 'Fechas operativas distintas del histórico filtrado.', 'info') +
    kpiCardPAT('Registros válidos', dq.registrosValidos, 'Persona-día analizados.', 'info') +
    kpiCardPAT('Registros SIN HORA', dq.registrosSinHora + ' (' + SPEC.formatNum(dq.pctSinHora) + '%)', 'Ficheros day-level sin hora de fichaje: no se les asigna turno.', 'warn') +
    kpiCardPAT('Registros con OTRA', dq.registrosOtra, 'Persona-día con alguna tarea OTRA (sin clasificación productiva).', 'warn') +
    kpiCardPAT('Casos SIN MAPPING', dq.casosSinMapping, 'Incidencias sección 5: volumen sin TASKSPEC única.', 'error') +
    kpiCardPAT('Datos incompletos', dq.datosIncompletos, 'Secciones 4 (sin volumen) + 6/7 (revisión manual).', 'error') +
    kpiCardPAT('Versiones por reprocesado', dq.duplicadosVersionados, 'Cambios de versión en el histórico (trazabilidad, NO duplicados).', 'info') +
    kpiCardPAT('UDS sin horas (archivo)', SPEC.formatNum0(dq.udsSinHorasArchivo), 'Σ uds de VOL SIN HORAS (informativo, fuera del reparto).', 'info') +
    '</div>';
  // Reparto de causas (§50)
  html += '<h4>Separación de causas — ¿problema operativo o de datos?</h4><div class="kpi-grid">' +
    kpiCardPAT('Operativo (personas)', dq.repartoCausas.operativo.casos + ' (' + SPEC.formatNum(dq.repartoCausas.operativo.pct) + '%)', 'Secciones 1 (fichaje) y 4 (horas sin volumen): comportamiento operativo.', 'error') +
    kpiCardPAT('Datos / mapping', dq.repartoCausas.datos.casos + ' (' + SPEC.formatNum(dq.repartoCausas.datos.pct) + '%)', 'Secciones 2 (ambigüedad) y 5 (sin mapping): el problema está en el mapping, no en las personas.', 'warn') +
    kpiCardPAT('Revisión manual', dq.repartoCausas.revision.casos + ' (' + SPEC.formatNum(dq.repartoCausas.revision.pct) + '%)', 'Secciones 6/7: no imputable automáticamente.', 'info') +
    kpiCardPAT('Control (correctas)', dq.repartoCausas.control.casos + ' (' + SPEC.formatNum(dq.repartoCausas.control.pct) + '%)', 'Sección 3: tarea fichada correcta (no son errores).', 'success') +
    '</div>';
  // Tipos
  html += '<h4>Incidencias por tipo</h4>';
  if (dq.tipos.length === 0) {
    html += '<p class="pdd-note">Sin incidencias.</p>';
  } else {
    html += '<div class="pdd-table-wrap"><table class="data-table patrones-table"><caption class="sr-only">Incidencias por tipo de error</caption><thead><tr><th scope="col">Tipo</th><th scope="col">Categoría</th><th scope="col">Casos</th><th scope="col">% de incidencias</th><th scope="col">Horas</th><th scope="col">Personas</th><th scope="col">Días</th></tr></thead><tbody>' +
      dq.tipos.map(function (t) {
        return '<tr><td>' + escapeHtml(t.tipo) + '</td><td>' + escapeHtml(t.categoria) + '</td><td class="num">' + t.casos + '</td>' +
          '<td class="num">' + SPEC.formatNum(t.pctSobreIncidencias) + '%</td><td class="num">' + SPEC.formatNum(t.horas) + '</td>' +
          '<td class="num">' + t.personas + '</td><td class="num">' + t.dias + '</td></tr>';
      }).join('') + '</tbody></table></div>';
  }
  // Calidad del mapping (§30/§31)
  html += '<h4>Calidad del mapping</h4><div class="kpi-grid">' +
    kpiCardPAT('Tareas clasificadas', mq.tareasClasificadas, 'TASK_WMS distintas con actividad productiva en el histórico filtrado.', 'info') +
    kpiCardPAT('Tareas SIN mapping', mq.tareasSinMapping.length, 'TASK_WMS con incidencias sección 5 (sin TASKSPEC única).', (mq.tareasSinMapping.length > 0 ? 'error' : 'success')) +
    kpiCardPAT('Tareas ambiguas', mq.tareasAmbiguas.length, 'Tareas/HR Task con sección 2 (varias TASKSPEC con volumen).', (mq.tareasAmbiguas.length > 0 ? 'warn' : 'success')) +
    kpiCardPAT('Tareas OTRA', mq.tareasOtra.length, 'Con volumen y sin clasificación productiva.', (mq.tareasOtra.length > 0 ? 'warn' : 'success')) +
    kpiCardPAT('Cambios de mapping', mq.cambiosMapping, 'Mappings distintos − 1 en el histórico filtrado (los periodos no se mezclan: cada registro conserva su hash).', 'info') +
    '</div>';
  if (mq.tareasSinMapping.length > 0) {
    html += '<p class="pdd-note">⚠ Tareas sin mapping (casos):</p>' + miniLista(mq.tareasSinMapping.slice(0, 10).map(function (t) {
      return { nombre: t.taskWms, valor: t.casos + ' casos', extra: '' };
    }), null);
  }
  if (mq.mappings.length > 1) {
    html += '<h5>Histórico de mappings usados</h5><div class="pdd-table-wrap"><table class="data-table patrones-table"><caption class="sr-only">Mappings usados en el histórico</caption><thead><tr><th scope="col">Hash (SHA-256)</th><th scope="col">Registros</th><th scope="col">Primera fecha</th><th scope="col">Última fecha</th></tr></thead><tbody>' +
      mq.mappings.map(function (m) {
        return '<tr><td class="t-wms">' + escapeHtml(String(m.hash).slice(0, 16)) + '…</td><td class="num">' + m.registros + '</td><td>' + escapeHtml(m.primeraFecha || '—') + '</td><td>' + escapeHtml(m.ultimaFecha || '—') + '</td></tr>';
      }).join('') + '</tbody></table></div>';
  }
  wrap.innerHTML = html;
}

/* Puebla los selects dinámicos de filtro (cliente, mapping) con los valores
 * presentes en el histórico (§41) — sin inventar dimensiones. */
function poblarFiltrosDinamicos(snap) {
  const AN = window.SPEC_AN;
  const dims = AN.dimensionesDisponibles(snap.norm);
  const selCli = document.getElementById('patrones-filter-cliente');
  const selMap = document.getElementById('patrones-filter-mapping');
  if (selCli && !selCli.dataset.poblar) {
    dims.clientes.forEach(function (c) {
      const o = document.createElement('option');
      o.value = c; o.textContent = c.slice(0, 24);
      selCli.appendChild(o);
    });
    selCli.dataset.poblar = '1';
  }
  if (selMap && !selMap.dataset.poblar) {
    dims.mappings.forEach(function (m) {
      const o = document.createElement('option');
      o.value = m; o.textContent = String(m).slice(0, 14) + '…';
      selMap.appendChild(o);
    });
    selMap.dataset.poblar = '1';
  }
}

/* PERFIL HISTÓRICO (drill-down §34/§35/§36) — persona / tarea / actividad. */
function renderPatronesProfile(snap, tipo, id) {
  const wrap = document.getElementById('patrones-profile');
  if (!wrap) return;
  const AN = window.SPEC_AN;
  let html = '';
  if (tipo === 'persona') {
    const prof = AN.person.computePersonProfile(snap.list, id, snap.cfg);
    if (!prof) return;
    const s = prof.stats;
    html = '<div class="pp-head"><h3>👤 Perfil histórico — ' + escapeHtml(s.persona) + ' (' + escapeHtml(s.login) + ')</h3>' +
      '<button class="btn btn-link pp-close" type="button" aria-label="Cerrar perfil">✕ Cerrar</button></div>' +
      '<div class="kpi-grid">' +
      kpiCardPAT('Días analizados', s.dias, 'Persona-día del histórico filtrado.', 'info') +
      kpiCardPAT('Días con error', s.diasConError + ' (' + SPEC.formatNum(s.pctDiasConError) + '%)', 'Sección ≠ 3.', (s.pctDiasConError > 50 ? 'error' : 'warn')) +
      kpiCardPAT('Incidencias', s.incidencias, 'Todas las secciones.', 'warn') +
      kpiCardPAT('Horas afectadas', SPEC.formatNum(s.horasAfectadas) + ' h (' + SPEC.formatNum(s.pctHorasAfectadas) + '%)', 'Sobre ' + SPEC.formatNum(s.horasAnalizables) + ' h analizables.', 'error') +
      kpiCardPAT('Cambios de tarea', s.cambiosTarea, 'Incidencias sección 1.', 'warn') +
      kpiCardPAT('Racha máxima', s.maxRacha + ' d', 'Días consecutivos con error.', (s.maxRacha >= snap.cfg.rachaDias ? 'error' : 'info')) +
      kpiCardPAT('Semáforo', s.semaforo, 'Umbrales configurables.', 'info') +
      kpiCardPAT('Turnos', prof.turnos.join(', ') || '—', 'Turnos en los que fichó (SIN HORA incluido si procede).', 'info') +
      '</div>';
    if (prof.tendencia && prof.tendencia.suficiente) {
      html += '<p class="pdd-note">Tendencia (mitades): ' + SPEC.formatNum(prof.tendencia.tasaA) + '% → ' + SPEC.formatNum(prof.tendencia.tasaB) + '% (' + (prof.tendencia.deltaPP > 0 ? '+' : '') + SPEC.formatNum(prof.tendencia.deltaPP) + ' pp) — ' + escapeHtml(prof.tendencia.veredicto) + '.</p>';
    } else {
      html += '<p class="pdd-note">Tendencia: SIN EVIDENCIA (se necesitan ≥' + snap.cfg.minDiasComparar + ' días por mitad).</p>';
    }
    html += '<h4>Evolución diaria (errores)</h4>' + patLineChart(prof.evolucion.map(function (d) { return { fechaISO: d.fechaISO, value: d.errores }; }), 'value', null, 'n', null, 'errores/día');
    html += '<h4>Tareas con error</h4>' + miniLista(prof.tareasConError.slice(0, 10).map(function (t) {
      return { nombre: t.tarea, valor: t.errores + ' err', extra: t.dias + ' d · ' + SPEC.formatNum(t.horas) + ' h' };
    }), 'Tarea WMS afectada si existe; si no, HR Task fichada.');
    if (prof.recurrencias.length > 0) {
      html += '<h4>Errores recurrentes</h4>' + miniLista(prof.recurrencias.slice(0, 10).map(function (r) {
        return { nombre: r.pareja, valor: r.casos + ' casos', extra: r.dias + ' días · ' + SPEC.formatNum(r.horas) + ' h' };
      }), 'Misma confusión repetida en días distintos.');
    }
    const dias = snap.list.filter(function (r) { return r.login === id; });
    html += '<h4>Días (ir a Revisar)</h4><ul class="mini-list">' +
      dias.slice(-12).map(function (d) {
        return '<li><span class="ml-nombre">' + escapeHtml(d.fechaISO) + '</span><span class="ml-valor">' + d.incidencias.length + ' inc</span><span class="ml-extra">' + escapeHtml(d.turno) + '</span></li>';
      }).join('') + '</ul>';
  } else if (tipo === 'tarea') {
    const prof = AN.task.computeTaskProfile(snap.list, id, snap.cfg);
    if (!prof) return;
    const s = prof.stats || { errores: 0, oportunidades: 0, pctError: 0, horasAfectadas: 0, personasN: 0, diasN: 0, uds: 0, actividad: 'OTRA' };
    const tend = snap.tendTareas.filter(function (t) { return t.taskWms === id; })[0];
    html = '<div class="pp-head"><h3>📦 Detalle de TASK_WMS — ' + escapeHtml(id) + '</h3>' +
      '<button class="btn btn-link pp-close" type="button" aria-label="Cerrar perfil">✕ Cerrar</button></div>' +
      '<div class="kpi-grid">' +
      kpiCardPAT('Actividad', s.actividad, 'ACTIVIDAD_ANALISIS resuelta (override > actividad > default).', 'info') +
      kpiCardPAT('Oportunidades', s.oportunidades, 'Persona-día con volumen de esta tarea.', 'info') +
      kpiCardPAT('Errores', s.errores, 'Incidencias imputadas a esta tarea (§11).', (s.errores > 0 ? 'error' : 'success')) +
      kpiCardPAT('% error', SPEC.formatNum(s.pctError) + '%', 'errores / oportunidades.', 'warn') +
      kpiCardPAT('Horas afectadas', SPEC.formatNum(s.horasAfectadas) + ' h', 'Horas con incidencia imputadas.', 'error') +
      kpiCardPAT('Personas', s.personasN, 'Personas distintas.', 'info') +
      kpiCardPAT('UDS', SPEC.formatNum0(s.uds), 'Σ unidades con volumen.', 'info') +
      kpiCardPAT('Tendencia', tend && tend.suficiente ? tend.veredicto + ' (' + (tend.deltaPP > 0 ? '+' : '') + SPEC.formatNum(tend.deltaPP) + ' pp)' : 'SIN EVIDENCIA', 'Δ tasa entre mitades.', 'info') +
      '</div>';
    html += '<h4>Personas más afectadas</h4>' + miniLista(prof.personasAfectadas.slice(0, 10).map(function (p) {
      return { nombre: p.persona, valor: p.errores + ' err', extra: p.dias + ' d' };
    }), null);
    html += '<h4>Mappings usados</h4><ul class="mini-list">' + (prof.mappingsUsados.length ? prof.mappingsUsados.map(function (m) {
      return '<li><span class="ml-nombre">' + escapeHtml(String(m).slice(0, 16)) + '…</span><span class="ml-valor">hash</span></li>';
    }).join('') : '<li>Sin hash registrado</li>') + '</ul>';
  } else if (tipo === 'actividad') {
    const prof = AN.activity.computeActivityProfile(snap.list, id, snap.cfg);
    if (!prof) return;
    const s = prof.stats;
    html = '<div class="pp-head"><h3>📍 Detalle de actividad — ' + escapeHtml(id) + '</h3>' +
      '<button class="btn btn-link pp-close" type="button" aria-label="Cerrar perfil">✕ Cerrar</button></div>' +
      '<div class="kpi-grid">' +
      kpiCardPAT('Oportunidades', s.oportunidades, 'Apariciones persona-día-actividad.', 'info') +
      kpiCardPAT('Errores', s.errores, 'Imputados solo a esta actividad (§11).', (s.errores > 0 ? 'error' : 'success')) +
      kpiCardPAT('% error', SPEC.formatNum(s.pctError) + '%', 'errores / oportunidades.', 'warn') +
      kpiCardPAT('Horas afectadas', SPEC.formatNum(s.horasAfectadas) + ' h', 'Imputadas vía tarea afectada.', 'error') +
      kpiCardPAT('Tendencia', SPEC.formatNum(prof.tendencia.tasaA) + '% → ' + SPEC.formatNum(prof.tendencia.tasaB) + '%', 'Δ ' + (prof.tendencia.deltaPP > 0 ? '+' : '') + SPEC.formatNum(prof.tendencia.deltaPP) + ' pp entre mitades.', 'info') +
      '</div>';
    html += '<h4>Tareas de la actividad</h4><div class="pdd-table-wrap"><table class="data-table patrones-table"><caption class="sr-only">Tareas de la actividad</caption><thead><tr><th scope="col">TASK_WMS</th><th scope="col">Oportunidades</th><th scope="col">Errores</th><th scope="col">% error</th><th scope="col">Horas afectadas</th><th scope="col">UDS</th></tr></thead><tbody>' +
      prof.tareas.slice(0, 25).map(function (t) {
        return '<tr><td>' + escapeHtml(t.taskWms) + '</td><td class="num">' + t.oportunidades + '</td><td class="num">' + t.errores + '</td><td class="num">' + SPEC.formatNum(t.pctError) + '%</td><td class="num">' + SPEC.formatNum(t.horasAfectadas) + '</td><td class="num">' + SPEC.formatNum0(t.uds) + '</td></tr>';
      }).join('') + '</tbody></table></div>';
    html += '<h4>Distribución por turno (registros/errores)</h4><div class="pdd-table-wrap"><table class="data-table patrones-table"><caption class="sr-only">Distribución por turno</caption><thead><tr><th scope="col">Turno</th><th scope="col">Registros</th><th scope="col">Errores</th></tr></thead><tbody>' +
      Object.keys(s.turnos).map(function (t) {
        return '<tr><td>' + escapeHtml(t) + '</td><td class="num">' + s.turnos[t].registros + '</td><td class="num">' + s.turnos[t].errores + '</td></tr>';
      }).join('') + '</tbody></table></div>';
  }
  wrap.innerHTML = html;
  wrap.hidden = false;
  wrap.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  const btn = wrap.querySelector('.pp-close');
  if (btn) btn.addEventListener('click', function () { wrap.hidden = true; wrap.innerHTML = ''; });
}

/* ⚙ CONFIGURACIÓN ESTADÍSTICA (§38) — todos los umbrales visibles. */
var STAT_CONFIG_LABELS = {
  minDiasComparar: ['Mín. días para comparar periodos', 'días'],
  minObservaciones: ['Mín. observaciones (no MUESTRA PEQUEÑA)', 'obs.'],
  umbralCambioPP: ['Umbral cambio de tasa (mejora/empeora)', 'pp'],
  rachaDias: ['Racha de días con error → alerta', 'días'],
  recurrenciaHabitual: ['Días distintos → error HABITUAL', 'días'],
  recurrenciaRecurrente: ['Tope de días para RECURRENTE', 'días'],
  ventanaMediaMovil: ['Ventana de media móvil', 'días'],
  ventanaRollingLarga: ['Ventana rolling larga', 'días'],
  repeticionesConfusion: ['Repeticiones de confusión → alerta', 'casos'],
  umbralTurnoPP: ['Exceso de tasa de turno → alerta', 'pp'],
  otraUdsMinimas: ['UDS mínimas de tarea OTRA → alerta', 'uds'],
  impactoHorasAltas: ['Horas para considerar impacto alto', 'h'],
  semaforoBueno: ['Semáforo: ≤% → BUENO', '%'],
  semaforoNormal: ['Semáforo: ≤% → NORMAL', '%'],
  semaforoAtencion: ['Semáforo: ≤% → ATENCIÓN', '%'],
  semaforoMinDias: ['Semáforo: días mínimos', 'días'],
  pesoFrecuencia: ['Peso prioridad: frecuencia', 'peso'],
  pesoTasa: ['Peso prioridad: tasa', 'peso'],
  pesoHoras: ['Peso prioridad: horas', 'peso'],
  pesoRecurrencia: ['Peso prioridad: recurrencia', 'peso'],
  pesoTendencia: ['Peso prioridad: tendencia', 'peso'],
  pesoPersonas: ['Peso prioridad: personas', 'peso'],
  prioridadAlta: ['Prioridad ALTA ≥', 'score'],
  prioridadMedia: ['Prioridad MEDIA ≥', 'score']
};

function renderStatConfig() {
  const grid = document.getElementById('stat-config-grid');
  if (!grid) return;
  const AN = window.SPEC_AN;
  const cfg = AN.loadConfig();
  let html = '';
  Object.keys(STAT_CONFIG_LABELS).forEach(function (k) {
    html += '<div class="sc-item"><label for="sc-' + escapeAttr(k) + '">' + escapeHtml(STAT_CONFIG_LABELS[k][0]) +
      ' <span class="hint-inline">(' + escapeHtml(STAT_CONFIG_LABELS[k][1]) + ')</span></label>' +
      '<input type="number" step="any" min="0" id="sc-' + escapeAttr(k) + '" data-key="' + escapeAttr(k) + '" value="' + escapeAttr(String(cfg[k])) + '"></div>';
  });
  grid.innerHTML = html;
}

function setupStatConfig() {
  renderStatConfig();
  const btnSave = document.getElementById('btn-stat-config-save');
  const btnReset = document.getElementById('btn-stat-config-reset');
  const AN = window.SPEC_AN;
  if (btnSave) btnSave.addEventListener('click', function () {
    const cfg = AN.loadConfig();
    let ok = true;
    document.querySelectorAll('#stat-config-grid input[data-key]').forEach(function (inp) {
      const v = Number(inp.value);
      if (!isFinite(v) || v < 0) { ok = false; inp.classList.add('invalid'); return; }
      inp.classList.remove('invalid');
      cfg[inp.dataset.key] = v;
    });
    if (!ok) { toast('Los umbrales deben ser números ≥ 0.', { level: 'error' }); return; }
    AN.saveConfig(cfg);
    UI._patronesSnap = null; UI._patronesSnapFirma = null;
    if (UI.patronesRecords) renderPatronesView(UI.patronesRecords);
    toast('Configuración estadística guardada.', { level: 'success' });
  });
  if (btnReset) btnReset.addEventListener('click', function () {
    AN.resetConfig();
    renderStatConfig();
    UI._patronesSnap = null; UI._patronesSnapFirma = null;
    if (UI.patronesRecords) renderPatronesView(UI.patronesRecords);
    toast('Umbrales restablecidos a los valores por defecto (documentados).', { level: 'info' });
  });
  const det = document.getElementById('stat-config');
  if (det) det.addEventListener('toggle', function () { if (det.open) renderStatConfig(); });
}

/* Exportación analítica (§43) — XLSX con las dimensiones utilizadas. */
function exportarPatrones(que) {
  const AN = window.SPEC_AN;
  if (!UI.patronesRecords || UI.patronesRecords.length === 0) {
    toast('No hay histórico que exportar.', { level: 'warn' });
    return;
  }
  const snap = patronesSnapshot();
  const filtrosTxt = 'Filtros: ' + [
    snap.list.length + '/' + snap.norm.length + ' registros'
  ].join(' · ');
  let data = [], nombre = 'patrones_' + que;
  if (que === 'resumen') {
    nombre = 'patrones_resumen';
    const k = snap.kpi;
    data = [
      { Metrica: 'Personas analizadas', Valor: k.personas },
      { Metrica: 'Días analizados', Valor: k.dias },
      { Metrica: 'Persona-día', Valor: k.personaDia },
      { Metrica: 'Horas analizadas', Valor: k.horasAnalizables },
      { Metrica: 'Incidencias', Valor: k.incidencias },
      { Metrica: '% persona-día con incidencia', Valor: k.pctPersonaDiaConIncidencia },
      { Metrica: 'Persona-día con error', Valor: k.personaDiaConError },
      { Metrica: '% persona-día con error', Valor: k.pctPersonaDiaConError },
      { Metrica: 'Horas afectadas', Valor: k.horasAfectadas },
      { Metrica: '% horas afectadas', Valor: k.pctHorasAfectadas },
      { Metrica: 'Errores de asignación', Valor: k.erroresAsignacion },
      { Metrica: '% errores de asignación', Valor: k.pctErroresAsignacion },
      { Metrica: 'Δ pp % error (actual-anterior)', Valor: snap.comp.cambios.pctPersonaDiaConError.deltaPP },
      { Metrica: 'Veredicto tendencia', Valor: AN.etiquetaComparacion(snap.comp, snap.cfg) },
      { Metrica: 'Nota', Valor: filtrosTxt }
    ];
  } else if (que === 'personas') {
    data = snap.personas.map(function (p) {
      return { Persona: p.persona, Login: p.login, Dias: p.dias, DiasConError: p.diasConError, PctDiasConError: p.pctDiasConError, Incidencias: p.incidencias, IncidenciasPorDia: p.incidenciasPorDia, HorasAfectadas: p.horasAfectadas, PctHorasAfectadas: p.pctHorasAfectadas, CambiosTarea: p.cambiosTarea, RecurrenciaDias: p.diasConError, RachaMaxima: p.maxRacha, Semaforo: p.semaforo, MuestraPequena: p.muestraPequena ? 'SI' : 'NO' };
    });
  } else if (que === 'tareas') {
    data = snap.tareas.map(function (t) {
      return { TASK_WMS: t.taskWms, Actividad: t.actividad, Oportunidades: t.oportunidades, Errores: t.errores, PctError: t.pctError, Personas: t.personasN, Dias: t.diasN, HorasAfectadas: t.horasAfectadas, UDS: t.uds, HAsignadas: t.horasAsignadas, Fuente: t.fuente, MuestraPequena: t.muestraPequena ? 'SI' : 'NO' };
    });
  } else if (que === 'actividades') {
    data = snap.actividades.map(function (a) {
      return { Actividad: a.actividad, Oportunidades: a.oportunidades, Errores: a.errores, PctError: a.pctError, Personas: a.personas, Dias: a.dias, HorasAfectadas: a.horasAfectadas, UDS: a.uds, HAsignadas: a.horasAsignadas, NTareas: a.nTareas };
    });
  } else if (que === 'errores') {
    data = snap.matrix.map(function (c) {
      return { Fichada: c.origen, Correcta: c.destino, Casos: c.casos, Personas: c.personas, Dias: c.dias, Horas: c.horas, WmsTasks: c.wmsTasks.join(' | ') };
    });
  } else if (que === 'evolucion') {
    data = snap.daily.serie.map(function (s) {
      return { Fecha: s.fechaISO, Registros: s.registros, Personas: s.personas, ConError: s.conError, PctPersonaDiaError: s.pctPersonaDiaError, Incidencias: s.incidencias, ErroresAsignacion: s.erroresAsignacion, HorasAfectadas: s.horasAfectadas, PctHorasAfectadas: s.pctHorasAfectadas, MediaMovil7: s.mediaMovilTasa, Rolling7: s.rolling7 ? s.rolling7.incidencias : null };
    });
  } else if (que === 'historico') {
    data = snap.list.map(function (r) {
      return {
        Login: r.login, Persona: r.persona, FechaOperativa: r.fechaISO, Semana: r.semana, Mes: r.mes, Turno: r.turno,
        HorasFichadas: r.horasFichadas, HorasAnalizables: r.horasAnalizables, UdsTotales: r.udsTotales,
        HorasEquivalentes: r.horasEquivalentes, HorasAsignadas: r.horasAsignadas, NActividades: r.tareas.length,
        Incidencias: r.nIncidencias, Errores: r.nErrores, HorasConIncidencia: r.horasConIncidencia,
        Decision: r.decision, MappingHash: r.mappingHash, ProductivityVersion: r.productivityVersion,
        OverrideVersion: r.overrideVersion, DatasetFingerprint: r.datasetFingerprint, AppVersion: r.appVersion,
        Version: r.version, Tareas: r.tareas.map(function (t) { return t.taskWms + '(' + t.actividad + ',' + t.uds + 'uds,' + t.horasAsignadas.toFixed(2) + 'h)'; }).join(' | ')
      };
    });
  }
  if (data.length === 0) { toast('Nada que exportar con los filtros actuales.', { level: 'warn' }); return; }
  SPEC.exportToXlsx(data, nombre + '_' + new Date().toISOString().slice(0, 10) + '.xlsx', que);
  toast('Exportado ' + data.length + ' filas (' + que + ') con los filtros activos.', { level: 'success' });
}


/* Gráfico de barras SVG agrupadas (dos series) o simple (una). */
function evolSvgChart(series, fieldA, fieldB) {
  if (series.length === 0) return '<p class="pdd-note">Sin datos.</p>';
  const W = 720, rowH = 26, padL = 150, padR = 90;
  const H = 40 + series.length * rowH;
  const maxV = Math.max(1, ...series.map(s => Math.max(fieldB ? Math.max(s[fieldA], s[fieldB]) : s[fieldA], 0)));
  const barMax = W - padL - padR;
  let svg = '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Gráfico de evolución" style="width:100%; height:auto;">';
  svg += '<rect x="0" y="0" width="' + W + '" height="' + H + '" fill="var(--c-bg-panel, #fff)" rx="6"/>';
  let y = 10;
  for (const s of series) {
    const a = fieldB ? s[fieldA] : 0;
    const b = fieldB ? s[fieldB] : s[fieldA];
    // Serie A (total) — barra clara
    const wA = Math.round(a / maxV * barMax);
    svg += '<rect x="' + padL + '" y="' + y + '" width="' + Math.max(wA, a > 0 ? 1 : 0) + '" height="10" rx="2" fill="#2a4a78" opacity="0.45"/>';
    // Serie B (incidencia) — barra superpuesta sólida
    const wB = Math.round(b / maxV * barMax);
    svg += '<rect x="' + padL + '" y="' + (y + 11) + '" width="' + Math.max(wB, b > 0 ? 1 : 0) + '" height="10" rx="2" fill="#EA1925" opacity="0.85"/>';
    svg += '<text x="' + (padL - 8) + '" y="' + (y + 14) + '" text-anchor="end" font-size="11" fill="var(--c-text, #222)">' + escapeHtml(String(s.label).slice(0, 20)) + '</text>';
    svg += '<text x="' + (padL + Math.max(wA, wB) + 6) + '" y="' + (y + 14) + '" font-size="10" fill="var(--c-text-muted, #666)">' +
      (fieldB ? SPEC.formatNum(a) + ' / ' + SPEC.formatNum(b) : SPEC.formatNum(b)) + '</text>';
    y += rowH;
  }
  svg += '</svg>';
  if (series.length > 40) svg += '<p class="pdd-note">Mostrando ' + series.length + ' períodos.</p>';
  return svg;
}

/* ===== v6.2 — Gráficos SVG de Patrones (líneas, Pareto, dispersión, mapa de
 * calor). Todos con role="img" + aria-label y valores accesibles en <title>
 * de cada punto (los datos SIEMPRE están también en tablas). ============ */

/* Gráfico de líneas: serie (array de puntos con x etiqueta + y numérico),
 * campo Y principal, campo opcional de media móvil (línea discontinua). */
function patLineChart(serie, campoY, campoMM, unidad, mmLabel, altLabel) {
  if (!serie || serie.length === 0) return '<p class="pdd-note">Sin datos.</p>';
  const W = 720, H = 220, padL = 46, padR = 16, padT = 14, padB = 42;
  const plotW = W - padL - padR, plotH = H - padT - padB;
  const vals = serie.map(function (s) { return Math.max(0, Number(s[campoY]) || 0); });
  const mmVals = (campoMM ? serie.map(function (s) { return s[campoMM] != null ? Number(s[campoMM]) : null; }) : []).filter(function (v) { return v != null; });
  const maxV = Math.max(1, Math.max.apply(null, vals.concat(mmVals.length ? mmVals : [0])));
  const n = serie.length;
  const X = function (i) { return padL + (n === 1 ? plotW / 2 : i / (n - 1) * plotW); };
  const Y = function (v) { return padT + plotH - Math.max(0, v) / maxV * plotH; };
  let svg = '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + escapeAttr(altLabel || ('Evolución de ' + campoY)) + '" style="width:100%; height:auto;">';
  svg += '<rect x="0" y="0" width="' + W + '" height="' + H + '" fill="var(--c-bg-panel, #fff)" rx="6"/>';
  // rejilla + eje Y (4 divisiones)
  for (let g = 0; g <= 4; g++) {
    const v = maxV * g / 4, y = Y(v);
    svg += '<line x1="' + padL + '" y1="' + y + '" x2="' + (W - padR) + '" y2="' + y + '" stroke="var(--c-border, #ddd)" stroke-width="1" stroke-dasharray="' + (g === 0 ? '0' : '3 3') + '"/>';
    svg += '<text x="' + (padL - 6) + '" y="' + (y + 3) + '" text-anchor="end" font-size="10" fill="var(--c-text-muted, #666)">' + SPEC.formatNum(Math.round(v * 100) / 100) + '</text>';
  }
  // línea principal
  let path = '';
  serie.forEach(function (s, i) { path += (i === 0 ? 'M' : 'L') + X(i).toFixed(1) + ' ' + Y(Math.max(0, Number(s[campoY]) || 0)).toFixed(1) + ' '; });
  svg += '<path d="' + path + '" fill="none" stroke="#EA1925" stroke-width="2" stroke-linejoin="round"/>';
  // media móvil
  if (campoMM) {
    let mmPath = '', started = false;
    serie.forEach(function (s, i) {
      if (s[campoMM] == null) return;
      mmPath += (started ? 'L' : 'M') + X(i).toFixed(1) + ' ' + Y(Number(s[campoMM])).toFixed(1) + ' ';
      started = true;
    });
    if (mmPath) svg += '<path d="' + mmPath + '" fill="none" stroke="#0f766e" stroke-width="2" stroke-dasharray="6 4"/>';
  }
  // puntos con <title> (tooltip nativo accesible)
  serie.forEach(function (s, i) {
    if (i % Math.ceil(n / 24) !== 0 && i !== n - 1 && n > 24) return; // no saturar
    const v = Math.max(0, Number(s[campoY]) || 0);
    const lbl = s.fechaISO || s.label || s.clave || ('#' + (i + 1));
    svg += '<circle cx="' + X(i).toFixed(1) + '" cy="' + Y(v).toFixed(1) + '" r="3" fill="#EA1925"><title>' + escapeHtml(String(lbl) + ': ' + SPEC.formatNum(v) + (unidad === '%' ? '%' : '')) + '</title></circle>';
  });
  // eje X (máx ~8 etiquetas)
  const step = Math.max(1, Math.ceil(n / 8));
  for (let i = 0; i < n; i += step) {
    const lbl = String(serie[i].fechaISO || serie[i].label || serie[i].clave || ('#' + (i + 1))).slice(5, 10);
    svg += '<text x="' + X(i).toFixed(1) + '" y="' + (H - 8) + '" text-anchor="middle" font-size="9" fill="var(--c-text-muted, #666)">' + escapeHtml(lbl) + '</text>';
  }
  svg += '</svg>';
  if (campoMM) svg += '<p class="pdd-note chart-legend"><span class="lg lg-main">— ' + escapeHtml(campoY) + '</span><span class="lg lg-mm">-- media móvil (' + escapeHtml(mmLabel || campoMM) + ', solo con ventana completa)</span></p>';
  return svg;
}

/* Curva de Pareto: barras (valor individual) + línea de % acumulado. */
function patParetoChart(pareto) {
  const items = pareto.items.slice(0, 20);
  if (items.length === 0) return '';
  const W = 720, rowH = 22, padL = 200, padR = 120;
  const H = 30 + items.length * rowH;
  const barMax = W - padL - padR;
  let svg = '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Curva de Pareto" style="width:100%; height:auto;">';
  svg += '<rect x="0" y="0" width="' + W + '" height="' + H + '" fill="var(--c-bg-panel, #fff)" rx="6"/>';
  let y = 8;
  items.forEach(function (it, i) {
    const wBar = Math.round((it.pctIndividual || 0) / 100 * barMax);
    const xDot = padL + Math.round((it.pctAcumulado || 0) / 100 * barMax);
    const nombre = String(it.taskWms || it.persona || it.actividad || it.nombre || '').slice(0, 30);
    svg += '<text x="' + (padL - 8) + '" y="' + (y + 11) + '" text-anchor="end" font-size="10" fill="var(--c-text, #222)">' + escapeHtml(nombre) + '</text>';
    svg += '<rect x="' + padL + '" y="' + y + '" width="' + Math.max(wBar, 1) + '" height="' + (rowH - 8) + '" rx="2" fill="#2a4a78" opacity="0.55"><title>' + escapeHtml(nombre + ': ' + it.valor + ' (' + it.pctIndividual + '%)') + '</title></rect>';
    svg += '<circle cx="' + xDot + '" cy="' + (y + (rowH - 8) / 2) + '" r="3.5" fill="#EA1925"><title>' + escapeHtml('Acumulado: ' + it.pctAcumulado + '%') + '</title></circle>';
    svg += '<text x="' + (padL + barMax + 8) + '" y="' + (y + 11) + '" font-size="9" fill="var(--c-text-muted, #666)">' + escapeHtml(String(it.pctAcumulado) + '%') + '</text>';
    y += rowH;
  });
  // Línea vertical al 80%
  const x80 = padL + Math.round(0.8 * barMax);
  svg += '<line x1="' + x80 + '" y1="4" x2="' + x80 + '" y2="' + (H - 6) + '" stroke="#EA1925" stroke-width="1" stroke-dasharray="4 3"/>';
  svg += '<text x="' + (x80 + 4) + '" y="' + (H - 6) + '" font-size="9" fill="#EA1925">80%</text>';
  svg += '</svg>';
  svg += '<p class="pdd-note chart-legend"><span class="lg lg-main">■ valor individual</span><span class="lg lg-mm">● % acumulado (rojo) · línea discontinua = 80%</span></p>';
  return svg;
}

/* Dispersión frecuencia (X: errores) × impacto (Y: horas) con medianas. */
function patScatter(fi, titulo) {
  const pts = fi.puntos;
  if (!pts || pts.length === 0) return '<p class="pdd-note">Sin puntos para ' + escapeHtml(titulo) + '.</p>';
  const W = 460, H = 300, padL = 44, padR = 16, padT = 16, padB = 40;
  const plotW = W - padL - padR, plotH = H - padT - padB;
  const maxX = Math.max(1, Math.max.apply(null, pts.map(function (p) { return p.errores; })));
  const maxY = Math.max(1, Math.max.apply(null, pts.map(function (p) { return p.horasAfectadas; })));
  const X = function (v) { return padL + Math.max(0, v) / maxX * plotW; };
  const Y = function (v) { return padT + plotH - Math.max(0, v) / maxY * plotH; };
  let svg = '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Matriz frecuencia e impacto: ' + escapeAttr(titulo) + '" style="width:100%; max-width:520px; height:auto;">';
  svg += '<rect x="0" y="0" width="' + W + '" height="' + H + '" fill="var(--c-bg-panel, #fff)" rx="6"/>';
  svg += '<line x1="' + X(fi.medianaErrores) + '" y1="' + padT + '" x2="' + X(fi.medianaErrores) + '" y2="' + (padT + plotH) + '" stroke="var(--c-border, #999)" stroke-dasharray="4 3"/>';
  svg += '<line x1="' + padL + '" y1="' + Y(fi.medianaHoras) + '" x2="' + (W - padR) + '" y2="' + Y(fi.medianaHoras) + '" stroke="var(--c-border, #999)" stroke-dasharray="4 3"/>';
  pts.forEach(function (p) {
    const cls = p.cuadrante === 'ALTO×ALTO' ? 'q-hh' : (p.cuadrante === 'ALTO×BAJO' ? 'q-hl' : (p.cuadrante === 'BAJO×ALTO' ? 'q-lh' : 'q-ll'));
    svg += '<circle cx="' + X(p.errores).toFixed(1) + '" cy="' + Y(p.horasAfectadas).toFixed(1) + '" r="4" class="' + cls + '"><title>' + escapeHtml(p.nombre + ' — errores: ' + p.errores + ' · horas: ' + p.horasAfectadas + ' · cuadrante ' + p.cuadrante) + '</title></circle>';
  });
  svg += '<text x="' + (padL + 4) + '" y="' + (padT + 12) + '" font-size="9" fill="var(--c-text-muted)">↑ alto impacto</text>';
  svg += '<text x="' + (W - padR - 4) + '" y="' + (padT + plotH - 6) + '" text-anchor="end" font-size="9" fill="var(--c-text-muted)">alta frecuencia →</text>';
  svg += '<text x="' + (padL - 6) + '" y="' + (padT - 4) + '" text-anchor="end" font-size="9" fill="var(--c-text-muted)">' + SPEC.formatNum(Math.round(maxY)) + ' h</text>';
  svg += '<text x="' + (W - padR) + '" y="' + (H - 8) + '" text-anchor="end" font-size="9" fill="var(--c-text-muted)">' + SPEC.formatNum(maxX) + ' err</text>';
  svg += '<text x="' + (padL + plotW / 2) + '" y="' + (H - 8) + '" text-anchor="middle" font-size="10" fill="var(--c-text)">' + escapeHtml(titulo) + ' (medianas: ' + fi.medianaErrores + ' err · ' + SPEC.formatNum(fi.medianaHoras) + ' h)</text>';
  svg += '</svg>';
  return svg;
}

/* Heatmap de confusiones (tabla cruzada origen×destino, intensidad = casos). */
function patHeatmap(matrix) {
  const AN = window.SPEC_AN;
  const hm = AN.confusion.computeConfusionHeatmap(matrix);
  if (hm.origenes.length === 0 || hm.destinos.length === 0) return '<p class="pdd-note">Sin confusiones.</p>';
  const maxO = Math.max.apply(null, hm.origenes.map(function (o) { return String(o).length; }));
  const cellW = Math.max(60, Math.min(120, Math.floor(560 / hm.destinos.length)));
  const cellH = 24, padL = Math.min(200, Math.max(90, maxO * 6 + 10));
  const W = padL + hm.destinos.length * cellW + 10, H = 30 + hm.origenes.length * cellH;
  let svg = '<div class="pdd-table-wrap"><svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Mapa de calor de confusiones" style="width:100%; height:auto;">';
  svg += '<rect x="0" y="0" width="' + W + '" height="' + H + '" fill="var(--c-bg-panel, #fff)" rx="6"/>';
  hm.destinos.forEach(function (d, j) {
    svg += '<text x="' + (padL + j * cellW + cellW / 2) + '" y="22" text-anchor="middle" font-size="8" fill="var(--c-text-muted)">' + escapeHtml(String(d).slice(0, 12)) + '</text>';
  });
  hm.origenes.forEach(function (o, i) {
    const y = 30 + i * cellH;
    svg += '<text x="' + (padL - 6) + '" y="' + (y + 15) + '" text-anchor="end" font-size="8" fill="var(--c-text, #222)">' + escapeHtml(String(o).slice(0, 32)) + '</text>';
    hm.destinos.forEach(function (_d, j) {
      const v = hm.grid[i][j];
      const alpha = hm.max > 0 ? v / hm.max : 0;
      const fill = v > 0 ? 'rgba(234,25,37,' + (0.15 + alpha * 0.85).toFixed(2) + ')' : 'var(--c-bg-subtle, #f5f5f5)';
      svg += '<rect x="' + (padL + j * cellW) + '" y="' + y + '" width="' + (cellW - 2) + '" height="' + (cellH - 2) + '" rx="3" fill="' + fill + '"><title>' + escapeHtml(String(o) + ' → ' + String(_d) + ': ' + v + ' caso(s)') + '</title></rect>';
      if (v > 0) svg += '<text x="' + (padL + j * cellW + cellW / 2) + '" y="' + (y + 15) + '" text-anchor="middle" font-size="9" fill="' + (alpha > 0.5 ? '#fff' : 'var(--c-text)') + '">' + v + '</text>';
    });
  });
  svg += '</svg></div>';
  return svg;
}

/* ============================================================================
 * v6.1 — Setup de las nuevas pestañas + hooks de init/analizar
 * ========================================================================== */

function setupPatronesTab() {
  // Vistas
  document.querySelectorAll('.pv-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      UI.patronesView = btn.dataset.view;
      document.querySelectorAll('.pv-tab').forEach(x => {
        const active = x === btn;
        x.classList.toggle('active', active);
        x.setAttribute('aria-selected', active ? 'true' : 'false');
      });
      document.querySelectorAll('.patrones-view').forEach(v => {
        v.hidden = (v.id !== 'patrones-view-' + UI.patronesView);
        v.classList.toggle('active', !v.hidden);
      });
    });
  });
  // Filtros GLOBALES (combinables) — v6.2 añade task/cliente/mapping
  const ids = ['patrones-filter-date-from', 'patrones-filter-date-to', 'patrones-filter-persona', 'patrones-filter-turno', 'patrones-filter-actividad', 'patrones-filter-decision', 'patrones-filter-semana', 'patrones-filter-mes', 'patrones-filter-task', 'patrones-filter-cliente', 'patrones-filter-mapping'];
  for (const id of ids) {
    const el = document.getElementById(id);
    if (!el) continue;
    const ev = (el.tagName === 'INPUT' && (el.type === 'text' || el.type === 'search')) ? 'input' : 'change';
    el.addEventListener(ev, () => {
      if (UI.patronesRecords) renderPatronesView(UI.patronesRecords);
    });
  }
  const btnClear = document.getElementById('patrones-filter-clear');
  if (btnClear) btnClear.addEventListener('click', () => {
    for (const id of ids) {
      const el = document.getElementById(id);
      if (el) el.value = '';
    }
    if (UI.patronesRecords) renderPatronesView(UI.patronesRecords);
  });
  const gran = document.getElementById('evol-granularidad');
  if (gran) gran.addEventListener('change', () => {
    UI.evolGranularidad = gran.value;
    if (UI.patronesRecords) renderPatronesView(UI.patronesRecords);
  });
  // v6.2 — configuración estadística + exportaciones
  setupStatConfig();
  const expWrap = document.getElementById('patrones-export');
  if (expWrap) {
    expWrap.querySelectorAll('button[data-export]').forEach(function (b) {
      b.addEventListener('click', function () { exportarPatrones(b.dataset.export); });
    });
  }
}

/* Limpieza v6.1 al reiniciar: los listeners originales viven en el closure
 * del primer IIFE, así que registramos listeners ADICIONALES que se ejecutan
 * después y limpian el estado persona/día de v6.1. */
function setupResetHooksV61() {
  const btnRc = document.getElementById('btn-reiniciar');
  if (btnRc) btnRc.addEventListener('click', () => {
    // tras reiniciarCarga: no borrar el mapping persistido (MEJORA 3), solo el resto
    UI.currentPersonDayId = null;
    actualizarUnifiedChecklist();
    renderMappingActivoCard();
  });
  const btnRp = document.getElementById('btn-reiniciar-proceso');
  if (btnRp) btnRp.addEventListener('click', () => {
    // tras reiniciarProceso: limpiar también el análisis persona/día
    SPEC.STATE.personaDiaRecords = [];
    if (SPEC.STATE.queries) delete SPEC.STATE.queries['17_PersonaDiaAnalitica'];
    UI.currentPersonDayId = null;
    if (UI.activeTab === 'revisar') renderReviewPanel();
  });
}

/* ===== Hook init: cargar mapping persistente + setups v6.1 ===== */
const _origInitV61 = init;
init = function () {
  _origInitV61();
  setupUnifiedZone();
  setupProductividadesEditor();
  setupPatronesTab();
  setupResetHooksV61();
  setupPostAnalisisHook();
  renderMappingActivoCard();
  // MEJORA 3 — mapping guardado: cargar automáticamente sin pedir al usuario
  cargarMappingPersistente().catch(err => {
    console.warn('cargarMappingPersistente falló:', err);
    renderMappingActivoCard();
  });
  // Refrescar patrones si hay datos de una sesión restaurada
  if ((SPEC.STATE.personaDiaRecords || []).length > 0) {
    renderPatronesPanel().catch(() => {});
  }
};

/* ===== Hook post-análisis v6.1 =====
 * El listener de #btn-analizar captura por closure la versión IIFE-local de
 * analizar() (el mismo motivo por el que el hook v5 _origAnalizar2 nunca
 * disparó), por lo que un wrap global de analizar() NO se ejecuta. En su
 * lugar observamos #globalStatus: la función analizar() base termina siempre
 * con setStatus('Proceso completado ✓') — tanto por el path del Worker como
 * por el del main-thread — y el MutationObserver dispara DESPUÉS del bloque
 * síncrono (renders incluidos). Ahí ejecutamos el post-procesado v6.1. */
function setupPostAnalisisHook() {
  const gs = document.getElementById('globalStatus');
  if (!gs || typeof MutationObserver === 'undefined') return;
  let running = false;
  const mo = new MutationObserver(() => {
    const txt = gs.textContent || '';
    if (txt.indexOf('Proceso completado') < 0 || running) return;
    if (!SPEC.STATE.reporte || SPEC.STATE.reporte.length === 0) return;
    running = true;
    Promise.resolve().then(async () => {
      try {
        // Hook v5 (dormante): refrescar mappingCurrent tras la corrida
        initMappingData();
        // v6.1 — si el mapping se cargó sin pasar por el flujo persistente
        // (p.ej. zona avanzada por tipo), versionarlo ahora (MEJORA 3).
        if (!UI.mappingMeta && Array.isArray(SPEC.STATE.archivos.mapping) && SPEC.STATE.archivos.mapping.length > 0) {
          try {
            const rows = SPEC.leerMapping(SPEC.STATE.archivos.mapping[0].workbook);
            const meta = await guardarMappingVersion(SPEC.STATE.archivos.mapping[0].name, rows);
            delete meta.rows;
            UI.mappingMeta = meta;
            renderMappingActivoCard();
          } catch (e) {
            console.warn('No se pudo versionar el mapping cargado:', e);
          }
        }
        // 1. Recalcular persona/día con las preferencias del usuario
        recomputarPersonaDia();
        // 1b. v6.1.1 — refrescar el editor de PRODUCTIVIDAD POR TAREA con
        // las tareas recién cargadas (mapping + volumen)
        renderTaskProdEditor();
        // 2. Persistir registros diarios (sin duplicados, versionado, SERIALIZADO)
        await encolarPersistenciaRecords();
        UI.patronesRecords = null; // recargar en el próximo render
        if (UI.activeTab === 'mapping') renderMappingTable();
        // 3. Llevar automáticamente a la primera pestaña útil — SOLO si el
        // usuario no navegó ya a otra pestaña durante el análisis.
        if (UI.activeTab === 'cargaanalizar') {
          const tab = document.querySelector('.tab[data-tab="revisar"]');
          if (tab) {
            tab.click();
            renderReviewPanel();
          }
        }
        toast('Análisis completado: ' + (SPEC.STATE.personaDiaRecords || []).length + ' persona/día · ' +
          (SPEC.STATE.reporte || []).length + ' incidencias.', { level: 'success' });
      } catch (e) {
        console.error('v6.1 post-análisis falló:', e);
      } finally {
        running = false;
      }
    });
  });
  mo.observe(gs, { childList: true, characterData: true, subtree: true });
}

/* ===== Exposición a window (depuración + tests E2E) ===== */
Object.assign(window, {
  // v6.1 preferencias
  cargarProductividades,
  guardarProductividades,
  cargarTaskOverrides,
  renderProductividadesEditor,
  // v6.1.1 productividad por tarea (overrides)
  guardarTaskOverride,
  resetTaskOverride,
  renderTaskProdEditor,
  obtenerTareasConocidas,
  aplicarOverridesYRecalcular,
  // v6.1 mapping persistente
  idbHistoryOpen,
  guardarMappingVersion,
  cargarUltimoMapping,
  reconstruirMappingEntry,
  aplicarMappingEntry,
  cargarMappingPersistente,
  renderMappingActivoCard,
  procesarMappingCargado,
  dialogoCambiarMapping,
  // v6.1 carga unificada
  detectarTipoArchivo,
  cargarArchivosUnificados,
  actualizarUnifiedChecklist,
  setupUnifiedZone,
  // v6.1 persona/día
  recomputarPersonaDia,
  sincronizarDecisionesEnRecords,
  persistirPersonDailyRecords,
  encolarPersistenciaRecords,
  cargarTodosRecords,
  getPersonaDiaRecords,
  getFilteredPersonDays,
  renderPersonDayDetail,
  estadoDecisionRecord,
  navigateIncident,
  selectIncident,
  // v6.1/v6.2 patrones
  renderPatronesPanel,
  renderPatronesView,
  renderKpisResumen,
  renderFocosResumen,
  renderPersonasView,
  renderTareasView,
  renderActividadesView,
  renderErroresView,
  renderEvolucionView,
  renderParetoView,
  renderCalidadView,
  renderPatronesProfile,
  patronesSnapshot,
  evolSvgChart,
  patLineChart,
  patParetoChart,
  patScatter,
  patHeatmap,
  filtrarPatronesRecords,
  setupPatronesTab,
  setupStatConfig,
  exportarPatrones,
  setupPostAnalisisHook
});
