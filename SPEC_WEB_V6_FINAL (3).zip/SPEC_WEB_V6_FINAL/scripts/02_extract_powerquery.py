#!/usr/bin/env python3
"""
El DataMashup decodificado contiene DOS archivos ZIP concatenados:
- ZIP #1 (offset 8..8839): paquete de metadata (Config/Package.xml, [Content_Types].xml, etc.)
- ZIP #2 (offset 8839..39482): contiene los scripts M en Section1.m

Este script extrae ambos ZIPs y vuelca su contenido en texto.
"""
import os
import re
import base64
import zipfile
import io

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ITEM1 = os.path.join(ROOT, "audit", "extracted", "spec_extracted", "customXml", "item1.xml")
OUT_DIR = os.path.join(ROOT, "audit", "powerquery")  # relativo al proyecto (portable)
os.makedirs(OUT_DIR, exist_ok=True)

def read_raw_text():
    with open(ITEM1, "rb") as f:
        raw = f.read()
    return raw.decode("utf-16-le", errors="replace")

def extract_b64(text):
    m = re.search(r"<DataMashup[^>]*>([^<]+)</DataMashup>", text)
    return m.group(1).strip()

def find_zip_segments(data):
    """Localiza sub-ZIPs dentro de un binario grande. Cada ZIP termina en EOCD (PK\x05\x06)."""
    segments = []
    pk_local = b"PK\x03\x04"
    pk_eocd = b"PK\x05\x06"
    starts = [m.start() for m in re.finditer(re.escape(pk_local), data)]
    ends = [m.start() for m in re.finditer(re.escape(pk_eocd), data)]
    # Emparejamos
    starts_sorted = sorted(starts)
    ends_sorted = sorted(ends)
    # Para cada EOCD, el ZIP que termina ahí empezó en el PK\x03\x04 más cercano anterior
    # sin estar ya consumido.
    consumed = []
    for end in ends_sorted:
        # buscar el PRIMER start < end que no esté consumido
        candidate = None
        for s in starts_sorted:
            if s >= end:
                break
            if s not in consumed:
                candidate = s
                break  # tomar el primero
        if candidate is None:
            continue
        consumed.append(candidate)
        # El ZIP va desde candidate hasta end+22 (EOCD = 22 bytes)
        segments.append((candidate, end + 22))
    return segments

def main():
    text = read_raw_text()
    b64 = extract_b64(text)
    data = base64.b64decode(b64)
    print(f"Total bytes: {len(data)}")
    segments = find_zip_segments(data)
    print(f"ZIP segments found: {len(segments)}")
    for i, (start, end) in enumerate(segments):
        print(f"\n--- ZIP #{i+1}: offset {start}..{end} ({end-start} bytes) ---")
        zip_bytes = data[start:end]
        out_zip = os.path.join(OUT_DIR, f"_zip_{i+1}.zip")
        with open(out_zip, "wb") as f:
            f.write(zip_bytes)
        try:
            zf = zipfile.ZipFile(io.BytesIO(zip_bytes))
            names = zf.namelist()
            print(f"  entries: {names}")
            for name in names:
                content = zf.read(name)
                safe = name.replace("/", "__").replace("\\", "__")
                out = os.path.join(OUT_DIR, f"zip{i+1}__{safe}")
                with open(out, "wb") as f:
                    f.write(content)
                # Mostrar head si parece texto
                try:
                    head = content[:120].decode("utf-8", errors="replace")
                    print(f"    {name}: {len(content)} bytes | head: {head[:80]!r}")
                except Exception:
                    print(f"    {name}: {len(content)} bytes (binary)")
        except Exception as e:
            print(f"  parse error: {e}")

if __name__ == "__main__":
    main()
