#!/usr/bin/env python3
"""
Forense completo de SPEC V0.47.3.xlsm.

Extrae:
- Workbook: hojas (con estado visible/oculto/muy oculto), nombres definidos
- Connections
- Tables (estructuradas)
- Por cada hoja: dimensiones, tablas, celdas con fórmulas, validaciones,
  formato condicional, celdas combinadas, hipervínculos, dibujos/shapes,
  autofiltros, opciones de protección, botones con macros asignadas.
- VBA: referencia a macros asignadas a botones (en drawing/hyperlink)

Salida: <raiz-proyecto>/audit/spec_inventory.json + .md humano (rutas relativas, portable).
"""
import os
import re
import json
import zipfile
import xml.etree.ElementTree as ET
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
import base64

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SPEC = os.path.join(ROOT, "audit-ref", "drive", "SPEC V0.47.3.xlsm")
EXTRACT_DIR = os.path.join(ROOT, "audit", "extracted", "spec_extracted")
OUT_DIR = os.path.join(ROOT, "audit")
os.makedirs(OUT_DIR, exist_ok=True)

NS = {
    "main": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "x14": "http://schemas.microsoft.com/office/spreadsheetml/2009/9/main",
    "x15": "http://schemas.microsoft.com/office/spreadsheetml/2010/11/main",
    "mc": "http://schemas.openxmlformats.org/markup-compatibility/2006",
}

def el(tag, ns="main"):
    return f"{{{NS[ns]}}}{tag}"

def parse_workbook():
    """Lee xl/workbook.xml y _rels/workbook.xml.rels para mapear hojas, nombres definidos, etc."""
    wb_xml = os.path.join(EXTRACT_DIR, "xl", "workbook.xml")
    rels_xml = os.path.join(EXTRACT_DIR, "xl", "_rels", "workbook.xml.rels")
    tree = ET.parse(wb_xml)
    root = tree.getroot()
    # Relaciones
    rels = {}
    if os.path.exists(rels_xml):
        rtree = ET.parse(rels_xml)
        for rel in rtree.getroot():
            rels[rel.get("Id")] = rel.get("Target")

    sheets = []
    sheets_el = root.find(el("sheets"))
    for s in sheets_el:
        name = s.get("name")
        sheet_id = s.get("sheetId")
        rid = s.get(f"{{{NS['r']}}}id")
        state = s.get("state", "visible")
        target = rels.get(rid, "")
        sheets.append({"name": name, "sheetId": sheet_id, "r:id": rid,
                       "state": state, "target": target})
    # Defined names
    defined_names = []
    dn_el = root.find(el("definedNames"))
    if dn_el is not None:
        for d in dn_el:
            defined_names.append({
                "name": d.get("name"),
                "scope": d.get("localSheetId", "workbook"),
                "refers_to": d.text,
                "comment": d.get("comment", ""),
            })
    # Calc properties
    calc_el = root.find(el("calcPr"))
    calc = calc_el.attrib if calc_el is not None else {}
    return {"sheets": sheets, "defined_names": defined_names,
            "calc_properties": calc, "rels": rels}

def parse_connections():
    f = os.path.join(EXTRACT_DIR, "xl", "connections.xml")
    if not os.path.exists(f):
        return []
    tree = ET.parse(f)
    out = []
    for c in tree.getroot():
        cid = c.get("id")
        name = c.get("name")
        ctype = c.get("type")
        db = c.find(el("dbPr"))
        cmd = db.get("command") if db is not None else None
        conn_str = db.get("connection") if db is not None else None
        # Extraer Location y Query del connection string
        loc_m = re.search(r"Location=([^;]+)", conn_str or "")
        location = loc_m.group(1) if loc_m else None
        out.append({
            "id": cid, "name": name, "type": ctype,
            "command": cmd, "connection": conn_str, "location": location
        })
    return out

def parse_tables():
    """Lee cada xl/tables/tableN.xml"""
    tdir = os.path.join(EXTRACT_DIR, "xl", "tables")
    out = []
    if not os.path.isdir(tdir):
        return out
    for f in sorted(os.listdir(tdir)):
        if not f.endswith(".xml"):
            continue
        path = os.path.join(tdir, f)
        try:
            tree = ET.parse(path)
            root = tree.getroot()
            t = {
                "file": f,
                "name": root.get("name"),
                "displayName": root.get("displayName"),
                "ref": root.get("ref"),
                "headerRowCount": root.get("headerRowCount", "1"),
                "totalsRowCount": root.get("totalsRowCount", "0"),
                "headerRowDxfId": root.get("headerRowDxfId"),
                "columns": []
            }
            # TableStyleInfo
            tsi = root.find(el("tableStyleInfo"))
            if tsi is not None:
                t["styleInfo"] = tsi.attrib
            # Columns
            cols_el = root.find(el("tableColumns"))
            if cols_el is not None:
                for c in cols_el:
                    t["columns"].append({"id": c.get("id"), "name": c.get("name")})
            # QueryTable ref
            qt_rel_path = os.path.join(EXTRACT_DIR, "xl", "tables", "_rels", f + ".rels")
            if os.path.exists(qt_rel_path):
                qt_rels = []
                rtree = ET.parse(qt_rel_path)
                for rel in rtree.getroot():
                    qt_rels.append({"type": rel.get("Type"), "target": rel.get("Target")})
                t["queryTableRef"] = qt_rels
            out.append(t)
        except Exception as e:
            out.append({"file": f, "error": str(e)})
    return out

def parse_query_tables():
    """Lee xl/queryTables/queryTableN.xml"""
    qtdir = os.path.join(EXTRACT_DIR, "xl", "queryTables")
    out = []
    if not os.path.isdir(qtdir):
        return out
    for f in sorted(os.listdir(qtdir)):
        if not f.endswith(".xml"):
            continue
        path = os.path.join(qtdir, f)
        try:
            tree = ET.parse(path)
            root = tree.getroot()
            qt = {
                "file": f,
                "name": root.get("name"),
                "connectionId": root.get("connectionId"),
                "autoFormat": root.get("autoFormat"),
                "refreshOnLoad": root.get("refreshOnLoad"),
                "backgroundQuery": root.get("backgroundQuery"),
                "adjustColumnWidth": root.get("adjustColumnWidth"),
                "rowNumbers": root.get("rowNumbers"),
                "fetchedRowCountOverflow": root.get("fetchedRowCountOverflow"),
                "fillFormulas": root.get("fillFormulas"),
                "parameters": []
            }
            params = root.find(el("parameters"))
            if params is not None:
                for p in params:
                    qt["parameters"].append({
                        "name": p.get("name"),
                        "sqlType": p.get("sqlType"),
                        "parameterType": p.get("parameterType"),
                        "refreshOnChange": p.get("refreshOnChange"),
                        "prompt": p.get("prompt"),
                        "boolean": p.get("boolean"),
                        "double": p.get("double"),
                        "integer": p.get("integer"),
                        "string": p.get("string"),
                        "cell": p.get("cell"),
                    })
            out.append(qt)
        except Exception as e:
            out.append({"file": f, "error": str(e)})
    return out

def parse_worksheet_formulas(sheet_file):
    """Lee un sheetN.xml y extrae celdas con fórmula, validation, conditional formatting, merges, hyperlinks, drawings"""
    path = os.path.join(EXTRACT_DIR, "xl", "worksheets", sheet_file)
    if not os.path.exists(path):
        return None
    try:
        tree = ET.parse(path)
    except Exception:
        # XML inválido (p.ej. extLst). Intentar leer como texto
        with open(path, "rb") as f:
            raw = f.read()
        return {"error": "parse error", "size": len(raw)}

    root = tree.getroot()
    # Dimensiones
    dim = root.find(el("dimension"))
    dim_ref = dim.get("ref") if dim is not None else None
    # Sheet data
    sd = root.find(el("sheetData"))
    formulas = []
    values_count = 0
    if sd is not None:
        for row in sd:
            for c in row:
                if c.tag != el("c"):
                    continue
                ref = c.get("r")
                t = c.get("t", "n")
                v = c.find(el("v"))
                is_node = c.find(el("is"))
                f = c.find(el("f"))
                if f is not None:
                    formulas.append({
                        "cell": ref, "t": t,
                        "formula": (f.text or ""),
                        "ref": f.get("ref"),  # si tiene ref, es fórmula matricial
                        "value": v.text if v is not None else None
                    })
                else:
                    values_count += 1
    # Data validations
    dvs = []
    dv_root = root.find(el("dataValidations"))
    if dv_root is not None:
        for d in dv_root:
            dv = {
                "sqref": d.get("sqref"),
                "type": d.get("type"),
                "operator": d.get("operator"),
                "allowBlank": d.get("allowBlank"),
                "showInputMessage": d.get("showInputMessage"),
                "showErrorMessage": d.get("showErrorMessage"),
            }
            f1 = d.find(el("formula1"))
            f2 = d.find(el("formula2"))
            if f1 is not None: dv["formula1"] = f1.text
            if f2 is not None: dv["formula2"] = f2.text
            dvs.append(dv)
    # Merged cells
    merges = []
    m_el = root.find(el("mergeCells"))
    if m_el is not None:
        for m in m_el:
            merges.append(m.get("ref"))
    # Hyperlinks
    hl = []
    h_el = root.find(el("hyperlinks"))
    if h_el is not None:
        for h in h_el:
            hl.append({
                "ref": h.get("ref"),
                "display": h.get("display"),
                "tooltip": h.get("tooltip"),
                "r:id": h.get(f"{{{NS['r']}}}id"),
                "location": h.get("location"),
                "action": h.get("action"),
            })
    # Conditional formatting
    cf = []
    for cf_el in root.findall(el("conditionalFormatting")):
        rules = []
        for r in cf_el:
            rule = {
                "type": r.get("type"),
                "operator": r.get("operator"),
                "priority": r.get("priority"),
                "dxfId": r.get("dxfId"),
                "stopIfTrue": r.get("stopIfTrue"),
            }
            f1 = r.find(el("formula"))
            if f1 is not None:
                rule["formula"] = f1.text
            rules.append(rule)
        cf.append({"sqref": cf_el.get("sqref"), "rules": rules})
    # AutoFilter
    af = root.find(el("autoFilter"))
    af_ref = af.get("ref") if af is not None else None
    # Drawings (botones, formas)
    drawing_rel = None
    rels_path = os.path.join(EXTRACT_DIR, "xl", "worksheets", "_rels", sheet_file + ".rels")
    if os.path.exists(rels_path):
        rtree = ET.parse(rels_path)
        for rel in rtree.getroot():
            rtype = rel.get("Type", "")
            if "drawing" in rtype.lower():
                drawing_rel = rel.get("Target")
            elif "vml" in rtype.lower() or "legacy" in rtype.lower():
                drawing_rel = drawing_rel or {}
                drawing_rel = {"target": rel.get("Target"), "type": "vml/legacy"}
    # PageBreak, printOptions
    print_opts = root.find(el("printOptions"))
    print_options = print_opts.attrib if print_opts is not None else {}
    # Sheet protection
    prot = root.find(el("sheetProtection"))
    protection = prot.attrib if prot is not None else None

    return {
        "sheet_file": sheet_file,
        "dimension": dim_ref,
        "formula_cells_count": len(formulas),
        "non_formula_cells_count": values_count,
        "formulas_sample": formulas[:200],  # primeros 200 para no saturar
        "data_validations": dvs,
        "merged_cells": merges,
        "hyperlinks": hl,
        "conditional_formatting": cf,
        "autofilter": af_ref,
        "drawing_rel": drawing_rel,
        "print_options": print_options,
        "protection": protection,
    }

def extract_drawings_macros():
    """Lee xl/drawings/drawingN.xml y sus rels para ver botones y macros asignadas."""
    ddir = os.path.join(EXTRACT_DIR, "xl", "drawings")
    out = []
    if not os.path.isdir(ddir):
        return out
    for f in sorted(os.listdir(ddir)):
        if not f.endswith(".xml"):
            continue
        path = os.path.join(ddir, f)
        try:
            tree = ET.parse(path)
            root = tree.getroot()
            shapes = []
            # Buscar elementos con macro asignada
            for sp in root.iter():
                if sp.tag.endswith("}sp") or sp.tag.endswith("}pic") or sp.tag.endswith("}grpSp") or sp.tag.endswith("}graphicFrame"):
                    # Buscar atributos macro / fmla
                    info = {"tag": sp.tag.split("}")[-1]}
                    # nv* container -> cNvPr -> macro
                    for child in sp.iter():
                        if child.tag.endswith("}cNvPr"):
                            info["name"] = child.get("name")
                            info["macro"] = child.get("macro")
                            info["f"] = child.get("f")
                            break
                    shapes.append(info)
            out.append({"file": f, "shapes": shapes})
        except Exception as e:
            out.append({"file": f, "error": str(e)})
    # Rels
    rels_dir = os.path.join(ddir, "_rels")
    if os.path.isdir(rels_dir):
        for f in sorted(os.listdir(rels_dir)):
            path = os.path.join(rels_dir, f)
            rtree = ET.parse(path)
            for rel in rtree.getroot():
                out.append({
                    "file": f,
                    "rel_type": rel.get("Type"),
                    "rel_target": rel.get("Target")
                })
    return out

def read_shared_strings_sample(limit=200):
    f = os.path.join(EXTRACT_DIR, "xl", "sharedStrings.xml")
    if not os.path.exists(f):
        return []
    tree = ET.parse(f)
    out = []
    for si in tree.getroot():
        # concatenar todos los <t>
        txt = ""
        for t in si.iter():
            if t.tag == el("t"):
                txt += t.text or ""
        out.append(txt)
        if len(out) >= limit:
            break
    return out

def main():
    result = {}
    print("Parsing workbook.xml...")
    result["workbook"] = parse_workbook()
    print(f"  Sheets: {len(result['workbook']['sheets'])}")
    print(f"  Defined names: {len(result['workbook']['defined_names'])}")
    print("Parsing connections...")
    result["connections"] = parse_connections()
    print(f"  Connections: {len(result['connections'])}")
    print("Parsing tables...")
    result["tables"] = parse_tables()
    print(f"  Tables: {len(result['tables'])}")
    print("Parsing queryTables...")
    result["queryTables"] = parse_query_tables()
    print(f"  QueryTables: {len(result['queryTables'])}")
    print("Parsing worksheet formulas & validations...")
    result["worksheets"] = {}
    ws_dir = os.path.join(EXTRACT_DIR, "xl", "worksheets")
    for f in sorted(os.listdir(ws_dir)):
        if f.startswith("sheet") and f.endswith(".xml"):
            print(f"  -> {f}")
            result["worksheets"][f] = parse_worksheet_formulas(f)
    print("Parsing drawings...")
    result["drawings"] = extract_drawings_macros()
    print(f"  Drawing entries: {len(result['drawings'])}")

    with open(os.path.join(OUT_DIR, "spec_inventory.json"), "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(f"\nWrote {OUT_DIR}/spec_inventory.json")

    # Resumen humano
    with open(os.path.join(OUT_DIR, "spec_inventory_summary.md"), "w", encoding="utf-8") as f:
        f.write("# SPEC V0.47.3 - Inventario Forense\n\n")
        wb = result["workbook"]
        f.write(f"- Aplicación: {SPEC}\n")
        f.write(f"- Hojas totales: {len(wb['sheets'])}\n")
        for s in wb["sheets"]:
            f.write(f"  - {s['name']} (sheetId={s['sheetId']}, state={s['state']}, target={s['target']})\n")
        f.write(f"\n- Nombres definidos: {len(wb['defined_names'])}\n")
        for d in wb["defined_names"]:
            f.write(f"  - `{d['name']}` (scope={d['scope']}) = {d['refers_to']}\n")
        f.write(f"\n- Propiedades cálculo: {wb['calc_properties']}\n")
        f.write(f"\n## Conexiones ({len(result['connections'])})\n")
        for c in result["connections"]:
            f.write(f"- **{c['name']}** (id={c['id']}, type={c['type']}): loc={c['location']}\n")
            f.write(f"  - command: `{c['command']}`\n")
        f.write(f"\n## Tablas estructuradas ({len(result['tables'])})\n")
        for t in result["tables"]:
            if "name" in t:
                f.write(f"- **{t['name']}** ({t['file']}): ref={t['ref']}, cols={len(t['columns'])}\n")
                for c in t["columns"]:
                    f.write(f"  - {c['name']}\n")
        f.write(f"\n## QueryTables ({len(result['queryTables'])})\n")
        for q in result["queryTables"]:
            f.write(f"- {q.get('file')}: name={q.get('name')}, connectionId={q.get('connectionId')}\n")
        f.write(f"\n## Worksheets detail\n")
        for name, info in result["worksheets"].items():
            if isinstance(info, dict) and "error" not in info:
                f.write(f"\n### {name} (dim={info['dimension']})\n")
                f.write(f"- Celdas con fórmula: {info['formula_cells_count']}\n")
                f.write(f"- Otras celdas: {info['non_formula_cells_count']}\n")
                f.write(f"- Merged cells: {len(info['merged_cells'])}\n")
                f.write(f"- Data validations: {len(info['data_validations'])}\n")
                f.write(f"- Conditional formatting rules: {sum(len(c['rules']) for c in info['conditional_formatting'])}\n")
                f.write(f"- Hyperlinks: {len(info['hyperlinks'])}\n")
                f.write(f"- AutoFilter: {info['autofilter']}\n")
                f.write(f"- Protection: {info['protection']}\n")
                if info["merged_cells"]:
                    f.write(f"- Merged: {info['merged_cells'][:10]}\n")
                if info["data_validations"]:
                    for dv in info["data_validations"][:10]:
                        f.write(f"  - DV {dv['sqref']} type={dv['type']} op={dv['operator']} formula1={dv.get('formula1')}\n")
                # muestrear 5 fórmulas
                if info["formulas_sample"]:
                    f.write(f"- Fórmulas (muestra):\n")
                    for fm in info["formulas_sample"][:15]:
                        f.write(f"  - {fm['cell']}: ={fm['formula']}  (valor={fm['value']})\n")
            else:
                f.write(f"\n### {name}: {info}\n")
        f.write(f"\n## Drawings / shapes\n")
        for d in result["drawings"]:
            f.write(f"- {d.get('file')}: {d.get('shapes', [])[:5] if 'shapes' in d else d}\n")

    print(f"Wrote {OUT_DIR}/spec_inventory_summary.md")

if __name__ == "__main__":
    main()
