#!/usr/bin/env python3
"""P11-cierre — Update the embedded SheetJS bundle in SPEC_AUTONOMO_v6.html
with the new xlsx.full.min.js (0.20.3)."""

import os
import re

ROOT = os.path.dirname(os.path.abspath(__file__))
STANDALONE = os.path.join(ROOT, '..', 'SPEC_AUTONOMO_v6.html')
NEW_XLSX = os.path.join(ROOT, '..', 'xlsx.full.min.js')

with open(NEW_XLSX, 'r', encoding='utf-8') as f:
    new_bundle = f.read().rstrip('\n')

with open(STANDALONE, 'r', encoding='utf-8') as f:
    html = f.read()

# The SheetJS block is delimited by:
#   <!-- SheetJS (Apache 2.0) - embebido inline para autonomía -->
#   <script>
#   /*! xlsx.js (C) 2013-present SheetJS -- http://sheetjs.com */
#   ... bundle ...
#   </script>
# We use a regex that captures the whole block (non-greedy match of the bundle).
pattern = re.compile(
    r'(<\!-- SheetJS \(Apache 2\.0\) - embebido inline para autonomía -->\s*<script>\s*)'
    r'/\*! xlsx\.js \(C\) 2013-present SheetJS -- http://sheetjs\.com \*/[\s\S]*?'
    r'(\s*</script>)',
    re.MULTILINE
)

def _repl(m):
    return m.group(1) + new_bundle + m.group(2)

new_html, n = pattern.subn(_repl, html)
print(f'Replacements made: {n}')
if n == 0:
    print('ERROR: SheetJS block not found in standalone HTML')
    exit(1)

with open(STANDALONE, 'w', encoding='utf-8') as f:
    f.write(new_html)

print(f'OK — SPEC_AUTONOMO_v6.html updated with new SheetJS bundle ({len(new_bundle)} bytes)')
