#!/usr/bin/env node
/* Genera MANIFEST_SHA256.txt — SHA-256 y tamaño de TODOS los archivos del
 * proyecto excepto el propio manifest (evita referencia circular).
 * FASE 20 de la auditoría de certificación: el recuento NO se escribe a mano.
 * Uso: node scripts/generate_manifest.cjs (o regenerado por el pipeline)
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = path.resolve(__dirname, '..');
const EXCLUDE_DIRS = ['node_modules', '.git', 'test-results', 'playwright-report', 'coverage', '.nyc_output', 'download', 'skills'];
const EXCLUDE_FILES = ['MANIFEST_SHA256.txt'];

function walk(dir, rel, out) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    // Incluir dotfiles útiles (.github, .gitignore, .gitkeep); excluir el resto
    if (entry.name.startsWith('.') && !['.github', '.gitignore', '.gitkeep'].includes(entry.name)) continue;
    const full = path.join(dir, entry.name);
    const relPath = rel ? rel + '/' + entry.name : entry.name;
    if (entry.isDirectory()) {
      if (EXCLUDE_DIRS.includes(entry.name)) continue;
      walk(full, relPath, out);
    } else if (entry.isFile()) {
      if (EXCLUDE_FILES.includes(entry.name)) continue;
      out.push(relPath);
    }
  }
}

const files = [];
walk(ROOT, '', files);
files.sort();

const lines = [];
for (const f of files) {
  const buf = fs.readFileSync(path.join(ROOT, f));
  const hash = crypto.createHash('sha256').update(buf).digest('hex');
  lines.push(`${hash}  ${buf.length}  ./${f}`);
}

const now = new Date().toISOString().replace(/\.\d+Z$/, 'Z');
const header = [
  '# MANIFEST_SHA256 — SPEC Web v6.0 Certified Release',
  `# Generated: ${now}`,
  `# Total files: ${lines.length}`,
  '# NOTE: this file\'s own hash is NOT included (self-reference paradox).',
  '#       The SHA-256 of the ZIP itself is published EXTERNALLY in',
  '#       SPEC_WEB_V6_FINAL_SHA256.txt (created AFTER the ZIP is built).',
  ''
].join('\n');

fs.writeFileSync(path.join(ROOT, 'MANIFEST_SHA256.txt'), header + lines.join('\n') + '\n');
console.log(`MANIFEST_SHA256.txt regenerado: ${lines.length} entradas`);
