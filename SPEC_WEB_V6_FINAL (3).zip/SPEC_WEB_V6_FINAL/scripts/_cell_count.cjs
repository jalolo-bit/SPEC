const XLSX = require('xlsx');
const path = require('path');
const fs = require('fs');

// P8-cierre — rutas relativas al script (portabilidad: funciona desde cualquier
// instalación limpia, no solo en el entorno original de desarrollo).
const ROOT = path.resolve(__dirname, '..');
const DRIVE = path.join(ROOT, 'audit-ref', 'drive');

const wbXlsm = XLSX.readFile(path.join(DRIVE, 'SPEC V0.47.3.xlsm'), { cellDates: true });

const TABLES = [
  '01_HorasSinVolumen', '02_VolumenDetalle', '03_VolumenPersonaDia',
  '05_VolumenIdNumericoDia', '07_Conciliacion', '08_Validaciones',
  '09_VolumenSinHorasDetalle', '10_VolumenSinHorasPersonaDia',
  '12_MapeoActividadSPEC', '13_VolumenMapeadoSPEC',
  '14_VolumenPersonaDiaActividadSPEC', '15_VolumenSinHorasPersonaDiaActividadSPEC',
  '16_ControlMapeoSPEC', 'REPORTE_CAMBIOS_HR'
];

// Setup XLSX global
globalThis.XLSX = XLSX;

// Cargar app.js con new Function
const appSrc = fs.readFileSync(path.join(ROOT, "app.js"), "utf8");
const setupGlobal = new Function('globalThis', 'window', 'XLSX', appSrc + '\nreturn SPEC;');
const SPEC = setupGlobal(globalThis, globalThis, XLSX);

// Cargar los 4 archivos de input
const wbHoras = XLSX.readFile(path.join(DRIVE, 'HORA SIN VOLUMEN.xlsx'), { cellDates: true });
const wbVolumen = XLSX.readFile(path.join(DRIVE, 'VOLUMEN.xlsx'), { cellDates: true });
const wbVSH = XLSX.readFile(path.join(DRIVE, 'VOL SIN HORAS.xlsx'), { cellDates: true });
const wbMapping = XLSX.readFile(path.join(DRIVE, 'Mapping.xlsx'), { cellDates: true });

SPEC.STATE.archivos = {
  horas: { name: 'HORA SIN VOLUMEN.xlsx', workbook: wbHoras },
  volumen: { name: 'VOLUMEN.xlsx', workbook: wbVolumen },
  volSinHoras: { name: 'VOL SIN HORAS.xlsx', workbook: wbVSH },
  mapping: { name: 'Mapping.xlsx', workbook: wbMapping }
};

SPEC.analizarYConciliar().then(() => {
  let total = 0;
  const perTable = {};
  for (const t of TABLES) {
    const jsRows = t === 'REPORTE_CAMBIOS_HR' ? SPEC.STATE.reporte : SPEC.STATE.queries[t];
    if (!jsRows) { perTable[t] = 0; continue; }
    const cols = Object.keys(jsRows[0] || {});
    const cells = jsRows.length * cols.length;
    perTable[t] = cells;
    total += cells;
  }
  console.log('Celdas por tabla (JS rows × cols):');
  for (const t of TABLES) {
    console.log('  ' + t.padEnd(50) + perTable[t]);
  }
  console.log('');
  console.log('TOTAL CELLS (JS rows × cols):', total);
}).catch(e => { console.error(e); process.exit(1); });
