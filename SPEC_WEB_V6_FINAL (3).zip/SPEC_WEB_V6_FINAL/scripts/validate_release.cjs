/* P13-cierre — Validador ampliado de Release Candidate.
 *
 * Comprueba: versiones, features, security, testing, documentation, contradictions.
 * Detecta inconsistencias entre código y documentación (e.g. M-15 marcada como
 * NO IMPLEMENTADA pero manifest.json existe).
 *
 * Uso: node scripts/validate_release.cjs
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = path.resolve(__dirname, '..');
const FAIL = [];
const PASS = [];

function check(name, condition, details = '') {
  if (condition) {
    PASS.push(`✓ ${name}${details ? ' — ' + details : ''}`);
  } else {
    FAIL.push(`✗ ${name}${details ? ' — ' + details : ''}`);
  }
}

function fileExists(rel) {
  return fs.existsSync(path.join(ROOT, rel));
}

function readFile(rel) {
  return fs.readFileSync(path.join(ROOT, rel), 'utf8');
}

console.log('=== P13-cierre — RELEASE CANDIDATE VALIDATOR ===');
console.log('Project:', ROOT);
console.log('');

// === VERSION ===
console.log('--- VERSION ---');
const pkg = JSON.parse(readFile('package.json'));
check('package.json name="spec-web"', pkg.name === 'spec-web', `name="${pkg.name}"`);
check('package.json version="6.2.0"', pkg.version === '6.2.0', `version="${pkg.version}"`);

const appJs = readFile('app.js');
const m = appJs.match(/AppVersion:\s*['"]([^'"]+)['"]/);
check('app.js PARAMS.AppVersion contains 6.2', m && m[1].includes('6.2'), `AppVersion="${m ? m[1] : '?'}"`);

const indexHtml = readFile('index.html');
check('index.html version-badge v6.2', indexHtml.includes('version-badge">v6.2<'));
check('index.html NO v.5 references', !/>v\.5</.test(indexHtml));

const standalone = fileExists('SPEC_AUTONOMO_v6.html');
check('SPEC_AUTONOMO_v6.html (renamed from v.5)', standalone);
if (standalone) {
  const sa = readFile('SPEC_AUTONOMO_v6.html');
  check('SPEC_AUTONOMO_v6.html version-badge v6.2', sa.includes('version-badge">v6.2<'));
  check('SPEC_AUTONOMO_v6.html NO v.5 references', !/>v\.5</.test(sa));
}

const manifestJson = fileExists('manifest.json');
if (manifestJson) {
  try {
    const pwa = JSON.parse(readFile('manifest.json'));
    check('manifest.json version=6.2.0', pwa.version === '6.2.0', `version="${pwa.version}"`);
  } catch (e) {
    check('manifest.json valid JSON', false, e.message);
  }
}

const workerJs = readFile('worker.js');
check('worker.js no version reference to v5', !/v\.5/.test(workerJs));

// === FEATURES ===
console.log('--- FEATURES ---');
check('Worker (worker.js exists)', fileExists('worker.js'));
check('Worker has importScripts', workerJs.includes('importScripts'));
check('Worker multi-file (arrays)', workerJs.includes('normalizeEntries') || workerJs.includes('Array.isArray(val)'));

check('IndexedDB code in ui.js', readFile('ui.js').includes('indexedDB') && readFile('ui.js').includes('idbOpen'));

check('Mapping tab in index.html', indexHtml.includes('data-tab="mapping"') && indexHtml.includes('panel-mapping'));
check('Mapping setupMappingTab in ui.js', readFile('ui.js').includes('setupMappingTab'));

check('Multi-file support', indexHtml.includes('multiple') && readFile('ui.js').includes('loadFiles'));

check('Virtual scrolling', readFile('ui.js').includes('VIEWER_THRESHOLD') && readFile('ui.js').includes('_viewerRenderWindow'));

check('PWA manifest.json present', fileExists('manifest.json'));
check('PWA sw.js present', fileExists('sw.js'));
check('PWA sw-register.js present', fileExists('sw-register.js'));
check('PWA manifest linked in index.html', indexHtml.includes('rel="manifest"'));
check('PWA sw-register loaded in index.html', indexHtml.includes('sw-register.js'));

// === SECURITY ===
console.log('--- SECURITY ---');
const csvInjectionTest = readFile('tests/unit/csv_injection.test.js');
check('CSV injection test exists', fileExists('tests/unit/csv_injection.test.js'));
check('CSV injection escape in app.js', appJs.includes('FORMULA_PREFIXES'));

const escapeHtmlTest = fileExists('tests/unit/escape_html.test.js');
check('XSS escapeHtml test exists', escapeHtmlTest);

check('CSP meta tag in index.html', indexHtml.includes('http-equiv="Content-Security-Policy"'));
check('X-Content-Type-Options meta tag', indexHtml.includes('X-Content-Type-Options'));
check('Referrer-Policy meta tag', indexHtml.includes('Referrer-Policy'));
check('NO frame-ancestors in meta (not supported)', !indexHtml.includes('frame-ancestors'));

const xlsxPkgPath = path.join(ROOT, 'node_modules/xlsx/package.json');
if (fs.existsSync(xlsxPkgPath)) {
  const xlsxPkg = JSON.parse(fs.readFileSync(xlsxPkgPath, 'utf8'));
  check('SheetJS version', xlsxPkg.version === '0.18.5' || xlsxPkg.version === '0.20.3', `version="${xlsxPkg.version}"`);
} else {
  // If node_modules not installed (e.g., ZIP just extracted), check package.json declared dep
  check('SheetJS declared in package.json', !!pkg.dependencies?.xlsx, `declared="${pkg.dependencies?.xlsx || '?'}"`);
}

// === TESTING ===
console.log('--- TESTING ---');
check('Unit tests dir present', fs.existsSync(path.join(ROOT, 'tests/unit')));
check('Integration tests dir present', fs.existsSync(path.join(ROOT, 'tests/integration')));
check('E2E tests dir present', fs.existsSync(path.join(ROOT, 'tests/e2e')));
check('Equivalence valores test', fileExists('tests/integration/equivalence_valores.test.js'));
check('Equivalence requires 0 mismatches (P7-closure)', readFile('tests/integration/equivalence_valores.test.js').includes('.toBe(0)'));
check('Equivalence legacy script .cjs', fileExists('scripts/07_test_equivalencia_valores.cjs'));
check('EQUIVALENCE_MACHINE_RESULT.json exists', fileExists('reports/EQUIVALENCE_MACHINE_RESULT.json'));

// === DOCUMENTATION ===
console.log('--- DOCUMENTATION ---');
const reports = ['TEST_RESULTS_FINAL.md', 'FINAL_EQUIVALENCE_REPORT.md', 'REGISTRO_RIESGOS_FINAL.md',
  'MEJORAS_IMPLEMENTADAS.md', 'SBOM_REPORT.md', 'COVERAGE_REPORT.md', 'DELIVERY_CONCORDANCE_MATRIX.md',
  'FINAL_DELIVERY_REPORT.md', 'AUDITORIA_POST_IMPLEMENTACION.md', 'FINAL_VALIDATION_REPORT.md',
  'ACCESSIBILITY_REPORT.md', 'PRIVACY_TEST_DATA.md', 'PLAN_IMPLEMENTACION_COMPLETO.md',
  'FINAL_RELEASE_VERIFICATION.md', 'FINAL_RELEASE_CERTIFICATION.md'];
for (const r of reports) {
  check(`Report ${r} exists`, fileExists(`reports/${r}`) || fileExists(r));
}

// === CONTRADICTION CHECK ===
console.log('--- CONTRADICTION DETECTION ---');

// M-15 contradiction: if manifest.json + sw.js + sw-register.js exist AND a report says "M-15 NO IMPLEMENTADA", FAIL
const m15Files = fileExists('manifest.json') && fileExists('sw.js') && fileExists('sw-register.js');
const m15Reports = ['reports/MEJORAS_IMPLEMENTADAS.md', 'reports/DELIVERY_CONCORDANCE_MATRIX.md',
  'reports/REGISTRO_RIESGOS_FINAL.md', 'reports/FINAL_DELIVERY_REPORT.md', 'reports/FINAL_VALIDATION_REPORT.md'];
let m15Contradiction = false;
for (const r of m15Reports) {
  if (fileExists(r)) {
    const c = readFile(r);
    if (m15Files && (c.includes('M-15 NO IMPLEMENTADA') || c.includes('M-15 Aplazada') || c.includes('M-15 aplazada'))) {
      m15Contradiction = true;
      FAIL.push(`✗ CONTRADICTION: ${r} says "M-15 NO IMPLEMENTADA" but manifest.json+sw.js+sw-register.js exist`);
    }
  }
}
if (!m15Contradiction) {
  PASS.push('✓ No M-15 contradictions (PWA files match documentation)');
}

// 74.172 contradiction: docs say 74.172 but actual is 74.672
let cellCountContradiction = false;
const allReports = reports.map(r => `reports/${r}`).concat(['README.md', 'CHANGELOG.md', 'docs/PRUEBAS_EQUIVALENCIA.md']);
for (const r of allReports) {
  if (fileExists(r)) {
    const c = readFile(r);
    if (c.includes('74.172') && !c.includes('74.672')) {
      cellCountContradiction = true;
      FAIL.push(`✗ CONTRADICTION: ${r} references 74.172 without 74.672 clarification`);
    }
    // 74.172 may be present IF clearly marked as historical/typo
    if (c.includes('74.172') && !c.toLowerCase().includes('typo') && !c.toLowerCase().includes('histórico') && !r.includes('PRUEBAS_EQUIVALENCIA')) {
      // Soft warning — allow in historical docs but flag
    }
  }
}
if (!cellCountContradiction) {
  PASS.push('✓ No 74.172 contradictions');
}

// Old SHA-256 references (from previous ZIPs)
const oldZipsHashes = [
  'e5457410340f123ccace90e5441a54aa603513bc85a4320f03fd65d98ff1df0b',
  '0119df3c8bcf1c9e81d4b8dedae26e62a24c19e1e4fe7b2c14fcc2357a057ea0',
  '20899911c7a11757722fa0ef78f48463dc55e0d0dd0dc89c32f672f5f500e823'
];
let oldHashRef = false;
const allMdFiles = reports.map(r => `reports/${r}`).concat(['README.md', 'RELEASE_FINAL.md']);
for (const r of allMdFiles) {
  if (fileExists(r)) {
    const c = readFile(r);
    for (const h of oldZipsHashes) {
      if (c.includes(h)) {
        oldHashRef = true;
        FAIL.push(`✗ CONTRADICTION: ${r} references old ZIP SHA-256 ${h.substring(0, 16)}...`);
      }
    }
  }
}
if (!oldHashRef) {
  PASS.push('✓ No old ZIP SHA-256 references');
}

// Old test counts — P9-cierre (FASE 18): este check era código muerto (detectaba
// pero NO hacía FAIL). Ahora falla de verdad: las cifras 219/220/206 provienen
// de ejecuciones anteriores y NO pueden aparecer como estado actual.
// Además se verifica el PISO ESTÁTICO: contar las declaraciones reales de
// tests en el código (it(/test( ancladas a inicio de línea) y exigir que la
// cifra documentada en TEST_RESULTS_FINAL.md nunca sea menor. El runtime
// siempre es >= el estático (los bucles for...it() generan más), por lo que
// documentado < estático es matemáticamente imposible sin documento obsoleto.
const oldTestCounts = ['219 tests', '220 tests', '206 tests'];
for (const r of allMdFiles) {
  if (fileExists(r)) {
    const c = readFile(r);
    for (const tc of oldTestCounts) {
      if (c.includes(tc) && !c.includes('histórico') && !c.includes('typo')) {
        FAIL.push(`✗ STALE: ${r} cita "${tc}" como cifra actual (los números antiguos deben regenerarse desde la última ejecución real)`);
      }
    }
  }
}

// Piso estático de tests: recuento de declaraciones en el código fuente
function countStaticTests(dirs, pattern) {
  let n = 0;
  for (const dir of dirs) {
    const full = path.join(ROOT, dir);
    if (!fs.existsSync(full)) continue;
    for (const f of fs.readdirSync(full)) {
      if (!/\.(test|spec)\.js$/.test(f)) continue;
      const src = fs.readFileSync(path.join(full, f), 'utf8');
      const matches = src.match(pattern) || [];
      n += matches.length;
    }
  }
  return n;
}
const staticVitest = countStaticTests(['tests/unit', 'tests/integration'], /^\s*it\(/gm);
const staticPlaywright = countStaticTests(['tests/e2e'], /^\s*test\(/gm);

// Cifra documentada en TEST_RESULTS_FINAL.md (Subtotal Vitest / Subtotal Playwright)
if (fileExists('reports/TEST_RESULTS_FINAL.md')) {
  const tr = readFile('reports/TEST_RESULTS_FINAL.md');
  const vitestDoc = parseInt((tr.match(/\*\*Subtotal Vitest\*\*\s*\|\s*\*\*(\d+)\*\*/) || [])[1] || '0', 10);
  const pwDoc = parseInt((tr.match(/\*\*Subtotal Playwright\*\*\s*\|\s*\*\*(\d+)\*\*/) || [])[1] || '0', 10);
  check(`TEST_RESULTS_FINAL: Subtotal Vitest (${vitestDoc}) >= piso estático (${staticVitest})`,
    vitestDoc >= staticVitest, `doc=${vitestDoc}, static=${staticVitest} (doc menor que el estático = cifra obsoleta)`);
  check(`TEST_RESULTS_FINAL: Subtotal Playwright (${pwDoc}) >= piso estático (${staticPlaywright})`,
    pwDoc >= staticPlaywright, `doc=${pwDoc}, static=${staticPlaywright} (doc menor que el estático = cifra obsoleta)`);
} else {
  check('reports/TEST_RESULTS_FINAL.md exists', false, 'necesario para el check de piso estático');
}

// Cifras antiguas de archivos/hashes (FASE 18)
const staleFilePatterns = ['80 archivos', '77 hashes', '87 files', '88 files', '92 hashes', '93 hashes', '92 entradas'];
for (const r of allMdFiles) {
  if (fileExists(r)) {
    const c = readFile(r);
    for (const sp of staleFilePatterns) {
      if (c.includes(sp) && !c.includes('histórico')) {
        FAIL.push(`✗ STALE: ${r} contiene la cifra obsoleta "${sp}" (debe regenerarse con el recuento real)`);
      }
    }
  }
}

// Manifest validation
console.log('--- MANIFEST ---');
const manifestPath = path.join(ROOT, 'MANIFEST_SHA256.txt');
if (fs.existsSync(manifestPath)) {
  const manifestContent = readFile('MANIFEST_SHA256.txt');
  const lines = manifestContent.split('\n').filter(l => /^[a-f0-9]{64}/.test(l));
  let hashOk = 0, hashFail = 0, missing = 0;
  for (const line of lines) {
    const m = line.match(/^([a-f0-9]{64})\s+(\d+)\s+(.+)$/);
    if (!m) continue;
    const expectedHash = m[1];
    const expectedSize = parseInt(m[2], 10);
    let filePath = m[3].trim().replace(/^\.\//, '');
    const full = path.join(ROOT, filePath);
    if (!fs.existsSync(full)) { missing++; continue; }
    const buf = fs.readFileSync(full);
    const actualHash = crypto.createHash('sha256').update(buf).digest('hex');
    const actualSize = buf.length;
    if (actualHash === expectedHash && actualSize === expectedSize) hashOk++;
    else hashFail++;
  }
  check(`MANIFEST valid (${hashOk} OK, ${hashFail} hash mismatch, ${missing} missing)`,
    hashFail === 0 && missing === 0, `verified=${hashOk}`);
} else {
  check('MANIFEST_SHA256.txt present', false, 'MISSING');
}

// SBOM
console.log('--- SBOM ---');
if (fileExists('sbom.json')) {
  try {
    const sbom = JSON.parse(readFile('sbom.json'));
    check('sbom.json valid JSON', true);
    check('sbom.json CycloneDX', sbom.bomFormat === 'CycloneDX', `bomFormat=${sbom.bomFormat}`);
    check('sbom.json has timestamp', !!sbom.metadata?.timestamp, `ts=${sbom.metadata?.timestamp}`);
    check('sbom.json has components', (sbom.components || []).length > 0, `count=${(sbom.components||[]).length}`);
    const xlsxComp = (sbom.components || []).find(c => c.name === 'xlsx' || c.name.startsWith('xlsx@'));
    check('sbom.json includes xlsx component', !!xlsxComp, xlsxComp ? `${xlsxComp.name}@${xlsxComp.version}` : 'NOT FOUND');
  } catch (e) {
    check('sbom.json valid JSON', false, e.message);
  }
} else {
  check('sbom.json present', false, 'MISSING');
}

// File count check (auto-calculated, not hardcoded)
console.log('--- FILE COUNT ---');
const { execSync } = require('child_process');
try {
  const fileList = execSync(
    `find . -type f -not -path "./node_modules/*" -not -path "./.git/*" -not -path "./test-results/*" -not -path "./playwright-report/*" -not -path "./coverage/*" -not -path "./.nyc_output/*" -not -path "./download/*"`,
    { cwd: ROOT, encoding: 'utf8' }
  ).trim().split('\n').filter(l => l);
  const realFileCount = fileList.length;
  const manifestEntries = readFile('MANIFEST_SHA256.txt').split('\n').filter(l => /^[a-f0-9]{64}/.test(l)).length;
  check(`File count consistency (real=${realFileCount}, manifest=${manifestEntries}, expected diff=1 for MANIFEST itself)`,
    Math.abs(realFileCount - manifestEntries) <= 1,
    `real=${realFileCount}, manifest=${manifestEntries}`);
} catch (e) {
  check('File count consistency', false, e.message);
}

// === CI WORKFLOW (FASE 15) ===
console.log('--- CI WORKFLOW ---');
if (fileExists('.github/workflows/ci.yml')) {
  const ci = readFile('.github/workflows/ci.yml');
  const ciLines = ci.split('\n');
  // 1. Los valores de branches deben ser secuencias de flujo con '[' abierto
  const badBranches = ciLines.filter(l => /^\s*branches:\s*[^[\s]/.test(l) && !/^\s*branches:\s*$/.test(l));
  check('ci.yml: branches usan secuencia [..]', badBranches.length === 0,
    badBranches.length === 0 ? '' : `líneas sospechosas: ${badBranches.map(l => l.trim()).join(' | ')}`);
  // 2. Los run: con ': ' interno DEBEN estar entrecomillados (YAML inválido si no)
  const badRun = ciLines.filter(l => {
    const m = l.match(/^\s*run:\s*(.+)$/);
    if (!m) return false;
    const v = m[1].trim();
    if (v.startsWith("'") || v.startsWith('"') || v.startsWith('>') || v.startsWith('|')) return false;
    return /:\s/.test(v); // 'WARN: foo' sin quote rompe el parser YAML
  });
  check('ci.yml: comandos run con ": " internos entrecomillados', badRun.length === 0,
    badRun.length === 0 ? '' : `líneas sin quote: ${badRun.map(l => l.trim().slice(0, 60)).join(' | ')}`);
  // 3. Jobs esperados presentes
  for (const job of ['lint', 'unit-tests', 'integration-tests', 'e2e-tests', 'accessibility', 'performance', 'security-checks', 'sbom', 'build']) {
    check(`ci.yml: job "${job}" definido`, new RegExp(`^  ${job}:`, 'm').test(ci));
  }
} else {
  check('.github/workflows/ci.yml exists', false, 'MISSING');
}

// === @perf TAGS (FASE 17) ===
console.log('--- PERF TAGS ---');
const perfTagCount = countStaticTests(['tests/e2e'], /@perf/gm);
check('npm run test:perf tiene tests @perf reales (>0)', perfTagCount > 0, `@perf occurrences=${perfTagCount}`);

// === REGRESIÓN M-07/M-10 (Mapping multi-file) ===
console.log('--- MAPPING MULTI-FILE REGRESSION GUARD ---');
if (fileExists('ui.js')) {
  const ui = readFile('ui.js');
  check('ui.js initMappingData soporta formato array M-10 (regresión M-07)',
    /function initMappingData[\s\S]{0,600}Array\.isArray\(SPEC\.STATE\.archivos\.mapping\)/.test(ui),
    'Array.isArray presente en initMappingData');
}

// === RESULT ===
console.log('');
console.log('=== RESULTS ===');
PASS.forEach(p => console.log(p));
console.log('');
if (FAIL.length > 0) {
  console.log('--- FAILURES ---');
  FAIL.forEach(f => console.log(f));
  console.log('');
  console.log(`RESULT: FAIL (${FAIL.length} failures, ${PASS.length} passes)`);
  process.exit(1);
} else {
  console.log(`RESULT: PASS (${PASS.length} checks passed)`);
  process.exit(0);
}
