// Coverage hook for SPEC Web v6.0
//
// Problem: tests/setup.js loads app.js via `new Function(readFileSync(appPath))`
// which bypasses vitest's istanbul transform pipeline (Vite hooks run on
// ESM imports, not fs.readFileSync). The result is 0% coverage for app.js and
// charts.js even though every function is exercised.
//
// Workaround: monkey-patch fs.readFileSync so that when setup.js reads
// app.js / charts.js, we return the istanbul-instrumented source instead.
// The instrumented source contains coverage counters that write into a
// global `__coverage__` object, which vitest's istanbul reporter picks up.
//
// Usage:
//   NODE_OPTIONS="--require ./scripts/coverage_hook.cjs" npm run test:coverage
//
// This file is excluded from eslint (scripts/** is ignored).

'use strict';

const { readFileSync: origReadFileSync } = require('node:fs');
const { resolve } = require('node:path');
const { createInstrumenter } = require('istanbul-lib-instrument');

const projectRoot = resolve(__dirname, '..');

const instrumenter = createInstrumenter({
  esModules: false,
  coverageVariable: '__coverage__',
  produceSourceMap: false
});

const TARGETS = new Set([
  resolve(projectRoot, 'app.js'),
  resolve(projectRoot, 'charts.js')
]);

// Cache original sources and instrumented versions
const originalCache = new Map();
const instrumentedCache = new Map();

function getInstrumented(path) {
  if (!TARGETS.has(path)) return null;
  if (instrumentedCache.has(path)) return instrumentedCache.get(path);
  let src;
  if (originalCache.has(path)) {
    src = originalCache.get(path);
  } else {
    src = origReadFileSync(path, 'utf8');
    originalCache.set(path, src);
  }
  // Pass the absolute path as the file path so istanbul keys the coverage
  // data with the same absolute path that vitest's istanbul provider uses.
  const instrumented = instrumenter.instrumentSync(src, path);
  instrumentedCache.set(path, instrumented);
  return instrumented;
}

// Monkey-patch fs.readFileSync. We only intercept calls for our target files
// when the encoding is 'utf8' (string output), so binary reads elsewhere are
// unaffected.
const fs = require('node:fs');
const origRead = fs.readFileSync;
fs.readFileSync = function patchedReadFileSync(path, options) {
  try {
    const p = typeof path === 'string' ? path : (path && path.toString());
    const norm = p && resolve(p);
    if (norm && TARGETS.has(norm)) {
      const opts = typeof options === 'string' ? options : (options && options.encoding);
      if (opts === 'utf8' || opts === 'utf-8') {
        const instr = getInstrumented(norm);
        if (instr) return instr;
      }
    }
  } catch (_e) {
    // fall through to original
  }
  return origRead.apply(this, arguments);
};

// istanbul-lib-instrument writes the coverage object to globalThis.__coverage__
// Make sure it exists so reporters can find it.
if (typeof globalThis.__coverage__ === 'undefined') {
  globalThis.__coverage__ = {};
}

module.exports = { getInstrumented };

// (debug) console.error(`[coverage_hook] loaded in process ${process.pid} cwd=${process.cwd()}`);
