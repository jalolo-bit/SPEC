#!/usr/bin/env python3
"""
F-13 / R-18 — Generador de datos sintéticos anonimizados para SPEC Web v6.0.

Crea 4 archivos .xlsx con la misma estructura que los reales pero con:
- Nombres sintéticos (no reales)
- WMS logins sintéticos
- Cobertura de los 7 secciones del REPORTE_CAMBIOS_HR
- Casos límite (login con prefijo+dígitos, leading zeros, duplicados, etc.)

Uso: python3 scripts/08_generate_synthetic_data.py
Salida: test-data/synthetic/{HORA_SIN_VOLUMEN,VOLUMEN,VOL_SIN_HORAS,Mapping}_synth.xlsx
"""
import os
import random
from datetime import date, timedelta
from openpyxl import Workbook
from openpyxl.styles import Font

OUT_DIR = os.path.join(os.path.dirname(__file__), '..', 'test-data', 'synthetic')
os.makedirs(OUT_DIR, exist_ok=True)

random.seed(42)  # determinista

NOMBRES_SINTETICOS = [
    'GARCIA PEREZ ANA', 'MARTINEZ LOPEZ BRUNO', 'SANCHEZ RUIZ CARLA',
    'FERNANDEZ GOMEZ DIEGO', 'TORRES JIMENEZ ELENA', 'RAMOS ORTIZ PABLO',
    'NAVARRO HERRERA LUCIA', 'MOLINA CASTRO ALVARO', 'ORTEGA DELGADO MARINA',
    'AGUILAR VEGA HUGO', 'PENA SOTO IRENE', 'LOPEZ DIAZ MARIO',
    'MORALEZ CRUZ SARA', 'HEREDIA SANTOS IVAN', 'VARGAS LEON NURIA',
    'PASCUAL MOYA JAVI', 'BLANCO PEÑA LIDIA', 'CAMPOS GIL ERNESTO',
    'CANO REYES BEATRIZ', 'IBANEZ MORA ADRIAN',
]

LOGINS = [
    # (login, sección esperada)
    ('OTO1020', 1),  # cambio HR Task: 1020 → propuesta 1050
    ('OTO1050', 3),  # HR Task correcta
    ('OTO0499', 1),  # cambio con leading zeros
    ('EU20080', 1),  # cambio
    ('EU20052', 3),  # correcta
    ('OTO', 6),      # sin IdNum, multi HR Task
    ('EU1020', 6),   # multi HR Task (mismo num que OTO1020)
    ('', 4),         # sin login → sin volumen
    ('OTO0001', 7),  # ambigüedad IdNum (mismo num que OTO1)
    ('OTO1', 7),     # ambigüedad IdNum
    ('OTO3000', 2),  # varias TaskSpec (mapear a 2 TASK_SPEC)
    ('OTO3001', 5),  # WMS Task sin mapping
    ('OTO4000', 1),  # cambio
    ('OTO5000', 3),  # correcta
    ('OTO6000', 4),  # sin volumen
]

TASKS_SPEC = {
    'PUTAWAY': '20052',
    'PICKING': '20080',
    'PACKING': '20051',
    'CHECKOUT': '20053',
    'DEVOLUCIONES': '20054',
}

MAPEOS = [
    # (SAP_CODE, CUSTOMER, TASK_WMS, TASK_SPEC)
    ('SAP001', 'INDITEX', 'PUTAWAY', '20052'),
    ('SAP001', 'INDITEX', 'PICKING', '20080'),
    ('SAP001', 'INDITEX', 'PACKING', '20051'),
    ('SAP001', 'INDITEX', 'CHECKOUT', '20053'),
    ('SAP001', 'INDITEX', 'DEVOLUCIONES', '20054'),
    # Ambiguo: PUTAWAY mapeado a 2 TaskSpec
    ('SAP001', 'INDITEX', 'PUTAWAY', '20099'),
    # Sin mapping: TASK_WMS_NO_MAPPING
]

def make_hora_sin_volumen():
    wb = Workbook()
    ws = wb.active
    ws.title = 'Export'
    headers = ['Site name', 'Department', 'Activity', 'Subactivity', 'Date',
               'HR Task', 'WMS Login', 'Name', 'Hours without volume']
    ws.append(headers)
    for c in ws[1]:
        c.font = Font(bold=True)
    fecha = date(2026, 8, 25)
    for login, sec in LOGINS:
        if sec == 4 and not login:  # sin login
            continue
        if sec == 6:  # multi HR Task: 2 filas para el mismo login
            for hr_task in ['PUTAWAY', 'PICKING']:
                ws.append(['ONTIGOLA', 'ECOM', hr_task, 'SUB',
                           fecha, hr_task, login,
                           random.choice(NOMBRES_SINTETICOS),
                           round(random.uniform(0.5, 5), 2)])
        else:
            hr_task = 'PUTAWAY' if sec != 5 else 'TASK_WMS_NO_MAPPING'
            ws.append(['ONTIGOLA', 'ECOM', hr_task, 'SUB',
                       fecha, hr_task, login,
                       random.choice(NOMBRES_SINTETICOS),
                       round(random.uniform(0.5, 4), 2)])
    # 2 filas de footer (que el motor filtra)
    ws.append(['TOTAL', '', '', '', '', '', '', '', 100])
    ws.append(['Filtros aplicados: VW_ALERT_TASK_HR_DIRECT_HOURS_NO_WMS_VOLUME_DAY'])
    wb.save(os.path.join(OUT_DIR, 'HORA_SIN_VOLUMEN_synth.xlsx'))

def make_volumen():
    wb = Workbook()
    ws = wb.active
    ws.title = 'Export'
    headers = ['DATE', 'SAP_CODE', 'CUSTOMER', 'WMS_TASK', 'WMS_LOGIN', 'USER_NAME', 'WMS_UOM']
    ws.append(headers)
    for c in ws[1]:
        c.font = Font(bold=True)
    fecha = date(2026, 8, 25)
    # Generar volumen para algunos logins
    for login, sec in LOGINS:
        if sec == 4:  # sin volumen
            continue
        if sec == 5:  # sin mapping
            wms_task = 'TASK_WMS_NO_MAPPING'
        else:
            wms_task = random.choice(['PUTAWAY', 'PICKING', 'PACKING', 'CHECKOUT'])
        # Volume positivo
        ws.append([fecha, 'SAP001', 'INDITEX', wms_task, login,
                   'user_synth', random.randint(50, 500)])
        # Algunos con volume negativo (correcciones)
        if random.random() < 0.2:
            ws.append([fecha, 'SAP001', 'INDITEX', wms_task, login,
                       'user_synth', -random.randint(10, 50)])
    # 8 sin login (caso límite)
    for _ in range(8):
        ws.append([fecha, 'SAP001', 'INDITEX', 'PUTAWAY', '',
                   'user_synth', random.randint(50, 200)])
    ws.append(['TOTAL', '', '', '', '', '', 99999])
    wb.save(os.path.join(OUT_DIR, 'VOLUMEN_synth.xlsx'))

def make_vol_sin_horas():
    wb = Workbook()
    ws = wb.active
    ws.title = 'Export'
    headers = ['Site name', 'Department', 'Activity', 'Subactivity', 'Date',
               'HR Task', 'WMS Login', 'Name', 'Volume Without Hours']
    ws.append(headers)
    for c in ws[1]:
        c.font = Font(bold=True)
    fecha = date(2026, 8, 25)
    for _ in range(15):
        ws.append(['ONTIGOLA', 'ECOM', random.choice(['PUTAWAY', 'PICKING']),
                   'SUB', fecha, 'DEVOLUCIONES',
                   random.choice(LOGINS)[0],
                   random.choice(NOMBRES_SINTETICOS),
                   random.randint(10, 100)])
    ws.append(['TOTAL', '', '', '', '', '', '', '', 9999])
    wb.save(os.path.join(OUT_DIR, 'VOL_SIN_HORAS_synth.xlsx'))

def make_mapping():
    wb = Workbook()
    ws = wb.active
    ws.title = 'Mapping'
    headers = ['SAP_CODE', 'WMS_DC', 'CUSTOMER', 'DEPARTMENT', 'ACTIVITY',
               'SUB_ACTIVITY', 'TASK_WMS', 'TASK_SPEC',
               'HIERARCHY', 'PRODUCTIVE_TASK', 'DIRECT_TASK',
               'GLOBAL_EFFICIENCY', 'GLOBAL_PRODUCTIVITY', 'UOM']
    ws.append(headers)
    for c in ws[1]:
        c.font = Font(bold=True)
    for sap, cust, wms, spec in MAPEOS:
        ws.append([sap, 'DC1', cust, 'ECOM', wms, 'SUB', wms, spec,
                   'N1', 'Y', 'N', 0.85, 0.92, 'U'])
    wb.save(os.path.join(OUT_DIR, 'Mapping_synth.xlsx'))

if __name__ == '__main__':
    make_hora_sin_volumen()
    make_volumen()
    make_vol_sin_horas()
    make_mapping()
    print('OK — synthetic data generated in', OUT_DIR)
    for f in sorted(os.listdir(OUT_DIR)):
        full = os.path.join(OUT_DIR, f)
        print(f'  {f}: {os.path.getsize(full)} bytes')
