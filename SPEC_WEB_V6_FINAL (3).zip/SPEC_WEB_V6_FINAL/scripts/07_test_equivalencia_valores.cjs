/* P8-cierre — Test de equivalencia LEGACY migrado a CommonJS (.cjs).
 *
 * Original: scripts/07_test_equivalencia_valores.js (require-based, hardcoded paths)
 * Migración: .cjs para compatibilidad con "type":"module" de package.json.
 *
 * Compara cada celda de cada tabla entre el Excel (SPEC V0.47.3.xlsm) y el port JS.
 * Genera reports/EQUIVALENCE_MACHINE_RESULT.json con el resultado estructurado.
 *
 * P7-cierre — PASS requiere: 0 mismatches + 0 structural issues + rows match.
 *
 * Uso: node scripts/07_test_equivalencia_valores.cjs
 */

const XLSX = require('xlsx');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

// P8-cierre — paths relativos al script, no hardcoded
const ROOT = path.resolve(__dirname, '..');
const APP_JS = path.join(ROOT, 'app.js');
const DRIVE_DIR = path.join(ROOT, 'audit-ref', 'drive');
const SPEC_XLSM = path.join(DRIVE_DIR, 'SPEC V0.47.3.xlsm');

// Load app.js via eval (legacy pattern, app.js is IIFE that uses globalThis)
globalThis.XLSX = XLSX;
const src = fs.readFileSync(APP_JS, 'utf8');
// eslint-disable-next-line no-new-func
const loader = new Function('globalThis', 'window', 'XLSX', src + '\nreturn SPEC;');
const SPEC = loader(globalThis, globalThis, XLSX);

const TABLES_TO_COMPARE = [
  { js: '01_HorasSinVolumen', excel: '01_HorasSinVolumen', isReporte: false },
  { js: '02_VolumenDetalle', excel: '02_VolumenDetalle', isReporte: false },
  { js: '03_VolumenPersonaDia', excel: '03_VolumenPersonaDia', isReporte: false },
  { js: '05_VolumenIdNumericoDia', excel: '05_VolumenIdNumericoDia', isReporte: false },
  { js: '07_Conciliacion', excel: '07_Conciliacion', isReporte: false },
  { js: '08_Validaciones', excel: '08_Validaciones', isReporte: false },
  { js: '09_VolumenSinHorasDetalle', excel: '09_VolumenSinHorasDetalle', isReporte: false },
  { js: '10_VolumenSinHorasPersonaDia', excel: '10_VolumenSinHorasPersonaDia', isReporte: false },
  { js: '12_MapeoActividadSPEC', excel: '12_MapeoActividadSPEC', isReporte: false },
  { js: '13_VolumenMapeadoSPEC', excel: '13_VolumenMapeadoSPEC', isReporte: false },
  { js: '14_VolumenPersonaDiaActividadSPEC', excel: '14_VolumenPersonaDiaActividadSP', isReporte: false },
  { js: '15_VolumenSinHorasPersonaDiaActividadSPEC', excel: '15_VolumenSinHorasPersonaDiaAct', isReporte: false },
  { js: '16_ControlMapeoSPEC', excel: '16_ControlMapeoSPEC', isReporte: false },
  { js: 'REPORTE_CAMBIOS_HR', excel: 'REPORTE_CAMBIOS_HR', isReporte: true }
];

function readXlsx(p) {
  const buf = fs.readFileSync(p);
  return XLSX.read(buf, { type: 'buffer', cellDates: true });
}

function setupArchivos() {
  const wbHoras = readXlsx(path.join(DRIVE_DIR, 'HORA SIN VOLUMEN.xlsx'));
  const wbVolumen = readXlsx(path.join(DRIVE_DIR, 'VOLUMEN.xlsx'));
  const wbVSH = readXlsx(path.join(DRIVE_DIR, 'VOL SIN HORAS.xlsx'));
  const wbMapping = readXlsx(path.join(DRIVE_DIR, 'Mapping.xlsx'));
  SPEC.STATE.archivos.horas = [{ name: 'HORA SIN VOLUMEN.xlsx', workbook: wbHoras }];
  SPEC.STATE.archivos.volumen = [{ name: 'VOLUMEN.xlsx', workbook: wbVolumen }];
  SPEC.STATE.archivos.volSinHoras = [{ name: 'VOL SIN HORAS.xlsx', workbook: wbVSH }];
  SPEC.STATE.archivos.mapping = [{ name: 'Mapping.xlsx', workbook: wbMapping }];
}

function readSheetAsRows(p, sheetName) {
  const wb = readXlsx(p);
  const ws = wb.Sheets[sheetName];
  if (!ws) return null;
  const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: null });
  if (aoa.length === 0) return null;
  const headers = aoa[0].map((h) => (h == null ? '' : String(h)));
  const rows = [];
  for (let i = 1; i < aoa.length; i++) {
    const r = aoa[i];
    if (!r.some((c) => c != null && String(c).trim() !== '')) continue;
    const obj = {};
    for (let j = 0; j < headers.length; j++) {
      obj[headers[j]] = r[j] != null ? r[j] : null;
    }
    rows.push(obj);
  }
  return { headers, rows };
}

function normVal(v) {
  if (v == null) return '';
  if (v instanceof Date) {
    const y = v.getUTCFullYear();
    const m = String(v.getUTCMonth() + 1).padStart(2, '0');
    const d = String(v.getUTCDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
  if (typeof v === 'number') {
    if (!isFinite(v)) return 'NaN';
    return v.toLocaleString('en-US', { maximumFractionDigits: 12, useGrouping: false });
  }
  if (typeof v === 'boolean') return v ? 'TRUE' : 'FALSE';
  return String(v).trim();
}

function compareTable(name, expected, actual) {
  const issues = [];
  const expH = expected.headers.filter((h) => h);
  const actH = Object.keys(actual[0] || {});
  const missingInJs = expH.filter((h) => !actH.some((h2) => h2.toUpperCase().trim() === h.toUpperCase().trim()));
  const extraInJs = actH.filter((h) => !expH.some((h2) => h2.toUpperCase().trim() === h.toUpperCase().trim()));
  if (missingInJs.length > 0) issues.push(`Missing in JS: ${missingInJs.join(', ')}`);
  if (extraInJs.length > 0) issues.push(`Extra in JS: ${extraInJs.join(', ')}`);
  const commonCols = expH.filter((h) => actH.some((h2) => h2.toUpperCase().trim() === h.toUpperCase().trim()));
  // Canonical key: concat of all common column values normalized
  const canonKey = (r) => commonCols.map((c) => normVal(r[c] != null ? r[c] : r[c])).join('||');
  const expMap = new Map();
  for (const r of expected.rows) {
    const k = canonKey(r);
    if (!expMap.has(k)) expMap.set(k, r);
  }
  const actMap = new Map();
  for (const r of actual) {
    const k = canonKey(r);
    if (!actMap.has(k)) actMap.set(k, r);
  }
  let mismatches = 0;
  let totalCellsCompared = 0;
  const mismatchesByCol = {};
  for (const c of commonCols) mismatchesByCol[c] = 0;
  const sampleMismatches = [];
  for (const [k, expRow] of expMap.entries()) {
    const actRow = actMap.get(k);
    if (!actRow) {
      issues.push(`Row missing in JS for key="${k.substring(0, 60)}..."`);
      continue;
    }
    for (const c of commonCols) {
      const ev = normVal(expRow[c]);
      const av = normVal(actRow[c]);
      totalCellsCompared++;
      if (ev !== av) {
        mismatches++;
        mismatchesByCol[c]++;
        if (sampleMismatches.length < 5) {
          sampleMismatches.push({ col: c, exp: ev, act: av, key: k.substring(0, 60) });
        }
      }
    }
  }
  // Rows only in JS (not in Excel)
  for (const [k] of actMap.entries()) {
    if (!expMap.has(k)) {
      issues.push(`Extra row in JS for key="${k.substring(0, 60)}..."`);
    }
  }
  return {
    table: name,
    expectedRows: expected.rows.length,
    actualRows: actual.length,
    colsExpected: expH.length,
    colsActual: actH.length,
    commonCols: commonCols.length,
    cellsCompared: totalCellsCompared,
    mismatches,
    mismatchRate: totalCellsCompared > 0 ? Number((mismatches / totalCellsCompared * 100).toFixed(2)) : 0,
    mismatchesByCol,
    sampleMismatches,
    issues,
    passed: mismatches === 0 && issues.length === 0 && expected.rows.length === actual.length
  };
}

async function main() {
  setupArchivos();
  await SPEC.analizarYConciliar();

  const specSheets = {};
  for (const t of TABLES_TO_COMPARE) {
    specSheets[t.excel] = readSheetAsRows(SPEC_XLSM, t.excel);
  }

  const results = [];
  for (const t of TABLES_TO_COMPARE) {
    const expected = specSheets[t.excel];
    const actual = t.isReporte ? SPEC.STATE.reporte : SPEC.STATE.queries[t.js];
    if (!expected || !actual || actual.length === 0) {
      results.push({
        table: t.js, expectedRows: 0, actualRows: 0, cellsCompared: 0,
        mismatches: 0, issues: ['SKIP: empty'], passed: false
      });
      continue;
    }
    const r = compareTable(t.js, expected, actual);
    results.push(r);
  }

  const totalMismatches = results.reduce((s, r) => s + r.mismatches, 0);
  const totalCells = results.reduce((s, r) => s + r.cellsCompared, 0);
  const tablesPassed = results.filter(r => r.passed).length;
  const allIssues = results.flatMap(r => r.issues.map(i => ({ table: r.table, issue: i })));

  const summary = {
    // P9-cierre — SIN timestamp: el JSON de resultado es DETERMINISTA para que
    // re-ejecutar la equivalencia no invalide el MANIFEST_SHA256.txt del paquete
    // (hallazgo de la prueba de reproducibilidad FASE 23). La fecha de la
    // ejecución se informa por consola, no en el artifact.
    tables: TABLES_TO_COMPARE.length,
    tablesPassed,
    mismatches: totalMismatches,
    cellsCompared: totalCells,
    issues: allIssues,
    passed: totalMismatches === 0 && allIssues.length === 0 && tablesPassed === TABLES_TO_COMPARE.length,
    perTable: results.map(r => ({
      table: r.table,
      expectedRows: r.expectedRows,
      actualRows: r.actualRows,
      cellsCompared: r.cellsCompared,
      mismatches: r.mismatches,
      passed: r.passed,
      issues: r.issues
    }))
  };

  const outPath = path.join(ROOT, 'reports', 'EQUIVALENCE_MACHINE_RESULT.json');
  fs.writeFileSync(outPath, JSON.stringify(summary, null, 2));
  console.log('Equivalence result written to:', outPath);
  console.log('Tables:', summary.tables, '/', 'Passed:', summary.tablesPassed);
  console.log('Mismatches:', summary.mismatches);
  console.log('Cells compared:', summary.cellsCompared);
  console.log('Overall PASS:', summary.passed);
  if (!summary.passed) {
    console.log('Issues:');
    for (const i of summary.issues) console.log('  -', i.table, ':', i.issue);
    process.exit(1);
  }
}

main().catch(err => { console.error(err); process.exit(1); });
