// Standalone coverage runner for SPEC Web v6.0
//
// This script measures coverage of app.js and charts.js when exercised by
// the integration equivalence suite. It does NOT use vitest's istanbul
// provider because:
//   - The tests load app.js via `new Function(readFileSync('app.js'))`
//   - This bypasses vitest's vite-istanbul transform pipeline
//   - Result: vitest reports 0% coverage for app.js/charts.js
//
// Instead, this script:
//   1. Loads the coverage hook (scripts/coverage_hook.cjs), which monkey-
//      patches fs.readFileSync to return istanbul-instrumented app.js /
//      charts.js source when setup.js asks for them.
//   2. Imports tests/setup.js — this runs the IIFE that attaches SPEC
//      (instrumented with counters) to globalThis.SPEC.
//   3. Replicates the integration-test setup: reads the 4 real drive
//      files, populates SPEC.STATE.archivos, awaits analizarYConciliar.
//   4. Reads `globalThis.__coverage__` (populated by the instrumented app.js)
//      and emits text/html/lcov reports via istanbul-lib-coverage.
//
// Run:
//   node scripts/cover_integration.cjs
//
// Outputs:
//   coverage/lcov.info
//   coverage/index.html  (+ lcov-report/)
//   stdout text summary

'use strict';

const path = require('node:path');
const fs = require('node:fs');
const { resolve } = require('node:path');

const projectRoot = resolve(__dirname, '..');
process.chdir(projectRoot);

// Step 1: install the readFileSync monkey-patch (in this same process)
require('./coverage_hook.cjs');

// Step 2: load the test setup (this evals the instrumented app.js + xlsx)
require('../tests/setup.js');

// Step 3: load XLSX (CommonJS-style — it was assigned to globalThis by setup)
const XLSX = globalThis.XLSX;
const SPEC = globalThis.SPEC;

if (!XLSX || typeof XLSX.read !== 'function') {
  throw new Error('XLSX not loaded by tests/setup.js');
}
if (!SPEC || typeof SPEC.analizarYConciliar !== 'function') {
  throw new Error('SPEC.analizarYConciliar not loaded by tests/setup.js');
}

// Step 4: replicate the integration test scenario.
const drive = path.join(projectRoot, 'audit-ref', 'drive');
const wbHoras    = XLSX.readFile(path.join(drive, 'HORA SIN VOLUMEN.xlsx'));
const wbVolumen  = XLSX.readFile(path.join(drive, 'VOLUMEN.xlsx'));
const wbVSH      = XLSX.readFile(path.join(drive, 'VOL SIN HORAS.xlsx'));
const wbMapping  = XLSX.readFile(path.join(drive, 'Mapping.xlsx'));
SPEC.STATE.archivos.horas      = { name: 'HORA SIN VOLUMEN.xlsx', workbook: wbHoras };
SPEC.STATE.archivos.volumen    = { name: 'VOLUMEN.xlsx',           workbook: wbVolumen };
SPEC.STATE.archivos.volSinHoras = { name: 'VOL SIN HORAS.xlsx',     workbook: wbVSH };
SPEC.STATE.archivos.mapping    = { name: 'Mapping.xlsx',          workbook: wbMapping };

const reportDir = path.join(projectRoot, 'coverage');
fs.rmSync(reportDir, { recursive: true, force: true });
fs.mkdirSync(reportDir, { recursive: true });

SPEC.analizarYConciliar(() => {}).then(async () => {
  // Verify the run produced the expected 14 tables + reporte
  const queries = Object.keys(SPEC.STATE.queries);
  const reporte = SPEC.STATE.reporte || [];
  console.log('Integration scenario result:');
  console.log('  queries:', queries.length, '=>', queries.join(', '));
  console.log('  reporte rows:', reporte.length);

  // Step 5: collect coverage
  const covMap = globalThis.__coverage__ || {};
  console.log('Coverage files:', Object.keys(covMap));

  // Use istanbul-lib-coverage to compute a coverage summary
  const libCoverage = require('istanbul-lib-coverage');
  const map = libCoverage.createCoverageMap();
  for (const [filePath, data] of Object.entries(covMap)) {
    map.addFileCoverage(data);
  }

  const summary = map.getCoverageSummary();
  console.log('---');
  console.log('Coverage summary (integration suite, app.js + charts.js):');
  console.log('  Statements:', summary.statements.pct.toFixed(2) + '%',
              `(${summary.statements.covered}/${summary.statements.total})`);
  console.log('  Branches:  ', summary.branches.pct.toFixed(2) + '%',
              `(${summary.branches.covered}/${summary.branches.total})`);
  console.log('  Functions: ', summary.functions.pct.toFixed(2) + '%',
              `(${summary.functions.covered}/${summary.functions.total})`);
  console.log('  Lines:     ', summary.lines.pct.toFixed(2) + '%',
              `(${summary.lines.covered}/${summary.lines.total})`);
  console.log('---');
  console.log('Per-file breakdown:');
  for (const filePath of Object.keys(covMap).sort()) {
    const fileCoverage = map.fileCoverageFor(filePath);
    const s = fileCoverage.toSummary();
    const basename = path.basename(filePath);
    console.log('  ' + basename + ':');
    console.log('    stmts=' + s.statements.pct.toFixed(1) + '% (' + s.statements.covered + '/' + s.statements.total + ')',
                'branch=' + s.branches.pct.toFixed(1) + '% (' + s.branches.covered + '/' + s.branches.total + ')',
                'fn=' + s.functions.pct.toFixed(1) + '% (' + s.functions.covered + '/' + s.functions.total + ')',
                'lines=' + s.lines.pct.toFixed(1) + '% (' + s.lines.covered + '/' + s.lines.total + ')');
  }

  // Write reports using istanbul-lib-report
  const libReport = require('istanbul-lib-report');
  const reports = require('istanbul-reports');
  const context = libReport.createContext({
    dir: reportDir,
    coverageMap: map
  });
  const reporters = ['text', 'html', 'lcov'];
  for (const r of reporters) {
    const report = reports.create(r, {});
    report.execute(context);
  }

  // Also write a JSON dump for downstream tooling
  fs.writeFileSync(
    path.join(reportDir, 'coverage-summary.json'),
    JSON.stringify({ totals: summary.toJSON(), files: Object.fromEntries(
      Object.keys(covMap).map(f => [f, map.fileCoverageFor(f).toSummary().toJSON()])
    )}, null, 2)
  );

  console.log('Reports written to', reportDir);

  // Step 6: also exercise charts.js (loaded via the same hook) so we get a
  // coverage entry for it. charts.js is an IIFE that needs a `window` global
  // and uses document.createElement for SVG. We provide a minimal stub DOM
  // and call the top-level exports.
  console.log('');
  console.log('Loading charts.js with stub DOM to measure its coverage...');
  // Re-read charts.js via the hook (returns instrumented source)
  const chartsSrc = fs.readFileSync(path.join(projectRoot, 'charts.js'), 'utf8');
  const chartsLoader = new Function(
    'window', 'globalThis', 'document', 'navigator', 'localStorage',
    chartsSrc
  );
  // Stub DOM that supports the SVG operations charts.js performs
  const svgStubs = [];
  function makeSvgEl() {
    const el = {
      tagName: '',
      attributes: {},
      style: {},
      children: [],
      textContent: '',
      innerHTML: '',
      classList: { add() {}, remove() {}, contains() { return false; } },
      setAttribute(k, v) { this.attributes[k] = v; },
      getAttribute(k) { return this.attributes[k]; },
      appendChild(child) { this.children.push(child); return child; },
      removeChild(child) {
        this.children = this.children.filter(c => c !== child);
      },
      addEventListener() {},
      removeEventListener() {},
      querySelector() { return null; },
      querySelectorAll() { return []; }
    };
    svgStubs.push(el);
    return el;
  }
  const stubDocument = {
    createElement: () => makeSvgEl(),
    createTextNode: (t) => ({ textContent: String(t) }),
    getElementById: () => null,
    querySelector: () => null,
    querySelectorAll: () => [],
    addEventListener() {},
    body: { appendChild() {}, removeChild() {} }
  };
  const stubWindow = globalThis;
  try {
    chartsLoader(stubWindow, globalThis, stubDocument, globalThis.navigator, globalThis.localStorage);
  } catch (e) {
    console.log('  charts.js load error (will skip):', e.message);
  }
  if (globalThis.SPEC_CHARTS) {
    console.log('  SPEC_CHARTS loaded with methods:',
      Object.keys(globalThis.SPEC_CHARTS).join(', '));
    // Try calling renderChartsGrid with a stub container
    const container = makeSvgEl();
    container.id = 'charts-grid';
    container.children = [];
    stubDocument.getElementById = (id) => id === 'charts-grid' ? container : null;
    try {
      globalThis.SPEC_CHARTS.renderChartsGrid('charts-grid');
      console.log('  renderChartsGrid called successfully');
    } catch (e) {
      console.log('  renderChartsGrid error:', e.message);
    }
  }

  // Re-collect coverage (now includes charts.js if loaded)
  const covMap2 = globalThis.__coverage__ || {};
  console.log('Coverage files (after charts.js):', Object.keys(covMap2));
  const map2 = libCoverage.createCoverageMap();
  // Re-add all entries to a fresh map
  for (const [filePath, data] of Object.entries(covMap2)) {
    map2.addFileCoverage(data);
  }
  const summary2 = map2.getCoverageSummary();
  console.log('---');
  console.log('Final coverage summary (integration suite + charts.js loaded):');
  console.log('  Statements:', summary2.statements.pct.toFixed(2) + '%',
              `(${summary2.statements.covered}/${summary2.statements.total})`);
  console.log('  Branches:  ', summary2.branches.pct.toFixed(2) + '%',
              `(${summary2.branches.covered}/${summary2.branches.total})`);
  console.log('  Functions: ', summary2.functions.pct.toFixed(2) + '%',
              `(${summary2.functions.covered}/${summary2.functions.total})`);
  console.log('  Lines:     ', summary2.lines.pct.toFixed(2) + '%',
              `(${summary2.lines.covered}/${summary2.lines.total})`);
  console.log('Per-file:');
  for (const filePath of Object.keys(covMap2).sort()) {
    const s = map2.fileCoverageFor(filePath).toSummary();
    console.log('  ' + path.basename(filePath) + ':',
                'stmts=' + s.statements.pct.toFixed(1) + '% (' + s.statements.covered + '/' + s.statements.total + ')',
                'branch=' + s.branches.pct.toFixed(1) + '% (' + s.branches.covered + '/' + s.branches.total + ')',
                'fn=' + s.functions.pct.toFixed(1) + '% (' + s.functions.covered + '/' + s.functions.total + ')',
                'lines=' + s.lines.pct.toFixed(1) + '% (' + s.lines.covered + '/' + s.lines.total + ')');
  }

  // Re-emit reports with the full map
  fs.rmSync(reportDir, { recursive: true, force: true });
  fs.mkdirSync(reportDir, { recursive: true });
  const context2 = libReport.createContext({
    dir: reportDir,
    coverageMap: map2
  });
  for (const r of ['text', 'html', 'lcov']) {
    reports.create(r, {}).execute(context2);
  }
  fs.writeFileSync(
    path.join(reportDir, 'coverage-summary.json'),
    JSON.stringify({
      totals: summary2.toJSON(),
      files: Object.fromEntries(
        Object.keys(covMap2).sort().map(f => [f, map2.fileCoverageFor(f).toSummary().toJSON()])
      )
    }, null, 2)
  );
  console.log('Reports re-written to', reportDir);
}).catch(e => {
  console.error('FATAL:', e.stack || e.message);
  process.exit(1);
});
