/* P8-cierre — Entrada ESM portable para el test de equivalencia de VALORES.
 *
 * El histórico scripts/07_test_equivalencia_valores.js (CommonJS con require()
 * y rutas hardcodeadas del entorno de desarrollo original) NO era ejecutable
 * desde una instalación limpia: package.json declara "type":"module", por lo
 * que require() lanza ReferenceError, y además apuntaba a rutas inexistentes
 * (/home/z/my-project/app/app.js, /home/z/my-project/upload/z3).
 *
 * La implementación CANÓNICA vive en scripts/07_test_equivalencia_valores.cjs
 * (CommonJS real, rutas relativas a __dirname, genera
 * reports/EQUIVALENCE_MACHINE_RESULT.json). Este archivo es un thin-wrapper
 * ESM que delega en el .cjs para que AMBOS puntos de entrada funcionen:
 *
 *   node scripts/07_test_equivalencia_valores.js    (ESM → delega)
 *   node scripts/07_test_equivalencia_valores.cjs   (canónico directo)
 *
 * Uso: node scripts/07_test_equivalencia_valores.js
 */

import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const canonical = path.resolve(__dirname, '07_test_equivalencia_valores.cjs');

const result = spawnSync(process.execPath, [canonical], { stdio: 'inherit' });
process.exit(result.status ?? 1);
