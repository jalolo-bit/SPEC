#!/usr/bin/env python3
"""
Lee los 4 archivos de entrada con pandas y muestra estructura + muestra + estadísticas básicas.
"""
import os
import json
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IN_DIR = os.path.join(ROOT, "audit-ref", "drive")
FILES = ["HORA SIN VOLUMEN.xlsx", "VOLUMEN.xlsx", "VOL SIN HORAS.xlsx", "Mapping.xlsx"]
OUT = os.path.join(ROOT, "audit", "inputs_inventory.md")

def main():
    out_lines = ["# Inventario de archivos de entrada\n\n"]
    for f in FILES:
        path = os.path.join(IN_DIR, f)
        out_lines.append(f"## {f}\n\n")
        try:
            xl = pd.ExcelFile(path)
            out_lines.append(f"- Hojas: `{xl.sheet_names}`\n\n")
            for sh in xl.sheet_names:
                df = pd.read_excel(path, sheet_name=sh)
                out_lines.append(f"### Hoja `{sh}`\n")
                out_lines.append(f"- Filas: {len(df)}\n- Columnas: {len(df.columns)}\n")
                out_lines.append(f"- Encabezados: `{list(df.columns)}\n")
                # tipos
                out_lines.append(f"- Tipos:\n")
                for c in df.columns:
                    out_lines.append(f"  - `{c}`: {df[c].dtype} | n_unique={df[c].nunique()} | n_null={df[c].isna().sum()}\n")
                # primeras 3 filas
                out_lines.append(f"\n**Primeras 3 filas:**\n\n")
                out_lines.append("```\n")
                out_lines.append(df.head(3).to_string())
                out_lines.append("\n```\n\n")
        except Exception as e:
            out_lines.append(f"ERROR: {e}\n\n")
    with open(OUT, "w", encoding="utf-8") as f:
        f.write("".join(out_lines))
    print(f"Wrote {OUT}")
    # print summary
    for f in FILES:
        path = os.path.join(IN_DIR, f)
        try:
            xl = pd.ExcelFile(path)
            for sh in xl.sheet_names:
                df = pd.read_excel(path, sheet_name=sh)
                print(f"{f} :: {sh}: {len(df)} rows x {len(df.columns)} cols")
                print(f"  cols: {list(df.columns)}")
        except Exception as e:
            print(f"{f} ERROR: {e}")

if __name__ == "__main__":
    main()
