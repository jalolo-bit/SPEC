/* P5-cierre — Validador automático del MANIFEST_SHA256.txt
 *
 * Uso: node scripts/validate_manifest.cjs
 *
 * Comprueba:
 *   - missing = 0     (archivos en manifest que no existen en disco)
 *   - hash_mismatch = 0
 *   - size_mismatch = 0
 *   - unexpected = 0  (archivos en disco no incluidos en manifest)
 *
 * Excluye automáticamente node_modules, .git, test-results, playwright-report,
 * coverage, .nyc_output y al propio MANIFEST_SHA256.txt (auto-referencia).
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = path.resolve(__dirname, '..');
const MANIFEST = path.join(ROOT, 'MANIFEST_SHA256.txt');

const EXCLUDE_DIRS = new Set(['node_modules', '.git', 'test-results', 'playwright-report', 'coverage', '.nyc_output', 'download', 'skills']);
const EXCLUDE_FILES = new Set(['MANIFEST_SHA256.txt']);

let missing = 0, hashMismatch = 0, sizeMismatch = 0, unexpected = 0;
let verified = 0;

const manifestFiles = new Set();

if (!fs.existsSync(MANIFEST)) {
  console.error('FAIL: MANIFEST_SHA256.txt not found at', MANIFEST);
  process.exit(1);
}

const content = fs.readFileSync(MANIFEST, 'utf8');
const lines = content.split('\n').filter(l => /^[a-f0-9]{64}/.test(l));
for (const line of lines) {
  const m = line.match(/^([a-f0-9]{64})\s+(\d+)\s+(.+)$/);
  if (!m) continue;
  const expectedHash = m[1];
  const expectedSize = parseInt(m[2], 10);
  let filePath = m[3].trim().replace(/^\.\//, '');
  const full = path.join(ROOT, filePath);
  manifestFiles.add(filePath);
  if (!fs.existsSync(full)) {
    missing++;
    console.error('MISSING:', filePath);
    continue;
  }
  const buf = fs.readFileSync(full);
  const actualSize = buf.length;
  const actualHash = crypto.createHash('sha256').update(buf).digest('hex');
  if (actualSize !== expectedSize) {
    sizeMismatch++;
    console.error('SIZE_MISMATCH:', filePath, 'expected', expectedSize, 'got', actualSize);
  } else if (actualHash !== expectedHash) {
    hashMismatch++;
    console.error('HASH_MISMATCH:', filePath);
    console.error('  expected:', expectedHash);
    console.error('  actual:  ', actualHash);
  } else {
    verified++;
  }
}

// Walk disk and find unexpected files
function walk(dir, base = dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const e of entries) {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (EXCLUDE_DIRS.has(e.name)) continue;
      walk(full, base);
    } else if (e.isFile()) {
      if (EXCLUDE_FILES.has(e.name)) continue;
      const rel = path.relative(ROOT, full);
      if (!manifestFiles.has(rel)) {
        unexpected++;
        console.error('UNEXPECTED:', rel);
      }
    }
  }
}
walk(ROOT);

console.log('');
console.log('=== MANIFEST VALIDATION RESULT ===');
console.log('verified =', verified);
console.log('missing =', missing);
console.log('hash_mismatch =', hashMismatch);
console.log('size_mismatch =', sizeMismatch);
console.log('unexpected =', unexpected);

if (missing === 0 && hashMismatch === 0 && sizeMismatch === 0 && unexpected === 0) {
  console.log('RESULT: PASS');
  process.exit(0);
} else {
  console.log('RESULT: FAIL');
  process.exit(1);
}
