// Coverage hook for SPEC Web v6.0
//
// Problem: tests/setup.js loads app.js via `new Function(readFileSync(appPath))`
// which bypasses vitest's istanbul transform pipeline (Vite hooks run on
// ESM imports, not fs.readFileSync). The result is 0% coverage for app.js and
// charts.js even though every function is exercised.
//
// Workaround: monkey-patch fs.readFileSync so that when setup.js reads
// app.js / charts.js, we return the istanbul-instrumented source instead.
// The instrumented source contains coverage counters that write into a
// global `__coverage__` object, which vitest's istanbul reporter picks up.
//
// Usage:
//   NODE_OPTIONS="--require ./scripts/coverage_hook.js" npm run test:coverage
//
// This file is excluded from eslint (scripts/** is ignored).

import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { createInstrumenter } from 'istanbul-lib-instrument';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const projectRoot = resolve(__dirname, '..');

const instrumenter = createInstrumenter({
  esModules: false,
  coverageVariable: '__coverage__',
  produceSourceMap: false
});

const TARGETS = new Set([
  resolve(projectRoot, 'app.js'),
  resolve(projectRoot, 'charts.js')
]);

// Cache original sources and instrumented versions
const originalCache = new Map();
const instrumentedCache = new Map();

function getInstrumented(path) {
  if (!TARGETS.has(path)) return null;
  if (instrumentedCache.has(path)) return instrumentedCache.get(path);
  let src;
  if (originalCache.has(path)) {
    src = originalCache.get(path);
  } else {
    src = readFileSync.call(null, path, 'utf8');
    originalCache.set(path, src);
  }
  // The instrumenter wraps the IIFE in another function. Since setup.js uses
  // `new Function(...)`, the instrumented code runs in a fresh scope and the
  // global `__coverage__` is attached to `globalThis` via the instrumenter's
  // default behavior.
  const instrumented = instrumenter.instrumentSync(src, path);
  instrumentedCache.set(path, instrumented);
  return instrumented;
}

// Monkey-patch fs.readFileSync. We only intercept calls for our target files
// when the encoding is 'utf8' (string output), so binary reads elsewhere are
// unaffected.
import * as fs from 'node:fs';
const origReadFileSync = fs.readFileSync;
fs.readFileSync = function patchedReadFileSync(path, options) {
  const p = typeof path === 'string' ? path : (path && path.toString());
  const norm = p && resolve(p);
  if (norm && TARGETS.has(norm)) {
    const opts = typeof options === 'string' ? options : (options && options.encoding);
    if (opts === 'utf8' || opts === 'utf-8') {
      const instr = getInstrumented(norm);
      if (instr) return instr;
    }
  }
  return origReadFileSync.apply(this, arguments);
};

// istanbul-lib-instrument writes the coverage object to globalThis.__coverage__
// Make sure it exists so reporters can find it.
if (typeof globalThis.__coverage__ === 'undefined') {
  globalThis.__coverage__ = {};
}

export {};
