#!/usr/bin/env python3
"""
Extrae el proyecto VBA completo de SPEC V0.47.3.xlsm.
Convierte vbaProject.bin a código fuente legible usando oletools.
"""
import os
import sys
from oletools.olevba import VBA_Parser

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SPEC = os.path.join(ROOT, "audit-ref", "drive", "SPEC V0.47.3.xlsm")
OUT_DIR = os.path.join(ROOT, "audit", "vba")  # relativo al proyecto (portable)
os.makedirs(OUT_DIR, exist_ok=True)

def main():
    vba = VBA_Parser(SPEC)
    print(f"Detected VBA: {vba.detect_vba_macros()}")
    print(f"Number of macros: {vba.nb_macros}")
    all_streams = []
    for (filename, stream_path, vba_filename, vba_code) in vba.extract_macros():
        # filename = source xlsm; stream_path like "VBA/Module1"; vba_code is decoded text
        safe_name = vba_filename.replace('/', '_').replace('\\', '_').replace(':', '_')
        out_path = os.path.join(OUT_DIR, f"{safe_name}.vba.txt")
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(f"=== Stream: {stream_path} | Module: {vba_filename} ===\n")
            f.write(f"=== Source file: {filename} ===\n\n")
            f.write(vba_code)
        print(f"  -> wrote {out_path} ({len(vba_code)} bytes)")
        all_streams.append({
            "stream_path": stream_path,
            "vba_filename": vba_filename,
            "code": vba_code,
            "path": out_path
        })

    # Index
    with open(os.path.join(OUT_DIR, "_INDEX.md"), "w", encoding="utf-8") as f:
        f.write("# VBA Project Inventory\n\n")
        f.write(f"Source: {SPEC}\n\n")
        f.write(f"Total streams extracted: {len(all_streams)}\n\n")
        for s in all_streams:
            lines = s["code"].count("\n") + 1
            chars = len(s["code"])
            f.write(f"## {s['vba_filename']} (stream `{s['stream_path']}`)\n")
            f.write(f"- File: `{os.path.basename(s['path'])}`\n")
            f.write(f"- Lines: {lines}, Chars: {chars}\n\n")
    print("\n=== VBA extraction complete ===")
    print(f"Output dir: {OUT_DIR}")
    print(f"Modules extracted: {len(all_streams)}")

if __name__ == "__main__":
    main()
