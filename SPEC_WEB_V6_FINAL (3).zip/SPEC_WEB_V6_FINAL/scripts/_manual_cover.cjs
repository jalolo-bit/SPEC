'use strict';
// P8-cierre — rutas relativas al script (portable desde instalación limpia)
const path = require('path');
const ROOT = path.resolve(__dirname, '..');
process.chdir(ROOT);
require('./tests/setup.js');
const XLSX = require('xlsx');
const drive = path.join(ROOT, 'audit-ref', 'drive');
const wbHoras = XLSX.readFile(path.join(drive, 'HORA SIN VOLUMEN.xlsx'));
const wbVolumen = XLSX.readFile(path.join(drive, 'VOLUMEN.xlsx'));
const wbVSH = XLSX.readFile(path.join(drive, 'VOL SIN HORAS.xlsx'));
const wbMapping = XLSX.readFile(path.join(drive, 'Mapping.xlsx'));
globalThis.SPEC.STATE.archivos.horas = { name: 'HORA SIN VOLUMEN.xlsx', workbook: wbHoras };
globalThis.SPEC.STATE.archivos.volumen = { name: 'VOLUMEN.xlsx', workbook: wbVolumen };
globalThis.SPEC.STATE.archivos.volSinHoras = { name: 'VOL SIN HORAS.xlsx', workbook: wbVSH };
globalThis.SPEC.STATE.archivos.mapping = { name: 'Mapping.xlsx', workbook: wbMapping };
globalThis.SPEC.analizarYConciliar(() => {}).then(() => {
  console.log('queries:', Object.keys(globalThis.SPEC.STATE.queries).length);
  console.log('reporte rows:', globalThis.SPEC.STATE.reporte?.length || 0);
  const cov = globalThis.__coverage__ && globalThis.__coverage__[path.join(ROOT, 'app.js')];
  if (!cov) {
    console.log('NO coverage for app.js');
    return;
  }
  let hits = 0, total = 0;
  for (const k in cov.s) { total++; if (cov.s[k] > 0) hits++; }
  console.log('app.js statements covered:', hits, '/', total, '=', (100*hits/total).toFixed(2) + '%');
  let bHits = 0, bTotal = 0;
  for (const k in cov.b) { for (const c of cov.b[k]) { bTotal++; if (c > 0) bHits++; } }
  console.log('app.js branches covered:', bHits, '/', bTotal, '=', (100*bHits/bTotal).toFixed(2) + '%');
  let fHits = 0, fTotal = 0;
  for (const k in cov.f) { fTotal++; if (cov.f[k] > 0) fHits++; }
  console.log('app.js functions covered:', fHits, '/', fTotal, '=', (100*fHits/fTotal).toFixed(2) + '%');
}).catch(e => {
  console.error('ERROR:', e.message);
  process.exit(1);
});
