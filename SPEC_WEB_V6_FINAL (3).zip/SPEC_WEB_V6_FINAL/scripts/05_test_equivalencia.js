/* P8-cierre — Test de equivalencia LEGACY (recuentos + KPIs), versión ESM portable.
 *
 * Original histórico: scripts/05_test_equivalencia.js (CommonJS con rutas
 * hardcodeadas del entorno de desarrollo original — NO funcionaba desde una
 * instalación limpia porque package.json declara "type":"module" y el script
 * usaba require()).
 *
 * Esta versión ESM:
 *   - Usa import (compatible con "type":"module").
 *   - Resuelve TODAS las rutas relativas a __dirname (portable).
 *   - Produce la misma salida comparativa de recuentos que el original:
 *     ejecuta el port JS con los 4 archivos de audit-ref/drive y compara
 *     los row counts contra las hojas REALES del xlsm.
 *
 * El test de equivalencia de VALORES celda a celda vive en
 * scripts/07_test_equivalencia_valores.cjs (canónico, usado por CI).
 *
 * Uso: node scripts/05_test_equivalencia.js
 */

import XLSX from 'xlsx';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const DRIVE = path.join(ROOT, 'audit-ref', 'drive');
const APP_JS = path.join(ROOT, 'app.js');
const SPEC_XLSM = path.join(DRIVE, 'SPEC V0.47.3.xlsm');

// Cargar app.js (IIFE) vía new Function — mismo patrón que 07_...valores.cjs
globalThis.XLSX = XLSX;
const src = fs.readFileSync(APP_JS, 'utf8');
// eslint-disable-next-line no-new-func
const loader = new Function('globalThis', 'window', 'XLSX', src + '\nreturn SPEC;');
const SPEC = loader(globalThis, globalThis, XLSX);

function readXlsx(p) {
  const buf = fs.readFileSync(p);
  return XLSX.read(buf, { type: 'buffer', cellDates: true });
}

function setupArchivos() {
  const wbHoras = readXlsx(path.join(DRIVE, 'HORA SIN VOLUMEN.xlsx'));
  const wbVolumen = readXlsx(path.join(DRIVE, 'VOLUMEN.xlsx'));
  const wbVSH = readXlsx(path.join(DRIVE, 'VOL SIN HORAS.xlsx'));
  const wbMapping = readXlsx(path.join(DRIVE, 'Mapping.xlsx'));
  SPEC.STATE.archivos.horas = [{ name: 'HORA SIN VOLUMEN.xlsx', workbook: wbHoras }];
  SPEC.STATE.archivos.volumen = [{ name: 'VOLUMEN.xlsx', workbook: wbVolumen }];
  SPEC.STATE.archivos.volSinHoras = [{ name: 'VOL SIN HORAS.xlsx', workbook: wbVSH }];
  SPEC.STATE.archivos.mapping = [{ name: 'Mapping.xlsx', workbook: wbMapping }];
}

function readSpecSheets() {
  const wb = readXlsx(SPEC_XLSM);
  const result = {};
  for (const sn of wb.SheetNames) {
    const ws = wb.Sheets[sn];
    const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: null });
    if (aoa.length === 0) { result[sn] = { rows: 0, cols: 0, headers: [], firstRow: [] }; continue; }
    const headers = aoa[0];
    const dataRows = aoa.slice(1).filter(r => r.some(c => c != null && String(c).trim() !== ''));
    result[sn] = {
      rows: dataRows.length,
      cols: headers.length,
      headers: headers.filter(h => h != null).map(h => String(h)),
      firstRow: dataRows[0] ? dataRows[0].slice(0, Math.min(10, headers.length)) : []
    };
  }
  return result;
}

async function run() {
  console.log('=== Test de equivalencia SPEC (recuentos) ===\n');
  setupArchivos();

  await SPEC.analizarYConciliar(() => {});

  const jsCounts = {};
  for (const name of Object.keys(SPEC.STATE.queries)) {
    jsCounts[name] = SPEC.STATE.queries[name].length;
  }
  jsCounts['REPORTE_CAMBIOS_HR'] = SPEC.STATE.reporte.length;

  const specSheets = readSpecSheets();
  const specCounts = {};
  for (const sn of Object.keys(specSheets)) specCounts[sn] = specSheets[sn].rows;

  console.log('=== Comparativa de recuentos (Excel real vs port JS) ===\n');
  let pass = 0, fail = 0, warn = 0;
  for (const name of Object.keys(jsCounts)) {
    const lookupName = name.length > 31 ? name.slice(0, 31) : name;
    const exp = specCounts[lookupName] != null ? specCounts[lookupName] : specCounts[name];
    const act = jsCounts[name];
    if (exp == null) { console.log(`  ${name}: SKIP (sin hoja en xlsm)`); continue; }
    const diff = act - exp;
    let estado;
    if (diff === 0) { estado = 'OK'; pass++; }
    else if (Math.abs(diff) <= 2) { estado = 'WARN'; warn++; }
    else { estado = 'FAIL'; fail++; }
    console.log(`  ${name.padEnd(50)} Excel=${String(exp).padStart(5)} JS=${String(act).padStart(5)} diff=${String(diff).padStart(3)} ${estado}`);
  }
  console.log(`\nOK: ${pass}  WARN: ${warn}  FAIL: ${fail}\n`);

  if (fail > 0) {
    console.error('RESULT: FAIL');
    process.exit(1);
  }
  console.log('RESULT: ' + (warn > 0 ? 'PASS (con avisos)' : 'PASS'));
}

run().catch(err => {
  console.error('ERROR:', err.stack || err);
  process.exit(1);
});
