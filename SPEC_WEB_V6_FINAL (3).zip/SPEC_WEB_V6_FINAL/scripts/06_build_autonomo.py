#!/usr/bin/env python3
"""
Construye SPEC_AUTONOMO_v6.html: versión autónoma de un solo archivo
que embebe inline:
  - logo_idl.png (como base64 data URI para autonomía)
  - styles.css
  - xlsx.full.min.js (SheetJS)
  - app.js
  - ui.js
  - charts.js
  - index.html (estructura)

P9-cierre (auditoría de certificación): el standalone que venía en el ZIP
era un motor ANTIGUO renombrado a v6 (sin M-01 FORMULA_PREFIXES, sin audit
log SHA-256, sin validarArchivoEntrada R-06, sin M-04 IndexedDB, sin
M-05 virtual scrolling). Este generador se ha corregido para:
  1. Embeber los 4 scripts del index.html ACTUAL (xlsx, charts, app, ui).
  2. Eliminar los enlaces PWA (manifest, sw-register) — un único archivo
     no puede registrar Service Worker ni cargar manifest externo.
  3. Emitir SPEC_AUTONOMO_v6.html en la RAÍZ del proyecto (no en download/).
La versión modular también se copia a download/ (artefactos de build).
"""
import os
import base64
import hashlib
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
APP_DIR = ROOT
OUT_DIR = os.path.join(ROOT, "download")
os.makedirs(OUT_DIR, exist_ok=True)

def read(p):
    with open(os.path.join(APP_DIR, p), "r", encoding="utf-8") as f:
        return f.read()

def read_bytes(p):
    with open(os.path.join(APP_DIR, p), "rb") as f:
        return f.read()

html = read("index.html")
css = read("styles.css")
app_js = read("app.js")
ui_js = read("ui.js")
charts_js = read("charts.js")
xlsx_js = read_bytes("xlsx.full.min.js").decode("utf-8", errors="replace")
logo_png = read_bytes("logo_idl.png")
logo_b64 = base64.b64encode(logo_png).decode("ascii")

# v6.2 — capa analítica (analytics/*.js, cálculos puros sin DOM)
ANALYTICS = [
    "analytics/analyticsCore.js",
    "analytics/personAnalytics.js",
    "analytics/taskAnalytics.js",
    "analytics/activityAnalytics.js",
    "analytics/confusionAnalytics.js",
    "analytics/trendAnalytics.js",
    "analytics/paretoAnalytics.js",
    "analytics/alertAnalytics.js",
    "analytics/dataQualityAnalytics.js",
]
analytics_js = {p: read(p) for p in ANALYTICS}

# ===== Versión autónoma =====
autonomo = html

# 0. PWA: el standalone de un solo archivo NO puede registrar Service Worker
#    (requiere URL scope http(s)) ni cargar manifest.json externo.
autonomo = autonomo.replace('<link rel="manifest" href="manifest.json">\n', '')
autonomo = autonomo.replace('<link rel="manifest" href="manifest.json">', '')
autonomo = re.sub(r"<!--[^\n]*M-15 PWA[^\n]*-->\n?", "", autonomo)
autonomo = re.sub(r'<script src="sw-register\.js"></script>\n?', '', autonomo)

# 1. Reemplazar <link rel="stylesheet" href="styles.css">
autonomo = autonomo.replace(
    '<link rel="stylesheet" href="styles.css">',
    '<style>\n' + css + '\n</style>'
)

# 2. Reemplazar favicon e imagen del logo con data URI base64
# Favicon
autonomo = autonomo.replace(
    '<link rel="icon" type="image/png" href="logo_idl.png">',
    f'<link rel="icon" type="image/png" href="data:image/png;base64,{logo_b64}">'
)
# Header logo
autonomo = autonomo.replace(
    '<img src="logo_idl.png" alt="ID Logistics" class="header-logo">',
    f'<img src="data:image/png;base64,{logo_b64}" alt="ID Logistics" class="header-logo">'
)

# 3. Reemplazar los scripts (xlsx + charts + analytics + app + ui) con inline.
#    P9-cierre: patrón ACTUAL de index.html (scripts consecutivos + sw-register).
#    v6.2: además de los 4 originales, se embeben los 9 módulos analytics/*.
analytics_block = "".join(
    f'<!-- {p}: capa analítica v6.2 -->\n<script>\n' + analytics_js[p] + '\n</script>\n\n'
    for p in ANALYTICS
)
four_scripts = (
    '<script src="xlsx.full.min.js"></script>\n'
    '<script src="charts.js"></script>\n'
    + ''.join(f'<script src="{p}"></script>\n' for p in ANALYTICS)
    + '<script src="app.js"></script>\n'
    '<script src="ui.js"></script>'
)
four_replacement = (
    '<!-- SheetJS (Apache 2.0) - embebido inline para autonomía -->\n'
    '<script>\n' + xlsx_js + '\n</script>\n\n'
    '<!-- charts.js: visualizaciones SVG vanilla -->\n'
    '<script>\n' + charts_js + '\n</script>\n\n'
    + analytics_block
    + '<!-- app.js: núcleo del sistema (port de SPEC V0.47.3) -->\n'
    '<script>\n' + app_js + '\n</script>\n\n'
    '<!-- ui.js: interfaz -->\n'
    '<script>\n' + ui_js + '\n</script>'
)
if four_scripts in autonomo:
    autonomo = autonomo.replace(four_scripts, four_replacement)
else:
    # Fallback: reemplazar individualmente (todos y cada uno)
    replacements = [
        ('<script src="xlsx.full.min.js"></script>',
         '<!-- SheetJS (Apache 2.0) - embebido inline para autonomía -->\n<script>\n' + xlsx_js + '\n</script>'),
        ('<script src="charts.js"></script>',
         '<!-- charts.js: visualizaciones SVG vanilla -->\n<script>\n' + charts_js + '\n</script>'),
        ('<script src="app.js"></script>',
         '<!-- app.js: núcleo del sistema (port de SPEC V0.47.3) -->\n<script>\n' + app_js + '\n</script>'),
        ('<script src="ui.js"></script>',
         '<!-- ui.js: interfaz -->\n<script>\n' + ui_js + '\n</script>'),
    ]
    for old, new in replacements:
        if old not in autonomo:
            raise SystemExit(f"ERROR: patrón no encontrado en index.html: {old}")
        autonomo = autonomo.replace(old, new)

# 4. Verificación de integridad del build: el standalone DEBE contener
#    las mejoras de seguridad del v6.0 real (regresión del motor viejo).
for probe, desc in [
    ("FORMULA_PREFIXES", "M-01 protección inyección CSV"),
    ("calcularEntryHash", "FASE 3/8 audit log SHA-256"),
    ("verificarAuditLogChain", "FASE 8 verificación de cadena"),
    ("validarArchivoEntrada", "R-06 validación de entradas"),
    ("AppVersion: '6.2.0'", "versionado v6.2.0"),
    ("resolverClasificacionTarea", "v6.1.1 productividad por TASK_WMS"),
    ("repartirTiemposPorTarea", "v6.1.1 reparto por tarea"),
    ("filtrarRegistrosPorTurno", "v6.1.1 filtro real de turnos"),
    ("renderTaskProdEditor", "v6.1.1 editor PRODUCTIVIDAD POR TAREA"),
    ("SPEC_AN", "v6.2 capa analítica (namespace SPEC_AN)"),
    ("computePersonStats", "v6.2 analítica por persona"),
    ("computeTaskStats", "v6.2 analítica por tarea"),
    ("computeConfusionMatrix", "v6.2 matriz de confusiones"),
    ("computePareto", "v6.2 curva de Pareto"),
    ("computeTopPrioridades", "v6.2 top prioridades"),
    ("computeDataQuality", "v6.2 calidad de datos"),
    ("renderFocosResumen", "v6.2 vista focos de atención"),
    ("patronesSnapshot", "v6.2 snapshot analítica de patrones"),
    ("idbBackupDecisions", "M-04 backup IndexedDB"),
    ("VIEWER_THRESHOLD", "M-05 virtual scrolling"),
    ("fx_Turno", "v6.1 MEJORA 1 turnos"),
    ("FECHA_OPERATIVA_TURNO", "v6.1 MEJORA 1 fecha operativa nocturna"),
    ("q17_PersonaDiaAnalitica", "v6.1 MEJORA 4 persona/día + reparto"),
    ("fx_ActividadAnalisis", "v6.1 MEJORA 4 ACTIVIDAD_ANALISIS centralizada"),
    ("guardarMappingVersion", "v6.1 MEJORA 3 mapping persistente versionado"),
    ("undoApply", "v6.1 MEJORA 5 undo real"),
    ("person_daily_records", "v6.1 MEJORA 6 históricos IndexedDB"),
    ("cargarArchivosUnificados", "v6.1 MEJORA 2 carga unificada"),
]:
    if probe not in autonomo:
        raise SystemExit(f"ERROR: el standalone no contiene {desc} ({probe}) — build abortado")

# Banner
banner = """<!-- ============================================================
SPEC AUTONOMO v6.2 - Versión de un solo archivo
Port web de SPEC V0.47.3.xlsm (ID Logistics)

CARACTERÍSTICAS (idénticas al build modular v6.2):
- 100% offline. No requiere servidor ni conexión a Internet.
- Procesa los 4 archivos de entrada localmente en el navegador.
- Reproduce las 20 consultas Power Query (Section1.m) y
  el procedimiento VBA GenerarReporteCambiosHR (módulo VBA principal).
- M-01 protección inyección CSV, M-02 escape XSS, R-06 validación
  de entradas, audit log con hash chain SHA-256, M-04 backup
  IndexedDB, M-05 virtual scrolling.
- v6.1: turnos MAÑANA/TARDE/NOCHE con fecha operativa nocturna,
  carga unificada con detección automática, mapping persistente
  versionado (SHA-256), revisión por PERSONA+DÍA con reparto de
  tiempos (horas equivalentes), undo real persistente y patrones
  históricos en IndexedDB (PERSON_DAILY_RECORD).
- v6.2: módulo de estadística avanzada e inteligencia operativa en
  Patrones (capa analítica analytics/*.js embebida): rankings de
  personas/tareas/actividades con tasas y muestras, matriz de
  confusiones, recurrencia, Pareto, evolución con media móvil,
  comparación de periodos, alertas deterministas, top 5 prioridades
  con desglose transparente, calidad de datos/mapping y umbrales
  configurables desde la UI.
- NOTA standalone: la pestaña Patrones funciona con los registros de
  la sesión; el Worker no está disponible en un solo archivo y el
  cálculo se ejecuta en el hilo principal (fallback documentado).
- NOTA standalone: sin Service Worker ni manifest PWA (M-15 es
  exclusiva del build modular index.html, que sí los registra).

SEGURIDAD (CSP):
- La CSP del index.html modular (script-src 'self') BLOQUEARÍA los
  scripts inline del standalone. El build regenera la CSP con los
  hashes SHA-256 EXACTOS de cada script embebido: sin 'unsafe-inline',
  cualquier modificación de los scripts rompe la página (integridad
  criptográfica activa en el propio archivo).

BIBLIOTECAS:
- SheetJS (xlsx.full.min.js) 0.18.5 - Apache License 2.0 - embebida inline.
- Logo ID Logistics - embebido como data URI base64.

USO:
- Abrir con Microsoft Edge o Google Chrome actuales.
- Pestaña "Cargar y analizar": arrastra los 4 archivos a la vez
  (detección automática) o selecciónalos por tipo.
- Pulsa ANALIZAR; la app te lleva a "Revisar incidencias".
============================================================ -->

"""
autonomo = banner + autonomo

# 5b. CSP con hashes: calcular sha256 (base64) de cada script inline y
#     reescribir la CSP del <head> para permitir exactamente esos scripts.
#     La política original (script-src 'self') bloquearía el standalone
#     completo porque TODO su código es inline. Con hashes no se necesita
#     'unsafe-inline' y cualquier alteración de un script queda bloqueada.
inline_scripts = re.findall(r"<script>(.*?)</script>", autonomo, re.S)
if not inline_scripts:
    raise SystemExit("ERROR: no se encontraron scripts inline en el standalone")
script_hashes = []
for s in inline_scripts:
    h = hashlib.sha256(s.encode("utf-8")).digest()
    script_hashes.append("'sha256-" + base64.b64encode(h).decode("ascii") + "'")
hash_list = " ".join(script_hashes)
new_csp = (
    "default-src 'self'; script-src 'self' " + hash_list + "; "
    "style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
    "font-src 'self'; connect-src 'self' data:; base-uri 'self'; "
    "form-action 'self'; object-src 'none'; worker-src 'self' blob:;"
)
csp_re = re.compile(r'<meta http-equiv="Content-Security-Policy" content="[^"]*">')
if csp_re.search(autonomo):
    autonomo = csp_re.sub(
        f'<meta http-equiv="Content-Security-Policy" content="{new_csp}">',
        autonomo, count=1
    )
else:
    # No había CSP (build antiguo) — insertarla tras <meta charset>
    autonomo = autonomo.replace(
        '<meta charset="UTF-8">',
        f'<meta charset="UTF-8">\n<meta http-equiv="Content-Security-Policy" content="{new_csp}">',
        1
    )
print(f"CSP del standalone: {len(script_hashes)} hashes de script embebidos")

# 5. Salida en la RAÍZ del proyecto (donde vive el artefacto del repo)
autonomo_path = os.path.join(ROOT, "SPEC_AUTONOMO_v6.html")
with open(autonomo_path, "w", encoding="utf-8") as f:
    f.write(autonomo)
print(f"Autónomo: {autonomo_path} ({len(autonomo)} chars)")

# ===== Versión modular (artefactos de build en download/) =====
MODULAR_FILES = ["index.html", "styles.css", "app.js", "charts.js", "ui.js",
                 "xlsx.full.min.js", "logo_idl.png"] + ANALYTICS
for fn in MODULAR_FILES:
    src = os.path.join(APP_DIR, fn)
    dst = os.path.join(OUT_DIR, fn)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    with open(src, "rb") as f:
        data = f.read()
    with open(dst, "wb") as f:
        f.write(data)
    print(f"Modular: {dst} ({len(data)} bytes)")
