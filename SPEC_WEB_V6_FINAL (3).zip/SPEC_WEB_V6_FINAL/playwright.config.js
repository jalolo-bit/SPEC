// Playwright config for SPEC Web v6.0
// E2E tests serve the project root via http-server on port 8799.
// Only Chromium is installed to keep CI time low.

import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests/e2e',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: [['html', { open: 'never' }], ['list']],
  use: {
    baseURL: 'http://127.0.0.1:8799',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure'
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] }
    }
  ],
  webServer: {
    command: 'npx http-server -p 8799 --cors --silent',
    url: 'http://127.0.0.1:8799',
    reuseExistingServer: !process.env.CI,
    timeout: 60_000
  }
});
