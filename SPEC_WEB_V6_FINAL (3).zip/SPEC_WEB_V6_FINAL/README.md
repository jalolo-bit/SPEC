# SPEC Web v6.1 — Certified Release

Versión v6.1 (iteración de mejoras funcionales y analíticas sobre la v6.0 certificada). ZIP autosuficiente (incluye audit-ref/drive/ con los 5 archivos Excel de referencia).

**Novedades v6.1:** turnos MAÑANA/TARDE/NOCHE con fecha operativa nocturna · pestaña *Cargar y analizar* unificada (detección automática de tipos) · mapping persistente versionado (SHA-256, confirmación old-vs-new) · revisión por **PERSONA + FECHA OPERATIVA** con reparto de tiempos (horas equivalentes) · **UNDO real** persistente y auditable · pestaña **Patrones** con históricos diarios (PERSON_DAILY_RECORD en IndexedDB, sin duplicados).

```bash
npm ci                          # 285 paquetes
npm test                        # 366 tests Vitest (22 archivos, unit + integration)
npx playwright install chromium
npx playwright test             # 30 tests E2E (smoke + a11y + multifile/Worker + IndexedDB + Mapping + PWA + @perf + standalone + 8 E2E v6.1)
npm run test:perf               # 3 tests @perf reales
node scripts/07_test_equivalencia_valores.cjs   # 14/14 tablas, 0 mismatches, 74.672 celdas (equivalencia V0.47.3 intacta)
```

Ver `reports/FINAL_RELEASE_CERTIFICATION.md` para la certificación completa.
Ver `MANIFEST_SHA256.txt` para los hashes de integridad de todos los archivos.


## v6.2.0 — Módulo de estadística avanzada e inteligencia operativa (Patrones)

La pestaña **Patrones** responde: ¿quién se equivoca más? ¿qué tareas se
fichan peor? ¿dónde poner el ojo? ¿estamos mejorando? ¿cuántas horas cuesta?

- 8 vistas: **Resumen** (KPIs con fórmula visible, evolución comparada en
  puntos porcentuales, TOP 5 prioridades con desglose transparente y alertas
  deterministas) · **Personas** (frecuencia + tasa + impacto + semáforo
  MUY BUENO→CRÍTICO + MUESTRA PEQUEÑA) · **Tareas** (oportunidades, errores
  imputados SOLO a la tarea afectada, tendencia, mejora/deterioro) ·
  **Actividades** (+ turnos + análisis de OTRA) · **Errores** (matriz
  fichada→correcta con heatmap, recurrentes AISLADO/RECURRENTE/HABITUAL) ·
  **Evolución** (diario/semana/mes, media móvil 7d solo con ventana,
  rolling 7/28, comparación de periodos con mejora/empeora) · **Pareto**
  (80/20 comprobado con datos + frecuencia×impacto) · **Calidad de datos**
  (operativo vs datos/mapping, SIN HORA, OTRA, sin mapping).
- ⚙ **Configuración estadística**: 24 umbrales/pesos editables, persistidos.
- **Exportación** XLSX de todas las vistas. **Filtros globales** con TASK_WMS,
  cliente y mapping. **Drill-down** a perfil de persona/tarea/actividad.
- Capa analítica pura en `analytics/*.js` (determinista, sin NaN) + 136
  tests unitarios y 14 E2E nuevos. Documentación:
  `reports/ADVANCED_ANALYTICS_SPEC.md`, `reports/HISTORICAL_ANALYTICS_MODEL.md`,
  `reports/ANALYTICS_METRICS_DICTIONARY.md`.

## Documentación de las mejoras v6.1

| Informe | Contenido |
|---|---|
| `reports/TIME_ALLOCATION_MODEL.md` | Modelo matemático del reparto de tiempos (horas equivalentes, pesos, conservación exacta) |
| `reports/PERSON_DAILY_RECORD_SPEC.md` | Modelo de datos del histórico diario (clave, campos, versionado, IndexedDB) |
| `reports/MAPPING_AMBIGUITIES.md` | Ambigüedades del mapping detectadas y decisiones de clasificación (ACTIVIDAD_ANALISIS) |
| `reports/INFORME_REGRESION_V6_1.md` | Informe de regresión de la iteración v6.1 |

## Estructura

```
SPEC_WEB_V6_FINAL/
├── app.js, ui.js, charts.js, worker.js   # Código fuente (motor + UI + Worker)
├── index.html, styles.css                # UI (build modular con PWA M-15, pestaña unificada)
├── SPEC_AUTONOMO_v6.html                 # Standalone single-file (v6.1, CSP por hashes)
├── xlsx.full.min.js, logo_idl.png         # Dependencias embebidas
├── package.json, package-lock.json
├── eslint.config.js, vitest.config.js, playwright.config.js
├── .github/workflows/ci.yml               # CI/CD (9 jobs, YAML validado)
├── audit-ref/drive/                       # 5 archivos Excel referencia (576KB)
├── tests/                                  # 408 tests (366 Vitest + 42 Playwright)
│   └── e2e/mejoras_v6.spec.js             # 8 E2E obligatorios de la iteración v6.1
├── scripts/                                # Generadores Python + tests legacy + validadores
├── test-data/synthetic/                   # Datos sintéticos anonimizados
├── test-data/turnos/                      # Fixtures v6.1 (horas con turno real, mapping v2)
├── docs/                                   # Documentación + CHANGELOG
├── reports/                                # Reportes v6.0 + informes v6.1
└── MANIFEST_SHA256.txt                    # Hashes de integridad
```

## Estado de certificación

- **14/15 mejoras v6.0 implementadas** (M-13 TypeScript NO implementada, documentada) + **6/6 mejoras v6.1**
- **369/369 tests PASS** (última ejecución real)
- **Equivalencia 14/14 tablas, 0 mismatches, 74.672 celdas** (sin cambios en las consultas 01-16 ni en el reporte)
- Limitaciones y riesgos residuales: ver `RELEASE_FINAL.md` y `reports/REGISTRO_RIESGOS_FINAL.md`
