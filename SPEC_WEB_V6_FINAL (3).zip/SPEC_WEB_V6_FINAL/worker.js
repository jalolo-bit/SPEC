/* ============================================================================
 * SPEC Web — Web Worker: motor de cálculo off-main-thread
 *
 * Tarea F4-A (M-03 / R-02). El hilo principal lee los 4 archivos Excel con
 * FileReader (en ui.js:loadFile → SPEC.leerArchivoExcel), construye los
 * workbook objects con XLSX.read y los guarda en SPEC.STATE.archivos[k].wb.
 * Pero los workbook objects NO son structured-cloneable (contienen funciones),
 * así que no pueden enviarse por postMessage al worker.
 *
 * Por eso el hilo principal re-lee cada File como ArrayBuffer (file.arrayBuffer())
 * y transfiere el buffer al worker (transfer list). El worker reconstruye los
 * workbook objects con XLSX.read(buffer, { type:'array', cellDates:true }) y los
 * asigna a su propio SPEC.STATE.archivos. Luego ejecuta SPEC.analizarYConciliar,
 * que es la función pura (sin dependencias de DOM) que produce queries + reporte.
 *
 * Comunicación:
 *   Main → Worker:  { type:'start', archivos: { horas:{name,buffer}, ... } }
 *                   (con transfer list de los 4 ArrayBuffers)
 *   Worker → Main:  { type:'progress', pct, label }
 *                   { type:'done',    state:{queries,reporte,log,stats} }
 *                   { type:'error',   message, stack }
 *
 * Notas:
 *  - Worker clásico (no module worker). Carga xlsx.full.min.js y app.js con
 *    importScripts. El IIFE de app.js detecta `typeof window !== 'undefined'`
 *    y en worker usa globalThis, exponiendo self.SPEC.
 *  - analizarYConciliar no escribe a STATE.auditLog ni STATE.decisions; solo a
 *    queries/reporte/log/stats. Por eso el payload de 'done' es safe para
 *    structured-clone (Date, number, string, boolean — sin funciones).
 *  - Si el cálculo lanza, el worker atrapa el error y lo devuelve como
 *    {type:'error'} — el hilo principal puede entonces caer al fallback
 *    main-thread o mostrar el error al usuario.
 * ========================================================================== */
// Worker globals: `importScripts` no está en globals.browser (sí en
// globals.worker). Accedemos vía self.importScripts para evitar false-positivos
// de no-undef cuando eslint lint con globals.browser. self/postMessage sí están
// en globals.browser (son compartidos con main-thread window).
self.importScripts('xlsx.full.min.js');
self.importScripts('app.js');

self.onmessage = async function (e) {
  const msg = e && e.data ? e.data : null;
  if (!msg || msg.type !== 'start') return;
  try {
    const archivos = msg.archivos || {};

    // Helper: reconstruir workbook desde un ArrayBuffer transferido.
    // Misma lógica que SPEC.leerArchivoExcel pero sincrónica (ya tenemos el buffer).
    const makeWb = (entry, kind) => {
      if (!entry || !entry.name) {
        throw new Error('Archivo "' + kind + '" no proporcionado al worker.');
      }
      const buf = entry.buffer;
      if (!buf || (typeof buf.byteLength === 'number' && buf.byteLength < 4)) {
        throw new Error('Archivo "' + entry.name + '" demasiado corto para ser un Excel válido (menos de 4 bytes).');
      }
      const u8 = new Uint8Array(buf);
      // Misma firma que leerArchivoExcel: type:'array', cellDates:true
      try {
        return XLSX.read(u8, { type: 'array', cellDates: true });
      } catch (err) {
        throw new Error('No se pudo interpretar "' + entry.name + '" como Excel. ¿Está corrupto o no es .xlsx/.xlsm/.xlsb real? — ' + (err && err.message ? err.message : String(err)));
      }
    };

    // F8 — Multi-archivo: el worker acepta arrays de archivos por tipo.
    // Cada tipo puede tener 1 o N archivos (M-10 multi-file). El worker
    // reconstruye cada workbook y construye un array de { name, workbook }
    // para cada tipo. Esto es lo que analizarYConciliar espera con su
    // helper `toArray` + `flatMap`.
    //
    // Formato del mensaje:
    //   msg.archivos = {
    //     horas:    [ { name:'a.xlsx', buffer:ArrayBuffer }, { name:'b.xlsx', buffer:... } ],
    //     volumen:  [ { name:'c.xlsx', buffer:... } ],   // 1 archivo OK
    //     volSinHoras: [ { name:'d.xlsx', buffer:... } ],
    //     mapping:  [ { name:'e.xlsx', buffer:... } ]
    //   }
    // Backward-compat: si el mensaje trae el formato anterior (entry individual,
    // no array), lo normalizamos a array de 1 elemento.
    const normalizeEntries = (val) => {
      if (Array.isArray(val)) return val;
      if (val && val.name) return [val];
      return [];
    };
    const buildArchivosArray = (kind, entries) => {
      const arr = normalizeEntries(entries);
      if (arr.length === 0) {
        throw new Error('No se proporcionaron archivos para "' + kind + '" al worker.');
      }
      return arr.map((entry) => ({
        name: entry.name,
        workbook: makeWb(entry, kind)
      }));
    };
    SPEC.STATE.archivos = {
      horas:       buildArchivosArray('horas',       archivos.horas),
      volumen:     buildArchivosArray('volumen',     archivos.volumen),
      volSinHoras: buildArchivosArray('volSinHoras', archivos.volSinHoras),
      mapping:     buildArchivosArray('mapping',     archivos.mapping)
    };

    // Hook de progreso: postMessage de vuelta al hilo principal.
    const onProgress = (pct, label) => {
      try {
        self.postMessage({ type: 'progress', pct: pct, label: String(label) });
      } catch {
        /* Si la serialización falla (no debería: pct número, label string),
         * swallow para no romper el cálculo. */
      }
    };

    // Ejecutar el orquestador. analizarYConciliar es async (espera await Promise).
    await SPEC.analizarYConciliar(onProgress);

    // Payload de resultado. Solo datos planos (Date, number, string, boolean).
    // Sin funciones ni workbook objects — seguro para structured-clone.
    const state = {
      queries: SPEC.STATE.queries,
      reporte: SPEC.STATE.reporte,
      log: SPEC.STATE.log,
      stats: SPEC.STATE.stats,
      // v6.1 — MEJORA 4/6: análisis persona-día + registros históricos
      personaDiaRecords: SPEC.STATE.personaDiaRecords || []
    };
    self.postMessage({ type: 'done', state: state });
  } catch (err) {
    const message = err && err.message ? err.message : String(err);
    const stack = err && err.stack ? String(err.stack) : '';
    try {
      self.postMessage({ type: 'error', message: message, stack: stack });
    } catch {
      // Si el propio postMessage de error falla, no hay mucho que hacer.
    }
  }
};
