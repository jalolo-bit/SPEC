# ADVANCED_ANALYTICS_SPEC — Módulo de Estadística Avanzada e Inteligencia Operativa

**Versión:** 6.3.0 · **Fecha:** 2026-10-06 · **Ámbito:** pestaña PATRONES de SPEC Web

## 1. Objetivo y principios

Transformar el histórico diario (`PERSON_DAILY_RECORD`, IndexedDB) en **información accionable**: quién se equivoca más, qué tareas se fichan peor, dónde concentrar el esfuerzo, si se mejora o empeora y cuánto cuesta en horas.

Principios irrenunciables:

1. **Cálculos puros y deterministas** — la capa `analytics/*.js` no toca el DOM; misma entrada → misma salida. Sin Machine Learning ni modelos opacos.
2. **Nunca NaN/Infinity** — toda división pasa por `safeDiv`/`pct` (denominador 0 → 0; las tasas parte-de-un-total se acotan a [0,100]).
3. **Umbrales visibles y configurables** — ⚙ CONFIGURACIÓN ESTADÍSTICA (localStorage `spec_stat_config_v1`); nada oculto en el código.
4. **Frecuencia + tasa + impacto + confianza juntos** — nunca un ranking solo por conteo absoluto (§8: no castigar a quien tiene más días analizados).
5. **80/20 solo si los datos lo dicen** — la regla se comprueba, no se afirma por defecto.
6. **Imputación mínima** — un error se imputa SOLO a la TASK_WMS realmente afectada (la que generó la propuesta), nunca a todas las actividades del día.
7. **Aditivo** — las consultas 01-16 y la equivalencia con SPEC V0.47.3 (14/14 tablas · 74.672 celdas) permanecen intactas.

## 2. Arquitectura

```
IndexedDB (spec_history_db.person_daily_records)
        │ cargarTodosRecords()
        ▼
normalizarRecords()  (analyticsCore)      ← defensivo: históricos v6.1/v6.1.1
        │ filtrarRecords(filtros globales) ← §42: afectan a TODAS las vistas
        ▼
patronesSnapshot()  (ui.js; memoizado por firma filtros+config+datos)
        ├─ person / task / activity / confusion / trend / pareto / alerts / dataQuality
        ▼
8 vistas: RESUMEN · PERSONAS · TAREAS · ACTIVIDADES · ERRORES · EVOLUCIÓN · PARETO · CALIDAD DE DATOS
```

Módulos (`window.SPEC_AN`): `analyticsCore` (config, seguridad numérica, clasificación, normalización, filtros, KPIs, periodos), `person`, `task` (espacios TASK_WMS y HR Task), `activity` (actividades + turnos), `confusion` (matriz + recurrencia + heatmap), `trend` (diario/semana/mes, MM, rolling, frecuencia×impacto), `pareto`, `alerts` (reglas A1-A11 + índice de prioridad + top 5), `dataQuality` (calidad del dato y del mapping).

## 3. Clasificación de incidencias (§50)

| Sección | Tipo | Causa | ¿Error? |
|---|---|---|---|
| 1. CAMBIO HR TASK PROPUESTO | ERROR DE FICHAJE | OPERATIVO | Sí |
| 2. VARIAS TASKSPEC | AMBIGÜEDAD MAPPING | DATOS | Sí |
| 3. HR TASK CORRECTA | REVISIÓN (CORRECTA) | CONTROL | **No** |
| 4. SIN VOLUMEN | SIN VOLUMEN | OPERATIVO | Sí |
| 5. WMS TASK SIN MAPPING | SIN MAPPING | DATOS | Sí |
| 6. MÚLTIPLES HR TASK | MÚLTIPLES HR TASK | REVISIÓN | Sí |
| 7. AMBIGÜEDAD IDNUM | AMBIGÜEDAD IDNUM | REVISIÓN | Sí |

**Horas afectadas**: el módulo usa `horasErrorDedup` (solo secciones ≠ 3, dedup por registro de horas). El `horasConIncidencia` v6.1 (incluye controles) se conserva por compatibilidad.

**ERROR DE ASIGNACIÓN** (definición v6.1, sin cambios): sección 1 + decisiones aceptadas.

## 4. Reglas deterministas de alerta (§37)

| Código | Regla | Umbral por defecto |
|---|---|---|
| A1_TASA_CRECIENTE | tarea con Δ tasa entre mitades > X pp, con evidencia | 5 pp · min 3 obs/mitad |
| A2_RACHA_PERSONA | persona con X días consecutivos con error | 3 días |
| A3_CONCENTRACION | top-N tareas cubren ≥80% de los errores | comprobación real de 80/20 |
| A4_TURNO_PEOR | tasa de un turno > global + X pp | 10 pp · min 3 registros |
| A5_OTRA_VOLUMEN | tarea OTRA con volumen relevante | 100 uds o 4 h |
| A6_CONFUSION_REPETIDA | misma confusión A→B ≥ X veces | 3 casos |
| A7_PERSONA_RECURRENTE | persona con ≥ X días distintos con error | 5 días |
| A8_IMPACTO_ALTO | pocos errores, muchas horas | ≤3 errores y ≥4 h |
| A9_PERSONA_EMPEORA | empeora sostenido (mitades) | 5 pp · min 3 días/mitad |
| A10_PERSONA_MEJORA | mejora sostenida (informativa) | 5 pp · min 3 días/mitad |
| A11_SIN_HORA | % registros SIN HORA ≥ X% | 50% · min 3 |

## 5. Índice de prioridad (§6, transparente)

```
score = 100 · Σ(wᵢ · vᵢ/máxᵢ) / Σwᵢ     v = valor del candidato
máxᵢ = máximo del conjunto candidato (0 si el máximo es 0)
w = pesos configurables: frecuencia 20 · tasa 20 · horas 20 ·
    recurrencia 15 · tendencia 15 · personas 10
tendencia entra como max(0, Δpp)/máxΔpp (empeorar puntúa, mejorar no penaliza)
nivel: ALTA ≥ 60 · MEDIA ≥ 35 · BAJA < 35 (configurables)
```

El desglose completo (valor, peso y contribución de cada componente) se muestra SIEMPRE en el TOP 5. El usuario puede auditar por qué algo es ALTA.

## 6. Semáforo de calidad de fichaje por persona (§9)

| Clase | Condición (defaults) |
|---|---|
| MUESTRA PEQUEÑA | días < 3 (el dato se muestra igualmente) |
| MUY BUENO | 0% días con error (≥3 días) |
| BUENO | ≤ 10% |
| NORMAL | ≤ 25% |
| ATENCIÓN | ≤ 50% |
| CRÍTICO | > 50% |

## 7. Tendencias y periodos (§14-§19)

- **Mitades**: el rango filtrado se divide por mediana de fechas (A = anterior, B = actual). Determinista.
- **Veredicto**: MEJORA/EMPEORA/SIN CAMBIO por Δ en **puntos porcentuales** del % de persona-día con error, con umbral ±5 pp. Exige ≥3 días por mitad; si no, SIN EVIDENCIA (nunca conclusiones con 1 día).
- **Media móvil 7 días**: solo desde el punto con ventana completa.
- **Rolling 7/28**: ventana sobre días contiguos del calendario (días sin datos = 0).

## 8. Vista Resumen (§61)

Bloque 1 KPIs (calidad + evolución comparada) → Bloque 2 «Dónde poner el ojo» (TOP 5 prioridades + alertas) → Bloques 3-5 (quién/qué/dónde: top personas, top tareas, actividad y turno) → Bloque 6 gráfico de evolución en la pestaña EVOLUCIÓN. Objetivo: entender el estado en <30 segundos sin saturar.

## 9. Límites conocidos y decisiones documentadas

- La comparación por defecto usa **mitades del rango filtrado** (no periodos arbitrarios): determinista y sin selección manual. Los periodos A/B explícitos quedan como mejora futura.
- El espacio de la matriz de confusiones es el de la **tarea fichada (HR Task)**: es donde vive la propuesta. La imputación a TASK_WMS usa `WMS TASK CON VOLUMEN` (v6.2).
- La sección 3 no es error, pero sí genera líneas de incidencia (aparece en «Incidencias» y en el REPORTE como control).
- La agregación visual por actividad sigue disponible (suma de sus tareas) — requisito §10 original.
- Umbrales por defecto: valores razonables documentados, NO decisión de negocio cerrada. Edítalos en ⚙ Configuración estadística.


## Cambios v6.3 (correcciones funcionales sobre esta especificación)

- **§3 Fingerprint:** pasa a incluir mappingHash/productivityVersion/overrideVersion/appVersion/SchemaVersion (ver HISTORICAL_ANALYTICS_MODEL §3, fingerprint v2).
- **§10/§11 Tareas y actividades:** la tasa pasa a ser «% oportunidades con error» (acotada por definición) y se añade «incidencias por oportunidad» como ratio sin cota. La tendencia por tarea usa la tasa acotada.
- **§14/§47 Tendencias:** los días sin datos NO se rellenan con cero. La serie solo contiene días observados; MM y rolling 7/28 se calculan sobre días con datos; `cobertura` expone los huecos de calendario.
- **§17/§18 Comparación de periodos:** además de mitades, comparación A/B explícita con rangos visibles y evidencia insuficiente marcada (FASE 8 del usuario).
- **§4 Resumen:** jerarquía de KPIs (4 primarios + impacto y alcance) y nuevo KPI `personasConError`.
