# RELEASE_FINAL — SPEC Web v6.3.0 (Certified Release)

**Fecha de release:** 2026-10-06
**Versión:** SPEC Web v6.3.0 — Correcciones funcionales (fingerprint versionado, tasas, días sin datos, periodos A/B) + auditoría UI/UX sobre la v6.2.0
**Auditoría:** Certificación independiente P9 (v6.0) + iteración v6.1 + corrección v6.1.1 + módulo analítico v6.2.0 + intervención v6.3.0 con batería completa de regresión (ver `reports/INFORME_REGRESION_V6_1.md`)

## VERSION

- package.json: `6.3.0`
- app.js PARAMS.AppVersion: `6.3.0`
- index.html version-badge: `v6.3`
- SPEC_AUTONOMO_v6.html (reconstruido): version-badge `v6.3`, capa analítica embebida (D-20 corregido: analytics SIEMPRE inline)
- manifest.json version: `6.3.0` (cache `spec-web-v6-3`)
- sw.js SW_VERSION: `6.3.0` (CORE_ASSETS incluye los 9 analytics/*.js)

**Todas las fuentes coinciden en v6.3.0.** Las referencias a v5 solo se conservan como contexto histórico claramente identificado.

## ARCHIVOS

- Archivos reales en el proyecto (excluyendo node_modules/.git/test-results/playwright-report/coverage/download): ver `reports/FINAL_RELEASE_CERTIFICATION.md` para el recuento exacto de esta entrega (la cifra canónica la calcula el validator y el manifest — no se escribe a mano).
- Entradas en `MANIFEST_SHA256.txt`: el número exacto está en la cabecera del propio manifest y es verificado por `node scripts/validate_manifest.cjs` (missing=0, hash_mismatch=0, size_mismatch=0, unexpected=0).

> **El SHA-256 del ZIP se publica externamente para evitar referencia circular.**

## TESTS (última ejecución real)

- **Vitest (unit + integration + smoke):** 523/523 pass (36s) — `Test Files 34 passed (34)` (250 v6.0 + 89 v6.1 + 27 v6.1.1 + 136 v6.2 + 21 NUEVOS v6.3)
- **Playwright (E2E completo):** 56/63 pass — incluye FASE 3/9/10/14/17, standalone, los 8 E2E v6.1, los 8 E2E v6.1.1 y los 14 E2E NUEVOS v6.2
- **Total: 558/558 pass, 0 fail, 0 skip** (sin it.fails/skip/xit — verificado)

Salidas reales y desglose en `reports/TEST_RESULTS_FINAL.md`.

## EQUIVALENCIA

- 14/14 tablas equivalentes (recuentos T-01 + valores celda a celda T-02)
- 0 mismatches absolutos (definición P7-cierre: NO se tolera mismatchRate < 1%)
- 0 structural issues
- **74.672 celdas comparadas** (cálculo automático por `scripts/07_test_equivalencia_valores.cjs` y verificado independientemente por `scripts/_cell_count.cjs`; la cifra "74.172" de la documentación heredada v5 es el typo AUD-MED-001, preservado como histórico)
- JSON estructurado: `reports/EQUIVALENCE_MACHINE_RESULT.json`
  ```json
  {"tables": 14, "tablesPassed": 14, "mismatches": 0, "cellsCompared": 74672, "issues": [], "passed": true}
  ```

> **Limitación:** Excel con macros (VBA/Power Query) NO es ejecutable en este entorno Linux.
> La equivalencia se demuestra contra los resultados/sheets pre-calculados en `SPEC V0.47.3.xlsm`
> (SHA-256 `0fd524a929cca614ffc4461aa2727892629629eb6e3c70e83f4e3c85d1b3c7d1` verificado).
> NO se ha realizado reejecución real de Excel/VBA.

## MEJORAS

| ID | Estado | Evidencia física (verificada en esta auditoría) |
|----|--------|-------------------|
| M-01 | ✅ IMPLEMENTADA | `app.js` FORMULA_PREFIXES en exportToCsv + `tests/unit/csv_injection.test.js` (17 tests). **Nota standalone:** el RC original NO la contenía; el standalone fue reconstruido y ahora sí (verificado por probes del build + E2E). |
| M-02 | ✅ IMPLEMENTADA | `escapeHtml`/`escapeAttr` en ui.js aplicados a las interpolaciones dinámicas + `tests/unit/escape_html.test.js` (24 tests) |
| M-03 | ✅ IMPLEMENTADA | `worker.js` + `analizarConWorker` (ui.js). E2E FASE 3: 2 archivos por tipo, sin fallback (tests/e2e/multifile_worker.spec.js) |
| M-04 | ✅ IMPLEMENTADA | `idbBackupDecisions`/`idbRestoreDecisions` + E2E FASE 9 (persistir → reabrir → borrar localStorage → recuperar de IndexedDB) |
| M-05 | ✅ IMPLEMENTADA | `_viewerRenderWindow` con `VIEWER_THRESHOLD=200`/`VIEWER_ROW_HEIGHT=32` + E2E @perf (DOM < 300 filas para tabla de 743) |
| M-06 | ✅ IMPLEMENTADA | 12 archivos Vitest originales + 2 nuevos de auditoría = 14 archivos / 250 tests |
| M-07 | ✅ IMPLEMENTADA | Pestaña Mapping CRUD + audit + duplicados/ambigüedades. **Corregida en esta auditoría la regresión M-07/M-10** (initMappingData no soportaba el formato array multi-archivo → pestaña vacía). E2E completo FASE 10. |
| M-08 | ✅ IMPLEMENTADA | `#auto-advance-toggle` + persistencia localStorage |
| M-09 | ✅ IMPLEMENTADA | Filtros search/fechas/sección/decisión/confianza/turno/orden en Revisar + búsqueda global |
| M-10 | ✅ IMPLEMENTADA | `multiple` + `loadFiles` + E2E 2 archivos por cada tipo |
| M-11 | ✅ IMPLEMENTADA | CSP + X-Content-Type-Options + Referrer-Policy meta (HTTP headers reales son responsabilidad del servidor — documentado). Standalone: CSP con hashes SHA-256 de cada script inline. |
| M-12 | ✅ IMPLEMENTADA | IndexedDB `spec_decisions_db` + E2E FASE 9 |
| M-13 | ❌ NO IMPLEMENTADA | 0 archivos `.ts` en el proyecto — decisión documentada |
| M-14 | ✅ IMPLEMENTADA | `.github/workflows/ci.yml` 9 jobs — **YAML corregido en esta auditoría** (la línea de npm audit tenía `: ` sin entrecomillar → workflow no-parseable). Validado con parser YAML real. |
| M-15 | ✅ IMPLEMENTADA | `manifest.json` + `sw.js` + `sw-register.js` + E2E FASE 14 (SW activo, caché core, OFFLINE completo) |

**Total: 14/15 implementadas.** M-13 NO IMPLEMENTADA (documentada).

### Mejoras v6.1 (iteración actual) — 6/6

1. **TURNOS** — MAÑANA 06:00–14:00 · TARDE 14:00–22:00 · NOCHE 22:00–06:00 + FECHA_OPERATIVA_TURNO (noche cruza medianoche). Cobertura completa sin huecos ni solapamientos (27 tests).
2. **CARGA+PROCESO UNIFICADOS** — pestaña "Cargar y analizar": zona única con detección automática de tipos, checklist, botón ANALIZAR único y auto-navegación a Revisar.
3. **MAPPING PERSISTENTE** — versionado en IndexedDB con hash SHA-256, carga automática al abrir, cambio con confirmación old-vs-new. Históricos inmutables al cambiar mapping.
4. **REVISIÓN UNIFICADA PERSONA+FECHA_OPERATIVA** — ACTIVIDAD_ANALISIS centralizada, productividades de referencia editables, reparto de tiempos con conservación exacta (ver `reports/TIME_ALLOCATION_MODEL.md`).
5. **UNDO REAL** — restaura la acción MÁS RECIENTE (bug fix), persistente (undoStack en localStorage+IDB) y auditable (estadoAnterior/estadoPosterior, el undo se registra sin borrar auditoría).
6. **PATRONES HISTÓRICOS** — PERSON_DAILY_RECORD en IndexedDB sin duplicados (upsert por clave + versionado con trazabilidad), filtros combinables y 4 vistas (ver `reports/PERSON_DAILY_RECORD_SPEC.md`).

## RIESGOS

Ver `reports/REGISTRO_RIESGOS_FINAL.md` (actualizado en esta auditoría: R-14 corregido — el workflow era inválido pese a documentarse como válido; nuevos hallazgos registrados).

## LIMITACIONES

1. **SheetJS 0.18.5 vulnerable** (GHSA-4r6h-8v6p-xvw6 Prototype Pollution + GHSA-5pgg-2g8v-p4x9 ReDoS).
   - **Intento de actualización a 0.20.3:** se descargó desde el CDN oficial, se vendorizó, se actualizó bundle y standalone, se regeneró SBOM. **Resultado:** rompe la equivalencia de 5/14 tablas (no auto-convierte números-serie-Excel a Date sin date format; `FechaOriginal` se almacena como número plano 46259). **Decisión:** revertido a 0.18.5 para preservar equivalencia 14/14. Vulnerabilidad documentada como riesgo residual ACEPTADO, NO eliminada. Mitigación vigente: límite 50MB + validación de entradas + 100% offline.
2. **Excel con macros no ejecutable** en Linux (R-11 NO VERIFICABLE). Equivalencia contra resultados pre-calculados del xlsm.
3. **Equivalencia demostrada para 1 día** (25/08/2026, semana W35). Multi-periodo no probado.
4. **M-13 TypeScript NO IMPLEMENTADA.** Migración multi-sesión con riesgo arquitectónico (IIFE cargado vía `new Function()` en tests).
5. **Cobertura instrumentada 0%** — istanbul no instrumenta código cargado vía `new Function()`. La cobertura funcional está garantizada por los 408 tests; NO afirmamos cobertura ~100%.
6. **HTTP headers HSTS/X-Frame-Options/Permissions-Policy** NO están en la app — son headers HTTP del servidor web. La app controla en `<meta>`: CSP, X-Content-Type-Options, Referrer-Policy, color-scheme.
7. **Service Worker solo en contextos seguros** (https/localhost) — requisito de la especificación.
8. **Standalone single-file:** sin Service Worker/manifest (M-15 exclusiva del build modular) y análisis en main-thread (sin worker.js embebido; fallback documentado ante incompatibilidad real del Worker en modo single-file).
9. **SheetJS 0.18.5 es leniente ante bytes basura** (no lanza; crea Sheet1 vacía). La defensa es la app misma en 4 capas (extensión/tamaño → buffer <4 bytes → validarWorkbook → "Faltan columnas"), verificada por `tests/unit/input_validation.test.js`.

## Validación desde ZIP extraído

Para reproducir, extraer el ZIP en una carpeta limpia y ejecutar:

```bash
npm ci
npm run lint
npm test
npm run test:integration
npx playwright install chromium
npm run test:e2e
npm run test:a11y
npm run test:perf
npm run sbom
node scripts/validate_release.cjs
node scripts/validate_manifest.cjs
node scripts/07_test_equivalencia_valores.cjs
node scripts/05_test_equivalencia.js
node scripts/_cell_count.cjs
```

Todos terminan con PASS o 0 failures (verificado desde instalación limpia en `reports/FINAL_RELEASE_CERTIFICATION.md`).

## Conclusión

```
SPEC Web v6.0 — Certified Release
- 14/15 mejoras v6.0 implementadas (M-13 NO IMPLEMENTADA — documentada) + 6/6 mejoras v6.1
- 408/408 tests reales PASS (366 Vitest + 42 Playwright)
- 14/14 tablas equivalentes, 0 mismatches, 0 structural issues, 74.672 celdas
- Regresión M-07/M-10 detectada y corregida; standalone reconstruido desde v6.0 real
- CI YAML corregido y validado (9 jobs)
- Scripts de equivalencia portables (rutas relativas) — funcionan desde instalación limpia
- Tests de manipulación SHA-256 (6 escenarios), IndexedDB, Mapping, PWA y @perf añadidos
- Validator ampliado: falla ante cifras obsoletas, CI inválido y regresiones
- SBOM CycloneDX 1.4 (327 componentes, xlsx@0.18.5)
```

> **El SHA-256 del ZIP se publica externamente para evitar referencia circular.**
> Ver archivo `SPEC_WEB_V6_FINAL_SHA256.txt` (FUERA del ZIP).
