# LEEME v6.3.0 — Entrega: correcciones funcionales + auditoría UI/UX

**Fecha:** 2026-10-07
**Web:** https://preview-c-6ac4ae24-14810412-80c0a3326694.space-z.ai/ (solo la app, actualizada a v6.3.0)
**ZIP:** `SPEC_WEB_V6_FINAL.zip` — 2.309.222 bytes
**SHA-256:** `1416f626667dce3336837ea5df34bd09c4e02ca7b9bff68a56f348f427d4aad5`

## Qué contiene esta entrega (v6.3.0)

### Objetivo A — Correcciones funcionales
1. **Fingerprint versionado (FASE 1):** el histórico ya no colisiona entre
   configuraciones distintas. El fingerprint incluye datos + mappingHash +
   productividad + overrides + versión de app y algoritmo. Reprocesar con otra
   configuración crea una VERSIÓN trazable (el núcleo anterior queda en
   previousVersions con su hash).
2. **Tasas estadísticamente correctas (FASE 5):** «% oportunidades con error»
   (acotada 0-100 por definición) y «Incidencias por oportunidad» (ratio sin
   cota) como métricas separadas y etiquetadas — nunca un 100% que oculte un
   ratio mayor.
3. **Días sin datos ≠ 0 errores (FASE 7):** el rolling 7/28 ya no rellena
   huecos con ceros; la vista Evolución muestra la cobertura del calendario.
4. **Periodos A/B explícitos (FASE 8):** comparación con rangos propios y
   rangos SIEMPRE visibles en la UI (qué se compara contra qué).
5. **Defecto D-20 corregido:** el standalone ahora SIEMPRE embebe la capa
   analítica (en v6.2 quedaban referencias externas rotas).
6. **-570 líneas de código muerto** eliminadas de ui.js (funciones sobrescritas
   y barra de acciones masivas huérfana).

### Objetivo B — Auditoría UI/UX (skill UI UX Pro Max)
- Jerarquía de KPIs (4 primarios + «Impacto y alcance»), % a 1 decimal,
  filtros agrupados en fieldsets, control segmentado de vistas, cabeceras
  sticky en tablas, estados vacíos y de carga unificados, banner Pareto,
  leyenda semántica en Calidad de datos, focus-visible global,
  prefers-reduced-motion, responsive verificado a 768px.

## Batería de regresión completa (re-ejecutada)

| Prueba | Resultado |
|---|---|
| Lint | 0 errors (30 warnings estilo preexistentes) |
| Vitest | **523/523** (34 archivos; +21 nuevos v6.3) |
| Playwright E2E | **63/63** (11 suites; +7 nuevos v6.3) |
| Accesibilidad (axe) | 5/5 |
| Performance | 3/3 |
| **Equivalencia SPEC V0.47.3** | **14/14 · 0 mismatches · 74.672 celdas (INTACTA)** |
| validate_manifest | PASS (157 entradas) |
| validate_release | PASS (78/78 checks) |
| Reproducibilidad desde ZIP | verificada (npm ci → validadores → 523/523 → 14/14 → E2E clave 26/26) |

## Documentación

- `ADVANCED_ANALYTICS_SPEC.md` / `HISTORICAL_ANALYTICS_MODEL.md` /
  `ANALYTICS_METRICS_DICTIONARY.md` — actualizados con fingerprint v2,
  semántica de tasas, días sin datos y periodos A/B.
- `INFORME_REGRESION_V6_1.md` — apéndice v6.3.0 (defectos F-01..F-05, D-20,
  U-01..U-10 y tests actualizados).
- `CHANGELOG.md` / `README.md` / `RELEASE_FINAL.md` / `TEST_RESULTS_FINAL.md` /
  `MANUAL_USUARIO.md` — al día con v6.3.0.

## Nota sobre históricos existentes

Al abrir un histórico v6.1/v6.2 con v6.3 y reprocesar, los registros se
versionan UNA vez (fingerprint v2 incluye la configuración). Es una
migración trazable, no una pérdida: cada previousVersions conserva su núcleo
y su mappingHash originales.
