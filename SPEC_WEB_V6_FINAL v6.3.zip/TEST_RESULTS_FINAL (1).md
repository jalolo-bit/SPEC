# TEST_RESULTS_FINAL — SPEC Web v6.3.0 (Certified Release)

**Fecha de certificación:** 2026-10-07
**Fuente:** Ejecución real desde `/home/z/my-project/SPEC_WEB_V6_FINAL/` (instalación `npm ci` desde lockfile). Todos los números de este documento provienen de la última ejecución real; ninguno se copió de informes anteriores.

## Resumen real

| Tipo | Tests | Pass | Fail | Skip | Resultado |
|------|------:|----:|----:|----:|-----------|
| Unit (Vitest) — v6.0 previos | 250 | 250 | 0 | 0 | ✅ 100% |
| Unit (Vitest) — v6.1 | 89 | 89 | 0 | 0 | ✅ 100% |
| Unit (Vitest) — v6.1.1 | 27 | 27 | 0 | 0 | ✅ 100% |
| Unit (Vitest) — NUEVOS v6.2.0 (analítica) | 136 | 136 | 0 | 0 | ✅ 100% |
| Unit (Vitest) — NUEVOS v6.3.0 (correcciones: fingerprint, tasas, rolling, periodos, separación) | 21 | 21 | 0 | 0 | ✅ 100% |
| **Subtotal Vitest** | **523** | **523** | **0** | **0** | ✅ 100% |
| E2E smoke (Playwright) | 8 | 8 | 0 | 0 | ✅ 100% |
| Accessibility (axe-core, @a11y) | 5 | 5 | 0 | 0 | ✅ 100% |
| Multi-file + Worker (FASE 3) | 2 | 2 | 0 | 0 | ✅ 100% |
| IndexedDB persistencia (FASE 9) | 2 | 2 | 0 | 0 | ✅ 100% |
| Mapping CRUD E2E (FASE 10) | 1 | 1 | 0 | 0 | ✅ 100% |
| PWA offline (FASE 14) | 4 | 4 | 0 | 0 | ✅ 100% |
| Performance E2E (@perf, FASE 17) | 3 | 3 | 0 | 0 | ✅ 100% |
| Standalone single-file | 1 | 1 | 0 | 0 | ✅ 100% |
| E2E v6.1 (mejoras_v6.spec.js) | 8 | 8 | 0 | 0 | ✅ 100% |
| E2E v6.1.1 (overrides_v612.spec.js) | 8 | 8 | 0 | 0 | ✅ 100% |
| E2E NUEVOS v6.2.0 (patrones_v62.spec.js) | 14 | 14 | 0 | 0 | ✅ 100% |
| E2E NUEVOS v6.3.0 (v63_correcciones.spec.js) | 7 | 7 | 0 | 0 | ✅ 100% |
| **Subtotal Playwright** | **63** | **63** | **0** | **0** | ✅ 100% |
| **TOTAL** | **586** | **586** | **0** | **0** | ✅ **100%** |

Notas de cálculo de subtotales:
- Subtotal Vitest = salida canónica de `npm test`: **Test Files 34 passed, Tests 523 passed** (14 archivos v6.0 con 250 tests + 6 archivos v6.1 con 89 tests + 2 archivos v6.1.1 con 27 tests + 11 archivos v6.2.0 con 136 tests + 1 archivo NUEVO v6.3.0 con 21 tests).
- Subtotal Playwright = suma real por suite ejecutada: smoke 8 + a11y 5 + multifile 2 + indexeddb 2 + mapping 1 + pwa 4 + perf 3 + standalone 1 + mejoras_v6 8 + overrides_v612 8 + patrones_v62 14 + v63_correcciones 7 = **63** (ejecutadas en lotes por timeout del runner).
- Sin `it.fails`, sin `.skip`, sin `xit`, sin `test.todo` (verificado con grep: 0 ocurrencias nuevas).

## Ejecuciones reales (comandos y salidas)

```
Lint:        0 errors, 30 warnings          # npm run lint (warnings preexistentes estilo)
Vitest:      523 passed (36.0s)             # npm test — Test Files 34 passed (34)
E2E total:   63 passed (4.4m)               # npx playwright test
A11y:        5 passed (23.9s)               # npm run test:a11y (@a11y grep)
Perf:        3 passed (9.6s)                # npm run test:perf (@perf grep)
Equivalence: PASS 14/14, 0 mismatches, 74672 celdas, 0 issues   # node scripts/07_test_equivalencia_valores.cjs
Validator:   PASS (78 checks)               # node scripts/validate_release.cjs
Manifest:    PASS (157 entradas)            # node scripts/validate_manifest.cjs
```

## Detalle Vitest por archivo (salida real de `npm test`)

```
✓ tests/unit/analytics_core.test.js (33)      [NUEVO — v6.2 núcleo: config/seguridad/filtros/KPIs/periodos]
✓ tests/unit/analytics_person.test.js (12)    [NUEVO — v6.2 personas: §8 no-castigo, semáforo, mejora/empeora, rachas]
✓ tests/unit/analytics_task.test.js (12)      [NUEVO — v6.2 tareas: §11 imputación, fichaje, tendencia, detalle]
✓ tests/unit/analytics_activity.test.js (8)    [NUEVO — v6.2 actividades + turnos + OTRA]
✓ tests/unit/analytics_confusion.test.js (10) [NUEVO — v6.2 matriz confusiones + recurrencia + persistencia]
✓ tests/unit/analytics_trend.test.js (11)     [NUEVO — v6.2 series + MM7 + rolling + frecuencia×impacto]
✓ tests/unit/analytics_pareto.test.js (6)     [NUEVO — v6.2 Pareto + 80/20 comprobación real]
✓ tests/unit/analytics_alerts.test.js (17)    [NUEVO — v6.2 alertas A1-A11 + prioridad transparente + top5]
✓ tests/unit/analytics_dataquality.test.js (10) [NUEVO — v6.2 calidad datos + mapping + causas §50]
✓ tests/unit/analytics_edge.test.js (14)      [NUEVO — v6.2 batería §58: sin NaN/Infinity, casos extremos]
✓ tests/unit/person_daily_v62.test.js (5)     [NUEVO — v6.2 campos del record + versionado]
✓ tests/unit/overrides_task.test.js (17 tests)      [v6.1.1]
✓ tests/unit/regression_bugs.test.js (31 tests)
✓ tests/unit/persona_dia.test.js (15 tests)         [v6.1]
✓ tests/unit/escape_html.test.js (24 tests)
✓ tests/unit/audit_log_chain.test.js (22 tests)
✓ tests/unit/csv_injection.test.js (17 tests)
✓ tests/unit/input_validation.test.js (24 tests)
✓ tests/unit/actividad_analisis.test.js (16 tests)  [v6.1]
✓ tests/unit/fx_normalizalogin.test.js (17 tests)
✓ tests/unit/reparto_tiempos.test.js (12 tests)     [v6.1]
✓ tests/unit/performance.test.js (4 tests)
✓ tests/unit/mapping_persist.test.js (8 tests)      [v6.1]
✓ tests/unit/undo_persist.test.js (11 tests)        [v6.1]
✓ tests/unit/fx_fecha.test.js (23 tests)
✓ tests/unit/filtro_turnos_real.test.js (10 tests)  [v6.1.1]
✓ tests/unit/fx_normalizatexto.test.js (20 tests)
✓ tests/unit/turnos.test.js (27 tests)              [v6.1]
✓ tests/unit/calcular_materialidad.test.js (23 tests)
✓ tests/unit/number_from.test.js (21 tests)
✓ tests/unit/smoke.test.js (3 tests)
✓ tests/integration/equivalence_valores.test.js (14 tests)
✓ tests/integration/equivalence_recuentos.test.js (7 tests)
Test Files  33 passed (33)
     Tests  502 passed (502)
```

## Detalle Playwright por suite (salida real)

```
✓ smoke.spec.js (8)            — flujo crítico completo
✓ multifile_worker.spec.js (2) — multi-archivo en Worker (M-10)
✓ indexeddb.spec.js (2)        — persistencia decisiones (M-04/M-12)
✓ mapping.spec.js (1)          — CRUD mapping + audit log (M-07)
✓ mejoras_v6.spec.js (8)       — E2E obligatorios v6.1
✓ pwa.spec.js (4)              — PWA offline (M-15) — manifest 6.2.0, cache spec-web-v6-2
✓ standalone.spec.js (1)       — SPEC_AUTONOMO_v6.html (v6.2.0, probes analytics embebidos)
✓ accessibility.spec.js (5)     — axe-core WCAG 2.1 AA (claro + oscuro + teclado)
✓ performance_e2e.spec.js (3)  @perf — latencia y no-degradación
✓ overrides_v612.spec.js (8)  — E2E obligatorios v6.1.1
✓ patrones_v62.spec.js (14)   [NUEVO — E2E obligatorios v6.2:
     1 histórico vacío · 2 cargar un día · 3 segundo día sin duplicados ·
     4 cerrar/abrir conserva histórico · 5 ranking personas + semáforo +
     perfil drill-down · 6 ranking TASK_WMS con imputación §11 · 7 ranking
     actividades + OTRA · 8 matriz confusiones + recurrentes HABITUAL ·
     9 evolución con gráficos · 10 comparación de periodos MEJORA/EMPEORA ·
     11 alertas deterministas · 12 cambio de mapping con versiones
     trazables · 13 override TASK_WMS versiona el histórico ·
     14 filtros combinados]
```

## Qué cubren los tests NUEVOS v6.2.0

**analytics_core.test.js (33)** — configuración estadística documentada y persistible (defaults completos, fusión válida, basura ignorada, JSON corrupto → defaults) · safeDiv/pct nunca NaN/Infinity · media móvil SOLO con ventana completa · clasificación de las 7 secciones (tipo + causa OPERATIVO/DATOS/REVISIÓN/CONTROL, error de asignación = sec. 1 + aceptadas) · normalización de records v6.2 y legacy · filtros globales por fecha/semana/mes/persona/turno/actividad/TASK_WMS/cliente/mapping combinables · dimensiones disponibles · KPIs con denominadores · comparación de periodos con pp y % nulo sin base · partirPorMitades determinista.

**analytics_person.test.js (12)** — agregación por persona · §8 NO castigar por más días (10/100 vs 5/5 con frecuencia+tasa juntas) · muestra pequeña configurable · racha con huecos · semáforo con umbrales documentados y editables · mejora/empeoramiento SOLO con evidencia (minDiasComparar) · veredicto ESTABLE · perfil histórico completo.

**analytics_task.test.js (12)** — oportunidades/personas/días/uds · §11 imputación SOLO a la tarea afectada (la otra tarea del mismo día NO recibe el error) · dedup de horas por ID REGISTRO · tasa con muestra pequeña · incidencias sin wmsTask no se imputan · tareas fichadas (espacio HR Task) con propuestaHabitual · tendencia mejora/deterioro con/sin evidencia · detalle de tarea.

**analytics_activity.test.js (8)** — orden canónico · §11 imputación por actividad de la tarea afectada · OTRA siempre visible · turnos con SIN HORA separado (nunca repartido) · tendencia por turno · detalle de actividad con distribución por turno.

**analytics_confusion.test.js (10)** — matriz fichada→correcta con casos/personas/días/horas · sección 2 no entra (correcta no determinada) · split de propuestas ' | ' · dedup por registro+destino · heatmap · recurrencias por persona+pareja · persistencia AISLADO/RECURRENTE/HABITUAL configurable.

**analytics_trend.test.js (11)** — serie diaria completa · MM7 solo desde el 7º punto · MM refleja cambios reales · rolling 7/28 sobre días contiguos · buckets semana/mes con Δ frente al anterior · frecuencia×impacto con cuadrantes por mediana.

**analytics_pareto.test.js (6)** — curva ordenada con % acumulado · nPara80 · 80/20 afirmado SOLO si se cumple · ceros sin NaN · valorFn personalizado (horas) · empates deterministas · wrappers personas/tareas/actividades.

**analytics_alerts.test.js (17)** — A1 tasa creciente · A2 racha · A3 concentración real · A4 turno peor · A5 OTRA con volumen · A6 confusión repetida · A7 recurrencia · A8 impacto alto · A9 empeora · A10 mejora · A11 sin hora · sin errores → sin alertas · vacío → sin alertas · índice de prioridad 0-100 con desglose que suma los pesos · umbrales configurables · la tendencia empeorando sube el score · top5 ≤5 con desglose.

**analytics_dataquality.test.js (10)** — días/registros/sin hora/OTRA/sin mapping/incompletos · §50 separación de causas que suma 100% · tipos con categoría · versiones y VSH · modoVolumen · vacío sin NaN · mapping quality con sin-mapping/ambiguas/OTRA/clasificadas · cambios de mapping sin mezclar periodos.

**analytics_edge.test.js (14) — batería §58** — histórico vacío · cero errores · cero horas (0/0) · cero uds · un solo día/persona/tarea · todas y ninguna persona con error · cambio de mapping coexistente · mapping incompleto · OTRA con alerta · SIN HORA separado · noche cruzando medianoche · ningún porcentaje de parte-de-un-total >100 · recorre TODA la capa buscando no-finitos · records legacy v6.1.

**person_daily_v62.test.js (5)** — incidencias enriquecidas (wmsTask/volumen/cliente/sapCode) · tareas con tasksSpec/cliente · productivityVersion/overrideVersion deterministas + datasetFingerprint alias · fingerprint cambia SOLO con cambios reales de clasificación (override al motor) · PARAMS.AppVersion=6.2.0.
