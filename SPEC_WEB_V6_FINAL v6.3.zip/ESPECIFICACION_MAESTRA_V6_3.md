# ESPECIFICACIÓN MAESTRA FUNCIONAL — SPEC WEB v6.3.0

**Documento:** Especificación funcional auditable de la aplicación SPEC Web v6.3.0
**Fecha de elaboración:** 2026-10-07
**Artefacto auditado:** `SPEC_WEB_V6_FINAL.zip` (v6.3.0, SHA-256 `1416f626667dce3336837ea5df34bd09c4e02ca7b9bff68a56f348f427d4aad5`, 2.309.222 bytes, 177 entradas)
**Copia de trabajo analizada:** `/home/z/my-project/SPEC_WEB_V6_FINAL/`
**Propósito:** Este documento es una **especificación contractual de auditoría**. Otra IA (o auditor humano) debe poder tomarlo junto con el ZIP y auditar, una por una, todas las funcionalidades (F-001 … F-122) contra la implementación real, sin descubrir desde cero qué debería hacer la aplicación. **No se ha modificado ni una línea de código para elaborarlo.**

**Marcas de trazabilidad usadas en todo el documento:**
- `[C]` VERIFICADO EN CÓDIGO (leído directamente en el fuente)
- `[T]` VERIFICADO EN TEST (unitario/integración Vitest que ejecuta el comportamiento)
- `[E]` VERIFICADO EN E2E (Playwright que lo ejerce en navegador real)
- `[D]` DOCUMENTADO (afirmado por README/CHANGELOG/informes; verificado que el documento existe)
- `[I]` INFERIDO (deducción razonada, no comprobable directamente)
- `[N]` NO VERIFICADO (no se pudo demostrar; tratar con cautela)

**Estado real de la batería certificada (referencia de partida):** lint 0 errors/30 warnings · Vitest **523/523** (34 archivos = 32 unit + 2 integration) · Playwright **63/63** (12 specs, incluye a11y 5 y perf 3) · equivalencia con SPEC V0.47.3 **14/14 tablas · 0 mismatches · 74.672 celdas** · validate_manifest PASS (157 entradas) · validate_release PASS (78/78) `[D]` (TEST_RESULTS_FINAL.md, LEEME_V6_3.md).

---

## 1. RESUMEN EJECUTIVO

### 1.1 Qué es SPEC Web

SPEC Web es un **port 100 % cliente (vanilla JS, sin backend, sin framework)** de la herramienta Excel/VBA "SPEC V0.47.3" de ID Logistics. Su función: **conciliar horas fichadas en HR sin volumen productivo contra volumen WMS**, generar un reporte de propuestas de cambio de HR Task (`REPORTE_CAMBIOS_HR`) con 7 secciones, permitir la revisión humana decisión a decisión (con auditoría criptográfica SHA-256), y —desde v6.1— acumular un **histórico inmutable por persona/día** (`PERSON_DAILY_RECORD`, IndexedDB) sobre el que v6.2/v6.3 construyen un **módulo de estadística avanzada e inteligencia operativa** (pestaña Patrones: personas, tareas, actividades, errores, evolución, Pareto, calidad de datos, alertas A1-A11, índice de prioridad). `[C][D]`

### 1.2 Arquitectura en una frase

Once archivos runtime + 9 módulos analíticos puros (`analytics/*.js`, namespace `SPEC_AN`), un Web Worker para el cálculo, Service Worker para PWA/offline, IndexedDB (2 bases) + localStorage (8 claves) para persistencia, y equivalencia célula a célula con el Excel original verificada por tests automáticos (74.672 celdas, 0 mismatches). `[C]`

### 1.3 Inventario funcional

Este documento cataloga **122 funcionalidades (F-001 … F-122)** en 14 áreas: INGESTA (18), MOTOR/CONSULTAS (15), FUNCIONES PURAS (7), CLASIFICACIÓN Y REPARTO (7), REVISIÓN (13), MAPPING TAB (8), OVERRIDES (3), DECISIONES/AUDITORÍA (6), HISTÓRICO (6), PATRONES/ANALYTICS (16), RESULTADOS/REPORTE (7), EXPORTACIÓN (3), UI GLOBAL (7), SEGURIDAD/PWA/OFFLINE/STANDALONE (6). Cada una con ficha completa (§4), matriz de dependencias (§16), casos de prueba TC (§17) y matriz de cobertura (§18).

### 1.4 Datos duales que condicionan toda la auditoría

- **Equivalencia V0.47.3 como contrato:** las consultas Q01–Q16 + REPORTE reproducen el comportamiento del Excel original y están protegidas por 21 tests de integración de recuentos y valores (0 mismatches permitidos). Cualquier cambio en esas consultas rompe la equivalencia ⇒ **son funcionalidades CRÍTICAS congeladas**. `[T]`
- **Capa v6.1–v6.3 aditiva:** turnos, q17 (persona/día), histórico, analytics y UI nueva se construyeron expresamente SIN tocar Q01–Q16 (verificado: `analizarYConciliar` app.js:2743-2759 marca el límite). `[C]`

### 1.5 Salud global (para calibrar la auditoría)

| Dimensión | Estado | Evidencia |
|---|---|---|
| Motor de cálculo | **Sólido** | 14/14 tablas equivalentes, 74.672 celdas, 0 mismatches `[T]` |
| Tests | **Fuerte pero con huecos** | 586 tests reales; huecos: `exportToXlsx` (solo existencia), `charts.js` (sin unit), `worker.js` (solo E2E), a11y solo 3 pantallas `[T]` |
| Persistencia | **Correcta pero sin limpieza** | Ningún `delete`/`clear` de IndexedDB: crecimiento ilimitado (riesgo documentado parcialmente) `[C]` |
| Documentación | **Extensa, algunas cifras stale** | 30+ documentos; bloque "Detalle Vitest por archivo" de TEST_RESULTS_FINAL desactualizado; `manifest.json` name dice v6.2 con version 6.3.0 `[C]` |
| Seguridad | **Razonable y documentada** | CSP sin unsafe-eval, escapeHtml/CSV-injection testeados, SheetJS 0.18.5 vulnerable aceptado con mitigaciones `[C][D]` |
| Versionado/traceabilidad | **Fuerte (v6.3)** | fingerprint v2 (datos+config), hash chain SHA-256, previousVersions ≤10 `[C][T]` |

### 1.6 Las 3 reglas de oro que el auditor debe comprobar antes que nada

1. **Nada rompe la equivalencia:** ejecutar `npm ci && npm test` (523/523) y `node scripts/07_test_equivalencia_valores.cjs` (14/14, 0 mismatches, 74.672 celdas). Si esto falla, TODO lo demás es discusión secundaria.
2. **El histórico es inmutable:** cambiar mapping/productividades/overrides NUNCA reescribe versiones anteriores; crea `version+1` con `previousVersions` (verificar casos A–E de §9.5).
3. **Toda tasa es honesta:** `% oportunidades con error` ∈ [0,100] por definición (numerador ⊆ denominador); `Incidencias por oportunidad` es ratio sin cota, etiquetado aparte; NUNCA existe un clamp silencioso `min(rate,100)` que oculte ratios >1 (ver §8.3).

---

## 2. ARQUITECTURA FUNCIONAL

### 2.1 Pila técnica

| Aspecto | Valor | Verificación |
|---|---|---|
| Lenguaje | JavaScript ES5+/clásico (IIFE, `'use strict'`), sin bundler ni framework | `[C]` app.js/ui.js |
| Dependencia runtime | **1 sola**: SheetJS `xlsx.full.min.js` 0.18.5 (vendored) | `[C]` package.json |
| DevDeps | vitest, playwright, @axe-core/playwright, eslint, http-server, cyclonedx-npm, c8/nyc | `[C]` package.json |
| Build | `"build": "echo 'No build step — vanilla JS, served as static files.'"` | `[C]` |
| Servidor | Estático (http-server para E2E; en producción: raíz del sitio) | `[C]` playwright.config.js |
| Navegadores objetivo | Chromium (E2E); PWA instalable standalone | `[E]` |
| Version actual | 6.3.0 (package.json, manifest.json `version`, `PARAMS.AppVersion`, SW_VERSION, badge index, standalone) | `[C]` |

### 2.2 Archivos runtime (los 20 archivos servibles + worker + standalone)

| Archivo | Líneas (v6.3) | Rol | Namespace global |
|---|---|---|---|
| `index.html` | 827 | Shell: header, 10 pestañas, paneles, modales, CSP, manifest link | — |
| `app.js` | 2.932 | **Motor**: PARAMS, fx_*, consultas Q01–Q17, reporte, reparto, PERSON_DAILY_RECORD, undo puro, hashes, export | `window.SPEC` |
| `ui.js` | 6.561 | **Toda la UI**: tabs, dropzones, revisión, mapping, productividades, persistencia IndexedDB, Patrones render, exports UI | funciones en `window` + `UI` (privada) |
| `worker.js` | 136 | Web Worker: importScripts(xlsx+app), reconstruye workbooks desde ArrayBuffers transferidos, ejecuta `analizarYConciliar`, postMessage done/error | `self.SPEC` (aislado) |
| `charts.js` | 334 | Gráficos SVG desde `SPEC.STATE` (barras por sección, líneas por persona/día, actividad por persona) | `window.SPEC_CHARTS` |
| `styles.css` | 2.885 | Tema claro/oscuro AA, tokens primitive→semantic→component (v6.3), responsive 720/1100px, reduced-motion | — |
| `sw.js` | 107 | Service Worker: cache-first + revalidación, 19 assets precacheados, offline document fallback | — |
| `sw-register.js` | 28 | Registro SW (solo contexto seguro) | — |
| `manifest.json` | 44 | PWA manifest | — |
| `xlsx.full.min.js` | — | SheetJS 0.18.5 | `window.XLSX` |
| `analytics/analyticsCore.js` | 604 | Núcleo analítico: config 24 umbrales, safeDiv/pct, clasificación de incidencias, normalización de históricos, filtros, KPIs, periodos A/B | `window.SPEC_AN` |
| `analytics/personAnalytics.js` | 231 | Estadísticas y semáforo por persona, racha, tendencia mejora/empeora | `SPEC_AN.person` |
| `analytics/taskAnalytics.js` | 282 | Ranking TASK_WMS (oportunidades/tasas), tareas fichadas HR Task, tendencia por tarea | `SPEC_AN.task` |
| `analytics/activityAnalytics.js` | 193 | Actividades (7 + OTRA), turnos (SIN HORA separado) | `SPEC_AN.activity` |
| `analytics/confusionAnalytics.js` | 132 | Matriz fichada→correcta, heatmap, recurrentes (AISLADO/RECURRENTE/HABITUAL) | `SPEC_AN.confusion` |
| `analytics/trendAnalytics.js` | 213 | Series diarias, MM, rolling 7/28 (días observados), buckets semana/mes, frecuencia×impacto | `SPEC_AN.trend` |
| `analytics/paretoAnalytics.js` | 76 | Curva 80/20 con comprobación REAL | `SPEC_AN.pareto` |
| `analytics/alertAnalytics.js` | 272 | Alertas A1–A11 deterministas + índice de prioridad + TOP 5 | `SPEC_AN.alerts` |
| `analytics/dataQualityAnalytics.js` | 155 | Calidad de datos (causas OPERATIVO/DATOS/REVISIÓN/CONTROL) y calidad del mapping | `SPEC_AN.dataQuality` |
| `logo_idl.png` | — | Logo/icono PWA | — |
| `SPEC_AUTONOMO_v6.html` | ~1,5 MB | Build standalone de un solo archivo (motor + analytics + estilos embebidos, CSP por hashes, sin manifest) | — |

### 2.3 Puntos de entrada

1. **`index.html`** (app modular): registra `sw-register.js`; carga en orden `styles.css → xlsx.full.min.js → app.js → analytics/analyticsCore.js → person/task/activity/confusion/trend/pareto/alerts/dataQuality → charts.js → ui.js` (ui.js último: `init()` al final). `[C]` index.html:785-826
2. **`SPEC_AUTONOMO_v6.html`** (standalone): mismo motor embebido inline (reconstruido por `scripts/06_build_autonomo.py` con probes obligatorios v6.3); **sin** SW/manifest (PWA exclusiva del modular). `[C][E]` standalone.spec.js
3. **Web Worker** (`worker.js`): importScripts de `xlsx.full.min.js` y `app.js`; el IIFE de app.js detecta `typeof window === 'undefined'` y se cuelga de `globalThis` (`self`). `[C]` worker.js:38-39

### 2.4 Capas y separación de responsabilidades

```
CAPA PRESENTACIÓN        index.html + styles.css + ui.js (render, eventos, persistencia IndexedDB)
                              ↕ window.SPEC / SPEC_AN / SPEC_CHARTS
CAPA ANALÍTICA PURA      analytics/*.js (9 módulos, sin DOM, deterministas, testeables)
                              ↕ PERSON_DAILY_RECORD normalizados
CAPA MOTOR               app.js (fx_* puras + Q01–Q16 congeladas + Q17 + REPORTE + reparto + fingerprints)
                              ↕ transferibles ArrayBuffer
CAPA EJECUCIÓN           worker.js (off-main-thread) ── fallback → main-thread (ui.js analizarEnMainThread)
CAPA PERSISTENCIA        IndexedDB (spec_history_db, spec_decisions_db) + localStorage (8 claves) + SW cache
```

**Principio de inmutabilidad del motor:** `analizarYConciliar` (app.js:2609-2765) ejecuta Q01–Q16 con productividades por defecto y `taskOverrides={}`; la UI recalcula SOLO q17+histórico con las preferencias del usuario vía `recomputarPersonaDia` (ui.js:4246) ⇒ las consultas congeladas nunca ven configuración del usuario. `[C]`

### 2.5 Flujos de sesión (antes/durante/después)

- **Arranque:** init() → restaurar decisiones (localStorage → fallback IndexedDB) → cargar mapping persistente (IndexedDB `mappings`, reconstruye File) → restaurar estado del último análisis (`spec_state`, si existe) → registrar SW. `[C]` ui.js:1318-1386
- **Ciclo principal:** Cargar 4 tipos de archivo → ANALIZAR (worker) → auto-navegación a Revisar → decisiones (audit log + undo + persistencia) → Patrones (histórico acumulado) → exportaciones.
- **Cierre:** `beforeunload` avisa solo si hay decisiones sin persistir (condición casi nunca cierta porque `persistDecisions` escribe inmediatamente — ver discrepancia D-003).

### 2.6 Entorno de pruebas

- **Unit/integración:** Vitest con `tests/setup.js` (shims DOM + eval de app.js → `globalThis.SPEC`); analytics se cargan igual vía setup. Cobertura real por `scripts/cover_integration.cjs` (monkey-patch `fs.readFileSync` para instrumentar el eval — la vía istanbul da 0 % por `new Function`). `[C][D]`
- **E2E:** Playwright + http-server sobre el directorio del proyecto; fixtures reales en `audit-ref/drive/` (4 archivos del Excel original) y `test-data/{turnos,patrones}/`. `[E]`
- **Validadores de release:** `scripts/validate_manifest.cjs` (157 entradas SHA-256), `scripts/validate_release.cjs` (78 checks incl. floors de tests y guardas de versión). `[C][D]`
---

## 3. ÁRBOL COMPLETO DE FUNCIONALIDADES

Árbol construido desde `index.html` (pestañas/paneles reales, líneas 54-826) y `ui.js` (funciones que los pueblan). Los códigos F-XXX se detallan en §4.

```
SPEC WEB v6.3.0
│
├── [Tab 1] CARGAR Y ANALIZAR (panel-cargaanalizar)
│   ├── Dropzone unificada multi-tipo (#drop-unified) .......................... F-001
│   ├── Detección automática de tipo (detectarTipoArchivo) ..................... F-002
│   ├── Validación pre-lectura + lectura SheetJS ................................ F-003, F-004, F-005
│   ├── Gestión multi-archivo por tipo (arrays, quitar archivo) ............... F-010, F-013
│   ├── Checklist unificada de carga (actualizarUnifiedChecklist) .............. F-011
│   ├── Botón ANALIZAR (Worker) ................................................. F-014, F-015, F-016, F-017
│   ├── Auto-navegación a Revisar + toasts post-análisis ....................... F-018
│   ├── Tarjeta "Mapping activo" (persistente) .................................. F-068
│   └── Registro de ejecución (log del análisis) ................................ F-016
│
├── [Tab 2] REVISAR INCIDENCIAS (panel-revisar) — unidad PERSONA+FECHA_OPERATIVA
│   ├── Filtros: sección / turno (real) / estado decisión / búsqueda ........... F-049
│   ├── Lista de tarjetas persona/día con prioridad y aviso SIN HORA .......... F-048, F-050
│   ├── Detalle persona/día: KPIs, fichajes, actividades y reparto ............. F-051
│   ├── Acciones: Aceptar / Rechazar / Mantener + tarea final + motivo ........ F-052, F-053, F-054, F-055
│   ├── UNDO (decisión / última acción) ......................................... F-056, F-057
│   ├── Auto-avance configurable ............................................... F-058
│   └── Navegación por teclado / navegación siguiente-anterior ................ F-059
│
├── [Tab 3] RESULTADOS (panel-resultados)
│   ├── KPIs resumen + drilldown ............................................... F-103
│   ├── Gráficos SVG (charts.js) ............................................... F-102
│   └── Listado de 17 tablas → visor con orden, scroll virtual, export ....... F-100, F-101
│
├── [Tab] MAPPING (panel-mapping)
│   ├── Visualización 167 filas + hash + stats .................................. F-061
│   ├── Búsqueda y filtros (Customer, Task WMS) ................................ F-062
│   ├── CRUD: editar fila / eliminar fila (con confirm) ....................... F-063
│   ├── Badges duplicados / ambigüedades + resaltado ........................... F-064
│   ├── Export mapping XLSX .................................................... F-065
│   ├── Import mapping XLSX manual ............................................ F-012
│   └── Persistencia versionada (IndexedDB mappings) + auto-carga + diálogo .. F-066, F-067, F-068
│
├── [Tab 4] REPORTE HR (panel-reporte)
│   ├── Tabla REPORTE_CAMBIOS_HR (7 secciones) .................................. F-104
│   └── Filtros de sección + export XLSX/CSV ................................... F-104
│
├── [Tab 5] PATRONES — Estadística avanzada (panel-patrones)
│   ├── Filtros globales (11 dimensiones en 3 fieldsets) ....................... F-085
│   ├── ⚙ CONFIGURACIÓN ESTADÍSTICA (24 parámetros persistidos) ................ F-086
│   ├── Sub-pestaña RESUMEN: KPIs jerárquicos + evolución + TOP5 + alertas ..... F-087
│   ├── Sub-pestaña PERSONAS: ranking + semáforo + racha + drill-down .......... F-088, F-089
│   ├── Sub-pestaña TAREAS: TASK_WMS + fichadas HR Task + tendencia ............ F-090
│   ├── Sub-pestaña ACTIVIDADES: 7+OTRA + turnos + SIN HORA .................... F-091
│   ├── Sub-pestaña ERRORES: matriz confusión + heatmap + recurrentes .......... F-092
│   ├── Sub-pestaña EVOLUCIÓN: series + MM + rolling + buckets + A/B .......... F-093, F-094
│   ├── Sub-pestaña PARETO: curva 80/20 + banner ............................... F-095
│   ├── Sub-pestaña CALIDAD DE DATOS: causas + mapping ......................... F-096
│   ├── Motor: snapshot memoizada (patronesSnapshot) .......................... F-084
│   └── Exportación XLSX de 7 vistas ............................................ F-099
│
├── [Tab 6] TRAZABILIDAD (panel-trazabilidad)
│   └── Origen de un registro: selección tabla+fila → árbol de dependencias .. F-105
│
├── [Tab 7] AUDITORÍA (panel-auditoria)
│   ├── Cadena de decisiones (audit log SHA-256) .............................. F-072, F-073, F-074, F-075
│   └── Export auditoría CSV + vaciado ......................................... F-109
│
├── [Tab 8] EXPORTAR (panel-exportar)
│   ├── Tablas a XLSX/CSV (por tabla) ........................................... F-107, F-108
│   ├── Correcciones aprobadas (XLSX/CSV) ...................................... F-109
│   └── Reporte + histórico .................................................... F-109
│
├── [Tab ?] AYUDA (panel-ayuda)
│   └── Manual integrado (qué hace, cómo usarla, limitaciones) ................ F-116
│
├── ⚙ PRODUCTIVIDADES (sección dentro de Configuración/panel)
│   ├── Editor de productividades por ACTIVIDAD ............................... F-047, F-069
│   └── PRODUCTIVIDAD POR TAREA (overrides TASK_WMS) ........................... F-070, F-071
│
├── TRANSVERSAL
│   ├── Búsqueda global ......................................................... F-106
│   ├── Tema claro/oscuro/auto ................................................. F-111
│   ├── Persistencia de sesión (spec_state) + indicador ....................... F-112
│   ├── Toasts / modales / focus-trap / panel detalle / preview ............... F-113, F-114
│   ├── Atajos de teclado + beforeunload ....................................... F-115
│   └── Undo núcleo puro (app.js) .............................................. F-056
│
├── MOTOR (invisible para el usuario)
│   ├── Consultas Q01–Q17 + REPORTE + materialidad ............................ F-019 … F-033
│   ├── Funciones puras fx_* (texto, login, fecha, número, turnos) ............. F-034 … F-040
│   ├── Clasificación de actividades + resolución por tarea + reparto ........... F-041 … F-046
│   ├── PERSON_DAILY_RECORD + fingerprint v2 + persistencia versionada ....... F-078 … F-083
│   └── Session/mapping hashes + audit chain (app.js) .......................... F-073, F-074
│
├── PERSISTENCIA
│   ├── IndexedDB spec_history_db: mappings, person_daily_records ............. F-066, F-080, F-081
│   ├── IndexedDB spec_decisions_db: decisions (backup) ......................... F-076
│   ├── localStorage: 8 claves (tema, estado, decisiones, productividades,
│   │   overrides, sesión, config estadística, auto-avance) ................... F-068/F-069/F-070/F-076/F-086/F-111/F-112/F-058
│   └── Service Worker cache (recursos, nunca datos) .......................... F-119
│
├── SEGURIDAD
│   ├── CSP + nosniff + no-referrer ............................................. F-117
│   ├── escapeHtml / escapeAttr (XSS) .......................................... F-118
│   └── CSV formula injection (M-01/R-05) ...................................... F-108
│
└── PWA / OFFLINE / STANDALONE
    ├── Manifest + instalación standalone ...................................... F-120
    ├── Service Worker (cache-first, 19 assets, fallback offline) ............. F-119
    ├── Modo offline completo tras primera carga ............................... F-121
    └── SPEC_AUTONOMO_v6.html (single-file, CSP por hashes) .................... F-122
```

**Nota sobre la pestaña "Configuración":** el usuario pedía "Configuración" en el árbol; en la implementación real NO existe una pestaña con ese nombre: la configuración se reparte en (a) sección ⚙ **Productividades** (productividad por actividad y por tarea), (b) `⚙ CONFIGURACIÓN ESTADÍSTICA` dentro de Patrones, y (c) parámetros del motor `SPEC.PARAMS` (no editables desde UI). `[C]`

---

## 4. CATÁLOGO DE FUNCIONALIDADES (F-001 … F-122)

Convención de cada ficha: **Categoría · Criticidad · Ubicación** (archivo:línea aproximada) y bloques: Descripción/Objetivo · Precondiciones · Entradas · Proceso · Reglas · Salida · Persistencia · Dependencias → Alimenta a · Estados · Errores · Casos límite · Comportamiento esperado · Verificación (tests existentes / faltan).

Criticidades: **CRÍTICA** (resultados incorrectos o pérdida de información), **ALTA** (parte esencial del flujo cae), **MEDIA** (afecta una parte, hay workaround), **BAJA** (UX/conveniencia).

---

### 4.1 ÁREA: INGESTA (F-001 … F-018)

---

#### F-001 · Carga unificada de archivos (dropzone multi-tipo)
- **Categoría:** INGESTA · **Criticidad:** CRÍTICA · **Ubicación:** ui.js:167-435 (setupDropZones/setupUnifiedZone), index.html `#drop-unified` (panel-cargaanalizar).
- **Descripción/Objetivo:** Permitir al usuario cargar **uno o varios** archivos Excel de cada uno de los 4 tipos (HORA SIN VOLUMEN, VOLUMEN, VOL SIN HORAS, MAPPING) en una única zona de arrastre o mediante selección de archivos. Un solo punto de entrada desde v6.1 (MEJORA 2).
- **Precondiciones:** App cargada; nada más. El mapping también puede venir auto-cargado (F-067) sin tocar la dropzone.
- **Entradas:** Eventos `dragover/drop` o `change` de `<input type=file multiple>`; `File` objects del SO.
- **Proceso:** 1) drag/drop o selección → 2) por cada File se llama a detección de tipo (F-002) → 3) validación pre-lectura (F-003) → 4) `SPEC.leerArchivoExcel` (F-004) → 5) el workbook se guarda en `SPEC.STATE.archivos[tipo]` como elemento del array `{name, workbook, file}` (el `File` original se retiene para transferirlo al worker) → 6) actualización visual de la checklist (F-011).
- **Reglas:** un archivo solo puede clasificarse en UN tipo; el mismo archivo puede añadirse varias veces bajo nombres distintos (los duplicados de contenido NO se detectan aquí — se detectan por ClaveNatural en q01/q02, F-019/F-020); el usuario puede mezclar N archivos por tipo.
- **Salida:** `STATE.archivos.{horas|volumen|volSinHoras|mapping}` = array de `{name, workbook, file}`.
- **Persistencia:** memoria solamente (el contenido no se persiste; el mapping sí se persiste aparte vía F-066).
- **Dependencias:** F-003, F-004, F-002. → **Alimenta a:** F-014 (worker), F-017.
- **Estados:** vacía / parcial (algunos tipos) / completa (≥1 por tipo; el botón ANALIZAR requiere los 4).
- **Errores:** extensión no permitida, archivo >50 MB, archivo 0 bytes, MIME sospechoso (warning), Excel corrupto → mensaje inline en la zona + no se añade.
- **Casos límite:** archivo con hoja EXPORT vacía (pasa la carga, falla al analizar con error claro); dos archivos iguales con distinto nombre (se suman filas y las claves duplicadas saltan como POSIBLE DUPLICADO); arrastre de 20 archivos de golpe.
- **Comportamiento esperado:** la zona muestra los archivos aceptados por tipo con su tamaño; los rechazados muestran el motivo; ANALIZAR solo habilitado con los 4 tipos presentes.
- **Verificación:** `[E]` smoke.spec.js t2 (4 archivos), multifile_worker.spec.js (7 archivos), mejoras_v6.spec.js t1 (dropzone unificada + detección). Faltan: test de límite de muchos archivos simultáneos; test de archivo >50 MB es unitario (F-003) pero no E2E.

#### F-002 · Detección automática de tipo de archivo
- **Categoría:** CLASIFICACIÓN/INGESTA · **Criticidad:** ALTA · **Ubicación:** ui.js:4087-4166 (`detectarTipoArchivo`).
- **Descripción/Objetivo:** Clasificar cada workbook subido en uno de los 4 tipos sin preguntar al usuario, inspeccionando las hojas/cabeceras.
- **Entradas:** workbook SheetJS ya leído.
- **Proceso/Reglas (orden de decisión `[C]`):** 1) hoja "MAPPING" con las 8 columnas estructurales ⇒ `mapping`; 2) hoja con columnas de horas (`Site name` + `Hours without volume`) ⇒ `horas`; 3) columnas de volumen (`DATE`+`WMS_TASK`+`WMS_UOM`) ⇒ `volumen`; 4) columnas VSH (`Volume Without Hours`) ⇒ `volSinHoras`; 5) si nada encaja ⇒ rechazo con mensaje "no se pudo determinar el tipo".
- **Salida:** string de tipo o error.
- **Dependencias:** F-004. → **Alimenta a:** F-001.
- **Errores:** archivo sin tipo reconocible.
- **Casos límite:** un mismo archivo que contenga hojas de dos tipos (gana el orden de reglas anterior); Mapping.xlsx con hoja "Mapping" pero columnas mal llamadas (cae a "no reconocido").
- **Comportamiento esperado:** el usuario nunca elige tipo manualmente; la checklist refleja la clasificación.
- **Verificación:** `[E]` mejoras_v6.spec.js t1 (detección automática con los 4 reales). Faltan: unit test directo de `detectarTipoArchivo` con fixtures ambiguos (hoja con ambas cabeceras).

#### F-003 · Validación pre-lectura de archivo (`validarArchivoEntrada`)
- **Categoría:** VALIDACIÓN/SEGURIDAD · **Criticidad:** ALTA · **Ubicación:** app.js:484-529 (expuesta en `SPEC`).
- **Descripción/Objetivo:** Rechazar entradas claramente inválidas ANTES de parsear (mitigación R-06/AUD-MED-005 del riesgo SheetJS).
- **Reglas `[C]`:** extensión ∈ {`.xlsx`, `.xlsm`, `.xlsb`} (si no, error); MIME si existe ∈ lista de 5 tipos conocidos o warning `application/octet-stream` aceptado (Firefox .xlsb); tamaño > `PARAMS.TamanoMaximoArchivoMB` (50 MB, configurable, 0 = desactiva) → error; size 0 → error; devuelve `{ok, error, warnings[]}` — nunca lanza.
- **Dependencias:** —. → **Alimenta a:** F-004 (que la invoca de nuevo internamente), F-001.
- **Casos límite:** extensión `.csv`/`.exe` (rechazo); MIME raro (warning, NO rechazo); tamaño exactamente 50 MB (no rechazado, condición `>`).
- **Verificación:** `[T]` input_validation.test.js (7 casos: null, 0 bytes, csv/exe, >50MB, real OK, MIME raro). Fuerte.

#### F-004 · Lectura/parseo Excel (`leerArchivoExcel`)
- **Categoría:** INGESTA · **Criticidad:** CRÍTICA · **Ubicación:** app.js:573-600 (`SPEC.leerArchivoExcel`), ui.js la llama desde la dropzone.
- **Proceso:** FileReader → `Uint8Array` → sanity buffer ≥4 bytes → `XLSX.read(data, {type:'array', cellDates:true})`.
- **Reglas:** `cellDates:true` convierte seriales a Date (base 1899-12-30); error de parseo se transforma en mensaje accionable ("¿Está corrupto…?").
- **Errores:** buffer <4 bytes; SheetJS lanza (ZIP/OLE2 inválido).
- **Casos límite:** archivo basura que SheetJS 0.18.5 parsea como hoja vacía "Sheet1" (documentado: la defensa REAL son las capas F-005/F-006 — lenitud de SheetJS reconocida en tests).
- **Verificación:** `[T]` input_validation.test.js (defensa en profundidad: buffer vacío, 2 bytes); `[E]` smoke t3. Faltan: nada relevante.

#### F-005 · Validación de estructura de workbook (`validarWorkbook`)
- **Categoría:** VALIDACIÓN · **Criticidad:** ALTA · **Ubicación:** app.js:535-571.
- **Reglas `[C]`:** workbook no nulo y con hojas; `encontrarHojaExport` busca hoja "EXPORT" (case-insensitive) y **si no existe usa la primera hoja** (fallback documentado); rows ≥1 (vacía) y ≥2 (solo cabecera); cabecera presente; >100 columnas → warning.
- **Salida:** `{ok, error, warnings, sheetName, headers}`.
- **Casos límite:** archivo sin hoja EXPORT pero primera hoja con datos (se acepta y usa la primera — decisión heredada del Excel original, verificada en test).
- **Verificación:** `[T]` input_validation.test.js (9 casos: null, sin hojas, EXPORT vacía, solo cabecera, mínimo, >100 columnas, VOLUMEN real, Mapping real, fallback primera hoja).

#### F-006 · Transformador HORAS SIN VOLUMEN (`fx_TransformaHoras`)
- **Categoría:** PROCESAMIENTO · **Criticidad:** CRÍTICA · **Ubicación:** app.js:625-671 (Section1.m líneas 57-79).
- **Entradas:** workbook + nombre de archivo.
- **Proceso/Reglas `[C]`:** hoja EXPORT (o primera); **filtrado de pie**: primera columna nula/vacía fuera; filas que empiezan por "TOTAL" fuera; filas que contienen "FILTROS APLICADOS" fuera (Bug 2 del Excel original corregido); columnas requeridas exactas: `Site name, Department, Activity, Subactivity, Date, HR Task, WMS Login, Name, Hours without volume` (si falta una → throw con nombre de archivo y hoja); proyecta a objetos con `ArchivoOrigen` y `FilaOrigen = idx+2`.
- **Salida:** array de filas crudas por archivo (se concatenan entre archivos en F-017).
- **Verificación:** `[T]` input_validation.test.js (HORA SIN VOLUMEN real → 116 filas), regression_bugs.test.js Bug 2 (743/745 en volumen, equivalente en horas).

#### F-007 · Transformador VOLUMEN (`fx_TransformaVolumen`)
- **Categoría:** PROCESAMIENTO · **Criticidad:** CRÍTICA · **Ubicación:** app.js:674-715.
- **Reglas:** igual patrón; pie filtrado por columna DATE (o primera); requeridas: `DATE, SAP_CODE, CUSTOMER, WMS_TASK, WMS_LOGIN, USER_NAME, WMS_UOM`; `VolumenNeto = WMS_UOM`.
- **Verificación:** `[T]` input_validation (743 filas reales sin TOTAL/FILTROS), regression_bugs Bug 2, equivalencia de valores 14/14. `[E]` smoke t3.

#### F-008 · Transformador VOL SIN HORAS (`fx_TransformaVolumenSinHoras`)
- **Categoría:** PROCESAMIENTO · **Criticidad:** ALTA · **Ubicación:** app.js:718-759.
- **Reglas:** requeridas: `Site name, Department, Activity, Subactivity, Date, HR Task, WMS Login, Name, Volume Without Hours`; sufijos `VSH` en campos ArchivoOrigenVSH/FilaOrigenVSH.
- **Verificación:** `[T]` input_validation (490 filas reales en multifile).

#### F-009 · Lectura de Mapping (`leerMapping`)
- **Categoría:** PROCESAMIENTO · **Criticidad:** CRÍTICA · **Ubicación:** app.js:762-807.
- **Reglas `[C]`:** hoja "MAPPING" exacta (case-insensitive) o que contenga "MAPPING"; cabeceras normalizadas (mayúsculas, NBSP→espacio, espacios→`_`); 8 columnas obligatorias: `SAP_CODE, WMS_DC, CUSTOMER, DEPARTMENT, ACTIVITY, SUB_ACTIVITY, TASK_WMS, TASK_SPEC`; si faltan → throw con lista.
- **Salida:** array de objetos de 8 campos (orden de columnas canónico).
- **Verificación:** `[T]` input_validation (Mapping real OK), mapping_persist (hash sobre 167 filas reales). `[E]` mapping.spec.js.

#### F-010 · Gestión multi-archivo por tipo (M-10)
- **Categoría:** INGESTA · **Criticidad:** ALTA · **Ubicación:** ui.js:361-446 (updateDropZoneFiles/removeFile/checkAllLoaded), app.js:2630-2637 (normalización toArray en analizarYConciliar), worker.js:66-101.
- **Reglas:** `STATE.archivos[k]` admite array o objeto legacy; el motor concatena con `flatMap` las filas de todos los archivos del mismo tipo (cada fila conserva `ArchivoOrigen`); mapping: concatenación + dedup posterior por (SAP_CODE|CUSTOMER|TASK_WMS) en q12; el usuario puede quitar archivos individuales (botón ✕ por chip).
- **Casos límite:** 2 archivos de horas idénticos → filas duplicadas → POSIBLE DUPLICADO (F-019) por ClaveNatural.
- **Verificación:** `[T]` — implícito en analizarYConciliar; `[E]` multifile_worker.spec.js (2+2+2+1 archivos: 1486 filas en 02, 490 en 09, sin fallback).

#### F-011 · Checklist unificada de carga
- **Categoría:** UI · **Criticidad:** BAJA · **Ubicación:** ui.js:4168-4192 (`actualizarUnifiedChecklist`), index.html (cargaanalizar).
- **Descripción:** resumen por tipo: nº archivos, nº filas válidas, estado; habilita ANALIZAR solo con 4 tipos.
- **Verificación:** `[E]` mejoras_v6 t1. Faltan: asserts de conteos exactos en E2E.

#### F-012 · Importación manual de Mapping XLSX
- **Categoría:** INGESTA/PERSISTENCIA · **Criticidad:** ALTA · **Ubicación:** ui.js:3412-3430 (`importMappingXlsx`).
- **Descripción/Objetivo:** El mapping ES aportado manualmente por el usuario (no hay mapping operativo fijo en el proyecto; el fixture Mapping.xlsx es un ejemplo). Desde la pestaña Mapping el usuario importa un XLSX que sobrescribe `UI.mappingCurrent` (copia editable) manteniendo `mappingOriginal` como referencia; recalcula hash; guarda versión en IndexedDB (F-066); registra `mapping_import` en audit log; persiste decisiones.
- **Reglas:** validación F-009; tras importar, `SPEC.STATE.stats.mappingHash` se actualiza; si ya existía mapping cargado se muestra el diálogo old-vs-new (F-068) ANTES de sustituir.
- **Verificación:** `[E]` mapping.spec.js (importación), mejoras_v6 t2-t3. `[T]` mapping_persist.

#### F-013 · Eliminación/reinicio de archivos y proceso
- **Categoría:** INGESTA · **Criticidad:** MEDIA · **Ubicación:** ui.js:412-435 (removeFile), ui.js:509-560 (reiniciarCarga/reiniciarProceso), ui.js:6394-6440 (setupResetHooksV61).
- **Descripción:** quitar un archivo concreto de un tipo; reiniciar la carga (limpia STATE y UI); reiniciar el proceso completo (además borra `spec_state` persistido y detiene worker activo con `worker.terminate()` si estaba en marcha).
- **Verificación:** `[E]` parcial (smoke). Faltan: E2E de reinicio a mitad de análisis.

#### F-014 · Análisis en Web Worker
- **Categoría:** PROCESAMIENTO · **Criticidad:** ALTA · **Ubicación:** ui.js:616-692 (`analizarConWorker`), worker.js completo.
- **Proceso `[C]`:** main-thread re-lee cada `File` como `ArrayBuffer` (los workbooks NO son structured-cloneable) → `postMessage({type:'start', archivos}, transfer)` zero-copy → worker reconstruye workbooks con `XLSX.read` → ejecuta `SPEC.analizarYConciliar(onProgress)` en su propio `self.SPEC` → `postMessage({type:'done', state:{queries, reporte, log, stats, personaDiaRecords}})`.
- **Reglas:** solo datos planos viajan de vuelta (Date/number/string/boolean — safe para structured-clone); `analizarYConciliar` nunca toca `decisions/auditLog` (no viajan).
- **Errores:** worker lanza → `{type:'error', message, stack}` → fallback F-015.
- **Casos límite:** transfer de buffers vacíos (<4 bytes → error claro); contexto sin `Worker` (file:// antiguo) → fallback.
- **Comportamiento esperado:** el UI no se congela; barra de progreso con % y etiqueta por consulta; **ningún warning de consola** por fallback.
- **Verificación:** `[E]` multifile_worker.spec.js (2 tests: verifica AUSENCIA de warnings de fallback con 2 y 7 archivos). Faltan: unit test directo de worker.js; test de error de worker → fallback (solo inferible).

#### F-015 · Fallback a hilo principal
- **Categoría:** PROCESAMIENTO · **Criticidad:** MEDIA · **Ubicación:** ui.js (analizarEnMainThread, invocada si no hay Worker o si falla).
- **Descripción:** mismo `analizarYConciliar` en el hilo principal; UI bloqueante con progreso.
- **Verificación:** `[C]` código; usada por tests de integración (cover_integration). `[T]` implícito. Faltan: E2E del fallback forzado.

#### F-016 · Progreso y log de análisis
- **Categoría:** UI · **Criticidad:** MEDIA · **Ubicación:** app.js:2644-2759 (callbacks onProgress 0→100 con etiqueta por consulta), index.html "Registro de ejecución", STATE.log (cap 1000 entradas, app.js:93-98).
- **Salida:** barra de progreso + mensajes ("01_HorasSinVolumen: 214 filas válidas", …) + log interno `{ts, level, msg}`.
- **Verificación:** `[E]` smoke t3; `[T]` performance (totalMs). Faltan: asserts del contenido del log.

#### F-017 · Orquestador `analizarYConciliar`
- **Categoría:** PROCESAMIENTO · **Criticidad:** CRÍTICA · **Ubicación:** app.js:2609-2765 (expuesta como `SPEC.analizarYConciliar`).
- **Precondiciones:** ≥1 archivo de cada tipo (si no: throw "Falta el archivo X").
- **Proceso (16 pasos con progreso `[C]`):** resetea STATE → stats de sesión (sessionId, versiones, mappingHash FNV, inputFiles con nº archivos/filas por tipo) → transforma los 4 tipos → **orden**: q01(20%) → q02(30%) → q09(40%) → q12(50%) → q13(60%) → q03(65%) → q05(70%) → q10 → q14 → q15(80%) → q16 → q07(90%) → q08 → REPORTE(95%) → **q17 con productividades por defecto** → generarPersonDailyRecords → totalMs.
- **Reglas de inmutabilidad:** q01–q16 y REPORTE NO reciben productividades/overrides del usuario (solo defaults) ⇒ equivalencia intacta; la recalculación con preferencias del usuario ocurre en `recomputarPersonaDia` (F-083) fuera del motor.
- **Salida:** `STATE.queries` (17 claves), `STATE.reporte`, `STATE.personaDiaRecords`, `STATE.stats`.
- **Verificación:** `[T]` performance.test.js (≥10 queries no vacías con 1k/10k/50k filas, no cuadrático), equivalencia de recuentos y valores. `[E]` smoke t3-t4. **Fuerte.**

#### F-018 · Post-análisis: auto-navegación y estado
- **Categoría:** UI · **Criticidad:** MEDIA · **Ubicación:** ui.js:6441-6480 (setupPostAnalisisHook), wrap de `analizar()` en ui.js:2259.
- **Proceso:** análisis OK → toasts resumen → auto-navegación a pestaña Revisar → `recomputarPersonaDia` con productividades/overrides del usuario → `persistirPersonDailyRecords` (F-080) → `persistState` (F-112) → refresco de paneles.
- **Verificación:** `[E]` mejoras_v6 t1 (auto-nav), patrones_v62 t2-t4 (persistencia tras análisis).

---
### 4.2 ÁREA: MOTOR — CONSULTAS Y REPORTE (F-019 … F-033)

> **Nota de auditoría:** Q01–Q16 + REPORTE están **congeladas por equivalencia** con SPEC V0.47.3 (tests de recuentos ±2 y de valores célula a célula con 0 mismatches sobre 74.672 celdas). Cualquier comportamiento aquí descrito puede verificarse contra `audit-ref/drive/` (los 4 archivos reales) ejecutando `npm run test:integration`.

---

#### F-019 · q01_HorasSinVolumen
- **Categoría:** PROCESAMIENTO · **Criticidad:** CRÍTICA · **Ubicación:** app.js:926-1009 (Section1.m q08).
- **Entradas:** filas crudas de fx_TransformaHoras (multi-archivo concatenadas).
- **Proceso/Reglas `[C]`:** 1) normalización por campo (`fx_NormalizaTexto` textos, `fx_Fecha` fecha, `numberFrom` horas, `fx_NormalizaLogin` login con 7 campos derivados); 2) **RegistroValido** con `MotivoInvalido` ∈ {FECHA INVALIDA, LOGIN VACIO, ACTIVITY VACIA, HORAS NO NUMERICAS, HORAS CERO O NEGATIVAS} (orden de precedencia exacto); 3) **ClaveNatural** = `Site|FechaISO|LoginCanonico|Department|Activity|Subactivity|HR Task|Horas(exacto 12 dec)`, separador `|`; 4) **RepeticionesClave** (group by) → **PosibleDuplicado** = repeticiones >1; 5) **IdRegistroHoras** = secuencial 1..N (¡recomputado en cada análisis!); 6) filtro final `RegistroValido=true` (los inválidos NO reciben IdRegistro).
- **Salida:** filas H (la base de todo el motor).
- **Casos límite:** horas negativas → inválidas (motivo explícito); login con >15 dígitos → BigInt R-12.
- **Verificación:** `[T]` equivalencia recuentos/valores, input_validation (116 filas reales), fx_* units. **Fuerte.**

#### F-020 · q02_VolumenDetalle
- **Categoría:** PROCESAMIENTO · **Criticidad:** CRÍTICA · **Ubicación:** app.js:1022-1085.
- **Reglas adicionales `[C]`:** `VolumenPositivo = v>0?v:0`; `VolumenNegativo = v<0?v:0`; `EsVolumenCero = v===0`; RegistroValido requiere `Fecha + VolumenNeto + WMS_TASK` no nulos; misma mecánica de ClaveNatural (`Fecha|SAP|CUSTOMER|WMS_TASK|LoginCanonico|VolumenNeto`) y PosibleDuplicado.
- **Verificación:** `[T]` equivalencia, regression_bugs Bug 2 (743 filas sin TOTAL/FILTROS APLICADOS), multifile (1486). **Fuerte.**

#### F-021 · q09_VolumenSinHorasDetalle
- **Categoría:** PROCESAMIENTO · **Criticidad:** ALTA · **Ubicación:** app.js:1086-1151. Análoga a q02 para VSH (campos con sufijo VSH; PosibleDuplicadoVSH).
- **Verificación:** `[T]` equivalencia; multifile (490 filas).

#### F-022 · q12_MapeoActividadSPEC
- **Categoría:** CLASIFICACIÓN · **Criticidad:** CRÍTICA · **Ubicación:** app.js:1152-1215.
- **Proceso/Reglas `[C]`:** filas válidas = `SAP_CODE + CUSTOMER + TASK_WMS` no nulos; group by esa triple; para cada grupo: listas distinct de ACTIVITY/TASK_SPEC/DEPARTMENT/SUB_ACTIVITY/WMS_DC; `EstadoMapeoSPEC` ∈ {SIN TASK_SPEC (0), UNICO (1), AMBIGUO (>1)}; `TieneMultipleWMS_DC` si el grupo tiene >1 WMS_DC distinto; `TasksSPEC` = join " | " (así las propuestas múltiples llevan " | " dentro del campo).
- **Salida:** tabla M de mapeos deduplicada.
- **Verificación:** `[T]` equivalencia (tabla 12), mapping_persist. **Fuerte.**

#### F-023 · q13_VolumenMapeadoSPEC
- **Categoría:** PROCESAMIENTO · **Criticidad:** CRÍTICA · **Ubicación:** app.js:1218-1226.
- **Reglas:** LEFT OUTER JOIN de q02 con q12 por `(SAP_CODE, CUSTOMER, WMS_TASK)`; toma el **primer match** (como Power Query expand); `EstadoMapeoFinal` = EstadoMapeoSPEC o **'SIN MAPEO'** si no hay fila de mapping.
- **Verificación:** `[T]` equivalencia. **Fuerte.**

#### F-024 · q03_VolumenPersonaDia
- **Categoría:** PROCESAMIENTO · **Criticidad:** ALTA · **Ubicación:** app.js:1229-1252. Group by (Fecha, LoginCanonico): VolumenTotalPositivo/Negativo/Neto, RegistrosVolumen/Cero/Negativos, NumeroTareasWMS, listas TareasWMS/ClientesWMS/SAPsWMS, TieneDuplicadosVolumen.
- **Verificación:** `[T]` equivalencia.

#### F-025 · q05_VolumenIdNumericoDia
- **Categoría:** PROCESAMIENTO · **Criticidad:** ALTA · **Ubicación:** app.js:1253-1270. Group by (Fecha, IdNumericoNormalizado): VolumenIdPositivo, NumeroLoginsDistintos, LoginsMismoNumero, PrefijosMismoNumero, **EsAmbiguoIdNumerico = logins>1** (la ambigüedad de id numérico nace aquí).
- **Verificación:** `[T]` equivalencia; q08 checks.

#### F-026 · q10_VolumenSinHorasPersonaDia
- **Categoría:** PROCESAMIENTO · **Criticidad:** MEDIA · **Ubicación:** app.js:1273-1289. Group by (Fecha, LoginCanonico) de VSH.
- **Verificación:** `[T]` equivalencia.

#### F-027 · q14_VolumenPersonaDiaActividadSPEC
- **Categoría:** PROCESAMIENTO · **Criticidad:** ALTA · **Ubicación:** app.js:1292-1308. Group by (Fecha, Login, ActividadSPEC) SOLO de filas con EstadoMapeoFinal='UNICO' y ActividadSPEC no nula.
- **Verificación:** `[T]` equivalencia.

#### F-028 · q15_VolumenSinHorasPersonaDiaActividadSPEC
- **Categoría:** PROCESAMIENTO · **Criticidad:** MEDIA · **Ubicación:** app.js:1311-1324. Group by (Fecha, Login, Activity) de VSH.
- **Verificación:** `[T]` equivalencia.

#### F-029 · q16_ControlMapeoSPEC
- **Categoría:** CONTROL/CALIDAD · **Criticidad:** ALTA · **Ubicación:** app.js:1327-1375.
- **Salida:** 13 controles informativos/bloqueantes: nº mapeos cargados (0 → ERROR BLOQUEANTE), WMS Task distintas, únicas (0 → ERROR BLOQUEANTE), ambiguas, sin mapeo, volúmenes positivo total/UNICO/AMBIGUO/SIN MAPEO/SIN LOGIN, **volumen UNICO atribuible** (excluye IdNumericos ambiguos), **cobertura total** y **cobertura atribuible** con estados SIN DATOS/OK (≥0,9)/REVISAR (≥0,7)/ERROR BLOQUEANTE (<0,7).
- **Verificación:** `[T]` equivalencia (tabla 16); `[E]` smoke (tabla visible en Resultados).

#### F-030 · q07_Conciliacion (la consulta central)
- **Categoría:** PROCESAMIENTO · **Criticidad:** CRÍTICA · **Ubicación:** app.js:1389-1564 (Section1.m q19).
- **Proceso/Reglas `[C]`:** base = q01 (deepClone); M1 join 03 por (Fecha, Login); M2 join-ALL 14 por (Fecha, Login, Activity=ActividadSPEC) → renombra a VolumenMismaActividad*; M3 join 05 por (Fecha, IdNumericoNormalizado) → VolumenMismoNumeroPositivo; M4 join 10 por (Fecha, Login); M5 join 15 por (Fecha, Login, Activity); nulls→0 en 15 columnas numéricas; nulls→false en 3 booleanos; VolumenOtrasActividadesPositivo = max(0, TotalPositivo − MismaActividadPositivo); M6 NumActHR por (Fecha, Login): NumeroActividadesHR, **NumeroHRTaskDistintas**, HRTaskDistintas join " | ", HorasTotalesPersonaDia.
- **Clasificación (orden exacto de precedencia `[C]` app.js:1483-1495):** POSIBLE DUPLICIDAD → REVISION MANUAL - AMBIGUEDAD ID NUMERICO → DESCUADRE RECIPROCO EN LA MISMA ACTIVITY SPEC → VOLUMEN SIN HORAS EN OTRA ACTIVITY SPEC → VOLUMEN EN LA MISMA ACTIVITY SPEC → VOLUMEN EN OTRA ACTIVITY SPEC O SIN MAPEO → POSIBLE ERROR DE IDENTIFICACION O PREFIJO → SOLO REGISTROS CERO O AJUSTES → SIN EVIDENCIA DE ACTIVIDAD PRODUCTIVA → CASO NO DETERMINABLE.
- **NivelConfianza:** ALTA (duplicidad, descuadre, VSH otra, misma actividad) / MEDIA (otra activity, identificación, cero-ajustes, REVISION MANUAL*) / NO DETERMINABLE (resto).
- **Evidencia:** cadena de hechos con valores formateados; **Explicacion** y **AccionRecomendada** por diccionario fijo (textos literales en app.js:1528-1554); Materialidad por fila.
- **Verificación:** `[T]` equivalencia 14/14. **La función más protegida del proyecto.**

#### F-031 · q08_Validaciones
- **Categoría:** CONTROL · **Criticidad:** ALTA · **Ubicación:** app.js:1567-1589.
- **Salida:** 18 controles OK/ERROR/REVISAR/INFORMATIVO (conservación de horas, volumen neto/positivo/negativo antes-después de mapping, nº registros, duplicados por fuente, WMS Task sin mapeo/ambiguas, volumen sin login, logins sin volumen, multi HR Task persona+dia, colisiones IdNumerico).
- **Verificación:** `[T]` equivalencia (tabla 08); `[E]` smoke t4.

#### F-032 · REPORTE_CAMBIOS_HR (`generarReporteCambiosHR`)
- **Categoría:** PROCESAMIENTO/DECISIONES · **Criticidad:** CRÍTICA · **Ubicación:** app.js:1607-1816 (VBA GenerarReporteCambiosHR).
- **Proceso `[C]`:** para cada fila H: busca volumen en VM con **Pass 1 LOGIN EXACTO** (fechaOperativa? NO — usa Fecha del registro + LoginCanonico; índice fecha|login) y **Pass 2 MISMO NUMERO, DISTINTO PREFIJO** (solo si Pass 1 vacío; índice fecha|IdNumericoNormalizado); solo filas con VolumenPositivo>0; enriquece con datos de 07 (multi HR task, ambigüedad idnum).
- **Secciones (decisión exacta `[C]` app.js:1731-1786):**
  - Sin volumen encontrado → **"4. SIN VOLUMEN"** (REVISAR) + observación con extras multi-HR/ambigüedad.
  - Con volumen: por cada fila de volumen: `EstadoMapeoFinal≠UNICO` o TasksSPEC vacío o con " | " → **"5. WMS TASK SIN MAPPING"**; multi HR task → **"6. REVISION MANUAL - MULTIPLES HR TASK"**; ambigüedad idnum en modo pass-2 → **"7. REVISION MANUAL - AMBIGUEDAD ID NUMERICO"**; >1 TasksSPEC distintas (excluye las que contienen " | ", H-05/H-05b) → **"2. VARIAS TASKSPEC CON VOLUMEN"**; HR Task fichada == TasksSPEC → **"3. HR TASK CORRECTA"** (REQUIERE CAMBIO=NO); resto → **"1. CAMBIO HR TASK PROPUESTO"** (REQUIERE CAMBIO=SI).
  - Modo pass-2 añade a la observación "El volumen se ha asociado por coincidencia del numero de usuario."
- **Salida:** filas `crearPropuesta` con 20 columnas (SECCION…OBSERVACION) — la materia prima de la revisión (F-048+) y de las incidencias del histórico (F-078).
- **Casos límite:** 1 registro de horas con 3 tareas de volumen → 3 propuestas (secciones 2/3/1 mezcladas); persona/día con ambigüedad y multi-task simultáneos (precedencia: 5 > 6 > 7 > 2 > 3 > 1).
- **Verificación:** `[T]` equivalencia (REPORTE_CAMBIOS_HR tabla), regression_bugs (idempotencia); `[E]` smoke t3 (214 propuestas con fixtures reales). **Fuerte.**

#### F-033 · Materialidad (`calcularMaterialidad`)
- **Categoría:** CLASIFICACIÓN · **Criticidad:** MEDIA · **Ubicación:** app.js:1594-1602 (VBA líneas 126-138).
- **Fórmula exacta (umbrales por `<` estricto `[C]`):** `h < 0.0833333333 → 'MICRO < 5 MIN'`; `< 0.25 → 'BAJA < 15 MIN'`; `< 1 → 'MEDIA < 1 H'`; `< 4 → 'ALTA 1-4 H'`; `≥ 4 → 'CRITICA >= 4 H'`.
- **Casos límite documentados:** null/undefined/'string'→0→MICRO; **NaN→CRITICA** (divergencia VBA documentada); negativos→MICRO; exactamente en el umbral → tier superior.
- **Verificación:** `[T]` calcular_materialidad.test.js (23 casos). **Fuerte.**

---

### 4.3 ÁREA: FUNCIONES PURAS DE NORMALIZACIÓN (F-034 … F-040)

#### F-034 · fx_NormalizaTexto
- **Ubicación:** app.js:192-209 (Section1.m 17-25) · **Criticidad:** CRÍTICA.
- **Reglas `[C]`:** Date→ISO; number→String; boolean→'TRUE'/'FALSE'; **Text.Clean** elimina chars de control 0x00-0x1F y 0x7F (NO los sustituye por espacio); trim; vacío→null; UPPER; split/collapse de espacios (incluye NBSP colapsado por el trim de \s).
- **Nota de seguridad:** NO es frontera de seguridad — payloads XSS y fórmulas pasan intactos (documentado en test; defienden escapeHtml/escapeCsv).
- **Verificación:** `[T]` fx_normalizatexto.test.js (20 casos). Fuerte.

#### F-035 · fx_NormalizaLogin
- **Ubicación:** app.js:214-275 · **Criticidad:** CRÍTICA.
- **Salida:** 7 campos: LoginOriginal, LoginOriginalLimpio, **LoginCanonico** (= letras+dígitos si ambos existen; si no, el limpio), IdNumerico (= literal), IdNumericoLiteral, **IdNumericoNormalizado** (Number o BigInt si >15 dígitos, R-12; ceros a la izquierda preservados al normalizar quitando ceros superfluos), Prefijo (solo letras).
- **Reglas:** separadores eliminados: espacio, `-`, `.`, `_`, `/`, `\`.
- **Verificación:** `[T]` fx_normalizalogin.test.js (17 casos, incl. BigInt 19 dígitos). Fuerte.

#### F-036 · fx_Fecha
- **Ubicación:** app.js:307-348 · **Criticidad:** CRÍTICA.
- **Reglas `[C]`:** Date→date-only UTC; número→serial Excel base **1899-12-30** con floor; string: es-ES `d/M/yy(yyy)` con separadores `/ - .` (año <100 → 2000+), ISO `yyyy-M-d`, fallback `new Date(s)`+stripTime; inválido→null. Todo date-only UTC (sin zona horaria).
- **Divergencias documentadas:** `"12345"` (string numérico) NO se trata como serial → año 12345; -1 → 1899-12-29.
- **Verificación:** `[T]` fx_fecha.test.js (23 casos). Fuerte.

#### F-037 · numberFrom
- **Ubicación:** app.js:462-473 · **Criticidad:** ALTA.
- **Reglas `[C]`:** es-ES semántica: quita `.` (miles), cambia `,`→`.` decimal. Divergencias documentadas: `"12.34"→1234` (punto=miles); `"1,234.56"→1.23456` (malinterpretado); Date→null; boolean→null; NaN/Infinity pasan (documentado).
- **Verificación:** `[T]` number_from.test.js (21 casos). Fuerte.

#### F-038 · fx_Turno
- **Ubicación:** app.js:367-381 (MEJORA 1) · **Criticidad:** CRÍTICA.
- **Fórmula `[C]`:** minutos m: `360≤m<840→MAÑANA`; `840≤m<1320→TARDE`; resto (1320-1439 + 0-359)→`NOCHE`. **Lanza** Error si tipo inválido o m∉[0,1440). Cobertura 480/480/480 minutos sin huecos ni solapes (verificado por test exhaustivo).
- **Verificación:** `[T]` turnos.test.js (11 casos de límites + cobertura exhaustiva). **Fuerte.**

#### F-039 · fx_FechaOperativaTurno
- **Ubicación:** app.js:412-428 · **Criticidad:** CRÍTICA.
- **Fórmula:** hora < 06:00 → fecha −1 día (NOCHE cruza medianoche); ≥06:00 → misma fecha; hora null → fecha sin tocar (day-level).
- **Casos:** cruce fin de mes/año (tests); Date o minutos como entrada.
- **Verificación:** `[T]` turnos.test.js (11 casos). Fuerte.

#### F-040 · extraerHoraFichaje
- **Ubicación:** app.js:441-457 · **Criticidad:** ALTA.
- **Reglas `[C]`:** Date exactamente a medianoche UTC→null (day-level); Date con hora→minutos; serial entero→null; serial con fracción→`round(frac×1440)%1440` (0→null); strings→null.
- **Limitación documentada:** un fichaje real exactamente a las 00:00:00.000 es indistinguible de "sin hora".
- **Verificación:** `[T]` turnos.test.js (5 casos), filtro_turnos_real (day-level). Fuerte.

---

### 4.4 ÁREA: CLASIFICACIÓN DE ACTIVIDADES Y REPARTO DE TIEMPOS (F-041 … F-047)

#### F-041 · fx_ActividadAnalisis
- **Categoría:** CLASIFICACIÓN · **Criticidad:** CRÍTICA · **Ubicación:** app.js:1871-1897.
- **Enum:** `ACTIVIDADES_ANALISIS = [AUDITORIA AGV, AUDITORIA MANUAL, UBICACION AGV, UBICACION MANUAL, PICKING AGV, PICKING MANUAL, OTRA]`.
- **Reglas exactas (orden `[C]`):** normaliza la tarea (mayúsculas, acentos ÁÀ→A etc., sin controles, espacios colapsados); override de tarea con actividad válida manda; `REPARTO POR CUADRANTE AGV*` / `REPARTO POR SUPERCUADRANTE AGV*`→PICKING AGV; `PICKING ECOMMERCE A MATRICULA*` / `PICKING POR CUADRANTE GUIADO*` / `PICKING SIN PAPEL*`→PICKING MANUAL; `UBICACION*`→AGV si contiene "AGV"/"AUTOMATIZADA", si no MANUAL; `AUDITORIA*`→AGV si contiene "AGV", si no MANUAL; `PICKING LIBRE*`→PICKING MANUAL (decisión documentada, misma TASK_SPEC 20051); **todo lo demás→OTRA (sin productividad inventada)** — incluye las ambiguas reales del mapping (REPARTO A TIENDA AGV×, PICKING POR TIENDA GUIADO, PICKING DE DEVOLUCIÓN DE LOCALIZACIÓN, TRASPASOS AGV…, ver reports/MAPPING_AMBIGUITIES.md).
- **Verificación:** `[T]` actividad_analisis.test.js (11 casos). Fuerte.

#### F-042 · resolverProductividad (nivel ACTIVIDAD)
- **Ubicación:** app.js:1904-1914 · **Criticidad:** ALTA.
- **Fórmula:** OTRA→null; override de tarea con productividad>0 manda; luego `productividades[actividad]` del usuario; luego default PARAMS; valor inválido→null. (Nota v6.1.1: para el reparto real por TAREA usar F-043.)
- **Verificación:** `[T]` actividad_analisis (5 casos).

#### F-043 · resolverClasificacionTarea (nivel TASK_WMS)
- **Ubicación:** app.js:1934-1959 (v6.1.1) · **Criticidad:** CRÍTICA.
- **Fórmula de prioridad EXACTA:** 1) override TASK_WMS (actividad y productividad) → fuente `OVERRIDE TASK_WMS`; 2) productividad de la actividad editada por el usuario → fuente `PRODUCTIVIDAD ACTIVIDAD` (si ≠ default) o `DEFAULT`; 3) actividad productiva sin valor válido → `SIN PRODUCTIVIDAD` (anomalía); tarea OTRA→productividad null, fuente `OTRA`. **NUNCA se usa la productividad de otra tarea.**
- **Verificación:** `[T]` overrides_task.test.js (8 casos de prioridad). `[E]` overrides_v612 t5-t7. Fuerte.

#### F-044 · repartirTiempos (nivel ACTIVIDAD — legado v6.1, aún expuesto)
- **Ubicación:** app.js:1973-1998 · **Criticidad:** MEDIA.
- **Fórmula:** `HE = uds/productividad` (solo clasificables); `peso = HE/ΣHE`; `horasAsignadas = tiempoAnalizable × peso`; `productividadImplicita = uds/horasAsignadas`; conservación exacta (redondeo solo presentación).
- **Verificación:** `[T]` reparto_tiempos.test.js (12 casos).

#### F-045 · repartirTiemposPorTarea (nivel TASK_WMS — el real desde v6.1.1)
- **Ubicación:** app.js:2016-2040 · **Criticidad:** CRÍTICA.
- **Fórmulas idénticas a F-044 pero por tarea:** `HE_t = uds_t/prod_t`; `peso_t = HE_t/ΣHE`; `hAsignadas_t = horasAnalizables × peso_t`. OTRA y sin productividad → fuera del reparto (peso 0/null, HE null). Conservación <1e-9. Ejemplo verificado: 200 uds@100 (HE 2) + 400 uds@200 (HE 2) sobre 8 h → 4 h + 4 h.
- **Verificación:** `[T]` overrides_task (4), persona_dia (9), reparto_tiempos; `[E]` mejoras_v6 t5, overrides_v612 t5-t7. **Fuerte.**

#### F-046 · q17_PersonaDiaAnalitica
- **Categoría:** PROCESAMIENTO/ANALYTICS · **Criticidad:** CRÍTICA · **Ubicación:** app.js:2078-2257 (MEJORA 4).
- **Unidad:** PERSONA + FECHA_OPERATIVA (NO persona+tarea).
- **Proceso `[C]`:** 1) índices de VM por (fecha|login) y (fecha|idNum) y de VSH por (fecha|login); 2) agrupa H por (LoginCanonico, fechaOperativa): por registro calcula hora (F-040)→turno (F-038)→fechaOperativa (F-039); acumula horasFichadas=horasAnalizables, registros[] con hora/turno/horas/hrTask, Set turnos; 3) udsSinHoras informativo por grupo; 4) volumen: Pass 1 exacto → si vacío Pass 2 idNum (modoVolumen 'LOGIN EXACTO'/'MISMO NUMERO, DISTINTO PREFIJO'/null); 5) **agregación por TASK_WMS** (taskMap por tarea normalizada, conserva tasksSpec y cliente, v6.2); 6) por tarea `resolverClasificacionTarea` + `repartirTiemposPorTarea`; 7) agregación VISUAL por actividad (productividad null = "varias"); 8) turno agregado: 'SIN HORA' si solo sin hora; 'MIXTO' si >1 turno real; 9) desviacion = horasAnalizables − ΣHE.
- **Salida:** grupos con actividades[].tareas[] completos → entrada de F-078.
- **Verificación:** `[T]` persona_dia.test.js (9 casos: 2 tareas→1 grupo, 3 tareas reparto, clave login|fecha, varias fichadas, noche 02:15→día anterior, day-level→SIN HORA, OTRA fuera, desviación, fallback idNum). `[E]` mejoras_v6 t4-t5. **Fuerte.**

#### F-047 · Productividades de referencia (PARAMS + edición)
- **Categoría:** CONFIGURACIÓN · **Criticidad:** ALTA · **Ubicación:** app.js:63-70 (defaults NETAS uds/h: AUDITORIA AGV 35, AUDITORIA MANUAL 23, UBICACION MANUAL 260, UBICACION AGV 240, PICKING MANUAL 100, PICKING AGV 150), persistencia en `spec_productividades` (F-069).
- **Reglas:** son **medias de referencia**, no tiempos exactos (documentado); OTRA nunca recibe productividad; editables por el usuario y persistidas; snapshot guardado en cada histórico.
- **Verificación:** `[T]` actividad_analisis (contrato completo del mapa), mapping_persist (snapshot). `[E]` mejoras_v6/overrides.
---

### 4.5 ÁREA: REVISIÓN DE INCIDENCIAS (F-048 … F-060)

#### F-048 · Panel Revisar (agrupación persona/día)
- **Categoría:** REVISIÓN · **Criticidad:** CRÍTICA · **Ubicación:** ui.js:4481-4541 (renderReviewPanel), index.html panel-revisar (líneas 172-331).
- **Descripción/Objetivo:** transformar el REPORTE (a nivel registro de horas) en **tarjetas por persona y día** (la unidad de decisión real). Desde v6.1 una persona/día con 2 tareas WMS produce UNA tarjeta.
- **Proceso:** `getPersonaDiaRecords()` (ui.js:4412) toma los grupos de q17 (personaDiaRecords en memoria) y les añade las incidencias/decisiones; `renderReviewList` pinta tarjetas con: persona, login, fecha operativa + semana ISO, turno(s), nº incidencias, horas, estado de decisión, prioridad (F-050), KPIs mini.
- **Dependencias:** F-046, F-032. → **Alimenta a:** F-052-F-057, F-078.
- **Estados:** vacío (sin análisis) con mensaje; con datos; filtrado vacío (con aviso de filtro).
- **Verificación:** `[E]` smoke t5, mejoras_v6 t4 (1 card por persona/día con 2 tareas). Fuerte.

#### F-049 · Filtros de revisión
- **Categoría:** REVISIÓN · **Criticidad:** ALTA · **Ubicación:** ui.js:2336-2404 (getFilteredIncidents/getFilteredPersonDays), ui.js:4420-4479; select de turno en HTML.
- **Reglas:** filtro por sección del reporte, estado de decisión (PENDIENTE/ACEPTADA/RECHAZADA/MANTENIDA…), búsqueda libre de persona; **filtro de turno REAL desde v6.1.1**: usa `SPEC.filtrarRegistrosPorTurno` (turno agregado O cualquier fichaje del día en ese turno; 'SIN HORA' solo registros day-level; nunca repartido). Cuando el filtro de turno oculta registros SIN HORA y quedan visibles registros sin hora → aviso «⚠ N registros no contienen hora de fichaje…» (mejoras_v6: renderReviewList).
- **Verificación:** `[T]` filtro_turnos_real.test.js (10 casos). `[E]` overrides_v612 t1-t4 (límites 05:59/06:00/13:59/14:00/21:59/22:00/02:00 + aviso SIN HORA). **Fuerte.**

#### F-050 · Lista de tarjetas y prioridad
- **Ubicación:** ui.js:2305-2335 (incidentId/incidentPriority), ui.js:4542-4624 (renderReviewList) · **Criticidad:** MEDIA.
- **Reglas:** `incidentId = "ID REGISTRO@FILA ORIGEN"`; `incidentPriority` ordena por criticidad de sección (1 y 4 primero…); ordenación por fecha/prioridad; indicadores por sección.
- **Verificación:** `[E]` smoke t5; patrones_v62 t5 (orden personas). Faltan: unit de incidentPriority.

#### F-051 · Detalle persona/día
- **Categoría:** REVISIÓN · **Criticidad:** CRÍTICA · **Ubicación:** ui.js:4625-4788 (renderPersonDayDetail), HTML `#incident-detail`.
- **Contenido:** KPIs del día (horas fichadas/analizables, uds, desviación), **tabla "Fichajes del día"** (hora, turno, horas, HR Task por registro; mensaje explícito por registro sin hora), tabla **"Actividades y reparto"** por TASK_WMS (sub-filas: tarea, uds, productividad, HE, peso, horas asignadas, **Fuente**), y la lista de incidencias del día con sus secciones/propuestas/decisiones.
- **Reglas de conservación visible:** Σ horas asignadas = horas analizables (el test E2E lo comprueba).
- **Verificación:** `[E]` mejoras_v6 t4-t5, overrides_v612 t2/t5-t7 (lectura de `.pdd-task-row`). Fuerte.

#### F-052 · Aceptar propuesta
- **Categoría:** DECISIONES · **Criticidad:** CRÍTICA · **Ubicación:** ui.js:2612+ (handleIncidentAction 'aceptar'), registrarDecision ui.js:4834-4907.
- **Proceso:** aceptar la TASKSPEC propuesta → guarda `{decision:'aceptada', tareaFinal: propuesta, motivo, timestamp, usuario:'usuario_local', evidencia, seccion, idRegistro, persona, fecha, tareaOriginal, propuesta, nivelConfianza}` en `STATE.decisions[incidentId]` → push al undoStack `{id, prev: <decisión anterior o null>, timestamp}` → entrada de audit log (F-072) → persistencia (F-076) → sincronización con histórico (F-060) → refresh UI (tarjeta→COMPLETADA/aceptada).
- **Reglas:** si el usuario edita la tarea final (datalist de tareas conocidas), se guarda la editada; el motivo es opcional salvo… (el motivo es siempre opcional, validado por longitud).
- **Verificación:** `[E]` smoke t6, mejoras_v6 t6. Fuerte.

#### F-053 · Rechazar propuesta
- **Igual flujo que F-052 con `decision:'rechazada'` y tareaFinal = tareaOriginal (la fichada). · Verificación:** `[E]` smoke, undo_persist `[T]` (rechazar→undo).

#### F-054 · Mantener tarea actual
- **Igual flujo con `decision:'mantenida'`** (no cambiar la HR Task fichada aunque exista propuesta). Distingue de "rechazar" en semántica de auditoría (el usuario declara expresamente que la fichada es correcta).
- **Verificación:** `[T]` undo_persist (mantener→undo); `[E]` mejoras_v6 t6.

#### F-055 · Motivo y nivel de confianza
- **Ubicación:** ui.js:2556-2600 (obtenerMotivoInput/getConfianza/generarRazonPropuesta), getAvailableTasks (datalist). · **Criticidad:** MEDIA.
- **Reglas:** NivelConfianza viene del motor (q07, F-030); la razón de la propuesta se genera del texto de OBSERVACION del reporte; el motivo del usuario se persiste y viaja al audit log y exports.

#### F-056 · UNDO de decisión (núcleo puro + UI)
- **Categoría:** DECISIONES · **Criticidad:** ALTA · **Ubicación:** app.js:2428-2459 (`undoFindLatestIndex`/`undoApply` — puro), ui.js:4908-4953 (undoDecision UI).
- **Reglas exactas `[C]`:** el undo busca la entrada **MÁS RECIENTE** del id en el undoStack (corrección del bug original findIndex=primera/la más antigua); aplica `prev` (restaura el estado anterior COMPLETO, copia) o elimina la decisión si prev=null; **no muta inputs** (devuelve mapas nuevos); la entrada de undo consumida sale del stack; se registra una nueva entrada de audit log (`undo`) con estadoAnterior/estadoPosterior; se persiste y refresca histórico.
- **Casos límite:** acciones consecutivas sobre el mismo id (aceptar→mantener→undo → restaura 'mantenida', NO el estado inicial; segundo undo → pendiente); id inexistente → `{ok:false}` sin efectos.
- **Qué NO se puede deshacer:** la carga de archivos, el análisis, las ediciones de mapping, los overrides, las exportaciones, el vaciado del audit log.
- **Verificación:** `[T]` undo_persist.test.js (11 casos). `[E]` smoke t7, mejoras_v6 t6 (doble undo + persistencia undoStack). **Fuerte.**

#### F-057 · UNDO última acción (`undoLastAction`)
- **Ubicación:** ui.js:4954-4963 · **Criticidad:** MEDIA. Deshace la última entrada del stack (cualquier id). Botón visible en Auditoría/Revisar. `[E]` smoke t7 (auditLog crece).

#### F-058 · Auto-avance
- **Categoría:** UI · **Criticidad:** BAJA · **Ubicación:** ui.js:2780-2790, checkbox `#auto-advance-toggle`, clave `spec_auto_advance`.
- **Reglas:** persistido como string 'true'/'false'; default false; al aceptar/rechazar salta a la siguiente tarjeta pendiente.

#### F-059 · Navegación y atajos en revisión
- **Criticidad:** BAJA · **Ubicación:** ui.js:4794-4833 (navigateIncident/selectIncident), setupKeyboardShortcuts ui.js:2882-2920.
- **Atajos documentados en Ayuda:** flechas para navegar tarjetas, teclas de acción rápida; focus management. `[E]` a11y t5 (teclado en tablist/dropzone/detalle+Escape).

#### F-060 · Sincronización decisión → histórico (`sincronizarDecisionesEnRecords`)
- **Categoría:** PERSISTENCIA · **Criticidad:** ALTA · **Ubicación:** ui.js:4276-4289.
- **Reglas:** copia las decisiones actuales en `STATE.personaDiaRecords[].incidencias[].decision` y recalcula el `decision` del record (`estadoDecisionRecord` ui.js:4402: SIN INCIDENCIAS / PENDIENTE / EN REVISIÓN (mixto) / COMPLETADA); encola persistencia (F-080).
- **Verificación:** `[E]` patrones_v62 (decisiones visibles en Patrones tras decidir).

---

### 4.6 ÁREA: PESTAÑA MAPPING (F-061 … F-068)

#### F-061 · Visualización del mapping
- **Categoría:** REVISIÓN · **Criticidad:** ALTA · **Ubicación:** ui.js:3043-3210 (initMappingData/populateMappingFilters/renderMappingTable/updateMappingStats).
- **Salida:** tabla de las 167 filas (fixture real) con las 8 columnas; stats: nº entradas, duplicados, ambigüedades; **badge de hash** (`Hash: <FNV>` recalculado con `SPEC.calcularMappingHash`).
- **Reglas:** `UI.mappingOriginal` (snapshot de solo lectura) vs `UI.mappingCurrent` (copia editable); los cambios NO afectan al análisis hasta reprocesar.
- **Verificación:** `[E]` mapping.spec.js (167 entradas + badge). Fuerte.

#### F-062 · Búsqueda y filtros de mapping
- **Ubicación:** ui.js:3086-3125 (populateMappingFilters), renderMappingTable con `UI.mappingFilter`. · **Criticidad:** BAJA. Filtros por Customer y Task WMS + búsqueda exacta. `[E]` mapping.spec (búsqueda exacta=1 resultado, sin resultados).

#### F-063 · Editor CRUD de mapping
- **Categoría:** DECISIONES/PERSISTENCIA · **Criticidad:** ALTA · **Ubicación:** ui.js:3267-3358 (openMappingEditor/closeMappingEditor/saveMappingEdit/deleteMappingEntry), index.html modal `#mapping-edit-modal`.
- **Proceso:** editar fila (modal precargado, guarda en mappingCurrent + recalcula hash + audit `mapping_update`) / crear (audit `mapping_create`) / eliminar (confirm del navegador + audit `mapping_delete`). Cada cambio persiste decisiones y deja trazabilidad; la edición NO toca el archivo original.
- **Verificación:** `[E]` mapping.spec.js (CRUD completo + integridad de hash chain tras CRUD). Fuerte.

#### F-064 · Duplicados y ambigüedades de mapping
- **Criticidad:** MEDIA · **Ubicación:** ui.js:3211-3266 (countDuplicates/highlightDuplicates/countAmbiguities/highlightAmbiguities).
- **Reglas:** duplicados = misma (SAP_CODE, CUSTOMER, TASK_WMS) en ≥2 filas; ambigüedad = mismo grupo con >1 TASK_SPEC; badges + resaltado visual `.duplicate`.
- **Contexto documentado:** las 4 ambigüedades reales conocidas están en reports/MAPPING_AMBIGUITIES.md (REPARTO A TIENDA AGV ×3 marca + Ubicación de SKU duchando) — clasificadas OTRA por el motor, resolución por override del usuario.
- **Verificación:** `[E]` mapping.spec (badges + resaltado). `[T]` analytics_dataquality (§30/§31).

#### F-065 · Export mapping XLSX
- **Ubicación:** ui.js:3394-3407 (`exportMappingXlsx`) → `mapping_export_<ts>.xlsx`. · **Criticidad:** BAJA. Exporta `UI.mappingCurrent`. `[E]` parcial (existence en export panel).

#### F-066 · Persistencia versionada de mapping (IndexedDB)
- **Categoría:** PERSISTENCIA · **Criticidad:** CRÍTICA · **Ubicación:** ui.js:3850-3924 (idbHistoryOpen/guardarMappingVersion/cargarUltimoMapping), store `spec_history_db.mappings` keyPath `version`.
- **Reglas `[C]`:** cada importación guarda `{version: última+1, nombre, fechaImportacion, timestamp, hash: SHA-256 (crypto.subtle, obligatorio — rechaza si no disponible), hashAlgoritmo:'SHA-256', nRows, rows}`; las versiones se acumulan (nunca se borran); `cargarUltimoMapping(conRows)` devuelve la mayor versión.
- **Verificación:** `[T]` mapping_persist.test.js (8 casos: SHA-256 determinista, sensible a cambios, independiente del orden de propiedades, solo 8 columnas estructurales). `[E]` mejoras_v6 t2. **Fuerte.**

#### F-067 · Auto-carga del último mapping
- **Categoría:** PERSISTENCIA · **Criticidad:** ALTA · **Ubicación:** ui.js:3926-3977 (reconstruirMappingEntry/aplicarMappingEntry/cargarMappingPersistente).
- **Proceso:** al abrir la app, lee la última versión de `mappings`, **reconstruye un File sintético** (`new File([...], nombre)`) con el workbook regenerado desde las `rows` persistidas y lo inyecta en `STATE.archivos.mapping` → el motor/worker lo tratan como un mapping cargado manualmente; tarjeta "Mapping activo" visible.
- **Casos límite:** base vacía (sin mapping → estado vacío con mensaje); hash SHA-256 verificado contra el guardado.
- **Verificación:** `[E]` mejoras_v6 t2 (recuperación tras cerrar/abrir). Fuerte.

#### F-068 · Diálogo de sustitución de mapping + tarjeta activa
- **Criticidad:** ALTA · **Ubicación:** ui.js:4049-4085 (dialogoCambiarMapping con confirmación old-vs-new: nombres, hashes, nº filas), ui.js:3978-4048 (renderMappingActivoCard en la pestaña de carga).
- **Reglas:** sustituir un mapping existente requiere confirmación explícita; tras confirmar se guarda la nueva versión (F-066) y el usuario debe **reprocesar** para que el análisis la use; los históricos anteriores conservan SU hash (no se reescriben).
- **Verificación:** `[E]` mejoras_v6 t3 (hash v2 en TODOS los records tras reprocesar). `[T]` mapping_persist (snapshot inmutable).

---

### 4.7 ÁREA: OVERRIDES DE PRODUCTIVIDAD (F-069 … F-071)

#### F-069 · Editor de productividades por ACTIVIDAD
- **Categoría:** CONFIGURACIÓN · **Criticidad:** ALTA · **Ubicación:** ui.js:3511-3629 (cargarProductividades/guardarProductividades/renderProductividadesEditor/setupProductividadesEditor), clave `spec_productividades`.
- **Reglas:** 6 actividades editables; validación isFinite>0; persistido como mapa; botón reset → defaults PARAMS; cargar con fusión de defaults.
- **Verificación:** `[E]` overrides_v612 t5 (editar y ver efecto). `[T]` mapeo contrato en actividad_analisis.

#### F-070 · PRODUCTIVIDAD POR TAREA (overrides TASK_WMS)
- **Categoría:** CONFIGURACIÓN · **Criticidad:** CRÍTICA · **Ubicación:** ui.js:3630-3848 (obtenerTareasConocidas/renderTaskProdEditor/guardarTaskOverride/resetTaskOverride/setupTaskProdEditor), clave `spec_task_overrides`.
- **Descripción/Objetivo:** resolver ambigüedades OTRA y afinar productividades por tarea concreta (la palanca de decisión del usuario sobre el reparto).
- **Proceso/Reglas:** tabla TASK_WMS | Actividad | Productividad | **Fuente** | Acción; datalist con tareas conocidas (mapping + volumen + overrides existentes); validación: productividad>0 si actividad productiva, OTRA→cualquier valor (sin productividad); Editar/Resetear por fila; persistencia `{tareaNormalizada: {actividad, productividad, taskWmsDisplay, updatedAt}}`; reset funcional (borra la clave del mapa).
- **Casos límite:** override OTRA→PICKING AGV 150 hace que la tarea entre al reparto; dos tareas de la misma actividad con productividades distintas NO se mezclan (F-045).
- **Verificación:** `[T]` overrides_task.test.js (17). `[E]` overrides_v612 t5-t7. **Fuerte.**

#### F-071 · Aplicar overrides y reprocesar (`aplicarOverridesYRecalcular`)
- **Criticidad:** CRÍTICA · **Ubicación:** ui.js:3752-3763.
- **Proceso:** al guardar un override → `recomputarPersonaDia` (F-083) con las productividades/overrides actuales → regenera personaDiaRecords con fingerprint v2 → persistencia versionada (F-080) → toasts; el REPORTE y Q01–Q16 no se recalculan (no les afectan los overrides — solo q17/histórico).
- **Regla de versionado:** cambiar un override cambia `overrideVersion` ⇒ distinto fingerprint ⇒ **nueva versión** del histórico con previousVersions (inmutabilidad).
- **Verificación:** `[T]` overrides_task (2 casos históricos+fingerprint). `[E]` overrides_v612 t8, patrones_v62 t13. **Fuerte.**

---

### 4.8 ÁREA: DECISIONES Y AUDITORÍA (F-072 … F-077)

#### F-072 · Registro de decisiones con audit log encadenado
- **Categoría:** SEGURIDAD/AUDITORÍA · **Criticidad:** CRÍTICA · **Ubicación:** ui.js:4834-4907 (registrarDecision), ui.js:3359-3393 (logMappingChange para CRUD mapping).
- **Entrada de audit log `[C]`:** `{timestamp, action ('decision_accept'/'decision_reject'/'decision_keep'/'undo'/'mapping_create'/'mapping_update'/'mapping_delete'/'mapping_import'/'bulk…'…), id, idRegistro, persona, seccion, tareaOriginal, propuesta, tareaFinal, motivo, nivelConfianza, sessionId, appVersion, mappingHash, schemaVersion, estadoAnterior, estadoPosterior, prevHash, entryHash}`.
- **Verificación:** `[E]` smoke t6-t7, mapping.spec (chain íntegra tras CRUD). Fuerte.

#### F-073 · Cálculo de entryHash (SHA-256 estricto)
- **Criticidad:** CRÍTICA · **Ubicación:** app.js:2532-2557.
- **Reglas `[C]` (P12-cierre):** SHA-256 sobre JSON {prev, ts, action, id, idRegistro, persona, seccion, tareaOriginal, propuesta, tareaFinal, motivo, nivelConfianza, sessionId, mappingHash, appVersion}; **NO hay fallback FNV**: sin `crypto.subtle` (contexto inseguro) RECHAZA → la entrada se marca `entryHash=null, integrity:'INSECURE_CONTEXT'` (nunca se afirman propiedades criptográficas falsas).
- **Verificación:** `[T]` audit_log_chain.test.js (5 casos del hash: formato 64 hex, determinista, avalanche, sensible a prevHash, **sin fallback FNV**). **Fuerte.**

#### F-074 · Verificación de la cadena (`verificarAuditLogChain`)
- **Criticidad:** CRÍTICA · **Ubicación:** app.js:2570-2607.
- **Reglas de verificación ESTRICTA `[C]`:** cadena vacía→ok; entrada sin entryHash→`missing_entryHash`; prevHash ausente en no-génesis→`missing_prevHash`; prevHash no nulo en génesis→`invalid_genesis_prevHash`; prevHash≠entryHash anterior→`broken_chain_prevHash`; recálculo≠guardado→`entryHash_mismatch`; excepción→`hash_computation_failed`. Devuelve `{ok, brokenAt, expectedHash, actualHash, reason}`.
- **Los 6 escenarios de manipulación** (modificada/eliminada/entryHash borrado/prevHash falsificado/orden alterado/invertida) están cubiertos por 22 tests.
- **Verificación:** `[T]` audit_log_chain (escenarios 1-6 completos). **Fuerte.**

#### F-075 · Panel Auditoría
- **Criticidad:** MEDIA · **Ubicación:** ui.js:2797-2880 (renderAuditoriaPanel/setupAuditoriaTab), index.html panel-auditoria.
- **Salida:** tabla cronológica de entradas (acción, persona, tarea original→final, motivo, hash truncado), estado de la cadena (válida/rota con motivo y posición), export CSV (F-109), vaciado con confirmación, botón UNDO última acción (F-057).
- **Verificación:** `[E]` smoke t6-t7; standalone (decisión con génesis prevHash null).

#### F-076 · Persistencia de decisiones (localStorage + backup IndexedDB)
- **Categoría:** PERSISTENCIA · **Criticidad:** CRÍTICA · **Ubicación:** ui.js:4964-4988 (persistDecisions), ui.js:2639-2737 (idbOpen/idbBackupDecisions).
- **Estructura `spec_decisions` `[C]`:** `{decisions: {incidentId: {…}}, auditLog: [], undoStack: [], savedAt, appVersion, schemaVersion, mappingHash, sessionId}`; el backup IndexedDB `spec_decisions_db.decisions` (keyPath sessionId, índice savedAt) guarda `{sessionId, decisions, auditLog, savedAt, appVersion, mappingHash}`.
- **Reglas:** se escribe en CADA decisión/undo/cambio de mapping; si localStorage falla (quota) intenta el backup; el backup sobrescribe por sessionId (los anteriores se acumulan sin purga).
- **Verificación:** `[E]` indexeddb.spec.js t1 (ciclo completo con recuperación desde IndexedDB tras borrar localStorage). `[T]` persistencia forma de entrada (undo_persist último test).

#### F-077 · Restauración de decisiones
- **Criticidad:** ALTA · **Ubicación:** ui.js:4989-5034 (restoreDecisions).
- **Proceso:** al init: leer `spec_decisions`; si vacío → `idbRestoreDecisions()` (cursor inverso por savedAt → el registro MÁS RECIENTE); revive el estado (decisions, auditLog, undoStack); **verifica la cadena solo en la rama de localStorage** (discrepancia D-006: la rama IndexedDB no re-verifica).
- **Verificación:** `[E]` indexeddb t1. Faltan: test de restauración desde IDB con cadena manipulada (ver D-006).

---

### 4.9 ÁREA: HISTÓRICO PERSON_DAILY_RECORD (F-078 … F-083)

#### F-078 · `generarPersonDailyRecords`
- **Categoría:** HISTÓRICO · **Criticidad:** CRÍTICA · **Ubicación:** app.js:2284-2416.
- **Salida:** array de records con la estructura completa de §7.4 (key `login|fechaOperativaISO`).
- **Reglas clave `[C]`:** incidencias vinculadas por `ID REGISTRO → grupo` vía `idRegToGrupo`; **horasConIncidencia con dedup por registro de horas** (máximo por idReg — una fila que genera 3 propuestas de sección 2 cuenta UNA vez); `decision` inicial: 'SIN INCIDENCIAS' o 'PENDIENTE'; metadatos: mappingHash, mappingVersion, **snapshot de productividades y taskOverrides usados**, productivityVersion/overrideVersion (FNV de la config), appVersion, sessionId; `version:1`, `previousVersions:[]`.
- **Verificación:** `[T]` persona_dia.test.js (6 casos de estructura/clave/immutabilidad/semana ISO validada contra Python isocalendar), person_daily_v62 (5), v63_correcciones (6 fingerprint). **Fuerte.**

#### F-079 · dataFingerprint v2 (identidad datos+config)
- **Criticidad:** CRÍTICA · **Ubicación:** app.js:2396-2414.
- **Fórmula EXACTA `[C]`:** `fingerprint = fnv1aStr(JSON.stringify([login, fechaOperativaISO, horasAnalizables, udsTotales, actividades[[actividad, uds, productividad, tareas[[taskWms, actividad, uds, productividad]]]], incidencias[[seccion, horasAfectadas, tareaOriginal, propuesta]], mappingHash, productivityVersion, overrideVersion, appVersion, SchemaVersion]))`; `fingerprintVersion: 2`; `datasetFingerprint` = alias.
- **Semántica:** mismos datos + misma configuración → mismo fingerprint (idempotente); CUALQUIER cambio de mapping/productividades/overrides/appVersion → fingerprint distinto → nueva versión (no colisión). Migración: históricos v6.1/v6.2 (fp sin config) se versionan UNA vez al reprocesar (documentado en HISTORICAL_ANALYTICS_MODEL.md §fingerprint).
- **Verificación:** `[T]` v63_correcciones (6 casos), overrides_task (idempotencia), person_daily_v62. `[E]` patrones_v62 t12-t13. **Fuerte.**

#### F-080 · Persistencia versionada en IndexedDB (`persistirPersonDailyRecords`)
- **Criticidad:** CRÍTICA · **Ubicación:** ui.js:4294-4362, store `spec_history_db.person_daily_records` keyPath `key`, índices login/fechaOperativaISO/semana/mes.
- **Algoritmo de upsert `[C]`:** por cada record: `get(key)` → no existe → `put` versión 1; existe y **fingerprint igual** → put conservando `createdAt` y `previousVersions` (refresca decisiones); existe y **fingerprint distinto** → `version+1`, push del núcleo compacto previo en `previousVersions` (**cap 10**, ui.js:4331), `put`. Serialización de escrituras por cadena de promesas (`_persistChain`) para evitar carreras; invalida caché `UI.patronesRecords`.
- **Verificación:** `[T]` mapping_persist (restauración snapshot), overrides_task (§14). `[E]` patrones_v62 t12-t13, overrides_v612 t8. **Fuerte.**

#### F-081 · Carga de históricos (`cargarTodosRecords`)
- **Criticidad:** ALTA · **Ubicación:** ui.js:4366-4399. `getAll()` + fusión con los de memoria por key (prioridad IDB) + revivir `fechaOperativa` como Date. Consumido por `renderPatronesPanel` (ui.js:5164). `[E]` patrones_v62 t3-t4.

#### F-082 · previousVersions (trazabilidad, cap 10)
- **Criticidad:** ALTA · **Ubicación:** ui.js:4326-4335. Núcleo compacto por versión: `{version, updatedAt, mappingHash, productividades, horasAnalizables, udsTotales, desviacion, actividades, incidencias}`. Nunca se borran (solo cap 10 FIFO). `[T]` mapping_persist; `[E]` overrides_v612 t8.

#### F-083 · `recomputarPersonaDia`
- **Criticidad:** CRÍTICA · **Ubicación:** ui.js:4246-4275.
- **Proceso:** recalcula q17 + generarPersonDailyRecords con las productividades/overrides ACTUALES del usuario (los del análisis de arranque van con defaults) → sustituye `STATE.personaDiaRecords` → sincroniza decisiones → persiste versionado. Se invoca: post-análisis, tras cambiar overrides (F-071), tras cambiar productividades.
- **Regla:** no toca Q01–Q16 ni REPORTE (equivalencia intacta).
- **Verificación:** `[E]` mejoras_v6 t6, overrides_v612 t8 (versión ≥2 con previousVersions). **Fuerte.**
---

### 4.10 ÁREA: PATRONES / ANALYTICS (F-084 … F-099)

#### F-084 · Panel Patrones y snapshot memoizada
- **Categoría:** ANALYTICS · **Criticidad:** ALTA · **Ubicación:** ui.js:5079-5172 (patronesSnapshot/patronesStampRecords/renderPatronesPanel), ui.js:6311-6393 (setupPatronesTab), index.html:496-661.
- **Proceso `[C]`:** al abrir Patrones (spinner `pat-loading`): `cargarTodosRecords` (si caché invalidada) → `normalizarRecords` (defensivo: revive legacy v6.1) → filtro global (F-085) → `patronesSnapshot()` calcula TODA la capa analítica (kpis, comp, personas+tendencias, tareas+tendencias+fichaje, actividades+turnos, matriz+recurrencias, daily/semanal/mensual, 3 paretos, alertas, top5, dq, mq) → memo por firma JSON de filtros+config+stamp (§53) → render de la vista activa de las 8.
- **Estados:** vacío unificado (`pat-empty`), loading, con datos, filtro sin resultados (estado vacío por vista).
- **Verificación:** `[E]` patrones_v62 t1-t4, v63 V4/V6. `[T]` capa completa vía analytics_* (136 tests). Fuerte.

#### F-085 · Filtros globales de Patrones (11 dimensiones)
- **Criticidad:** ALTA · **Ubicación:** ui.js:5036-5078 (filtrarPatronesRecords), ui.js:5877-5900 (poblarFiltrosDinamicos), index.html filtros en 3 fieldsets.
- **Dimensiones `[C]`:** fecha desde/hasta, persona (subcadena login O nombre, case-insensitive), turno (via `SPEC.filtrarRegistrosPorTurno` — MIXTO aparece en cada turno trabajado), actividad (alguna tarea del record), decisión, semana ISO (exacta, case-insensitive), mes, TASK_WMS (subcadena), cliente (subcadena en tareas O incidencias), mappingHash (select con los hashes presentes). Intersección AND. `dimensionesDisponibles` poblado dinámicamente.
- **Verificación:** `[T]` analytics_core (8 casos de filtros). `[E]` patrones_v62 t14 (filtros combinados: NOCHE→1, RECUR→5, EMPEORA+NOCHE→0/vacío, OTRA→1). **Fuerte.**

#### F-086 · ⚙ CONFIGURACIÓN ESTADÍSTICA
- **Categoría:** CONFIGURACIÓN/PERSISTENCIA · **Criticidad:** ALTA · **Ubicación:** analytics/analyticsCore.js:21-115 (DEFAULT_CONFIG/loadConfig/saveConfig/resetConfig, LS `spec_stat_config_v1`), ui.js:6021-6066 (renderStatConfig/setupStatConfig), index.html `#stat-config` (details/summary).
- **Los 24 parámetros con defaults `[C]`:** minDiasComparar 3 · minObservaciones 3 · umbralCambioPP 5 · rachaDias 3 · recurrenciaHabitual 5 · recurrenciaRecurrente 4 · ventanaMediaMovil 7 · ventanaRollingLarga 28 · repeticionesConfusion 3 · umbralTurnoPP 10 · otraUdsMinimas 100 · impactoHorasAltas 4 · semaforoBueno 10 · semaforoNormal 25 · semaforoAtencion 50 · semaforoMinDias 3 · pesoFrecuencia 20 · pesoTasa 20 · pesoHoras 20 · pesoRecurrencia 15 · pesoTendencia 15 · pesoPersonas 10 · prioridadAlta 60 · prioridadMedia 35.
- **Reglas:** loadConfig fusiona con defaults e ignora claves desconocidas/no finitas (JSON corrupto → defaults sin lanzar); saveConfig persiste; resetConfig borra la clave.
- **Verificación:** `[T]` analytics_core (5 casos). `[E]` v63 (persistencia implícita). Fuerte.

#### F-087 · Vista RESUMEN
- **Criticidad:** ALTA · **Ubicación:** ui.js:5226-5355 (renderKpisResumen/renderFocosResumen + miniLista).
- **Contenido (jerarquía v6.3 `[C]`):** 4 KPIs primarios «Calidad del período» (Personas con error, % persona-día con error, % horas afectadas, incidencias) + «Impacto y alcance» (horas analizables, personas analizadas, días, uds OTRA…) con tooltips; **evolución comparada** (modo mitades o manual con rangos SIEMPRE visibles); **TOP 5 prioridades con desglose**; **alertas** (A1-A11) con severidad; secciones «quién/qué/dónde» (mini-listas: top personas, top tareas, turnos).
- **Regla:** «Dónde poner el ojo» es el protagonista (jerarquía visual: TOP5+alertas arriba, KPIs de contexto).
- **Verificación:** `[E]` patrones_v62 t2 (14 records→KPIs), t10 (comparación), t11 (alertas+top5). `[T]` v63 kpisBase.

#### F-088 · Vista PERSONAS (§7-§9)
- **Criticidad:** ALTA · **Ubicación:** analytics/personAnalytics.js:31-116 + ui.js:5398-5462.
- **Métricas por persona:** días, díasConError, **tasaError/pctDiasConError**, incidencias, horasAfectadas, pctHorasAfectadas, cambiosTarea, erroresAsignacion, **maxRacha** (consecutivos; huecos rompen), muestraPequena (<minObservaciones), **semáforo** (0→MUY BUENO, ≤10 BUENO, ≤25 NORMAL, ≤50 ATENCIÓN, >50 CRÍTICO; <semaforoMinDias→MUESTRA PEQUEÑA), turnos, otraUds.
- **Principio §8:** NO castigar por más días: frecuencia+tasa+impacto SIEMPRE juntas; muestra pequeña excluida de extremos de ranking pero visible.
- **Verificación:** `[T]` analytics_person (14 casos). `[E]` patrones_v62 t5 (RECUR 5/5, racha 4, CRÍTICO; MEJORA→ATENCIÓN). **Fuerte.**

#### F-089 · Perfil de persona (drill-down §34)
- **Criticidad:** MEDIA · **Ubicación:** personAnalytics (perfilPersona), ui.js:5901-6020 (renderPatronesProfile).
- **Salida:** stats completas, evolución diaria, tareas con error, recurrencias; persona inexistente→null (guard). Navegación desde la fila de ranking. `[E]` patrones_v62 t5.

#### F-090 · Vista TAREAS (§10-§11, §20-§21)
- **Criticidad:** ALTA · **Ubicación:** analytics/taskAnalytics.js + ui.js:5463-5531.
- **Dos espacios SEPARADOS:** 1) **TASK_WMS** (desde el volumen): oportunidades = persona-día con volumen de esa tarea; **errores imputados SOLO a la tarea afectada** (via `wmsTask` de la incidencia — la otra tarea del mismo día NO recibe el error §11); dedup de horas por ID REGISTRO; uds, personasN, diasN; **pctOportunidadesConError** (acotada [0,100], etiqueta "% oport. con error"), **incidenciasPorOportunidad** (ratio sin cota, etiqueta "Inc./oport."); muestra pequeña. 2) **Tareas fichadas / HR Task** (desde los fichajes): fichajes, cambios, correctas, **propuestaHabitual** (solo si propuesta única), tasaCambio, **pctFichajesConCambio**, propuestasPorFichaje.
- **Tendencia por tarea (§20/§21):** deltaPP de la tasa acotada entre mitades, con evidencia (suficiente solo si ambas mitades ≥minDiasComparar); SIN EVIDENCIA si no.
- **Verificación:** `[T]` analytics_task (11) + v63 (5 de tasas). `[E]` patrones_v62 t6 (PICKING SIN PAPEL 12/12 100%; ECOMMERCE 0 imputados; OTRA 300 uds visible). **Fuerte.**

#### F-091 · Vista ACTIVIDADES + turnos (§27-§29, §36)
- **Criticidad:** ALTA · **Ubicación:** analytics/activityAnalytics.js + ui.js:5532-5611.
- **Reglas:** orden canónico 7 actividades + **OTRA siempre visible con su volumen** (§29) + sección turnos con **SIN HORA separado** (nunca repartido entre turnos) y pesoRelativo; tendencia por turno con mínimo de registros; perfil de actividad (tareas/tendencia/distribución). `[T]` analytics_activity (8). `[E]` patrones_v62 t7.

#### F-092 · Vista ERRORES (matriz, heatmap, recurrentes)
- **Criticidad:** ALTA · **Ubicación:** analytics/confusionAnalytics.js + ui.js:5612-5678.
- **Matriz de confusión (§12):** pares **tareaOriginal → propuesta** de incidencias de error; propuestas múltiples con " | " generan una celda por destino; casos/personas/días/horas/wmsTasks por celda; **la sección 2 NO entra** (correcta indeterminada); horas dedup por registro+destino. **Heatmap** (§13): tabla cruzada con intensidad (SVG). **Recurrentes (§22):** agrupados por persona+pareja con días/casos/horas/turnos y persistencia **AISLADO (1 día) / RECURRENTE (2-4) / HABITUAL (≥5)**, umbrales configurables (§23).
- **Verificación:** `[T]` analytics_confusion (10). `[E]` patrones_v62 t8 (20051→20052 + HABITUAL + heatmap svg). **Fuerte.**

#### F-093 · Vista EVOLUCIÓN (§14-§19, §47)
- **Criticidad:** ALTA · **Ubicación:** analytics/trendAnalytics.js + ui.js:5679-5770 (renderEvolucionView), gráficos evolSvgChart/patLineChart ui.js:6138-6222.
- **Series:** diaria (registros, personas, conError, incidencias, errores, erroresAsignacion, horas, %persona-día error, %horas afectadas); **MM7 SOLO desde el 7º punto** (ventana completa, null antes — configurable); **rolling 7/28 sobre los últimos N días CON datos** (ventana completa de N observados, tramo desde/hasta y diasConDatos explícitos — **nunca rellena ceros**); **cobertura**: diasSinDatosEnRango contabilizado entre fechas; buckets semana ISO / mes con Δ frente al anterior (primera → null); matriz frecuencia×impacto por medianas del conjunto.
- **Gráficos:** línea con serie+MM, desglose por fechas, granularidad seleccionable (día/semana/mes).
- **Verificación:** `[T]` analytics_trend (9) + v63 (3 rolling sin ceros). `[E]` patrones_v62 t9, v63 V3 (cobertura calendario). **Fuerte.**

#### F-094 · Comparación de periodos A/B (§17-§18, v6.3 FASE 8)
- **Criticidad:** ALTA · **Ubicación:** analyticsCore.js:426-573 (partirPorMitades/compararPeriodos/compararPeriodosExplicitos/compararMitades/etiquetaComparacion), ui.js (snapshot + renderEvolucionView), index.html `#evol-comp-controls` (modo + 4 fechas + reset).
- **Fórmulas:** mitades = fechas únicas ordenadas, `mitad = ceil(n/2)` (A=primeras, B=resto); manual = rangos A/B propios; comparación: deltas absolutos y relativos (sin base → null, no se inventa %) y **puntos porcentuales (pp)** para tasas; etiqueta MEJORA (Δpp < −umbral) / EMPEORA (> +umbral) / SIN CAMBIO; **evidencia por periodo** (≥minDiasComparar días CON DATOS cada uno; si no → aviso «Evidencia insuficiente»); **rangos SIEMPRE visibles** («A = fecha→fecha (N día(s) con datos)»).
- **Verificación:** `[T]` analytics_core (4), v63 (4). `[E]` v63 V1 (manual con rangos visibles + evidencia insuficiente + reset). **Fuerte.**

#### F-095 · Vista PARETO (§24)
- **Criticidad:** MEDIA · **Ubicación:** analytics/paretoAnalytics.js + ui.js:5771-5816.
- **Reglas:** orden desc + % acumulado + nPara80; **la regla 80/20 SOLO se afirma si se cumple de verdad** (pctElementos80 ≤20 y pctAcumulado ≥80); métrica nombrada (errores / horas); banner jerárquico v6.3 («Regla 80/20 NO cumplida» cuando procede); wrappers para tareas/personas/actividades; empates deterministas. `[T]` analytics_pareto (5). `[E]` v63 V7, patrones_v62 t8 (verificación con datos reales).

#### F-096 · Vista CALIDAD DE DATOS (§49-§50)
- **Criticidad:** ALTA · **Ubicación:** analytics/dataQualityAnalytics.js + ui.js:5817-5876.
- **Salida:** días/registros, **SIN HORA** (n y % — problema del dato, no operativo), **OTRA** (uds y registros), tipos de incidencia con **categoría de causa** (OPERATIVO: secciones 1+4; DATOS: 2+5; REVISIÓN: 6+7; CONTROL: 3) que suman 100 %, casos/horas/personas/días por tipo; **calidad del mapping** (§30/§31): sin-mapeo, ambiguas, OTRA, clasificadas, histórico de hashes sin mezclar periodos; modoVolumen (exacto vs idNum vs sin); leyenda de colores semánticos (v6.3 U-08).
- **Verificación:** `[T]` analytics_dataquality (9). `[E]` patrones (calidad visible), v63 V2. Fuerte.

#### F-097 · Alertas A1–A11 (detalladas en §10.2)
- **Criticidad:** ALTA · **Ubicación:** analytics/alertAnalytics.js:27-174.
- **Verificación:** `[T]` analytics_alerts (17). `[E]` patrones_v62 t11 (A2 racha 4, A6 confusión, A5 OTRA). **Fuerte.**

#### F-098 · Índice de prioridad + TOP 5 (§6, §62) — fórmula en §10.3
- **Criticidad:** ALTA · **Ubicación:** alertAnalytics.js:185-265 (computePrioridades/computeTopPrioridades).
- **Candidatos:** tareas con errores>0 u horas>0 + personas con errores>0. **TOP 5** con desglose por componente y flecha de tendencia. `[T]` analytics_alerts (3+2 casos). `[E]` patrones_v62 t11.

#### F-099 · Exportación de analytics (7 vistas)
- **Criticidad:** MEDIA · **Ubicación:** ui.js:6067-6137 (`exportarPatrones`).
- **Salida:** XLSX `patrones_resumen|personas|tareas|actividades|errores|evolucion|historico_<fecha>.xlsx` desde la snapshot filtrada actual. `[E]` parcial. Faltan: tests de contenido de export.

---

### 4.11 ÁREA: RESULTADOS / REPORTE / TRAZABILIDAD (F-100 … F-106)

#### F-100 · Panel Resultados (tablas de consultas)
- **Criticidad:** ALTA · **Ubicación:** ui.js:710-763 (renderResultadosPanel), index.html panel-resultados.
- **Salida:** KPIs de cabecera + listado de **17 tablas** (01, 02, 03, 05, 07, 08, 09, 10, 12, 13, 14, 15, 16, 17, REPORTE, + estadísticas) → click abre visor. `[E]` smoke t4 (13 tablas listadas en v6.0 → hoy 17 con q17; el test E2E sigue pasando porque comprueba un mínimo). Faltan: assert de las 17 exactas.

#### F-101 · Visor de tabla con scroll virtual
- **Criticidad:** ALTA · **Ubicación:** ui.js:754-971 (renderViewerTable + ventana virtual), orden por columnas (viewerSort).
- **Reglas:** solo ~300 filas en DOM (virtual scrolling); export de la vista; contadores de filas. `[E]` performance_e2e t2 (743 filas <5s, <300 en DOM). Faltan: unit tests.

#### F-102 · Gráficos SVG (charts.js)
- **Criticidad:** MEDIA · **Ubicación:** charts.js:1-334 (`SPEC_CHARTS`).
- **Salida:** desde STATE.queries/reporte — distribución por sección del reporte, incidencias por persona/día, volumen por actividad/persona. SVG puro (sin librería). `[E]` smoke t4 (visualizaciones). Faltan: unit tests (D-010).

#### F-103 · KPI drilldown
- **Criticidad:** MEDIA · **Ubicación:** ui.js:2130-2304 (setupKpiDrilldown/handleKpiDrilldown).
- **Salida:** click en KPI → navega a la tabla/filtro relacionado (p.ej. "horas sin volumen" → tabla 01 filtrada). `[E]` parcial. Faltan: tests específicos.

#### F-104 · Panel REPORTE HR + filtros
- **Criticidad:** ALTA · **Ubicación:** ui.js:972-1094 (renderReportePanel/renderReporteTable), index.html panel-reporte.
- **Salida:** tabla completa de REPORTE_CAMBIOS_HR con filtros por sección (1-7) y export XLSX/CSV; las 20 columnas de crearPropuesta. `[E]` smoke t3/t5. `[T]` equivalencia.

#### F-105 · Panel TRAZABILIDAD
- **Criticidad:** MEDIA · **Ubicación:** ui.js:1095-1211 (renderTrazabilidadPanel/mostrarTrazabilidad), docs/TRAZABILIDAD.md.
- **Salida:** selección tabla+fila → árbol de orígenes (de qué consultas/filas fuente proviene esa fila: ArchivoOrigen/FilaOrigen, joins implicados). `[C]` la UI recorre los `__matches`/orígenes de las filas. `[E]` parcial (render). Faltan: tests del contenido del árbol.

#### F-106 · Búsqueda global
- **Criticidad:** BAJA · **Ubicación:** ui.js:1516-1619 (setupGlobalSearch/doGlobalSearch), `#global-search`.
- **Reglas:** busca en todas las tablas cargadas; resultados con tabla+fila; navigate al resultado (abre visor en esa fila); aria-live. `[E]` a11y t5 (visible/operable). Faltan: tests de resultados.

---

### 4.12 ÁREA: EXPORTACIONES (F-107 … F-109)

#### F-107 · `exportToXlsx`
- **Categoría:** EXPORTACIÓN · **Criticidad:** ALTA · **Ubicación:** app.js:2771-2801.
- **Reglas:** conserva el orden de columnas del primer row; fechas → celdas tipo `d` con formato `dd/mm/yyyy`; datos vacíos → hoja con fila vacía; `XLSX.writeFile` dispara la descarga.
- **Verificación:** `[T]` SOLO existencia (smoke.test.js typeof) — **hueco D-011**. Faltan: tests de contenido/fechas.

#### F-108 · `exportToCsv` (con protección anti inyección)
- **Criticidad:** ALTA · **Ubicación:** app.js:2808-2839.
- **Reglas `[C]`:** delimitador `;` (es-ES), **BOM \ufeff**, CRLF, quoting de `;`, `"`, `\n`, `\r` (comillas dobladas); **CSV formula injection**: valores que empiezan por `=`, `+`, `-`, `@` se prefijan con `'` (OWASP; AUD-MED-007 fix — el código original escapaba `,` siendo el delimitador `;`); Date → dd/mm/yyyy; null→''.
- **Casos límite (testeados):** `=HYPERLINK(...)`, `=2+5+cmd|"/c calc"!A1` neutralizados; **nota de comportamiento:** números negativos (-5) también reciben el prefijo `'` al serializarse como string "-5" (protección deliberada del prefijo `-`; en Excel se muestran correctamente).
- **Verificación:** `[T]` csv_injection.test.js (17 casos, payloads reales). **Fuerte.**

#### F-109 · Exportaciones específicas de la UI
- **Criticidad:** MEDIA · **Ubicación:** ui.js:1212-1303 (renderExportarPanel), ui.js:1263/1281 (Correcciones_aprobadas_\<ts\>.xlsx/.csv — solo decisiones aceptadas), ui.js:2865 (Auditoria_decisiones_\<ts\>.csv), exportMappingXlsx (F-065), exportarPatrones (F-099), export por query (ui.js:1285-1300) y del visor/reporte.
- **Verificación:** `[E]` parcial (existence + descargas). Faltan: tests de contenido filtrado (p.ej. correcciones solo aceptadas).

---

### 4.13 ÁREA: UI GLOBAL (F-110 … F-116)

#### F-110 · Navegación por pestañas
- **Criticidad:** MEDIA · **Ubicación:** ui.js:91-166 (setupTabs), index.html nav.tabs (role=tablist).
- **Reglas:** 10 pestañas con `data-tab`; activa con aria-selected; flechas de teclado en tablist (a11y); render lazy de cada panel al activar. `[E]` a11y t5. Faltan: tests de render lazy.

#### F-111 · Tema claro/oscuro/auto
- **Criticidad:** BAJA · **Ubicación:** ui.js:1463-1515 (setupThemeToggle/applyTheme), clave `spec_theme` ∈ {light,dark,auto}; default auto (matchMedia prefers-color-scheme); 3 estados cíclicos; `body.dark` + data-theme-mode. `[E]` smoke t8, a11y t4 (contraste dark).

#### F-112 · Persistencia del estado de la sesión (`spec_state`)
- **Criticidad:** ALTA · **Ubicación:** ui.js:1621-1746 (persistState/restoreState/clearPersistedState/updatePersistIndicator/setupPersistence).
- **Contenido:** `{queries, reporte, stats, savedAt}` (Dates revividas vía `{__date: ISO}`); persist tras análisis OK; restauración al arranque con toast "sesión anterior disponible"; indicador "Guardado HH:MM" clicable → borrar con confirmación; `clearPersistedState` también desde reiniciarProceso.
- **Riesgo:** queries completas en localStorage (cuota 5-10 MB; comentario ui.js:2634). `[E]` smoke t8 + a11y.

#### F-113 · Toasts, modales, focus-trap
- **Criticidad:** MEDIA · **Ubicación:** ui.js:1387-1462 (toast/confirmDialog), ui.js:1748-1802 (_modalFocusables/_trapFocus/_releaseFocus).
- **Reglas:** toasts con auto-dismiss y aria-live; confirmDialog nativo estilizado; focus-trap en modales; Escape cierra; restauración de foco best-effort (documentado). `[E]` a11y t5.

#### F-114 · Panel de detalle y vista previa
- **Criticidad:** MEDIA · **Ubicación:** ui.js:1803-2100 (setupDetailPanel/openDetailPanel/closeDetailPanel/formatVal, setupPreviewModal/showPreview).
- **Salida:** panel lateral con TODAS las columnas de una fila (formatVal), y modal de vista previa de hoja del workbook cargado. `[E]` a11y (Escape cierra detalle).

#### F-115 · Atajos de teclado + beforeunload
- **Criticidad:** BAJA · **Ubicación:** ui.js:2882-2919 (setupKeyboardShortcuts — documentados en Ayuda), ui.js:2921-2931 (setupBeforeUnload).
- **Reglas:** beforeunload avisa SOLO si `decisions` no vacío Y `spec_decisions` NO existe — condición casi imposible (persistDecisions escribe al instante) ⇒ guarda inefectiva en la práctica (D-003). `[C]`.

#### F-116 · Panel AYUDA
- **Criticidad:** BAJA · **Ubicación:** index.html:736-808. Qué hace, cómo usarla, equivalencia con Excel, diferencias conocidas, bibliotecas, limitaciones, código/trazabilidad. `[C]`.

---

### 4.14 ÁREA: SEGURIDAD / PWA / OFFLINE / STANDALONE (F-117 … F-122)

#### F-117 · CSP y cabeceras
- **Categoría:** SEGURIDAD · **Criticidad:** ALTA · **Ubicación:** index.html:6-11.
- **Política `[C]`:** `default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; base-uri 'self'; form-action 'self'; object-src 'none'; worker-src 'self' blob:'.` + `X-Content-Type-Options: nosniff` + `Referrer-Policy: no-referrer`. Sin red externa; 'unsafe-inline' SOLO para estilos (documentado M-11/R-04); **sin unsafe-eval** (los tests cargan con new Function pero la página no).
- **Verificación:** `[C]` index.html; `[E]` smoke t1 (0 errores consola). Standalone usa CSP con hashes SHA-256 por script inline.

#### F-118 · escapeHtml / escapeAttr (XSS)
- **Criticidad:** CRÍTICA · **Ubicación:** ui.js:1304-1317, aplicado en TODOS los renders de datos dinámicos.
- **Reglas:** `&` primero (sin doble-escape), `<`, `>`, `"` (y `'`→`&#39;` en algunos paths), null/undefined→'', números→String, boolean→'true'. **escapeAttr NO elimina `javascript:`** (limitación documentada: no es sanitizador de URL — no hay URLs dinámicas en la app).
- **Verificación:** `[T]` escape_html.test.js (24 casos con payloads script/img/svg/polyglot, DoS 10k, orden de escapes). **Fuerte.**

#### F-119 · Service Worker
- **Categoría:** PWA · **Criticidad:** MEDIA · **Ubicación:** sw.js completo, sw-register.js.
- **Reglas `[C]`:** CACHE `spec-web-v6-3`; SW_VERSION 6.3.0; **19 assets precacheados** (los 11 runtime + 9 analytics… ver lista exacta en §15.1); install con allSettled individual + `skipWaiting`; activate borra cachés antiguas + `clients.claim`; fetch: **solo GET same-origin**, **cache-first con revalidación en background** (devuelve caché y si 200/basic actualiza), sin caché → red → cachea; **document fallback offline** → `./index.html`; resto offline → 504; mensaje 'SKIP_WAITING' → skipWaiting (**listener huérfano**: nadie lo envía, D-007). Los `.xlsx` del usuario JAMÁS se cachean (comentario sw.js:7-8).
- **Verificación:** `[E]` pwa.spec.js (4 tests: manifest válido, SW activo, caché core ≥10, offline real). **Fuerte en su alcance.** Faltan: test de actualización de versión (cache swap).

#### F-120 · Manifest PWA
- **Criticidad:** BAJA · **Ubicación:** manifest.json.
- **Campos `[C]`:** name **"SPEC Web v6.2 — ID Logistics"** (⚠ D-001: dice v6.2 con version 6.3.0 — y pwa.spec.js t1 lo AFIRMA), short_name "SPEC Web", display standalone, start_url ./index.html, theme #0f766e, 1 icono (any maskable), 3 shortcuts (carga/revisar/patrones), lang es, categories business/productivity/utilities.
- **Verificación:** `[E]` pwa t1.

#### F-121 · Modo offline
- **Criticidad:** MEDIA · **Dependencias:** F-119. Tras primera carga, la app funciona 100 % offline (motor, IndexedDB, localStorage, análisis completo — los archivos vuelven del disco del usuario, no de la caché). `[E]` pwa t4 (contexto sin red: 200 desde caché, pestañas renderizan, XLSX y SPEC disponibles).

#### F-122 · Standalone SPEC_AUTONOMO_v6.html
- **Categoría:** PWA/OFFLINE · **Criticidad:** MEDIA · **Ubicación:** SPEC_AUTONOMO_v6.html (generado por scripts/06_build_autonomo.py con probes obligatorios v6.3: resolverClasificacionTarea, repartirTiemposPorTarea, filtrarRegistrosPorTurno, renderTaskProdEditor + 6 probes v6.3).
- **Reglas:** motor + analytics + estilos inline (0 referencias externas — verificado por el build D-20 corregido); CSP por hashes SHA-256 de cada script inline (sin unsafe-inline); SIN manifest (PWA exclusiva del modular); **usa las MISMAS claves de localStorage/IndexedDB** que el modular → si conviven en el mismo origen compiten por el mismo estado (riesgo documentado R-21a).
- **Verificación:** `[E]` standalone.spec.js (1 mega-test: 4 archivos → 214 propuestas + 14 tablas + decisión con entryHash SHA-256 génesis + probes). MEDIA densidad.

---
---

## 5. FLUJOS END-TO-END (FASE 4)

### 5.1 Flujo maestro (el único flujo completo de la aplicación)

```
Excel (4 tipos, N archivos c/u)
 ↓ [F-001..F-013] Carga + detección + validación + lectura (workbooks en memoria, File retenido)
 ↓ [F-014] re-lectura como ArrayBuffer → TRANSFER al Worker (zero-copy)
 ↓ [F-017] analizarYConciliar (en worker):
 │    fx_Transforma* (filtrado de pie, columnas requeridas, ArchivoOrigen/FilaOrigen)
 │    → q01 H (validación registros, ClaveNatural, duplicados, IdRegistroHoras)
 │    → q02 V / q09 VSH (VolumenPositivo/Negativo/Cero, duplicados)
 │    → q12 M (mapping dedup + EstadoMapeoSPEC UNICO/AMBIGUO/SIN TASK_SPEC)
 │    → q13 VM (join por SAP_CODE|CUSTOMER|WMS_TASK; EstadoMapeoFinal + 'SIN MAPEO')
 │    → q03/q05/q10/q14/q15 (agregaciones por persona/día/actividad/idNum)
 │    → q16 controles + q07 Conciliacion (joins M1-M6 + Clasificacion + Confianza + Evidencia)
 │    → q08 Validaciones (18 controles)
 │    → REPORTE_CAMBIOS_HR (7 secciones, Pass1 exacto / Pass2 idNum)
 │    → q17 PersonaDiaAnalitica (turnos + fecha operativa + reparto por TAREA)
 │    → generarPersonDailyRecords (incidencias enriquecidas v6.2 + fingerprint v2)
 ↓ {type:'done'} state → main thread
 ↓ [F-018] recomputarPersonaDia (productividades/overrides del usuario) → persistirPersonDailyRecords (IndexedDB versionado)
 ↓ [F-018] auto-navegación → Revisar
 ↓ [F-048..F-060] Decisión humana: aceptar/rechazar/mantener + tareaFinal + motivo
 │    → decisions[incidentId] + undoStack + auditLog (SHA-256 chain) → localStorage + IndexedDB backup
 │    → sincronizarDecisionesEnRecords → persistencia de records (fingerprint igual → conserva versiones)
 ↓ [F-084..] Patrones: cargarTodosRecords → normalizarRecords → filtros globales
 │    → snapshot (kpis/personas/tareas/actividades/confusion/trend/pareto/alerts/dataQuality)
 │    → 8 vistas + TOP5 + alertas + comparación A/B
 ↓ [F-107..F-109] Exportaciones XLSX/CSV (tablas, reporte, correcciones, auditoría, patrones)
```

### 5.2 Transiciones con entrada/salida/validación/persistencia/errores

| # | Transición | Entrada | Transformación | Validación | Persistencia | Errores posibles |
|---|---|---|---|---|---|---|
| T1 | File → workbook | File | FileReader + XLS.read cellDates | ext/MIME/50MB/0B/≥4B | memoria | ext rechazada, corrupto, MIME warning |
| T2 | workbook → filas crudas | workbook | fx_Transforma* + filtrado pie | columnas requeridas (throw) | memoria | "Faltan columnas…" |
| T3 | filas → H/V/VSH validadas | filas crudas | fx_* + RegistroValido + ClaveNatural + duplicados | motivo inválidos; solo válidas pasan | memoria | registro excluido (contabilizado) |
| T4 | mapping → M | filas mapping | normaliza cabeceras + group by triple | 8 columnas obligatorias | memoria + IndexedDB (versiones) | hoja MAPPING inexistente |
| T5 | V×M → VM | V, M | left join por triple | — | memoria | — (SIN MAPEO como estado) |
| T6 | H+agregs → C | H + 5 agregaciones | joins M1-M6 + Clasificacion | q08 controles | memoria | — |
| T7 | H+VM+C → REPORTE | 3 tablas | 2 pases de búsqueda de volumen + 7 secciones | — | memoria | — |
| T8 | H+VM → q17 grupos | 3 tablas | turnos + fecha operativa + reparto por tarea | conservación <1e-9 | memoria | — |
| T9 | grupos → PERSON_DAILY_RECORD | grupos + REPORTE | vinculación por ID REGISTRO + dedup horas + fingerprint | login/fecha presentes | **IndexedDB (upsert versionado)** | — |
| T10 | decisión → decisions/auditLog | interacción usuario | registrarDecision + entryHash SHA-256 | motivo/tarea | localStorage + IndexedDB | contexto inseguro → INSECURE_CONTEXT |
| T11 | records → analytics | records IDB | normalizar + filtros + snapshot | sin NaN (batería §58) | memoria (memo) | — |
| T12 | datos → export | tablas/snapshot | serialize + escape | BOM/quoting/injection | descarga archivo | quota del navegador |

### 5.3 Flujo de arranque en frío (cold start)

1. init() idempotente (guard `__spec_init_done`) → 2. setupTabs/theme/search → 3. restoreDecisions (localStorage → IDB fallback) → 4. cargarMappingPersistente (injecta File sintético en STATE.archivos.mapping) → 5. restoreState (si spec_state: restaurar queries/reporte del último análisis + toast) → 6. render paneles → 7. SW register (load). `[C]` ui.js:1318-1386.

### 5.4 Flujo de reprocesado con otra configuración (el flujo que define v6.3)

Usuario cambia mapping (F-068) o override (F-070) → aplicarOverridesYRecalcular → recomputarPersonaDia → fingerprint DISTINTO → persistirPersonDailyRecords: record existente con mismo key → `version+1` + previousVersions.push(núcleo anterior) → el histórico NUNCA se reescribe → Patrones muestra la versión actual; las anteriores quedan trazables (mappingHash/productividades por versión). `[C][T][E]`

---

## 6. REGLAS DE NEGOCIO (FASES 7, 8, 10 + MAPPING FASE 6)

### 6.1 CLASIFICACIÓN DE INCIDENCIAS DEL REPORTE (7 secciones) — FASE 7

| Sección | Nombre | Condición de entrada (precedencia exacta) | REQUIERE CAMBIO | Tipo (analyticsCore) | Causa (§50) |
|---|---|---|---|---|---|
| 1 | CAMBIO HR TASK PROPUESTO | hay volumen único mapeado, sin multi-HR, sin ambigüedad, 1 TasksSPEC, y HR Task fichada ≠ TasksSPEC | SI | ERROR DE FICHAJE | OPERATIVO |
| 2 | VARIAS TASKSPEC CON VOLUMEN | >1 TasksSPEC distintas (excluye las que contienen " \| ") | REVISAR | AMBIGÜEDAD MAPPING | DATOS |
| 3 | HR TASK CORRECTA | HR Task fichada == TasksSPEC (única) | NO | REVISIÓN (CORRECTA) | CONTROL |
| 4 | SIN VOLUMEN | Pass 1 y Pass 2 sin volumen positivo | REVISAR | SIN VOLUMEN | OPERATIVO |
| 5 | WMS TASK SIN MAPPING | EstadoMapeoFinal ≠ UNICO o TasksSPEC vacía o con " \| " | REVISAR | SIN MAPPING | DATOS |
| 6 | REVISION MANUAL - MULTIPLES HR TASK | la persona fichó >1 HR Task ese día (Número de tareas distintas > 1) | REVISAR | MÚLTIPLES HR TASK | REVISIÓN |
| 7 | REVISION MANUAL - AMBIGUEDAD ID NUMERICO | modo Pass 2 + EsAmbiguoIdNumerico | REVISAR | AMBIGÜEDAD IDNUM | REVISIÓN |

**Doble sistema de clasificación de la q07 (F-030)** — 10 categorías de conciliación con NivelConfianza ALTA/MEDIA/NO DETERMINABLE, diccionarios de Evidencia/Explicación/Acción fijos. **Regla de imputación v6.2 (§11): el error de una incidencia se imputa a la TAREA WMS afectada (`wmsTask` del reporte), no a todas las tareas del día.**

**Espacio HR Task ≠ espacio TASK_WMS (FASE 4 del usuario, ya correcto):** `computeFichajeStats` (fichadas, desde registros[].hrTask) vs `computeTaskStats` (volumen, desde incidencias.wmsTask + tareas) son espacios separados que nunca se mezclan. `[T]` v63 (2 casos).

### 6.2 TURNOS Y FECHA OPERATIVA — FASE 8 (tabla exigida)

Límites `[C]` PARAMS: TurnoMananaInicio=360, TurnoTardeInicio=840, TurnoNocheInicio=1320.

| Hora | Turno (fx_Turno) | Fecha operativa (fx_FechaOperativaTurno) |
|---|---|---|
| 05:59 | NOCHE | día ANTERIOR |
| 06:00 | MAÑANA | misma |
| 13:59 | MAÑANA | misma |
| 14:00 | TARDE | misma |
| 21:59 | TARDE | misma |
| 22:00 | NOCHE | misma |
| 23:59 | NOCHE | misma |
| 00:00 | NOCHE | día ANTERIOR |
| 05:59 (del día siguiente) | NOCHE | día anterior a esa 05:59 |

**Reglas complementarias:** cobertura 0-1439 sin huecos (480+480+480 min, test exhaustivo); sin hora conocida (serial entero / Date medianoche) → 'SIN HORA', la fecha operativa NO se desplaza y el registro NUNCA aparece al filtrar por un turno concreto; día con fichajes de varios turnos → turno agregado 'MIXTO' (aparece al filtrar por cualquiera de sus turnos vía `turnos[]`); **regla clave del proyecto: nunca se desplazan masivamente las fechas day-level** (el bug evitado por extraerHoraFichaje).

### 6.3 REPARTO DE TIEMPOS — FASE 10 (matemática exacta)

**Modelo por TAREA (v6.1.1+, el vigente):**

```
HORAS_EQUIVALENTES_t   = UDS_t / PRODUCTIVIDAD_t                     (solo tareas clasificables: actividad ≠ OTRA y prod > 0)
PESO_t                  = HE_t / Σ_t HE                              (fracción exacta)
HORAS_ASIGNADAS_t       = HORAS_ANALIZABLES_persona-día × PESO_t
PRODUCTIVIDAD_IMPLÍCITA_t = UDS_t / HORAS_ASIGNADAS_t                (informativa)
DESVIACIÓN_persona-día  = HORAS_ANALIZABLES − Σ HE
CONSERVACIÓN: Σ_t HORAS_ASIGNADAS_t = HORAS_ANALIZABLES  (tolerancia < 1e-9; el redondeo es SOLO presentación)
```

**Ejemplo numérico verificado por tests `[T]`:** persona/día con 8 h analizables, PICKING AGV 200 uds @100 uds/h (HE=2) y UBICACIÓN 400 uds @200 (HE=2) → pesos 0,5/0,5 → 4 h + 4 h. Ejemplo con implícita: 900 uds @150 (HE 6) + 520 uds @260 (HE 2) sobre 8 h → pesos 0,75/0,25 → 6 h + 2 h.

**Casos especiales (todos testeados):** OTRA y 0 uds → fuera del reparto (peso 0, HE null); solo OTRA → no se reparte nada (desviación = todo); 1e9 uds sin overflow; redondeo solo visual; tiempo 0 → reparto nulo; misma actividad con 2 productividades distintas NO se mezclan (agregación por tarea y luego visual por actividad con productividad null = "varias").

### 6.4 SISTEMA DE MAPPING — FASE 6 (comportamiento esperado, mapping = insumo del usuario)

1. **El mapping lo aporta el usuario** (Mapping.xlsx con hoja MAPPING, 8 columnas estructurales). El proyecto NO contiene un mapping operativo fijo: el archivo de `audit-ref/drive/` es fixture de referencia (167 filas).
2. **Ciclo de vida:** importación (F-012) → hash FNV para audit + **SHA-256 para versionado** (F-066) → guardado versionado en IndexedDB con las rows completas → auto-carga al abrir (F-067, reconstruye File) → si se importa otro: diálogo old-vs-new con hashes y nº filas (F-068) → confirmación → nueva versión → **el análisis debe reprocesarse manualmente** para usarlo.
3. **Trazabilidad:** cada PERSON_DAILY_RECORD guarda el `mappingHash`/`mappingVersion`/snapshot con el que fue calculado; cambiar el mapping NO reescribe históricos (fingerprint distinto → nueva versión); `changesMapping` de dataQuality muestra los hashes sin mezclar periodos.
4. **Interacción con productividad:** TasksSPEC del mapping NO decide la actividad analítica (la decide fx_ActividadAnalisis sobre TASK_WMS); el mapping aporta la PROPUESTA del reporte (secciones 1-7) y tasksSpec/cliente por tarea (v6.2, dimensiones de análisis).
5. **Interacción con overrides:** un TASK_WMS sin mapping (sección 5) sigue recibiendo overrides de actividad/productividad; el mapping se completa con CRUD (F-063) y las ambigüedades (2 TasksSPEC) se resuelven por el usuario vía override.
6. **Auditoría:** mapping_create/update/delete/import quedan en la cadena SHA-256.

### 6.5 Otras reglas de negocio invariantes

- **Nº máximo de registros en log:** 1000 (FIFO).
- **Decisión inicial de un record:** 'SIN INCIDENCIAS' (0 incidencias) o 'PENDIENTE'.
- **Estado persona/día:** SIN INCIDENCIAS → PENDIENTE → (mixto) EN REVISIÓN / COMPLETADA (estadoDecisionRecord).
- **cap de previousVersions:** 10.
- **safeDiv:** denominador 0 o no finito → 0; **pct:** acotado [0,100] SOLO para partes de un total.
- **Orden determinista de históricos:** fecha + login (normalizarRecords).
- **Usuario de las decisiones:** literal `'usuario_local'` (sin auth).
- **SessionId:** `'sess-<base36 ts>-<random>'` persistido en `spec_session_id` (regenera al cerrar navegador).
---

## 7. MODELO DE DATOS (FASE 12 estructura)

### 7.1 Consultas del motor (STATE.queries) — 17 claves

| Query | Filas | Clave natural | Campos distintivos |
|---|---|---|---|
| 01_HorasSinVolumen | 214 (fixtures reales) | IdRegistroHoras | login canónico 7 campos, RegistroValido, ClaveNatural, PosibleDuplicado |
| 02_VolumenDetalle | 743 | fila | VolumenPositivo/Negativo/Cero, login fields |
| 03_VolumenPersonaDia | ~80 | Fecha+LoginCanonico | totales por persona/día |
| 05_VolumenIdNumericoDia | ~80 | Fecha+IdNumerico | EsAmbiguoIdNumerico, LoginsMismoNumero |
| 07_Conciliacion | 214 | IdRegistroHoras | Clasificacion (10), NivelConfianza, Evidencia, Explicacion, AccionRecomendada |
| 08_Validaciones | 18 | Control | ValorOrigen/Resultado, Estado |
| 09_VolumenSinHorasDetalle | 490 | fila | sufijos VSH |
| 10_VolumenSinHorasPersonaDia | ~110 | Fecha+Login | VolumenSinHorasPersonaDia |
| 12_MapeoActividadSPEC | 167 | SAP+CUSTOMER+TASK_WMS | EstadoMapeoSPEC, TasksSPEC " \| " |
| 13_VolumenMapeadoSPEC | 743 | fila | EstadoMapeoFinal (+SIN MAPEO) |
| 14/15_VSH por actividad | ~110/112 | Fecha+Login+Activity | — |
| 16_ControlMapeoSPEC | 13 | Control | Valor, Estado |
| 17_PersonaDiaAnalitica | ~19 (fixtures) | login\|fechaOperativaISO | estructura completa del record (ver §7.4) |
| REPORTE (STATE.reporte) | ~214+ | — | 20 columnas (SECCION…OBSERVACION) |

### 7.2 REPORTE_CAMBIOS_HR — 20 columnas exactas `[C]` (crearPropuesta)

`SECCION · ID REGISTRO · FECHA · PERSONA · LOGIN HORAS · HORAS SIN VOLUMEN · MATERIALIDAD · HR TASK FICHADA · TASKSPEC SEGUN MAPPING · VOLUMEN POSITIVO · WMS TASK CON VOLUMEN · TIPO COINCIDENCIA · LOGIN UTILIZADO EN VOLUMEN · SAP_CODE · CUSTOMER · WMS_DC · ARCHIVO ORIGEN · FILA ORIGEN · REQUIERE CAMBIO RRHH · OBSERVACION`

### 7.3 Entrada de decisión (decisions[incidentId]) `[C]`

`{decision: 'aceptada'|'rechazada'|'mantenida', tareaFinal, motivo, timestamp, usuario:'usuario_local', evidencia, seccion, idRegistro, persona, fecha, tareaOriginal, propuesta, nivelConfianza}` — clave `incidentId = "ID REGISTRO@FILA ORIGEN"`.

### 7.4 PERSON_DAILY_RECORD (estructura completa v6.3) `[C]` app.js:2326-2414

```jsonc
{
  "key": "LOGIN|YYYY-MM-DD",            // clave estable (upsert)
  "login": "", "persona": "",
  "fechaOperativa": "Date", "fechaOperativaISO": "YYYY-MM-DD",
  "semana": "YYYY-Www", "mes": "YYYY-MM",
  "turno": "MAÑANA|TARDE|NOCHE|MIXTO|SIN HORA", "turnos": ["..."],
  "registros": [ { "idRegistroHoras": 1, "hora": 480, "turno": "MAÑANA", "horas": 8, "hrTask": "20051" } ],
  "horasFichadas": 8, "horasAnalizables": 8,
  "udsTotales": 600, "udsSinHoras": 0,
  "horasEquivalentes": 4.0, "horasAsignadas": 8.0, "desviacion": 4.0,
  "nActividades": 2,
  "actividades": [ { "actividad": "PICKING MANUAL", "uds": 200, "tareasWms": ["..."],
      "tareas": [ { "taskWms": "...", "actividad": "...", "uds": 200, "productividad": 100,
                    "fuente": "DEFAULT|PRODUCTIVIDAD ACTIVIDAD|OVERRIDE TASK_WMS|OTRA|SIN PRODUCTIVIDAD",
                    "horasEquivalentes": 2, "peso": 0.5, "horasAsignadas": 4,
                    "productividadImplicita": 50, "tasksSpec": "20051", "cliente": "..." } ],
      "productividad": 100, "horasEquivalentes": 2, "peso": 0.5, "horasAsignadas": 4 } ],
  "modoVolumen": "LOGIN EXACTO|MISMO NUMERO, DISTINTO PREFIJO|null",
  "incidencias": [ { "id": "214@45", "seccion": "1. CAMBIO HR TASK PROPUESTO",
      "horasAfectadas": 8, "requiereCambio": "SI", "tareaOriginal": "20051", "propuesta": "20052",
      "wmsTask": "PICKING SIN PAPEL", "volumen": 200, "tipoCoincidencia": "LOGIN EXACTO",
      "cliente": "...", "sapCode": "...", "decision": "aceptada|null" } ],
  "nIncidencias": 1, "horasConIncidencia": 8,
  "decision": "SIN INCIDENCIAS|PENDIENTE",
  "mappingHash": "fnv8hex", "mappingVersion": 2,
  "productividades": { "...snapshot..." }, "taskOverrides": { "...snapshot..." },
  "productivityVersion": "fnv8hex", "overrideVersion": "fnv8hex",
  "appVersion": "6.3.0", "sessionId": "sess-...",
  "version": 1, "dataFingerprint": "fnv8hex", "datasetFingerprint": "=dataFingerprint",
  "fingerprintVersion": 2,
  "createdAt": "ISO", "updatedAt": "ISO",
  "previousVersions": [ { "version": 1, "updatedAt": "...", "mappingHash": "...", "productividades": {},
      "horasAnalizables": 8, "udsTotales": 600, "desviacion": 4, "actividades": [], "incidencias": [] } ]
}
```

**Nota:** `horasConIncidencia` deduplica por idRegistro pero incluye la sección 3; la capa analítica calcula aparte `horasErrorDedup` (solo errores ≠ sec. 3, §50) — dos métricas con semántica distinta, ambas persistidas/derivadas respectivamente.

### 7.5 Registro analítico normalizado (SPEC_AN.normalizarRegistro)

Añade a cada incidencia: `tipoError, categoria, esError (≠3), esErrorFichaje (1), esErrorAsignacion (1 o aceptada), esControl (3), esSinMapping (5), esSinVolumen (4), esRevisionManual (6/7), esAmbiguedad (2)`; aplana tareas con contexto; añade `nErrores, horasErrorDedup, conIncidencia, conError`; descarta sin login/fecha; orden fecha+login; revive legacy v6.1 (actividades sin tareas → filas por tareasWms `_agregadaLegacy`).

---

## 8. DICCIONARIO DE MÉTRICAS (FASE 14 + 15 + 17)

Convención: **Tasa** = % acotado [0,100] con denominador explícito (numerador ⊆ denominador). **Ratio** = cociente sin cota con unidad. Nunca se mezclan; la UI las etiqueta "…%"/"Inc. por oportunidad" respectivamente.

### 8.1 Métricas globales (kpisBase — Resumen y comparaciones)

| Métrica (técnico) | Mostrada como | Fórmula | Nivel | Fuente | Tests |
|---|---|---|---|---|---|
| personas | Personas analizadas | `|logins distintos|` | global | analyticsCore | core |
| personasConError | Personas con error | `|logins con ≥1 record conError|` | global | analyticsCore | v63 |
| dias | Días con datos | `|fechas distintas|` | global | analyticsCore | core |
| personaDia | Registros persona-día | `n(records)` | global | analyticsCore | core |
| horasAnalizables | Horas analizables | `Σ horasAnalizables` | global | analyticsCore | core |
| horasAfectadas | Horas afectadas | `Σ horasErrorDedup` (solo ≠3) | global | analyticsCore | core, v63 |
| incidencias / errores | Incidencias / Errores | `Σ incidencias` / `Σ nErrores` | global | analyticsCore | core |
| erroresAsignacion | Errores de asignación | `Σ esErrorAsignacion` | global | analyticsCore | core |
| pctPersonaDiaConError | % persona-día con error | `pct(conError, n)` | global | analyticsCore | core, v63 |
| pctHorasAfectadas | % horas afectadas | `pct(horasErrorDedup, horasAnalizables)` | global | analyticsCore | core |
| pctErroresAsignacion | % errores de asignación | `pct(errAsig, incidencias)` | global | analyticsCore | core |
| incidenciasPorPersonaDia | Inc. por persona-día | `safeDiv(incs, n)` (ratio) | global | analyticsCore | core |

### 8.2 Personas (§7-§9)

`dias, diasConError, incidencias, errores, erroresAsignacion, cambiosTarea (sec 1), horasAfectadas (Σ horasErrorDedup), tasaError = diasConError/dias [0,1], pctDiasConError (tasa %), pctHorasAfectadas, incidenciasPorDia (ratio), maxRacha (consecutivos con error; huecos rompen), muestraPequena (dias<minObservaciones), semaforo (0 MUY BUENO / ≤10 BUENO / ≤25 NORMAL / ≤50 ATENCIÓN / >50 CRÍTICO / <3 días MUESTRA PEQUEÑA), turnos (Set), sinHoraDias, otraUds, udsTotales`. Tendencia por mitades: `tasaA, tasaB, deltaPP, veredicto MEJORA/EMPEORA/ESTABLE, suficiente (ambas mitades ≥minDiasComparar)`.

### 8.3 Tareas (§10-§11) — semántica de tasas v6.3 (FASE 5)

| Métrica | Fórmula | Cota | Etiqueta UI |
|---|---|---|---|
| oportunidades | nº persona-día con volumen de esa tarea | ≥0 | Oportunidades |
| errores | incidencias de error imputadas a la tarea (via wmsTask) | — | Errores |
| oportunidadesConError | nº oportunidades con ≥1 error | ≤ oportunidades | — |
| **pctOportunidadesConError** | `pct(oportConError, oportunidades)` | **[0,100] por definición** | **"% oport. con error"** |
| **incidenciasPorOportunidad** | `safeDiv(errores, oportunidades)` | **sin cota** (1 oportunidad con 2 errores → 2,0) | **"Inc./oport."** |
| horasAfectadas | Σ horas dedup por ID registro | — | Horas |
| personasN / diasN / uds | conteos y volumen | — | — |
| muestraPequena | `oportunidades < minObservaciones` | — | badge |

Aliases compatibles: `tasaError = pctError = pctOportunidadesConError` (acotada); `tasa` (0-1). **Verificación anti-clamp:** `analytics_task` + `v63_correcciones` (5 casos: 1 oportunidad 2 errores → 100 % + ratio 2,0 — el clamp `min(rate,100)` NO existe).

**Fichaje (HR Task, espacio separado):** `fichajes, erroresCambio (sec 1), correctas (sec 3), tasaCambio = pct(cambios, cambios+correctas), pctFichajesConCambio = pct(fichajesConCambio dedup, fichajes), propuestasPorFichaje = safeDiv(erroresCambio, fichajes) (ratio), propuestaHabitual (solo si propuesta única)`.

### 8.4 Actividades y turnos

`oportunidades, errores (imputados), pctOportunidadesConError, incidenciasPorOportunidad, uds, horasAfectadas, personas, dias, muestraPequena`; turnos: `registros, conError, pctError = pct(conError, registros), pesoRelativo = pct(registros, total)` con **SIN HORA como categoría propia**.

### 8.5 Confusión y recurrencias

Celda: `origen→destino, casos, personas, dias, horas (dedup registro+destino), wmsTasks`. Recurrente: `login+pareja, dias, casos, horas, turnos, persistencia AISLADO(1)/RECURRENTE(2-4)/HABITUAL(≥5)` (umbrales recurrenciaRecurrente/Habitual configurables).

### 8.6 Evolución (FASE 15) — qué días entran exactamente en cada cálculo

| Cálculo | Días que entran | Nulos/regla |
|---|---|---|
| Serie diaria | SOLO fechas presentes en el histórico (≥1 persona-día) | un hueco NO es un 0 |
| MM7 (ventana configurable) | últimos 7 días OBSERVADOS | null hasta índice 6 (ventana completa) |
| Rolling 7/28 | últimos N días OBSERVADOS, ventana completa | `diasConDatos=N`, `desde/hasta` (tramo calendario con huecos), tasa = pct(conError, registros) |
| Cobertura | todo el rango calendario | `diasSinDatosEnRango` = días de calendario sin registros |
| Bucket semana/mes | agrupación por semana ISO/mes | Δ vs bucket anterior (primera → null) |
| Frecuencia×impacto | personas/tareas | cuadrantes por **medianas** del conjunto |
| Comparación A/B | mitades: ceil(n/2) fechas únicas; manual: rangos | deltas + **pp**; evidencia ≥minDiasComparar días con datos POR periodo; MEJORA/EMPEORA por umbralCambioPP |

**Regla FASE 7 (v6.3):** un día con 0 errores = fecha presente con conError=0; un día sin datos = fecha ausente que NO se inventa como 0 en medias ni gráficos. `[T]` v63_correcciones (3 casos) + analytics_trend.

### 8.7 Pareto

`items orden desc con valor/pct/ pctAcumulado; nPara80; pctElementos80 = pct(nPara80, nElementos); cumple8020 = pctElementos80 ≤ 20 && pctAcum(nPara80) ≥ 80` — **afirmación 80/20 solo si de verdad se cumple**.

---

## 9. HISTÓRICO, VERSIONADO Y UNDO (FASES 11-12)

### 9.1 Casos A–E exigidos (comportamiento esperado y verificado)

| Caso | Escenario | Comportamiento esperado | Verificación |
|---|---|---|---|
| **A** | Mismos datos + misma configuración | `dataFingerprint` IDÉNTICO → el upsert refresca decisiones y marca updatedAt, **conserva** version/createdAt/previousVersions (idempotente, sin duplicados) | `[T]` overrides_task (idempotencia), mapping_persist; `[E]` patrones t2-t4 |
| **B** | Mismos datos + mapping diferente | fingerprint DISTINTO → `version+1`; previousVersions conserva el núcleo con SU mappingHash; el nuevo cálculo usa el mapping nuevo; los analytics filtran por mappingHash sin mezclar | `[T]` v63 fingerprint, analytics_dataquality §31; `[E]` mejoras_v6 t3, patrones t12 |
| **C** | Mismos datos + productividades diferentes | ídem vía `productivityVersion` distinto | `[T]` v63 (fp distinto) |
| **D** | Mismos datos + override diferente | ídem vía `overrideVersion`; los no afectados conservan núcleo | `[T]` overrides_task §14, v63; `[E]` overrides_v612 t8, patrones t13 |
| **E** | Datos diferentes (p.ej. otro día) | key distinta (login\|fecha distinta) → NUEVO record versión 1; el histórico acumula | `[T]` persona_dia; `[E]` patrones t3 (21 records sin duplicados) |

### 9.2 Inmutabilidad

- Ninguna ruta de código reescribe el contenido de una versión anterior: solo `put` de la versión actual (con push del núcleo previo).
- Los records conservan `productividades`/`taskOverrides` **snapshot** con los que se calcularon (no referencias vivas).
- Los analytics nunca recalculan con la config actual del usuario: leen lo persistido (normalización defensiva).

### 9.3 UNDO (FASE 11) — alcance exacto

| Pregunta | Respuesta |
|---|---|
| Qué se puede deshacer | decisiones: aceptar/rechazar/mantener (+cambio de motivo/tareaFinal) y la última acción global |
| Qué es "última acción" | la entrada MÁS RECIENTE del undoStack para ese id (undo decisión) o la última del stack (undoLastAction) |
| Stack | `undoStack: [{id, prev, timestamp}]` — prev = copia del estado anterior de la decisión (null si no existía) |
| Persistencia | dentro de `spec_decisions` (localStorage) y del backup IDB → **sobrevive recargar/cerrar** |
| Auditoría | cada undo añade entrada 'undo' con estadoAnterior/estadoPosterior y hash de la cadena |
| Acciones consecutivas | aceptar→mantener→undo restaura 'mantenida' (no el estado inicial); segundo undo → pendiente |
| Qué NO se puede deshacer | análisis, carga de archivos, ediciones de mapping, overrides, exports, vaciado de auditoría, versiones del histórico |

### 9.4 Migración de históricos antiguos

v6.3 fingerprint v2 incluye la configuración; los históricos v6.1/v6.2 (fp sin config) **se versionan UNA vez al reprocesar** (documento: HISTORICAL_ANALYTICS_MODEL.md §fingerprint). Sin pérdida: cada previousVersions conserva su núcleo y mappingHash. `[D][T]` v63 (inmutabilidad del anterior).
---

## 10. ANALYTICS — INVENTARIO COMPLETO (FASES 13, 16, 17, 18)

### 10.1 Inventario de funcionalidades analíticas (todas `[C]` en analytics/*.js)

| # | Funcionalidad | Módulo | Vista UI |
|---|---|---|---|
| 1 | KPIs globales con denominadores | core | Resumen |
| 2 | Configuración estadística persistida (24 params) | core | ⚙ dentro Patrones |
| 3 | Filtros globales combinables (11 dimensiones) | core | todas |
| 4 | Comparación de periodos (mitades + manual A/B con evidencia) | core | Resumen/Evolución |
| 5 | Estadísticas por persona (frecuencia+tasa+impacto juntos) | person | Personas |
| 6 | Semáforo de calidad de fichaje | person | Personas |
| 7 | Racha máxima de días consecutivos | person | Personas/alertas |
| 8 | Mejora/empeoramiento con evidencia mínima | person | Personas/alertas |
| 9 | Perfil histórico de persona (drill-down) | person | Personas→perfil |
| 10 | Ranking TASK_WMS con oportunidades e imputación exacta | task | Tareas |
| 11 | Tareas fichadas HR Task (espacio separado) + propuestaHabitual | task | Tareas |
| 12 | Tendencia por tarea (deltaPP con evidencia) | task | Tareas |
| 13 | Perfil de tarea (personas afectadas, mappings usados) | task | Tareas→perfil |
| 14 | Ranking actividades (7+OTRA) | activity | Actividades |
| 15 | Turnos con SIN HORA separado + peso relativo | activity | Actividades |
| 16 | Tendencia por turno | activity | Actividades |
| 17 | Perfil de actividad | activity | Actividades→perfil |
| 18 | Matriz de confusión fichada→correcta | confusion | Errores |
| 19 | Heatmap de confusión (SVG) | confusion | Errores |
| 20 | Errores recurrentes por persona+pareja (AISLADO/RECURRENTE/HABITUAL) | confusion | Errores |
| 21 | Serie diaria completa | trend | Evolución |
| 22 | Media móvil (ventana completa) | core/trend | Evolución |
| 23 | Rolling 7/28 sobre días observados | trend | Evolución |
| 24 | Cobertura de calendario (días sin datos) | trend | Evolución |
| 25 | Buckets semana ISO / mes con Δ | trend | Evolución |
| 26 | Matriz frecuencia×impacto (medianas) | trend | Errores/Evolución |
| 27 | Pareto (tareas/personas/actividades) con 80/20 REAL | pareto | Pareto |
| 28 | Alertas deterministas A1-A11 | alerts | Resumen |
| 29 | Índice de prioridad 0-100 con desglose | alerts | Resumen TOP5 |
| 30 | TOP 5 prioridades | alerts | Resumen |
| 31 | Calidad de datos (causas OPERATIVO/DATOS/REVISIÓN/CONTROL) | dataQuality | Calidad |
| 32 | Calidad del mapping (sin mapeo/ambiguo/OTRA/versiones) | dataQuality | Calidad |
| 33 | modoVolumen por persona/día | dataQuality | Calidad |

### 10.2 ALERTAS A1–A11 (FASE 16 — exactas `[C]` alertAnalytics.js)

| ID | Nombre | Condición exacta | Umbral default | Severidad | Dónde |
|---|---|---|---|---|---|
| A1 | TASA_CRECIENTE | tarea con `deltaPP > umbralCambioPP` entre mitades Y evidencia suficiente en ambas | 5 pp | ALTA | Resumen |
| A2 | RACHA_PERSONA | persona con `maxRacha ≥ rachaDias` | 3 | ALTA | Resumen |
| A3 | CONCENTRACIÓN | Pareto de tareas: `total>0`; título Top-n; severidad ALTA si `pctElementos80 ≤ 20`; afirma 80/20 solo si cumple | 80/20 | ALTA/MEDIA | Resumen |
| A4 | TURNO_PEOR | turno con `registros ≥ minObservaciones` y `pctError > tasaGlobal + umbralTurnoPP` | 3 obs, +10 pp | MEDIA | Resumen |
| A5 | OTRA_VOLUMEN | tarea OTRA con `uds ≥ otraUdsMinimas` O `horasAfectadas ≥ impactoHorasAltas` | 100 uds / 4 h | MEDIA | Resumen |
| A6 | CONFUSION_REPETIDA | celda de confusión con `casos ≥ repeticionesConfusion`; severidad ALTA si `dias ≥ recurrenciaHabitual` | 3 / 5 | ALTA/MEDIA | Resumen |
| A7 | PERSONA_RECURRENTE | persona con `diasConError ≥ recurrenciaHabitual` | 5 | ALTA | Resumen |
| A8 | IMPACTO_ALTO | tarea con `0 < errores ≤ minObservaciones` Y `horasAfectadas ≥ impactoHorasAltas` | 3 / 4 h | MEDIA | Resumen |
| A9 | PERSONA_EMPEORA | tendencia persona EMPEORA con evidencia | minDiasComparar | MEDIA | Resumen |
| A10 | PERSONA_MEJORA | tendencia persona MEJORA con evidencia | 3 | INFO | Resumen |
| A11 | SIN_HORA | categoría SIN HORA con `registros ≥ minObservaciones` Y `pesoRelativo ≥ 50%` | — | INFO | Resumen |

Sin registros → sin alertas; sin errores → sin alertas; vacío → sin alertas (3 tests dedicados).

### 10.3 ÍNDICE DE PRIORIDAD (FASE 17 — fórmula reproducible `[C]` alertAnalytics.js:185-229)

```
score = round( 100 · Σ_i (peso_i · c_i) / Σ_i peso_i )      c_i = valor_i / máx_i (máx del conjunto candidato; 0 si máx=0)
   componentes i:  frecuencia (errores), tasa (0-100), horas (afectadas),
                   recurrencia (días), tendencia (max(0, deltaPP)/máx deltaPP), personas
   pesos default:  20/20/20/15/15/10 (configurables)
   candidatos:      tareas con errores>0 u horas>0; personas con errores>0
   nivel:           score ≥ 60 → ALTA · ≥ 35 → MEDIA · resto BAJA (configurable)
   orden:           score desc
   desglose:        SIEMPRE visible: {valor, peso, contribución redondeada} por componente + flecha tendencia
   TOP 5:           computeTopPrioridades(records, cfg, 5)
```

### 10.4 CALIDAD DE DATOS (FASE 18 — separación operativo vs datos)

| Problema | Categoría | Contamina ranking de personas |
|---|---|---|
| Sección 1 (fichaje erróneo) | OPERATIVO | SÍ |
| Sección 4 (horas sin volumen) | OPERATIVO | SÍ |
| Sección 2 (ambigüedad mapping) | DATOS | NO (imputado a tarea/mapping) |
| Sección 5 (sin mapping) | DATOS | NO |
| Secciones 6/7 (revisión manual) | REVISIÓN | NO |
| Sección 3 (correcta) | CONTROL | NO |
| SIN HORA | CALIDAD DEL DATO (no error) | NO |
| OTRA | clasificación pendiente (DATOS) | NO (visible aparte) |

`[T]` analytics_dataquality (9: §49 conteos, §50 causas suman 100 %, §30/§31 mapping) + v63 (2 casos de separación) + analytics_edge.

---

## 11. PERSISTENCIA — MAPA COMPLETO (FASE 20)

### 11.1 IndexedDB

```
IndexedDB
├── spec_history_db (v1)
│   ├── mappings              keyPath: version (numérico incremental, sin índices)
│   │    {version, nombre, fechaImportacion, timestamp, hash(SHA-256), hashAlgoritmo, nRows, rows[8 col]}
│   └── person_daily_records  keyPath: key ("login|fechaISO"); índices: login, fechaOperativaISO, semana, mes
│        (estructura §7.4; upsert versionado por fingerprint; previousVersions cap 10; NUNCA se borra)
└── spec_decisions_db (v1)
    └── decisions             keyPath: sessionId; índice savedAt
         {sessionId, decisions, auditLog, savedAt, appVersion, mappingHash}
```

| Store | Quién escribe | Quién lee | Se elimina | Si está corrupto | Si no existe |
|---|---|---|---|---|---|
| mappings | guardarMappingVersion (import/reemplazo/hook post-análisis) | cargarUltimoMapping (arranque + versionado) | NUNCA | reject → mapping no persiste (app funciona sin él) | se crea en primer onupgradeneeded |
| person_daily_records | persistirPersonDailyRecords (serializado por _persistChain) | cargarTodosRecords (Patrones) | NUNCA | getAll lanza → catch en UI (histórico vacío) | se crea al primer análisis |
| decisions (backup) | idbBackupDecisions (en cada persistDecisions; y si LS falla) | idbRestoreDecisions (solo si LS vacío; cursor inverso savedAt → más reciente) | NUNCA | reject → no restaura | fallback limpio |

### 11.2 localStorage — 8 claves exactas

| Clave | Qué guarda | Escribe | Lee | Borra | Default si falta |
|---|---|---|---|---|---|
| `spec_theme` | light/dark/auto | theme-toggle | arranque + matchMedia + ciclo | nunca | 'auto' |
| `spec_state` | {queries, reporte, stats, savedAt} del último análisis OK | persistState (tras análisis) | restoreState (arranque); indicador | clearPersistedState (indicador/reinicio) | sin sesión previa |
| `spec_auto_advance` | 'true'/'false' | checkbox | setupReviewTab | nunca | false |
| `spec_decisions` | {decisions, auditLog, undoStack, savedAt, appVersion, schemaVersion, mappingHash, sessionId} | persistDecisions (cada decisión/undo/mapping CRUD) | restoreDecisions, beforeunload | nunca (solo usuario/manual) | sin decisiones |
| `spec_productividades` | mapa 6 actividades → uds/h | guardarProductividades | cargarProductividades (fusión con defaults) | nunca (reset reescribe defaults) | PARAMS defaults |
| `spec_task_overrides` | {tareaNorm: {actividad, productividad, taskWmsDisplay, updatedAt}} | guardar/resetTaskOverride | cargarTaskOverrides | nunca (reset borra clave interna) | {} |
| `spec_session_id` | 'sess-<base36>-<rand>' | generarSessionId (1ª vez) | generarSessionId | nunca | se genera |
| `spec_stat_config_v1` | 24 umbrales | saveConfig | loadConfig (fusión defensiva) | resetConfig | DEFAULT_CONFIG |

**sessionStorage: NO SE USA en absoluto** (grep 0 resultados). Sin cookies, sin OPFS, sin Cache API de datos.

### 11.3 Migraciones

Ninguna: ambas BD están en versión 1 y `onupgradeneeded` solo crea stores si no existen. La "migración" de históricos v6.1/v6.2 es lógica (fingerprint v2 versiona una vez al reprocesar), no de esquema.

---

## 12. IMPORTACIÓN / EXPORTACIÓN (FASES 5 y 19)

### 12.1 Importación — especificación exhaustiva (FASE 5)

| Aspecto | Regla |
|---|---|
| Extensiones | .xlsx, .xlsm, .xlsb (error explícito para otras) |
| Tamaño máx | 50 MB configurables (0 desactiva el check) |
| Tamaño mín | ≥4 bytes (firma ZIP/OLE2) |
| Cantidad | 1..N archivos por tipo (arrays; worker normaliza) |
| Detección de tipo | por hojas/cabeceras (F-002): MAPPING con 8 columnas → mapping; Site name+Hours without volume → horas; DATE+WMS_TASK+WMS_UOM → volumen; Volume Without Hours → volSinHoras |
| Hoja esperada | EXPORT (case-insensitive) o PRIMERA hoja (fallback documentado); mapping: hoja que contenga "MAPPING" |
| Columnas obligatorias | horas: Site name, Department, Activity, Subactivity, Date, HR Task, WMS Login, Name, Hours without volume · volumen: DATE, SAP_CODE, CUSTOMER, WMS_TASK, WMS_LOGIN, USER_NAME, WMS_UOM · VSH: Site name, Department, Activity, Subactivity, Date, HR Task, WMS Login, Name, Volume Without Hours · mapping: las 8 estructurales |
| Filtrado de pie | primera col (o DATE) nula; empieza por "TOTAL"; contiene "FILTROS APLICADOS" |
| Fechas | Date/serial Excel base 1899-12-30 (floor)/dd-MM-yyyy es-ES/ISO/fallback; TODO date-only UTC |
| Horas/números | numberFrom es-ES (coma decimal, punto miles — divergencias documentadas) |
| Registros vacíos | fila sin Site name/DATE → fuera del transformador |
| Duplicados | no se rechazan: ClaveNatural → PosibleDuplicado (q01/q02/q09) + duplicidad de mapping (F-064) |
| Archivos inválidos/corruptos | pre-validación + error de parseo con mensaje accionable; basura que SheetJS parsea como Sheet1 vacía → rechazada por validarWorkbook/throw de columnas |
| Progreso | 0→100 % con etiqueta por consulta (worker → UI) |
| Fallback | main-thread si Worker no disponible o falla |
| Mensajes | inline en dropzone + toasts + registro de ejecución |

### 12.2 Exportaciones — inventario completo (FASE 19)

| Exportación | Origen | Formato | Nombre | Filtros aplicados | Encoding |
|---|---|---|---|---|---|
| Tabla del visor | STATE.queries | XLSX | `<tabla>.xlsx` | orden del visor | fechas dd/mm/yyyy |
| Tabla del visor | STATE.queries | CSV | `<tabla>.csv` | orden del visor | UTF-8 BOM, `;`, CRLF, anti-inyección |
| REPORTE (por sección) | STATE.reporte | XLSX/CSV | `Reporte_CAMBIOS_HR...` | filtro de sección activo | ídem |
| Correcciones aprobadas | decisions | XLSX/CSV | `Correcciones_aprobadas_<ts>` | SOLO aceptadas | ídem |
| Auditoría | auditLog | CSV | `Auditoria_decisiones_<ts>` | completo | ídem |
| Mapping | UI.mappingCurrent | XLSX | `mapping_export_<ts>` | filtro/búsqueda NO (completo) | — |
| Patrones (7 vistas) | snapshot filtrada | XLSX | `patrones_resumen|personas|tareas|actividades|errores|evolucion|historico_<fecha>` | filtros globales activos | fechas dd/mm/yyyy |
| Query individual | cualquier query | XLSX/CSV | por botón | — | ídem |

**Comportamiento ante caracteres especiales (CSV `[C]`):** prefijo `'` para `=+-@`; quoting doble para `;`, `"`, `\n`, `\r`; comillas dobladas; BOM; CRLF; null→''; Date→dd/mm/yyyy. **XLSX:** sin protección de fórmulas (SheetJS escribe tipos nativos; el riesgo CSV-injection es de CSV/visualización, mitigado en CSV; XLSX sin clamping — documentado como aceptado). Errores: quota de descargas → toast; datos vacíos → archivo con cabecera.
---

## 13. UI/UX — COMPORTAMIENTO ESPERADO POR PANTALLA (FASE 23)

> Esta sección define **cómo debe comportarse la interfaz** (contrato de comportamiento), NO audita si está bien hecho. Estructura = percepción esperada; el auditor valida contra la app real.

### 13.1 Estructura y navegación global
- **Header:** logo, título con badge v6.3, búsqueda global (aria-live de resultados), indicador de persistencia ("Sin guardar"/"Guardado HH:MM" con acción de borrar), toggle de tema (claro/oscuro/auto), estado global ("Sin procesar"→"Completado").
- **Tabs (10):** Cargar y analizar (default activa), Revisar, Resultados, Mapping, Reporte HR, Patrones, Trazabilidad, Auditoría, Exportar, Ayuda. Rol tablist; flechas ←→ navegan; skip-link primero en foco.
- **Modo oscuro:** contraste AA verificado por axe (color-contrast); persistido; auto sigue al SO.
- **Responsive:** desktop-first; sin overflow horizontal a 768 px (verificado E2E); breakpoints 720/1100 px; filtros en fieldsets colapsables.
- **Focus-visible global** (v6.3), `prefers-reduced-motion` respetado.

### 13.2 Cargar y analizar
- Dropzone unificada grande con estados: vacía ("Arrastra…"), hover, con archivos (chips por tipo con ✕), error inline. Enter abre file chooser (a11y).
- Checklist por tipo: nº archivos, nº filas, check/pendiente. Botón ANALIZAR deshabilitado hasta 4 tipos; al ejecutar: progreso 0-100 con etiqueta de fase; toasts al terminar; auto-navegación a Revisar.
- Tarjeta "Mapping activo" (nombre, versión, hash, botón cambiar). Registro de ejecución (log colapsable).
- **Estados:** inicial (vacío con instrucciones), cargado parcial, listo, analizando (loading), completado, error (toast + detalle).

### 13.3 Revisar incidencias
- Layout 2 columnas: lista de tarjetas (izq) + detalle (der). Filtros arriba (sección, turno, estado, búsqueda).
- Tarjeta persona/día: persona, login, fecha operativa + semana, turno(s) con badge, nº incidencias, horas, estado de decisión (color), aviso ⚠ si el filtro de turno oculta registros SIN HORA.
- Detalle: KPIs del día, tabla Fichajes del día (mensaje explícito por registro sin hora), tabla Actividades y reparto con sub-filas por tarea y columna Fuente, lista de incidencias con propuestas.
- Acciones por incidencia: Aceptar / Rechazar / Mantener + selector de tarea final (datalist) + motivo. UNDO (decisión y última acción). Auto-avance opcional.
- Estados: vacío (sin análisis, mensaje guía), con datos, filtrado sin resultados (mensaje de filtro), decisión tomada (tarjeta actualizada, navegación al siguiente si auto-avance).

### 13.4 Resultados
- KPIs de cabecera clicables (drilldown a tabla). Visualizaciones SVG. Listado de 17 tablas; visor con orden por columna, contador, scroll virtual (<300 filas en DOM), export por tabla. Estados: vacío / con datos / fila seleccionada (panel detalle lateral con TODAS las columnas).

### 13.5 Mapping
- Tabla completa (scroll), stats (entradas/duplicados/ambigüedades/hash), búsqueda + filtros Customer/Task WMS, badges y resaltado de duplicados/ambigüedades, acciones por fila (Editar/Eliminar), botones Importar/Exportar/Nuevo, modal de edición precargado con confirmación nativa para eliminar. Estados: sin mapping (mensaje + solo importar), con mapping, filtrado vacío.

### 13.6 Reporte HR
- Tabla REPORTE completa con 20 columnas, filtro por sección (1-7 + todas), contadores, export XLSX/CSV del filtro activo. Estado vacío sin análisis.

### 13.7 Patrones
- Encabezado: filtros globales en 3 fieldsets con legend (fechas/persona/turno/actividad/decisión/semana/mes + task/cliente/mapping), ⚙ CONFIGURACIÓN ESTADÍSTICA (details con grid de 24 campos + guardar/reset), selector de comparación de periodos (modo mitades/manual + 4 fechas + reset).
- Sub-pestañas (control segmentado con role=tab y aria-selected, Enter activa): Resumen, Personas, Tareas, Actividades, Errores, Evolución, Pareto, Calidad de datos.
- **Resumen:** jerarquía KPIs (4 primarios con tooltip → grupo "Impacto y alcance") → Evolución con rangos visibles → TOP 5 con desglose → Alertas por severidad → mini-listas quién/qué/dónde.
- **Tablas Patrones:** cabeceras sticky, hover, indicador ⇅ de orden, tooltips de métricas, alineación numérica derecha, badge MUESTRA PEQUEÑA, estados vacíos unificados (pat-empty) con hint accionable.
- **Evolución:** gráfico de líneas con serie+MM (leyenda), selector de granularidad, nota de cobertura («N días sin datos en el rango — un día sin datos no es un día con 0 errores»), rangos A/B siempre visibles con nº de días con datos y aviso de evidencia insuficiente.
- **Pareto:** banner de 80/20 (cumplida/NO cumplida) + tabla curva con % acumulado; métrica nombrada.
- **Calidad:** leyenda de colores semánticos (OPERATIVO/DATOS/REVISIÓN/CONTROL), tablas de causas y mapping.
- **Estados:** loading (spinner pat-loading al abrir), vacío histórico (estado vacío con CTA), vacío por filtro (por vista), con datos.
- **A11y:** th.sortable con tabindex/title/aria-sort; pv-tab con role/aria-selected/Enter; tablas con th scope; contraste AA claro/oscuro; focus visible; gráficos SVG con textos legibles.

### 13.8 Trazabilidad / Auditoría / Exportar / Ayuda
- Trazabilidad: selectores tabla+fila → árbol de orígenes (archivo/fila/joins). Auditoría: cadena cronológica con estado (válida/rota), export CSV, vaciar con confirmación, UNDO última acción. Exportar: lista de exportaciones disponibles con descripción. Ayuda: manual integrado (incluye atajos y limitaciones).

---

## 14. SEGURIDAD (FASE 22 — solo lo implementado, sin inventar)

| Mecanismo | Implementación | Verificación |
|---|---|---|
| CSP | modular: sin unsafe-eval, style unsafe-inline documentado; standalone: hashes SHA-256 por script inline (0 unsafe) | `[C]` index.html; `[E]` standalone.spec |
| Cabeceras | X-Content-Type-Options nosniff; Referrer-Policy no-referrer | `[C]` |
| XSS | escapeHtml/escapeAttr aplicados en TODOS los renders; escapeAttr NO filtra javascript: (documentado, sin URLs dinámicas) | `[T]` escape_html (24) |
| CSV injection | prefijo `'` a `=+-@` + quoting (OWASP) | `[T]` csv_injection (17) |
| Validación de archivos | extensión/MIME/50 MB/estructura/defensa en profundidad | `[T]` input_validation (24) |
| Auditoría | hash chain SHA-256 estricta sin fallback; INSECURE_CONTEXT si no hay crypto.subtle | `[T]` audit_log_chain (22) |
| Almacenamiento | 100 % local; sin envío de datos a red (CSP connect-src 'self') | `[C]` |
| Hashes de contenido | MANIFEST_SHA256.txt (157) + validador; SBOM CycloneDX | `[D]` validate_manifest PASS |
| Dependencias | SheetJS 0.18.5 con 2 vulnerabilidades conocidas (Prototype Pollution, ReDoS) — **riesgo ACEPTADO** con mitigaciones documentadas: límite 50 MB, validación de estructura, offline (AUD-MED-005, R-05) | `[D]` REGISTRO_RIESGOS |
| No implementado (NO afirmar que existe) | auth/usuarios, rate limiting, sanitización de URLs, cifrado en reposo, cabequeras HTTP del servidor (depende del hosting), SRI de subrecursos | — |

---

## 15. PWA / OFFLINE / SERVICE WORKER (FASE 21)

### 15.1 Service Worker (`sw.js`) — hechos exactos

- CACHE `spec-web-v6-3` (versionado manual); SW_VERSION 6.3.0.
- **Precache (19 assets `[C]` sw.js:22-42):** `./`, `./index.html`, `./styles.css`, `./app.js`, `./ui.js`, `./charts.js`, `./worker.js`, `./xlsx.full.min.js`, `./logo_idl.png`, `./manifest.json`, y los 9 `./analytics/*.js`.
- install: `Promise.allSettled` de `cache.add()` individuales (un fallo individual no rompe todo) + `skipWaiting`.
- activate: borra toda caché ≠ CACHE + `clients.claim`.
- fetch: SOLO GET same-origin; **cache-first con revalidación en background** (res 200/basic actualiza); network → caché si OK; offline: document → `./index.html` del caché; resto → `Response 504 'Offline'`.
- message `SKIP_WAITING` → skipWaiting (**huérfano**: la página nunca lo envía — D-007; la actualización depende del cambio de nombre de caché al desplegar).
- **Los .xlsx del usuario NUNCA se cachean** (comentario explícito).

### 15.2 Manifest

name "SPEC Web v6.2 — ID Logistics" (⚠ D-001), short_name "SPEC Web", version 6.3.0, display standalone, start_url ./index.html, scope ./, orientation any, lang es, theme #0f766e, background #fff, 1 icono PNG (any maskable), 3 shortcuts (carga/revisar/patrones con hash-navigation), categories business/productivity/utilities.

### 15.3 Offline / standalone / diferencias modular vs standalone

| Aspecto | Modular (index.html) | Standalone (SPEC_AUTONOMO_v6.html) |
|---|---|---|
| Archivos | 20 + worker | 1 solo (~1,5 MB) |
| PWA/SW | SÍ (instalable, offline) | NO (sin manifest/SW) |
| Analytics | 9 archivos externos | embebidos inline (fix D-20 v6.3, verificado por build) |
| CSP | style-src unsafe-inline | hashes SHA-256 por cada script inline |
| Persistencia | IndexedDB + localStorage | **LAS MISMAS CLAVES** (colisión si comparten origen — riesgo documentado) |
| Worker | SÍ | NO (motor en main-thread) |

**Offline:** tras la primera carga, la app funciona 100 % sin red (motor, análisis, IndexedDB); los archivos Excel provienen del disco del usuario en cada análisis. `[E]` pwa t4.

---

## 16. MATRIZ DE DEPENDENCIAS (FASE 24)

Formato: **Funcionalidad | Depende de | Alimenta a | Persistencia | Criticidad**. (LS=localStorage, IDB=IndexedDB, M=memoria, S=SW cache)

| F | Funcionalidad | Depende de | Alimenta a | Persistencia | Crit. |
|---|---|---|---|---|---|
| F-001 | Carga unificada | F-002,F-003,F-004 | F-014,F-017 | M | CRÍT |
| F-002 | Detección tipo | F-004 | F-001 | M | ALTA |
| F-003 | Validación pre-lectura | — | F-004,F-001 | — | ALTA |
| F-004 | Lectura Excel | F-003 | F-006-9 | M | CRÍT |
| F-005 | Validación workbook | F-004 | F-006-9 | — | ALTA |
| F-006/7/8 | Transformadores | F-004,F-005 | F-019-21, F-017 | M | CRÍT |
| F-009 | Leer mapping | F-004,F-005 | F-022, F-061+ | M | CRÍT |
| F-010 | Multi-archivo | F-001 | F-014,F-017 | M | ALTA |
| F-011 | Checklist | F-001 | usuario | M | BAJA |
| F-012 | Import mapping | F-009 | F-061,F-066 | IDB | ALTA |
| F-013 | Reset/quitar | F-001 | STATE | LS(spec_state) | MEDIA |
| F-014 | Worker | F-001,F-017 | F-018 | — | ALTA |
| F-015 | Fallback main | F-017 | F-018 | — | MEDIA |
| F-016 | Progreso/log | F-017 | UI | M(log) | MEDIA |
| F-017 | Orquestador | F-006-9,F-019-33 | TODO | M | CRÍT |
| F-018 | Post-análisis | F-014,F-017 | F-048,F-080,F-112 | IDB+LS | ALTA |
| F-019 | q01 | F-006 | q07,reporte,q17 | M | CRÍT |
| F-020 | q02 | F-007 | q03,q05,q13,q16 | M | CRÍT |
| F-021 | q09 | F-008 | q10,q15 | M | ALTA |
| F-022 | q12 | F-009 | q13 | M | CRÍT |
| F-023 | q13 | F-020,F-022 | reporte,q07,q17 | M | CRÍT |
| F-024/25/26 | q03/q05/q10 | F-020/21 | q07 | M | ALTA |
| F-027/28 | q14/q15 | F-023/21 | q07 | M | MEDIA |
| F-029 | q16 | F-023 | Resultados | M | ALTA |
| F-030 | q07 | F-019,q24-28 | reporte,detalle | M | CRÍT |
| F-031 | q08 | F-019-30 | Resultados | M | ALTA |
| F-032 | REPORTE | F-019,F-023,F-030 | F-048,F-078 | M | CRÍT |
| F-033 | Materialidad | — | reporte,q07 | M | MEDIA |
| F-034/35/36/37 | fx_Normaliza*/Fecha/numberFrom | — | TODO | — | CRÍT |
| F-038/39/40 | Turnos/fechaOp/hora | F-036 | q17, filtros | M | CRÍT |
| F-041 | fx_ActividadAnalisis | F-034 | F-042-46 | M | CRÍT |
| F-042 | resolverProductividad | F-041,F-047 | F-044 | — | ALTA |
| F-043 | resolverClasificacionTarea | F-041,F-047,F-070 | F-045, detalle | — | CRÍT |
| F-044/45 | repartir (act/tarea) | F-042/43 | F-046 | — | CRÍT |
| F-046 | q17 | F-019,F-023,F-038-45 | F-048,F-078 | M | CRÍT |
| F-047 | Productividades ref. | — | F-042/43/69 | LS | ALTA |
| F-048 | Panel Revisar | F-046,F-032 | decisiones | M | CRÍT |
| F-049 | Filtros revisión | F-038-40 | F-050 | M | ALTA |
| F-050 | Lista tarjetas | F-048 | F-051 | M | MEDIA |
| F-051 | Detalle p/d | F-046 | usuario | M | CRÍT |
| F-052/53/54 | Aceptar/Rechazar/Mantener | F-048,F-051 | F-072,F-076,F-060 | LS+IDB | CRÍT |
| F-055 | Motivo/confianza | F-030 | F-052-54 | LS | MEDIA |
| F-056 | UNDO decisión | F-052-54 | F-072,F-076 | LS+IDB | ALTA |
| F-057 | UNDO última | F-056 | auditoría | LS | MEDIA |
| F-058 | Auto-avance | F-052 | UX | LS | BAJA |
| F-059 | Navegación/atajos | F-048 | UX | — | BAJA |
| F-060 | Sincronizar decisions→records | F-052 | F-080 | IDB | ALTA |
| F-061 | Visualizar mapping | F-009 | usuario | M | ALTA |
| F-062 | Búsqueda mapping | F-061 | UX | M | BAJA |
| F-063 | CRUD mapping | F-061 | F-072,F-066 | LS+IDB | ALTA |
| F-064 | Dupli/ambigüedades | F-061 | F-096 | M | MEDIA |
| F-065 | Export mapping | F-061 | descarga | — | BAJA |
| F-066 | Versiones mapping IDB | F-012 | F-067 | IDB | CRÍT |
| F-067 | Auto-carga mapping | F-066 | F-001, F-017 | IDB | ALTA |
| F-068 | Diálogo sustitución | F-066 | F-067 | IDB | ALTA |
| F-069 | Editor productividades | F-047 | F-043 | LS | ALTA |
| F-070 | Overrides por tarea | F-041 | F-043,F-071 | LS | CRÍT |
| F-071 | Aplicar y reprocesar | F-070,F-083 | F-080 | IDB+LS | CRÍT |
| F-072 | Audit log | F-052-56,F-063 | F-075,F-109 | LS+IDB | CRÍT |
| F-073 | entryHash | F-072 | F-074 | — | CRÍT |
| F-074 | Verificar cadena | F-073 | F-075 | — | CRÍT |
| F-075 | Panel auditoría | F-074 | usuario | M | MEDIA |
| F-076 | Persistir decisiones | F-072 | F-077 | LS+IDB | CRÍT |
| F-077 | Restaurar decisiones | F-076 | F-048 | LS+IDB | ALTA |
| F-078 | generarPersonDailyRecords | F-046,F-032 | F-080 | M | CRÍT |
| F-079 | fingerprint v2 | F-078 | F-080 | — | CRÍT |
| F-080 | Upsert versionado | F-078,F-079 | F-081,F-084+ | IDB | CRÍT |
| F-081 | Cargar históricos | F-080 | Patrones | IDB | ALTA |
| F-082 | previousVersions | F-080 | trazabilidad | IDB | ALTA |
| F-083 | recomputarPersonaDia | F-046,F-069,F-070 | F-080 | IDB | CRÍT |
| F-084 | Panel Patrones | F-081,F-085-98 | usuario | M(memo) | ALTA |
| F-085 | Filtros globales | F-081 | todas las vistas | M | ALTA |
| F-086 | Config estadística | — | F-087-98 | LS | ALTA |
| F-087 | Resumen | F-084 | usuario | M | ALTA |
| F-088 | Personas | F-084 | F-089 | M | ALTA |
| F-089 | Perfil persona | F-088 | usuario | M | MEDIA |
| F-090 | Tareas | F-084 | F-089 | M | ALTA |
| F-091 | Actividades | F-084 | usuario | M | ALTA |
| F-092 | Errores | F-084 | usuario | M | ALTA |
| F-093 | Evolución | F-084 | usuario | M | ALTA |
| F-094 | Comparación A/B | F-084 | F-087,F-093 | M | ALTA |
| F-095 | Pareto | F-084 | F-097(A3) | M | MEDIA |
| F-096 | Calidad de datos | F-084 | usuario | M | ALTA |
| F-097 | Alertas A1-A11 | F-084 | F-087 | M | ALTA |
| F-098 | Prioridad+TOP5 | F-084 | F-087 | M | ALTA |
| F-099 | Export analytics | F-084 | descarga | — | MEDIA |
| F-100 | Panel Resultados | F-017 | usuario | M | ALTA |
| F-101 | Visor tablas | F-100 | usuario | M | ALTA |
| F-102 | Gráficos | F-017 | Resultados | M | MEDIA |
| F-103 | KPI drilldown | F-100 | visor | M | MEDIA |
| F-104 | Panel Reporte | F-032 | F-109 | M | ALTA |
| F-105 | Trazabilidad | F-017 | usuario | M | MEDIA |
| F-106 | Búsqueda global | F-100 | visor | M | BAJA |
| F-107 | exportToXlsx | F-017 | descargas | — | ALTA |
| F-108 | exportToCsv | F-017 | descargas | — | ALTA |
| F-109 | Exports específicos | F-104,F-072,F-084 | descargas | — | MEDIA |
| F-110 | Tabs | — | todo | LS(theme) | MEDIA |
| F-111 | Tema | — | UX | LS | BAJA |
| F-112 | Estado sesión | F-017 | F-048 (restaurar) | LS | ALTA |
| F-113 | Toasts/modales | — | UX | M | MEDIA |
| F-114 | Detalle/preview | F-100 | usuario | M | MEDIA |
| F-115 | Atajos/beforeunload | — | UX | — | BAJA |
| F-116 | Ayuda | — | usuario | — | BAJA |
| F-117 | CSP/cabeceras | — | todo | — | ALTA |
| F-118 | escapeHtml/Attr | — | todos los renders | — | CRÍT |
| F-119 | Service Worker | — | F-121 | S | MEDIA |
| F-120 | Manifest | — | instalación | — | BAJA |
| F-121 | Offline | F-119 | usuario | S | MEDIA |
| F-122 | Standalone | F-017(inline) | usuario | LS+IDB (¡mismas claves!) | MEDIA |
---

## 17. MATRIZ DE CASOS DE PRUEBA (FASE 25)

> Casos TC organizados por área. Cada uno indica: **Funcionalidad · Caso · Entrada · Resultado esperado**. Los marcados `[EXISTE]` ya tienen test automatizado que lo cubre (archivo entre paréntesis); el resto son casos que el auditor debe ejecutar manualmente o exigen test nuevo.

### 17.1 Ingesta y carga (F-001..F-018)

- **TC-001** F-001 · carga válida · 4 archivos reales drive · 4 claves en STATE.archivos y checklist OK. [EXISTE: smoke.spec t2]
- **TC-002** F-001 · 7 archivos (2 por tipo) · 02=1486 filas, 09=490, análisis OK en worker sin warnings. [EXISTE: multifile_worker t2]
- **TC-003** F-003 · archivo .csv/.exe · rechazo con mensaje de extensión. [EXISTE: input_validation]
- **TC-004** F-003 · archivo 0 bytes · rechazo. [EXISTE]
- **TC-005** F-003 · archivo >50 MB · rechazo con tamaño. [EXISTE]
- **TC-006** F-003 · MIME raro (text/plain) · WARNING, no rechazo. [EXISTE]
- **TC-007** F-004 · archivo basura de 4+ bytes · error "no se pudo interpretar". [EXISTE: input_validation defensa profundidad]
- **TC-008** F-005 · hoja EXPORT vacía / solo cabecera · error claro. [EXISTE]
- **TC-009** F-005 · workbook sin hoja EXPORT con datos en primera hoja · se usa la primera. [EXISTE]
- **TC-010** F-006 · archivo horas sin columna requerida · throw "Faltan columnas…". [EXISTE]
- **TC-011** F-006 · pie "TOTAL"/"FILTROS APLICADOS" · excluidos (743 no 745). [EXISTE: regression_bugs Bug 2]
- **TC-012** F-002 · archivo con hojas de dos tipos simultáneos · clasifica por orden de reglas (mapping>horas>volumen>VSH) — verificar comportamiento documentado. [NUEVO]
- **TC-013** F-001 · 20 archivos de golpe en la dropzone · sin degradación ni errores. [NUEVO]
- **TC-014** F-013 · quitar un archivo y volver a analizar · el análisis refleja solo los restantes. [NUEVO]
- **TC-015** F-014 · worker falla (simulado) · fallback main-thread + análisis completo. [NUEVO — hoy solo inferible]

### 17.2 Motor (F-019..F-033)

- **TC-016** F-019 · registro con fecha inválida/login vacío/horas 0 · excluido con MotivoInvalido correcto. [EXISTE: q01 vía equivalencia]
- **TC-017** F-019 · dos filas idénticas en 2 archivos · ambas PosibleDuplicado. [EXISTE implícito multifile; smoke fixtures duplicados]
- **TC-018** F-022 · mapping con 2 TASK_SPEC para la misma triple · EstadoMapeoSPEC=AMBIGUO. [EXISTE: equivalencia + mapping.spec]
- **TC-019** F-023 · volumen de tarea sin mapping · EstadoMapeoFinal=SIN MAPEO. [EXISTE]
- **TC-020** F-030 · las 10 clasificaciones de conciliación · cada una con su NivelConfianza/Evidencia. [EXISTE: equivalencia valores]
- **TC-021** F-032 · persona/día con 3 tareas de volumen · 3 propuestas correctas (secciones 2/3/1). [EXISTE: equivalencia]
- **TC-022** F-032 · pass 2 idNum · observación "…coincidencia del numero de usuario". [EXISTE]
- **TC-023** F-032 · multi HR task + volumen · sección 6 con HRTaskDistintas en observación. [EXISTE]
- **TC-024** F-033 · materialidad en umbrales exactos 0.0833…/0.25/1/4 · tier superior. [EXISTE: calcular_materialidad]
- **TC-025** F-033 · materialidad NaN · CRITICA (divergencia documentada). [EXISTE]
- **TC-026** F-017 · 50k filas sintéticas · <30 s, ≥10 tablas no vacías, no cuadrático. [EXISTE: performance + perf E2E]

### 17.3 Funciones puras (F-034..F-040)

- **TC-027..TC-032** por función: happy path, null/undefined, formato es-ES, seriales, límites — [EXISTE: fx_fecha 23, fx_normalizatexto 20, fx_normalizalogin 17 (BigInt 19 dígitos), number_from 21, turnos 27 (límites 05:59/06:00/13:59/14:00/21:59/22:00/00:00 + cobertura 1440), filtro_turnos 10 (MIXTO, SIN HORA, no-mutación)].

### 17.4 Clasificación y reparto (F-041..F-047)

- **TC-033** F-041 · las 3 picking manual explícitas + reparto AGV + ubicación con/sin AGV · clase correcta. [EXISTE: actividad_analisis]
- **TC-034** F-041 · tarea ambigua real (REPARTO A TIENDA AGV - BERSHKA) · OTRA (no inventa). [EXISTE]
- **TC-035** F-043 · prioridad completa override>actividad>default con Fuente correcta. [EXISTE: overrides_task]
- **TC-036** F-045 · conservación <1e-9 con 1/2/3 tareas y 1e9 uds. [EXISTE]
- **TC-037** F-046 · persona 2 tareas misma actividad productividades 100/200 · NO se mezclan; actividad "varias". [EXISTE: overrides_task q17 + overrides_v612 t7]
- **TC-038** F-046 · noche 02:15 · fecha operativa día anterior, turno NOCHE. [EXISTE: persona_dia]
- **TC-039** F-046 · day-level (sin hora) · SIN HORA, sin desplazamiento de fecha. [EXISTE]

### 17.5 Revisión y decisiones (F-048..F-060)

- **TC-040** F-048 · persona con 2 tareas WMS · UNA tarjeta con "Actividades y reparto". [EXISTE: mejoras_v6 t4]
- **TC-041** F-049 · filtro MAÑANA/TARDE/NOCHE en límites exactos · solo esos registros. [EXISTE: overrides_v612 t1-t3]
- **TC-042** F-049 · filtro SIN HORA · solo day-level + aviso ⚠ cuando aplica. [EXISTE t4]
- **TC-043** F-052 · aceptar · decision aceptada + auditLog ≥1 + persistencia + tarjeta actualizada. [EXISTE: smoke t6]
- **TC-044** F-052 · aceptar con tarea editada (datalist) · se guarda la editada. [NUEVO — parcial en manual]
- **TC-045** F-056 · aceptar→mantener→undo · restaura 'mantenida'; segundo undo → pendiente; audit=4. [EXISTE: mejoras_v6 t6]
- **TC-046** F-056 · undo tras recargar página · el stack persiste (spec_decisions). [EXISTE: undo_persist forma + indexeddb]
- **TC-047** F-057 · undo última acción con varias decisiones · deshace la última global. [EXISTE: smoke t7]
- **TC-048** F-060 · decidir y abrir Patrones · la decisión viaja al histórico. [EXISTE: patrones t12 + indexeddb]

### 17.6 Mapping (F-061..F-068)

- **TC-049** F-061 · visualización 167 filas + hash badge. [EXISTE: mapping.spec]
- **TC-050** F-063 · crear/editar/eliminar con audit + cadena íntegra. [EXISTE: mapping.spec]
- **TC-051** F-064 · badges duplicados/ambigüedades + resaltado. [EXISTE]
- **TC-052** F-066 · hash SHA-256 determinista, sensible a cualquier cambio de las 8 columnas, orden-independiente. [EXISTE: mapping_persist]
- **TC-053** F-067 · cerrar/abrir · mapping auto-cargado con hash y filas. [EXISTE: mejoras_v6 t2]
- **TC-054** F-068 · sustituir mapping con confirmación · TODOS los records nuevos llevan hash v2; los antiguos conservan v1. [EXISTE: mejoras_v6 t3, patrones t12]
- **TC-055** F-068 · hash corrupto en IDB · no auto-carga, estado vacío con mensaje. [NUEVO]

### 17.7 Overrides (F-069..F-071)

- **TC-056** F-070 · editar productividad de tarea desde UI · el motor la usa (Fuente OVERRIDE TASK_WMS, HE/peso/asignadas recalculadas). [EXISTE: overrides_v612 t5]
- **TC-057** F-070 · OTRA→PICKING AGV 150 · la tarea ENTRA al reparto. [EXISTE t6]
- **TC-058** F-070 · productividad inválida (0/negativa/texto) en tarea productiva · validación bloquea. [EXISTE: overrides_task validación; UI parcial]
- **TC-059** F-071 · cambiar override → reprocesar · versión ≥2 con previousVersions; núcleo intacto en no afectados. [EXISTE: overrides_v612 t8, patrones t13]
- **TC-060** F-069 · reset productividades · vuelve a defaults y recalcula. [NUEVO en UI]

### 17.8 Auditoría y persistencia de decisiones (F-072..F-077)

- **TC-061** F-074 · los 6 escenarios de manipulación de la cadena · detección con reason y brokenAt. [EXISTE: audit_log_chain — 22 tests]
- **TC-062** F-073 · contexto sin crypto.subtle · rechazo (sin fallback FNV). [EXISTE]
- **TC-063** F-076 · ciclo completo LS→reload→IDB→reload · recuperación con cadena íntegra. [EXISTE: indexeddb.spec t1]
- **TC-064** F-077 · restaurar desde IDB con cadena manipulada · ⚠ comportamiento no verificado (D-006). [NUEVO]
- **TC-065** F-076 · quota localStorage llena · backup IDB + sin crash. [NUEVO]

### 17.9 Histórico (F-078..F-083)

- **TC-066** F-079 · mismos datos+config → mismo fingerprint (idempotente). [EXISTE: v63]
- **TC-067** F-079 · cambia mapping/productividades/overrides/appVersion → fingerprint distinto. [EXISTE: v63]
- **TC-068** F-079 · históricos v6.1/v6.2 → se versionan UNA vez al reprocesar. [EXISTE: v63 inmutabilidad]
- **TC-069** F-080 · casos A-E de §9.5. [EXISTE: mapping_persist/overrides_task/patrones]
- **TC-070** F-082 · 11 versiones del mismo record · previousVersions mantiene SOLO 10. [EXISTE unit del cap; verificar en UI — NUEVO E2E]
- **TC-071** F-081 · 2 días procesados, cerrar/abrir · 6 records sin duplicados. [EXISTE: patrones t3-t4]
- **TC-072** F-080 · dos pestañas del navegador analizan a la vez (concurrencia) · _persistChain serializa; sin corrupción. [NUEVO]

### 17.10 Patrones/Analytics (F-084..F-099)

- **TC-073** F-084 · histórico vacío · estado vacío unificado en las 8 vistas. [EXISTE: patrones t1, v63 V4]
- **TC-074** F-085 · filtros combinados intersecan (NOCHE→1; RECUR→5; EMPEORA+NOCHE→0/vacío). [EXISTE: patrones t14]
- **TC-075** F-086 · config corrupta en LS → defaults sin crash. [EXISTE: analytics_core]
- **TC-076** F-086 · editar umbral (rachaDias) y guardar → cambia qué alertas A2 se disparan. [EXISTE: analytics_alerts configurables]
- **TC-077** F-088 · persona 5/5 días error · CRÍTICO + racha 4 + recurrencia 5; persona MEJORA→ATENCIÓN. [EXISTE: patrones t5]
- **TC-078** F-090 · PICKING SIN PAPEL 12/12 (100 %) y tarea no afectada sin imputación (§11). [EXISTE: patrones t6]
- **TC-079** F-090 · 1 oportunidad con 2 errores · 100 % + Inc./oport. 2,0 (sin clamp). [EXISTE: v63]
- **TC-080** F-092 · matriz 20051→20052 + HABITUAL + heatmap svg. [EXISTE: patrones t8]
- **TC-081** F-093 · MM7 null hasta 7º punto; rolling 7 con huecos (diasConDatos=7, tramo desde/hasta). [EXISTE: analytics_trend + v63]
- **TC-082** F-093 · día sin datos NO cuenta como 0 (cobertura explícita). [EXISTE: v63 V3]
- **TC-083** F-094 · A/B manual con rangos visibles + evidencia insuficiente + reset a mitades. [EXISTE: v63 V1]
- **TC-084** F-095 · Pareto: 80/20 afirmado solo si cumple; banner NO cumplida cuando procede. [EXISTE: analytics_pareto, v63 V7]
- **TC-085** F-096 · causas suman 100 %; OTRA visible; SIN HORA categoría propia. [EXISTE: analytics_dataquality]
- **TC-086** F-097 · alertas A2/A6/A5 con fixtures reales. [EXISTE: patrones t11]
- **TC-087** F-098 · TOP 5 ≤5 con desglose que suma los pesos. [EXISTE: analytics_alerts]
- **TC-088** F-084 · batería anti-NaN §58 (cero errores/personas/horas/uds, 1 día, legacy v6.1). [EXISTE: analytics_edge 14]

### 17.11 Resultados/Reporte/Exports/UI/PWA (F-100..F-122)

- **TC-089** F-101 · 743 filas renderizadas <5 s con <300 nodos DOM. [EXISTE: performance_e2e t2]
- **TC-090** F-104 · reporte filtrado por sección 1 · solo sección 1 en pantalla y en export. [EXISTE parcial; NUEVO el export filtrado]
- **TC-091** F-108 · payloads CSV (=HYPERLINK, =2+5+cmd…) neutralizados con prefijo '. [EXISTE: csv_injection]
- **TC-092** F-108 · delimitador ;, comillas, saltos, BOM, CRLF, null. [EXISTE]
- **TC-093** F-107 · export XLSX de tabla con fechas · celdas tipo d dd/mm/yyyy y columnas ordenadas. [NUEVO — D-011]
- **TC-094** F-109 · Correcciones_aprobadas contiene SOLO aceptadas con tareaFinal. [NUEVO]
- **TC-095** F-109 · exportarPatrones de 7 vistas XLSX con filtros activos. [NUEVO]
- **TC-096** F-111 · dark mode persiste tras recarga. [EXISTE: smoke t8]
- **TC-097** F-112 · restaurar sesión tras recarga · queries/reporte visibles sin reprocesar. [EXISTE implícito; NUEVO assert fuerte]
- **TC-098** F-115 · atajos de teclado documentados en Ayuda funcionan. [EXISTE parcial a11y t5]
- **TC-099** F-118 · payloads XSS en todos los inputs mostrados (persona, tarea, motivo) → escapados. [EXISTE: escape_html + smoke t1]
- **TC-100** F-119 · offline tras primera carga · navegación y análisis funcionan. [EXISTE: pwa t4]
- **TC-101** F-120 · manifest válido + instalable (display standalone, iconos servibles). [EXISTE: pwa t1]
- **TC-102** F-119 · despliegue de nueva versión (caché v6-4) · activate borra la anterior. [NUEVO]
- **TC-103** F-122 · standalone procesa 4 archivos → 214 propuestas + decisión génesis. [EXISTE: standalone.spec]
- **TC-104** F-122 · standalone y modular en el MISMO origen · comparten claves LS/IDB (riesgo R-21a) — documentar/verificar aislamiento. [NUEVO]
- **TC-105** A11y global · axe en las 8 pantallas restantes (Mapping, Patrones+8 vistas, Reporte, Trazabilidad, Auditoría, Exportar). [NUEVO — D-009]
- **TC-106** Responsive · 768 px sin overflow horizontal en todas las pestañas (hoy solo Patrones). [EXISTE v63 V6; extender]

---

## 18. MATRIZ DE COBERTURA ACTUAL (FASE 26)

Leyenda: ✅ implementado y verificado · ⚠️ existe pero con matices (ver nota) · ❌ ausente · N/A no aplica.

| F | Funcionalidad | Impl. | Doc. | Unit | E2E | UI real | Persist. | Riesgo |
|---|---|---|---|---|---|---|---|---|
| F-001 | Carga unificada | ✅ | ✅ | ⚠️ (validación solo) | ✅ | ✅ | M | BAJO |
| F-002 | Detección tipo | ✅ | ✅ | ❌ (solo E2E) | ✅ | ✅ | — | MEDIO |
| F-003 | Validación pre-lectura | ✅ | ✅ | ✅ (7) | — | ✅ | — | BAJO |
| F-004 | Lectura Excel | ✅ | ✅ | ✅ | ✅ | ✅ | — | BAJO |
| F-005 | Validación workbook | ✅ | ✅ | ✅ (9) | — | ✅ | — | BAJO |
| F-006/7/8 | Transformadores | ✅ | ✅ | ✅ | ✅ | — | — | BAJO |
| F-009 | Leer mapping | ✅ | ✅ | ✅ | ✅ | — | — | BAJO |
| F-010 | Multi-archivo | ✅ | ✅ | ⚠️ implícito | ✅ | ✅ | — | BAJO |
| F-011 | Checklist | ✅ | ⚠️ | ❌ | ⚠️ | ✅ | — | BAJO |
| F-012 | Import mapping | ✅ | ✅ | ⚠️ | ✅ | ✅ | IDB | BAJO |
| F-013 | Reset/quitar | ✅ | ⚠️ | ❌ | ⚠️ | ✅ | LS | MEDIO |
| F-014 | Worker | ✅ | ✅ | ❌ (D-012) | ✅ (por consola) | ✅ | — | MEDIO |
| F-015 | Fallback main | ✅ | ✅ | ⚠️ implícito | ❌ | ⚠️ | — | MEDIO |
| F-016 | Progreso/log | ✅ | ⚠️ | ⚠️ | ✅ | ✅ | M | BAJO |
| F-017 | Orquestador | ✅ | ✅ | ✅ (perf+equiv) | ✅ | — | M | BAJO |
| F-018 | Post-análisis | ✅ | ✅ | ⚠️ | ✅ | ✅ | IDB+LS | BAJO |
| F-019..F-032 | Q01-Q16+REPORTE | ✅ | ✅ | ✅ (21 integración) | ✅ | ✅ | M | BAJO |
| F-033 | Materialidad | ✅ | ✅ | ✅ (23) | — | ✅ | — | BAJO |
| F-034..F-040 | fx_* puras | ✅ | ✅ | ✅ (128 casos) | — | — | — | BAJO |
| F-041 | fx_ActividadAnalisis | ✅ | ✅ | ✅ (16) | — | — | — | BAJO |
| F-042/43 | Resolver clasificación | ✅ | ✅ | ✅ (13) | — | — | — | BAJO |
| F-044/45 | Reparto | ✅ | ✅ | ✅ (16) | ✅ | ✅ | — | BAJO |
| F-046 | q17 | ✅ | ✅ | ✅ (9) | ✅ | ✅ | — | BAJO |
| F-047 | Productividades ref. | ✅ | ✅ | ✅ contrato | — | ✅ | LS | BAJO |
| F-048 | Panel Revisar | ✅ | ✅ | ⚠️ (UI sin unit) | ✅ | ✅ | M | BAJO |
| F-049 | Filtros revisión | ✅ | ✅ | ✅ (10) | ✅ | ✅ | — | BAJO |
| F-050 | Lista/prioridad | ✅ | ⚠️ | ❌ | ⚠️ | ✅ | — | MEDIO |
| F-051 | Detalle p/d | ✅ | ✅ | ❌ | ✅ | ✅ | — | BAJO |
| F-052/53/54 | Acept/Rech/Mantener | ✅ | ✅ | ⚠️ | ✅ | ✅ | LS+IDB | BAJO |
| F-055 | Motivo/confianza | ✅ | ⚠️ | ❌ | ⚠️ | ✅ | LS | BAJO |
| F-056/57 | UNDO | ✅ | ✅ | ✅ (11) | ✅ | ✅ | LS+IDB | BAJO |
| F-058 | Auto-avance | ✅ | ⚠️ | ❌ | ❌ | ✅ | LS | BAJO |
| F-059 | Navegación/atajos | ✅ | ✅ | ❌ | ⚠️ a11y | ✅ | — | BAJO |
| F-060 | Sincronizar → records | ✅ | ✅ | ⚠️ | ✅ | ✅ | IDB | BAJO |
| F-061..F-065 | Mapping tab | ✅ | ✅ | ⚠️ | ✅ (mega-test) | ✅ | IDB/— | BAJO |
| F-066 | Versiones mapping | ✅ | ✅ | ✅ (8) | ✅ | — | IDB | BAJO |
| F-067 | Auto-carga | ✅ | ✅ | ⚠️ | ✅ | ✅ | IDB | BAJO |
| F-068 | Diálogo sustitución | ✅ | ✅ | ⚠️ | ✅ | ✅ | IDB | BAJO |
| F-069 | Editor productividades | ✅ | ✅ | ⚠️ | ✅ | ✅ | LS | BAJO |
| F-070 | Overrides por tarea | ✅ | ✅ | ✅ (17) | ✅ | ✅ | LS | BAJO |
| F-071 | Aplicar y reprocesar | ✅ | ✅ | ✅ | ✅ | ✅ | IDB | BAJO |
| F-072/073/074 | Audit chain | ✅ | ✅ | ✅ (22) | ✅ | ✅ | LS+IDB | BAJO |
| F-075 | Panel auditoría | ✅ | ✅ | ❌ | ⚠️ | ✅ | M | BAJO |
| F-076 | Persistir decisiones | ✅ | ✅ | ⚠️ forma | ✅ | — | LS+IDB | BAJO |
| F-077 | Restaurar | ✅ | ✅ | ❌ | ✅ | — | LS+IDB | MEDIO (D-006) |
| F-078 | generarPDR | ✅ | ✅ | ✅ (6+5) | ⚠️ | — | M | BAJO |
| F-079 | fingerprint v2 | ✅ | ✅ | ✅ (6+…) | ✅ | — | — | BAJO |
| F-080 | Upsert versionado | ✅ | ✅ | ✅ | ✅ | — | IDB | BAJO |
| F-081 | Cargar históricos | ✅ | ✅ | ⚠️ | ✅ | — | IDB | BAJO |
| F-082 | previousVersions | ✅ | ✅ | ✅ | ✅ | ⚠️ | IDB | BAJO |
| F-083 | recomputarPersonaDia | ✅ | ✅ | ⚠️ | ✅ | — | IDB | BAJO |
| F-084 | Panel Patrones | ✅ | ✅ | ✅ (capa) | ✅ | ✅ | M | BAJO |
| F-085 | Filtros globales | ✅ | ✅ | ✅ (8) | ✅ | ✅ | — | BAJO |
| F-086 | Config estadística | ✅ | ✅ | ✅ (5) | ⚠️ | ✅ | LS | BAJO |
| F-087 | Resumen | ✅ | ✅ | ✅ kpis | ✅ | ✅ | — | BAJO |
| F-088 | Personas | ✅ | ✅ | ✅ (14) | ✅ | ✅ | — | BAJO |
| F-089 | Perfil persona | ✅ | ✅ | ✅ (2) | ✅ | ✅ | — | BAJO |
| F-090 | Tareas | ✅ | ✅ | ✅ (11+5) | ✅ | ✅ | — | BAJO |
| F-091 | Actividades | ✅ | ✅ | ✅ (8) | ✅ | ✅ | — | BAJO |
| F-092 | Errores/confusión | ✅ | ✅ | ✅ (10) | ✅ | ✅ | — | BAJO |
| F-093 | Evolución | ✅ | ✅ | ✅ (9+3) | ✅ | ✅ | — | BAJO |
| F-094 | Comparación A/B | ✅ | ✅ | ✅ (4+4) | ✅ | ✅ | — | BAJO |
| F-095 | Pareto | ✅ | ✅ | ✅ (5) | ✅ | ✅ | — | BAJO |
| F-096 | Calidad datos | ✅ | ✅ | ✅ (9) | ⚠️ | ✅ | — | BAJO |
| F-097 | Alertas | ✅ | ✅ | ✅ (17) | ✅ | ✅ | — | BAJO |
| F-098 | Prioridad/TOP5 | ✅ | ✅ | ✅ (5) | ✅ | ✅ | — | BAJO |
| F-099 | Export analytics | ✅ | ⚠️ | ❌ | ⚠️ | ✅ | — | MEDIO |
| F-100 | Resultados | ✅ | ✅ | ❌ | ✅ | ✅ | M | BAJO |
| F-101 | Visor tablas | ✅ | ✅ | ❌ (D-010 UI) | ✅ perf | ✅ | — | MEDIO |
| F-102 | charts.js | ✅ | ⚠️ | ❌ (D-010) | ⚠️ svg | ✅ | — | MEDIO |
| F-103 | KPI drilldown | ✅ | ⚠️ | ❌ | ❌ | ✅ | — | MEDIO |
| F-104 | Panel reporte | ✅ | ✅ | ✅ equiv | ✅ | ✅ | M | BAJO |
| F-105 | Trazabilidad | ✅ | ✅ | ❌ | ❌ | ✅ | — | MEDIO |
| F-106 | Búsqueda global | ✅ | ⚠️ | ❌ | ❌ | ✅ | — | BAJO |
| F-107 | exportToXlsx | ✅ | ✅ | ❌ existence-only (D-011) | — | ✅ | — | MEDIO |
| F-108 | exportToCsv | ✅ | ✅ | ✅ (17) | — | ✅ | — | BAJO |
| F-109 | Exports específicos | ✅ | ⚠️ | ❌ | ⚠️ | ✅ | — | MEDIO |
| F-110..F-116 | UI global | ✅ | ⚠️ | ⚠️ | ✅ a11y/parcial | ✅ | LS | BAJO |
| F-117 | CSP | ✅ | ✅ | ⚠️ | ✅ | — | — | BAJO |
| F-118 | escapeHtml/Attr | ✅ | ✅ | ✅ (24) | ✅ | — | — | BAJO |
| F-119 | Service Worker | ✅ | ✅ | ❌ | ✅ (4) | — | S | BAJO |
| F-120 | Manifest | ✅ | ⚠️ (D-001) | ❌ | ✅ | — | — | BAJO |
| F-121 | Offline | ✅ | ✅ | ❌ | ✅ | — | S | BAJO |
| F-122 | Standalone | ✅ | ✅ | ❌ | ✅ (1 denso) | ✅ | LS+IDB | MEDIO |

**Conclusión de cobertura:** el **motor, turnos, reparto, overrides, histórico/fingerprint, analytics y auditoría** están FUERTEMENTE cubiertos (unit + E2E + equivalencia). Los **huecos reales** son: render UI puro (ui.js sin unit — solo E2E), `charts.js` y `exportToXlsx` (sin tests de comportamiento), worker (sin unit), a11y limitada a 3 pantallas, y exports específicos sin verificación de contenido.
---

## 19. DISCREPANCIAS ENCONTRADAS (FASE 27)

> Registro sin corrección (orden: sin resolver nada, solo documentar). Formato: código · documentación vs código vs tests vs conclusión vs qué debería hacerse · clasificación.

### D-001 · Nombre del manifest dice v6.2 con versión 6.3.0
- **Documentación:** LEEME/CHANGELOG afirman versionado coherente 6.3.0. **Código:** `manifest.json` → `"name": "SPEC Web v6.2 — ID Logistics"`, `"version": "6.3.0"`. **Tests:** `pwa.spec.js` t1 **afirma** `name = "SPEC Web v6.2"` (el test consagra la discrepancia). **Conclusión:** incoherencia cosmética del nombre visible al instalar la PWA. **Qué hacer:** actualizar name a v6.3 (y el test). **Clasificación: DOCUMENTACIÓN INCORRECTA (manifest) + TEST INCORRECTO (afirma el valor erróneo).**

### D-002 · Bloque "Detalle Vitest por archivo" de TEST_RESULTS_FINAL.md desactualizado
- **Doc:** muestra una salida de una ejecución anterior (33 archivos/502 tests, sin v63_correcciones, analytics_core 33 vs 34 real). **Código:** 34 archivos reales (32 unit + 2 integration), 523 tests. **Tests:** los totales certificados (523/34) SÍ cuadran. **Conclusión:** el detalle por archivo no fue regenerado al añadir v63_correcciones.test.js. **Qué hacer:** regenerar el bloque. **Clasificación: DOCUMENTACIÓN INCORRECTA (parcial/stale).**

### D-003 · beforeunload prácticamente inoperante
- **Código (ui.js:2921-2931):** avisa solo si `decisions` no vacío **Y** `spec_decisions` NO existe. Como `persistDecisions` escribe `spec_decisions` en cada decisión, la condición casi nunca es verdadera. **Doc:** no documentado. **Tests:** ninguno. **Conclusión:** la protección de pérdida de datos al cerrar es inefectiva por diseño. **Qué hacer:** comparar dirty-state en memoria vs persistido, o eliminar el guard. **Clasificación: COMPORTAMIENTO AMBIGUO / CÓDIGO INEFECTIVO.**

### D-004 · Crecimiento ilimitado de IndexedDB (sin delete/clear en ninguna ruta)
- **Código:** 0 llamadas a `.delete()`/`.clear()` en stores (verificado por grep); `spec_history_db.person_daily_records` crece con versiones; `mappings` acumula versiones; `spec_decisions_db.decisions` acumula sessionIds. Mitigaciones existentes: cap 10 en previousVersions, upsert por key. **Doc:** riesgo de cuota mencionado SOLO para spec_state (ui.js:2634), no para IDB. **Tests:** ninguno de límites. **Conclusión:** en uso multi-mes puede agotar cuota del navegador (varios cientos de MB). **Qué hacer:** política de purga/compactación (p.ej. mantener N sessionIds, compactar versiones). **Clasificación: FUNCIONALIDAD PARCIAL (gestión del ciclo de vida ausente) / RIESGO ACEPTADO NO DOCUMENTADO.**

### D-005 · `spec_state` persiste queries completas en localStorage
- **Código:** persistState guarda queries+reporte serializados (con revivido `{__date}`); comentario propio reconoce riesgo de cuota 5-10 MB. **Tests:** ninguno de cuota. **Conclusión:** con datasets grandes puede fallar silenciosamente (try/catch devuelve false) — aceptable pero sin aviso al usuario. **Clasificación: COMPORTAMIENTO AMBIGUO (documentado en código, no en manual).**

### D-006 · La restauración desde IndexedDB no re-verifica la cadena de auditoría
- **Código:** `restoreDecisions` verifica la cadena SOLO en la rama de localStorage (ui.js:5012); la rama IDB (idbRestoreDecisions) no lo hace. **Tests:** indexeddb.spec t1 verifica cadena en AMBAS restauraciones (pasa porque los datos están íntegros), pero no existe test de IDB con cadena manipulada. **Qué hacer:** unificar verificación. **Clasificación: TEST INSUFICIENTE + INCONSISTENCIA DE CÓDIGO.**

### D-007 · Mensaje SKIP_WAITING del SW sin emisor
- **Código:** sw.js:105-107 escucha 'SKIP_WAITING' → skipWaiting; grep 0 resultados: nadie hace postMessage. **Conclusión:** código muerto por ahora (la actualización depende del cambio de CACHE_NAME + reload). **Clasificación: FUNCIONALIDAD HUÉRFANA (ver F-30).**

### D-008 · Tests `.serial` con dependencia de orden interno
- **Tests:** patrones_v62.spec.js y v63_correcciones.spec.js son `.serial` (14 y 7 tests encadenados sobre el MISMO contexto de página/histórico). Un fallo intermedio enmascara los siguientes; no pueden ejecutarse aislados individualmente. **Conclusión:** fragilidad de suite aceptada por diseño (escenarios acumulativos). **Clasificación: TEST INSUFICIENTE (aislamiento).**

### D-009 · Cobertura a11y limitada a 3 pantallas
- **Tests:** axe-core solo escanea Carga/Resultados/Revisar (+dark/teclado). Mapping, Patrones (8 vistas), Reporte, Evolución, Trazabilidad, Auditoría, Exportar sin escaneo. **Doc:** ACCESSIBILITY_REPORT lo documenta. **Clasificación: TEST INSUFICIENTE (documentado).**

### D-010 · `charts.js` sin tests unitarios; cobertura vitest 0 % para ui.js render
- **Código:** charts.js solo se instrumenta vía cover_integration (con stub DOM). **Tests:** E2E solo comprueba existencia de `<svg>`. **Clasificación: TEST INSUFICIENTE (documentado en COVERAGE_REPORT como limitación de new Function).**

### D-011 · `exportToXlsx` sin test de comportamiento
- **Tests:** smoke.test.js hace `typeof` únicamente. No se verifican fechas dd/mm/yyyy, orden de columnas, ni hoja vacía. **Clasificación: TEST INSUFICIENTE.**

### D-012 · worker.js sin tests unitarios
- **Tests:** solo E2E por ausencia de warnings de consola (multifile_worker). No hay test del formato de mensaje, del error → fallback, ni del transfer. **Clasificación: TEST INSUFICIENTE (documentado en TEST_RESULTS).**

### D-013 · Conteo "214 propuestas" usado como valor de regresión global
- **Tests:** smoke t3, performance t1, standalone afirman exactamente 214 propuestas con los fixtures drive. Es un **assert de dato concreto** (correcto pero frágil si cambian fixtures). **Clasificación: COMPORTAMIENTO AMBIGUO (fragilidad aceptada).**

### D-014 · `smoke.test.js` es existence-only por diseño
- **Tests:** 3 tests de `typeof` (XLSX, SPEC, superficie de API). El propio archivo lo advierte. **Clasificación: TEST INSUFICIENTE (aceptado y documentado).**

### D-015 · indexeddb.spec t2 también existence-only
- **Tests:** el segundo test solo comprueba `typeof indexedDB !== 'undefined'` en Chromium. **Clasificación: TEST INSUFICIENTE (trivial).**

### D-016 · Test data sintética sin uso automatizado
- **Código:** `test-data/synthetic/` (4 archivos) no lo usa ningún test (lo genera scripts/08 para anonimización/documentación R-18). **Clasificación: FUNCIONALIDAD AUXILIAR (no es defecto; evitar confusión en auditoría).**

### D-017 · Divergencias documentadas de las funciones puras (constatadas, no corregir)
- `numberFrom("12.34")→1234`, `numberFrom("1,234.56")→1.23456`; `fx_Fecha("12345")→año 12345`; `calcularMaterialidad(NaN)→CRITICA`; `escapeAttr` no filtra `javascript:`. Todas con test que documenta la divergencia intencional (semántica es-ES del VBA original / no-sanitizador de URL). **Clasificación: COMPORTAMIENTO AMBIGUO (documentado en tests).**

### D-018 · Claims de cabecera "20 consultas Power Query"
- **Doc:** app.js:6 y README dicen "reproduce las 20 consultas". **Código:** 17 funciones q* (la numeración salta 04/06/11: consultas intermedias del M absorbidas en las demás; TRAZABILIDAD.md documenta el mapeo). **Tests:** equivalencia sobre las 14 tablas de salida + REPORTE. **Conclusión:** claim de alto nivel correcto (no hay consulta de salida faltante) pero literalmente impreciso. **Clasificación: DOCUMENTACIÓN INCORRECTA (menor).**

### D-019 · Same-origin collision standalone vs modular
- **Código:** standalone usa las MISMAS claves LS (`spec_*`) y BDs (`spec_history_db`, `spec_decisions_db`) que index.html. Si se sirven en el mismo origen, compiten por el mismo estado. **Doc:** riesgo registrado (R-21a) pero sin aviso en UI. **Clasificación: RIESGO ACEPTADO (documentado parcialmente).**

### D-020 · `apps without UI` scripts Python con rutas relativas
- **Código:** scripts 01-04/06/08 son herramientas de extracción/generación del proyecto original (no runtime); Task 2 los hizo portables. **Clasificación: FUNCIONALIDAD AUXILIAR (sin discrepancia — nota de alcance para el auditor).**

### D-021 · `docs/README.md` duplica README raíz con contenido divergente
- **Código:** existe README.md (raíz, 96 líneas) y docs/README.md (211 líneas, rol "documentación de auditoría del port"). **Doc:** títulos similares pueden confundir. **Clasificación: DOCUMENTACIÓN AMBIGUA (menor).**

---

## 20. FUNCIONALIDADES NO DOCUMENTADAS (FASE 28)

Existen en el código pero NO aparecen (o aparecen poco) en README/CHANGELOG/MANUAL_USUARIO:

| F | Funcionalidad | Dónde | Estado doc |
|---|---|---|---|
| F-060 | Sincronización decisiones → histórico | ui.js:4276 | solo implícita en HISTORICAL_ANALYTICS_MODEL |
| F-103 | KPI drilldown | ui.js:2130-2304 | no documentado en manual |
| F-105 | Panel Trazabilidad (árbol de orígenes) | ui.js:1095 | existe docs/TRAZABILIDAD.md (del port) pero el manual de usuario no lo cubre |
| F-106 | Búsqueda global entre tablas | ui.js:1516 | manual no lo detalla |
| F-083 | recomputarPersonaDia tras overrides | ui.js:4246 | TIME_ALLOCATION lo menciona indirectamente |
| F-099 | Exportación de 7 vistas de Patrones | ui.js:6067 | CHANGELOG v6.2 lo nombra de pasada; manual sin detalle |
| F-086 | Config estadística persistida | analyticsCore | sí documentada en diccionario §Umbrales pero no en MANUAL_USUARIO |
| — | `window.SPEC` API de depuración completa (todas las consultas y fx_* expuestas) | app.js:2855 | README lo menciona genéricamente; sin inventario |
| — | Badge v6.3 en header + shortcuts del manifest (3) | index.html/manifest.json | no documentados |
| — | Vaciado del audit log con confirmación | ui.js:2873 | manual no lo detalla |
| — | Aviso ⚠ de registros SIN HORA al filtrar turnos | renderReviewList | CHANGELOG v6.1.1 sí lo documenta (excepción) |

## 21. DOCUMENTACIÓN SIN IMPLEMENTACIÓN / DECLARADO PERO NO VERIFICADO (FASE 29)

Afirmaciones de docs que NO se pudieron demostrar en código/tests (tratar como NO VERIFICADO en auditoría):

| Afirmación | Fuente | Estado |
|---|---|---|
| "Cobertura automática de código" | README/package script `test:coverage` | **La vía vitest-istanbul da 0 %** (limitación new Function documentada en COVERAGE_REPORT; la real es `test:coverage:real`). No afirmar cobertura % sin ejecutar cover_integration. |
| "CI workflow ejecutable" | .github/ci.yml | Existe y fue corregido en Task 2 (YAML válido), pero **no hay evidencia de ejecución** en este entorno. NO VERIFICADO. |
| "PWA actualizable sin intervención" | — (implícito) | NO hay mecanismo completo: SKIP_WAITING huérfano (D-007); la actualización depende de que el usuario recargue y el activate borre cachés. NO VERIFICADO como flujo. |
| "Restauración desde IndexedDB audita la cadena" | — | NO implementado (D-006). |
| Cualquier cifra de docs históricos previos a v6.3 (206/219/250/339 tests…) | reports/FINAL_*.md (v6.0) | **Marcar como históricos** (así etiquetados en Task 2); NO usar como estado actual. |
| "Equivalencia 74.672 celdas" | reports/FINAL_EQUIVALENCE | VERIFICADO con ejecución real (07_test_equivalencia_valores.cjs) — sí válido. |

## 22. FUNCIONALIDADES HUÉRFANAS / CÓDIGO MUERTO (FASE 30)

| Elemento | Evidencia | Clasificación |
|---|---|---|
| Listener `SKIP_WAITING` en sw.js | 0 emisores | código muerto (D-007) |
| `test-data/synthetic/` | 0 consumidores en tests | dato auxiliar (D-016) |
| `analyticsCore.safeRate` | alias de safeDiv; usado mínimamente | conservado por claridad semántica (no defecto) |
| `dimensionesDisponibles().clientes` | los filtros de cliente son input libre (subcadena); la dimensión se calcula pero el select de cliente no es datalist | dato calculado con consumo parcial (no defecto; oportunidad de UI) |
| Funciones expuestas en `SPEC` no usadas por la UI (`fx_Transforma*`, `q03`…) | usadas por tests/consola de depuración | API de depuración deliberada |
| `cover_integration.cjs` + `coverage_hook` | usados solo por script específico | herramienta de build (no runtime) |
| **Antiguo código muerto de ui.js (5 duplicados + barra bulk)** | **ELIMINADO en v6.3** (−570 líneas: renderReviewPanel/ renderReviewList/ selectIncident/ navigateIncident/ renderPatronesPanel sobrescritos + persistDecisions/ registrarDecision/ restoreDecisions/ undoDecision/ undoLastAction duplicados + bulkAction huérfana) | resuelto — verificar que NO reaparezcan |

**Verificación de orfandad realizada para este documento:** grep de emisores/listeners por cada elemento listado; para funciones de ui.js/app.js, búsqueda de call-sites en index.html + scripts + tests. Los 9 módulos analytics tienen TODOS consumidores (patronesSnapshot). `charts.js` tiene consumidor (panel Resultados).
---

## 23. RIESGOS (REGISTRO CONSOLIDADO)

| ID | Riesgo | Prob. | Impacto | Mitigación existente | Referencia |
|---|---|---|---|---|---|
| R-A | Cuota de IndexedDB agotada por crecimiento ilimitado (records/mappings/sessionIds) | MEDIA en uso prolongado | histórico deja de persistir (fail silencioso con console.warn) | cap previousVersions; upsert por key | D-004 |
| R-B | Cuota localStorage por `spec_state` con datasets grandes | BAJA-MEDIA | no se restaura la última sesión | try/catch; indicador | D-005 |
| R-C | SheetJS 0.18.5 (Prototype Pollution + ReDoS, conocidas) | BAJA (offline + validación) | crítico si explota | límite 50 MB, validación estructura, sin red | AUD-MED-005, riesgo ACEPTADO |
| R-D | Standalone y modular comparten origen → colisión de estado | BAJA | corrupción/confusión de histórico | documentado | D-019 |
| R-E | Restauración IDB sin verificación de cadena | BAJA | se cargaría cadena manipulada sin aviso | tests existentes asumen íntegros | D-006 |
| R-F | beforeunload inefectivo (pérdida percibida de decisiones no persistidas) | BAJA | usuario cree perder datos | persistencia inmediata reduce ventana | D-003 |
| R-G | `.serial` E2E: fallo enmascarado en cadena | MEDIA | diagnóstico difícil | — | D-008 |
| R-H | A11y no cubierta en 7 pantallas | MEDIA | regresión a11y invisible hasta que se audite | 5 tests base + v63 V5 | D-009 |
| R-I | exportToXlsx sin tests → regresión silenciosa de exports | MEDIA | export corrupto sin aviso | CSV sí testado | D-011 |
| R-J | Datos reales sensibles en fixtures (logins reales en audit-ref/drive) | — | privacidad | PRIVACY_TEST_DATA.md + synthetic | R-18 doc |
| R-K | Serial Excel day-level vs fichaje 00:00:00 indistinguible | BAJA | un registro extreme se clasifica SIN HORA | documentado | F-040 |
| R-L | `numberFrom` en-US malinterpreta "1,234.56" | BAJA (fuentes es-ES) | valor ×1000 | documentado en tests | D-017 |
| R-M | Cuota/memoria con 50k+ filas × varios archivos | BAJA | lentitud | perf tests (<30 s) | performance |
| R-N | Pérdida de claves LS al cambiar de origen/dominio del despliegue | MEDIA | mapping/histórico "desaparece" | es inherente al navegador; documentar en manual | — |

## 24. FUNCIONALIDADES CRÍTICAS (FASE 31)

**CRÍTICAS (resultados incorrectos o pérdida de información si fallan):** F-004, F-006/7/8, F-009, F-017, F-019…F-032 (todas las Q01–Q16 + REPORTE), F-034…F-036 (fx puras), F-038/F-039 (turnos/fecha operativa), F-041, F-043, F-045, F-046, F-048, F-051, F-052/53/54 (decisiones), F-056 (undo correcto), F-066, F-070, F-071, F-072/073/074 (auditoría), F-076, F-078, F-079, F-080, F-083, F-118 (escape XSS).

**ALTAS:** F-002, F-003, F-005, F-010, F-012, F-014, F-018, F-021, F-024/25, F-029, F-031, F-037, F-040, F-042, F-047, F-049, F-060, F-061, F-063, F-067, F-068, F-069, F-077, F-081, F-082, F-084…F-098 (capa analítica completa), F-100, F-101, F-104, F-107, F-108, F-112, F-117.

**MEDIAS:** F-001 (hay validaciones aguas abajo), F-011, F-013, F-015, F-016, F-026/27/28, F-050, F-055, F-057, F-059, F-064, F-075, F-099, F-102, F-103, F-105, F-109, F-110, F-113, F-114, F-119, F-121, F-122.

**BAJAS:** F-058, F-062, F-065, F-106, F-111, F-115, F-116, F-120.

**Principio de regresión:** cualquier cambio que toque una CRÍTICA exige re-ejecutar `npm test` + equivalencia + los E2E de su área ANTES de aceptarse. Las 36 funcionalidades de la capa analítica (F-084…F-098) son ALTAS en conjunto pero individualmente toleran fallo (hay workaround visual); su protección real son los 136 tests unitarios de analytics.

---

## 25. ESPECIFICACIÓN MAESTRA PARA AUDITORÍA (FASE 32)

### 25.1 Protocolo de auditoría (cómo usar este documento)

Para auditar una funcionalidad **F-XXX**:
1. Leer su ficha (§4) → identificar ubicación (archivo:línea) y verificadores.
2. Ejecutar el **test de humo global** (§25.2).
3. Ejecutar los **tests existentes** listados en la ficha; confirmar que PASAN y que cubren el comportamiento afirmado (no solo su existencia).
4. Ejecutar los **TC-*** correspondientes (§17), incluidos los marcados [NUEVO].
5. Contrastar **comportamiento esperado** vs observado; registrar cualquier desviación como hallazgo con evidencia (captura/log).
6. No dar por buena una afirmación solo porque exista un test nominal ni porque un .md lo diga (reglas de calidad).

### 25.2 Batería de humo (pre-auditoría, ~15 min)

```bash
cd SPEC_WEB_V6_FINAL && npm ci
npm run lint                      # 0 errors (30 warnings conocidos)
npx vitest run                    # 523/523 (34 archivos)
node scripts/validate_manifest.cjs    # PASS 157
node scripts/validate_release.cjs     # PASS 78/78
node scripts/07_test_equivalencia_valores.cjs   # 14/14, 0 mismatches, 74672 celdas
npx playwright test               # 63/63 (12 suites, ~5 min)
```

### 25.3 Checklist de auditoría por área (qué debe encontrar el auditor)

| Área | Debe encontrar | Trampas a evitar |
|---|---|---|
| Carga | dropzone única, detección automática, validaciones con mensajes claros | no confundir warning MIME con rechazo |
| Worker | análisis sin congelar UI, 0 warnings de fallback, progreso 0-100 | ausencia de warnings ≠ test del worker |
| Q01-Q16+REPORTE | 214 propuestas/743 filas/167 mapeos con fixtures drive; igualdad célula a célula | NO aceptar recuentos "parecidos"; la tolerancia es ±2 SOLO en recuentos, 0 en valores |
| Turnos | límites exactos 06:00/14:00/22:00, NOCHE cruza a fecha anterior, day-level SIN HORA sin desplazar | un registro SIN HORA nunca aparece en turno concreto |
| Reparto | conservación <1e-9, Fuente por tarea, OTRA fuera, actividad "varias" | el REPORTE (Q) no cambia al meter overrides; solo q17/histórico |
| Revisar | 1 tarjeta por persona/día, acciones con undo real (última entrada), auditLog creciente | undo restaura el estado PREVIO, no el inicial |
| Mapping | versiones SHA-256 acumuladas, auto-carga, diálogo old-vs-new, CRUD auditado | cambiar mapping NO reescribe históricos |
| Overrides | prioridad override>actividad>default; cambiar override → nueva VERSIÓN | comprobar previousVersions conserva núcleo |
| Histórico | casos A-E de §9.5 exactos; cap 10; fingerprint v2 sensible a config | fingerprint IGUAL solo con datos+config iguales |
| Patrones | 8 vistas; tasas acotadas + ratios etiquetados; MM sin ventana incompleta; rolling sin ceros; A/B con rangos visibles; alertas con umbrales de config | % jamás >100 en tasas de oportunidad; un día sin datos NO es 0 |
| Auditoría | cadena SHA-256 verificable; 6 escenarios de manipulación detectados | contexto inseguro → INSECURE_CONTEXT (no crash) |
| Export | CSV con BOM/;/anti-inyección; XLSX con fechas dd/mm/yyyy | exportToXlsx sin tests: auditar manualmente |
| PWA | offline real; caché spec-web-v6-3 con 19 assets | manifest.name dice v6.2 (D-001) — no confundir con versión 6.3.0 |
| A11y | skip-link, tablist con flechas, Escape cierra detalle, contraste AA | solo 3 pantallas escaneadas por tests |

### 25.4 Criterios de aceptación de la auditoría global

- **CONFORME:** batería de humo 100 % verde + 0 desviaciones de comportamiento en las fichas CRÍTICAS/ALTAS + discrepancias D-001…D-021 registradas sin agravio.
- **CONFORME CON OBSERVACIONES:** hallazgos solo en MEDIAS/BAJAS o en huecos de test ya listados (D-009…D-012).
- **NO CONFORME:** cualquier fallo de equivalencia, cualquier pérdida/reescritura de histórico versiones previas, cualquier tasa >100 % en métricas de oportunidad, cualquier rotura de la cadena de auditoría no detectada por `verificarAuditLogChain`.

### 25.5 Mapa rápido F → verificación mínima

**Cada ficha F-XXX de §4 ya contiene: ubicación exacta, comportamiento esperado, tests existentes y tests que faltan.** El auditor debe poder responder para CUALQUIER F: qué tiene que encontrar / qué entrada usar / qué salida esperar / qué fórmula comprobar / qué estado ver / qué persistencia inspeccionar / qué error provocar / qué test ejecutar / qué caso límite probar.

- Fuentes de datos para pruebas: `audit-ref/drive/` (4 reales) · `test-data/turnos/` (límites + overrides) · `test-data/patrones/` (7 días, rachas, confusión, OTRA, noche, SIN HORA).
- Consola del navegador: `window.SPEC` (motor completo), `window.SPEC_AN` (analytics), `window.SPEC_CHARTS`, `SPEC.STATE` (estado en vivo), IndexedDB → `spec_history_db` / `spec_decisions_db`, localStorage → 8 claves `spec_*`.

---

*Fin de la Especificación Maestra. Elaborada mediante lectura directa del código de v6.3.0 (sin modificarlo), ejecución de análisis estático de fuentes/tests/docs, y contraste con la documentación de entrega. Cualquier afirmación sin marca [C]/[T]/[E] debe tratarse como [I] o [N] según las reglas de calidad.*
